package ma.mge.facturesimple

import android.content.ContentValues
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Item(val name: String, val qty: Double, val price: Double) {
    fun total(): Double = qty * price
}

class MainActivity : AppCompatActivity() {
    private lateinit var invoiceNo: EditText
    private lateinit var customer: EditText
    private lateinit var itemsBox: LinearLayout
    private lateinit var totalView: TextView

    private val prefs by lazy { getSharedPreferences("invoices", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        invoiceNo.setText(nextInvoiceNumber().toString())
        addItemRow()
        updateTotal()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        root.addView(TextView(this).apply {
            text = "فاتورة بسيطة"
            textSize = 25f
            gravity = Gravity.CENTER
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 8, 0, 18)
        }, lp())

        invoiceNo = field("رقم الفاتورة")
        customer = field("اسم الزبون (اختياري)")
        root.addView(invoiceNo, lp())
        root.addView(customer, lp())

        root.addView(TextView(this).apply {
            text = "التاريخ: ${today()}"
            textSize = 16f
            setPadding(4, 4, 4, 12)
        }, lp())

        root.addView(TextView(this).apply {
            text = "المنتجات"
            textSize = 19f
            setTypeface(null, Typeface.BOLD)
        }, lp())

        val scroll = ScrollView(this)
        itemsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 4, 0, 4)
        }
        scroll.addView(itemsBox)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(Button(this).apply {
            text = "＋ إضافة منتج"
            setOnClickListener { addItemRow() }
        }, lp())

        totalView = TextView(this).apply {
            textSize = 22f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 12)
        }
        root.addView(totalView, lp())

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        buttons.addView(Button(this).apply {
            text = "حفظ"
            setOnClickListener { saveInvoice() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(Button(this).apply {
            text = "PDF"
            setOnClickListener { createPdfAndShare() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(Button(this).apply {
            text = "فاتورة جديدة"
            setOnClickListener { resetInvoice() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(buttons)

        setContentView(root)
    }

    private fun addItemRow() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 6, 0, 6)
        }

        val name = field("البيان / اسم المنتج")
        val qty = field("الكمية").apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        val price = field("الثمن DH").apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }

        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { updateTotal() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        }
        qty.addTextChangedListener(watcher)
        price.addTextChangedListener(watcher)

        row.addView(name, lp())
        val numbers = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        numbers.addView(qty, LinearLayout.LayoutParams(0, -2, 1f))
        numbers.addView(price, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(numbers)
        row.addView(Button(this).apply {
            text = "حذف هذا المنتج"
            setOnClickListener {
                itemsBox.removeView(row)
                updateTotal()
            }
        }, lp())

        itemsBox.addView(row)
    }

    private fun readItems(): List<Item> {
        val result = mutableListOf<Item>()
        for (i in 0 until itemsBox.childCount) {
            val row = itemsBox.getChildAt(i) as? LinearLayout ?: continue
            if (row.childCount < 2) continue
            val name = (row.getChildAt(0) as EditText).text.toString().trim()
            val numbers = row.getChildAt(1) as? LinearLayout ?: continue
            val qty = (numbers.getChildAt(0) as EditText).text.toString().toDoubleOrNull() ?: 0.0
            val price = (numbers.getChildAt(1) as EditText).text.toString().toDoubleOrNull() ?: 0.0
            if (name.isNotEmpty()) result.add(Item(name, qty, price))
        }
        return result
    }

    private fun updateTotal() {
        val total = readItems().sumOf { it.total() }
        totalView.text = String.format(Locale.US, "TOTAL : %.2f DH", total)
    }

    private fun saveInvoice() {
        val no = invoiceNo.text.toString().trim()
        val obj = JSONObject().apply {
            put("number", no)
            put("date", today())
            put("customer", customer.text.toString())
            put("items", JSONArray().apply {
                readItems().forEach {
                    put(JSONObject().apply {
                        put("name", it.name)
                        put("qty", it.qty)
                        put("price", it.price)
                    })
                }
            })
        }
        prefs.edit().putString("invoice_$no", obj.toString()).apply()
        Toast.makeText(this, "تم حفظ الفاتورة رقم $no", Toast.LENGTH_SHORT).show()
    }

    private fun createPdfAndShare() {
        val no = invoiceNo.text.toString().trim()
        val data = readItems()
        if (data.isEmpty()) {
            Toast.makeText(this, "أضف منتجًا واحدًا على الأقل", Toast.LENGTH_SHORT).show()
            return
        }

        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val canvas = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 16f
        }
        val bold = Paint(paint).apply { typeface = Typeface.DEFAULT_BOLD }

        canvas.drawText("FACTURE / فاتورة", 220f, 45f, bold)
        canvas.drawText("N° : $no", 45f, 80f, paint)
        canvas.drawText("Date : ${today()}", 45f, 105f, paint)
        val cust = customer.text.toString().trim()
        if (cust.isNotEmpty()) canvas.drawText("Client : $cust", 45f, 130f, paint)

        var y = 175f
        canvas.drawText("Produit / البيان", 45f, y, bold)
        canvas.drawText("Qté", 360f, y, bold)
        canvas.drawText("Prix", 420f, y, bold)
        canvas.drawText("Total", 500f, y, bold)
        canvas.drawLine(40f, y + 10f, 555f, y + 10f, paint)
        y += 38f

        var grand = 0.0
        data.forEach {
            val t = it.total()
            grand += t
            canvas.drawText(it.name.take(34), 45f, y, paint)
            canvas.drawText(fmt(it.qty), 360f, y, paint)
            canvas.drawText(fmt(it.price), 420f, y, paint)
            canvas.drawText(fmt(t), 500f, y, paint)
            y += 28f
        }

        canvas.drawLine(40f, y, 555f, y, paint)
        y += 35f
        canvas.drawText("TOTAL : ${fmt(grand)} DH", 370f, y, bold)
        y += 55f
        canvas.drawText("Merci pour votre confiance", 200f, y, paint)

        doc.finishPage(page)

        val filename = "Facture_$no.pdf"
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, filename)
            put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            doc.close()
            Toast.makeText(this, "تعذر إنشاء ملف PDF", Toast.LENGTH_SHORT).show()
            return
        }

        contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) }
        doc.close()

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "مشاركة الفاتورة"))
    }

    private fun resetInvoice() {
        itemsBox.removeAllViews()
        customer.setText("")
        invoiceNo.setText(nextInvoiceNumber().toString())
        addItemRow()
        updateTotal()
    }

    private fun nextInvoiceNumber(): Int {
        val next = prefs.getInt("last_number", 0) + 1
        prefs.edit().putInt("last_number", next).apply()
        return next
    }

    private fun field(hint: String) = EditText(this).apply {
        this.hint = hint
        textSize = 16f
        setPadding(14, 10, 14, 10)
        background = AppCompatResources.getDrawable(this@MainActivity, android.R.drawable.edit_text)
    }

    private fun lp() = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 6 }

    private fun today() = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())

    private fun fmt(value: Double) = String.format(Locale.US, "%.2f", value)
}
