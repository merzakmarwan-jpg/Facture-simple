# 3.9.7.20 — Store Revenue / Bank Received / WhatsApp PDF

## Changes
1. Store revenue now defaults to **all periods** so imported and older invoices remain visible.
2. The Store revenue page always lists invoices, including invoices without a Store account in a visible fallback group.
3. Added filters for **shipping company**, **Store account**, and **bank settlement status**.
4. Importing a matched Virement automatically marks the matched invoice as **bank received** and stores the Virement date as the bank-received date.
5. Store invoice details show customer name, phone, city, tracking number, shipping company, Store, Virement and settlement status.
6. Only invoices marked as bank received can be selected for the settlement PDF.
7. Added a professional multi-page PDF report containing the selected invoices, customer information, tracking number, shipping cost, CRBT, net amount, Virement reference and totals.
8. The generated PDF is saved under `Downloads/FactureSimple` and is opened directly in WhatsApp when WhatsApp is installed; otherwise Android's share chooser is displayed.
