# MGE 3.9.7.52.1 — Per-Invoice Sync Status

- Adds a sync status panel to every invoice card.
- Green dot: the invoice is marked clean in local sync metadata after cloud synchronization.
- Red dot: the invoice is not synchronized or has a pending local change.
- Unsynchronized invoices show a manual “مزامنة هذه الفاتورة” button.
- The button calls `CloudManager.pushInvoiceNow(invoiceId, ...)` and refreshes the invoice list after success.
- Remote invoice application marks the invoice clean only after its item subcollection is successfully imported.
- Base project remains MGE 3.9.7.52; Android versionName is 3.9.7.52.1 and versionCode is 115.
