# MGE 3.9.7.29 — Partner Settlement Build Fix

Fixes the Android Java compilation error in `MainActivity.java` caused by passing the `long` return value of `createPartnerSettlement()` to `makePartnerSettlementPdf()`, which expects an `int` settlement ID.

The settlement IDs are already represented as `int` throughout the partner-settlement model and query methods. The call site now explicitly converts the database insert ID to `int` before passing it to the PDF generator.

No partner-settlement business logic was changed in this build-fix update.
