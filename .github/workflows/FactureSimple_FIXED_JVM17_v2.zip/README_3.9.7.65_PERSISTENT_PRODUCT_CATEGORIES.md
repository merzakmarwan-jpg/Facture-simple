# MGE 3.9.7.65 — Persistent Product Categories

Based on MGE 3.9.7.64 PRODUCT_CATEGORIES_INVOICE_GRID.

Changes:
- Added a dedicated local `product_categories` table.
- Categories are stored once and can be reused by many products.
- Existing product categories are migrated/backfilled into the category table.
- Product add/edit now uses a category picker instead of free-text entry.
- Picker includes `عام / بدون فئة` and `＋ إضافة فئة جديدة`.
- New categories can be created once and immediately selected for the current product.
- Product category chips and invoice product browser read from the persistent category list.
- Existing product category values continue to synchronize through product documents.
- Existing invoice/product/image/sync functionality is preserved.
