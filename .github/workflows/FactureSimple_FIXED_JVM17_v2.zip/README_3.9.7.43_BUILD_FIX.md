# MGE 3.9.7.43 — Invoice clipboard build fix

- Fixed the GitHub Actions Java compilation error caused by the ambiguous `ClipboardManager` reference.
- The invoice customer-data copy feature now explicitly uses `android.content.ClipboardManager`.
- Kept the customer data copied as: name, phone, address, city, tracking number.
- Kept the previously added `بسم الله الرحمن الرحيم` header in invoice PDFs and product-photo PDFs.
- VersionCode: 105
- VersionName: 3.9.7.43
