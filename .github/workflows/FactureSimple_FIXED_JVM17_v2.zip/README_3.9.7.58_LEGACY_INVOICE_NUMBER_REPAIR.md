# MGE 3.9.7.58 — Legacy Invoice Identity Repair

Based on 3.9.7.57. This build preserves existing invoice identities and visible invoice numbers during synchronization.

## Critical repair
Older local databases can contain an invoice with:
- a real `invoice_number`,
- a real immutable `cloud_key` (`inv_<UUID>`),
- but `invoice_number_final = 0`.

The old synchronization path treated that row as a new/provisional invoice and requested another global number. This could fail on Firebase permissions and could also change historical invoice numbers.

3.9.7.58 now checks Firebase for the existing visible number first. If no different cloud invoice owns that number, the existing number is preserved and marked final. A new global number is allocated only for a real number conflict or a genuinely numberless invoice.

## Sync behavior
- `cloud_key` remains the immutable Firestore document identity.
- Existing local invoices are merged; they are not replaced by a backup and are not renumbered unnecessarily.
- Header and `items` must both upload successfully before the local invoice becomes clean.
- Firestore realtime listeners remain enabled.
- The shared `counters/invoice_numbers` rule from 3.9.7.57 is required in Firebase Rules.

## Safety
Install this build on the tablet first. Do not uninstall, clear data, or restore the tablet backup onto the production phone. The production phone with 195 invoices remains untouched until the tablet test succeeds.

## Build
- versionName: 3.9.7.58
- versionCode: 118
- Android SDK 35 / JDK 17 / Gradle 8.9
- GitHub Actions uses `android-actions/setup-android@v4`.
