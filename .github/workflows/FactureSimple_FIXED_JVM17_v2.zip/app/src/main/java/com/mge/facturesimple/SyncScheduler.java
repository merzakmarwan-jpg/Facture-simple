package com.mge.facturesimple;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

/** Schedules automatic sync whenever a network connection is available. */
public final class SyncScheduler {
    private static final String PERIODIC = "mge_cloud_auto_sync";
    private static final String CHANNEL = "mge_cloud_sync";
    private SyncScheduler() {}

    public static void schedule(Context context) {
        Context c = context.getApplicationContext();
        Constraints constraints = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();
        PeriodicWorkRequest periodic = new PeriodicWorkRequest.Builder(CloudSyncWorker.class, 15, TimeUnit.MINUTES)
                .setConstraints(constraints)
                .build();
        WorkManager.getInstance(c).enqueueUniquePeriodicWork(PERIODIC, ExistingPeriodicWorkPolicy.UPDATE, periodic);
    }

    public static void runNow(Context context) {
        Context c = context.getApplicationContext();
        Constraints constraints = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(CloudSyncWorker.class)
                .setConstraints(constraints)
                .build();
        WorkManager.getInstance(c).enqueueUniqueWork("mge_cloud_sync_now", ExistingWorkPolicy.KEEP, request);
    }

    public static void cancel(Context context) {
        WorkManager.getInstance(context.getApplicationContext()).cancelUniqueWork(PERIODIC);
        WorkManager.getInstance(context.getApplicationContext()).cancelUniqueWork("mge_cloud_sync_now");
    }

    /** Clears any legacy sync-failure notification left by older app versions. */
    public static void clearStatusNotification(Context context) {
        NotificationManagerCompat.from(context.getApplicationContext()).cancel(3601);
    }

    public static void notify(Context context, String title, String body) {
        Context c = context.getApplicationContext();
        NotificationManagerCompat nm = NotificationManagerCompat.from(c);
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager manager = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(new NotificationChannel(CHANNEL, "MGE Cloud", NotificationManager.IMPORTANCE_DEFAULT));
        }
        nm.notify(3601, new NotificationCompat.Builder(c, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_notify_sync_noanim)
                .setContentTitle(title)
                .setContentText(body)
                .setAutoCancel(true)
                .build());
    }
}
