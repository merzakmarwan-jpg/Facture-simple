package com.mge.facturesimple;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.work.Constraints;
import androidx.work.NetworkType;
import androidx.work.WorkerParameters;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Background cloud synchronization. Runs only when the device has a network connection. */
public class CloudSyncWorker extends androidx.work.Worker {
    private static final long TIMEOUT_SECONDS = 9 * 60;

    public CloudSyncWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Store db = new Store(getApplicationContext());
        CloudManager cloud = new CloudManager(getApplicationContext(), db);
        if (!cloud.isLoggedIn()) return Result.success();
        if (!isOnline()) return Result.retry();

        final CountDownLatch latch = new CountDownLatch(1);
        final boolean[] ok = {false};
        final boolean[] ran = {false};
        Runnable done = () -> { ok[0] = true; ran[0] = true; latch.countDown(); };
        Runnable failed = () -> { ran[0] = true; latch.countDown(); };

        try {
            cloud.loadProfileAndRun(() -> {
                if (cloud.isAdmin()) {
                    // Invoice sync is the critical cross-device path. Run it first
                    // so a catalog/image problem can never prevent the phone/tablet
                    // invoice set from converging. The heavier full sync follows.
                    cloud.syncInvoicesOnlyForAdmin(
                            () -> cloud.syncLocalToCloud(done, failed),
                            failed);
                } else cloud.syncCloudToLocalForPartner(done, failed);
            }, failed);
            if (!latch.await(TIMEOUT_SECONDS, TimeUnit.SECONDS)) {
                // Automatic/background sync must not spam the user with a failure notification.
                // The next periodic run will retry; detailed status remains available in Settings.
                db.put("cloud_sync_last_status", "timeout");
                return Result.retry();
            }
        } catch (Exception e) {
            db.put("cloud_sync_last_status", "error");
            db.put("cloud_sync_last_error", e.getMessage()==null?e.getClass().getSimpleName():e.getMessage());
            return Result.retry();
        }

        if (ok[0]) {
            db.put("cloud_sync_last_status", "success");
            db.put("cloud_sync_last_auto", String.valueOf(System.currentTimeMillis()));
            return Result.success();
        }
        db.put("cloud_sync_last_status", "error");
        String reason = cloud.lastSyncError == null || cloud.lastSyncError.trim().isEmpty()
                ? "تحقق من الإنترنت وصلاحيات Firebase." : cloud.lastSyncError;
        db.put("cloud_sync_last_error", reason);
        // Do not show a notification for a partial/background sync failure.
        // Automatic periodic execution will retry without disturbing the user.
        return Result.retry();
    }

    private boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager)getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        if (Build.VERSION.SDK_INT >= 23) {
            Network n = cm.getActiveNetwork();
            return n != null && cm.getNetworkCapabilities(n) != null;
        }
        android.net.NetworkInfo info = cm.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }

    private void notifyStatus(String title, String body) {
        SyncScheduler.notify(getApplicationContext(), title, body);
    }
}
