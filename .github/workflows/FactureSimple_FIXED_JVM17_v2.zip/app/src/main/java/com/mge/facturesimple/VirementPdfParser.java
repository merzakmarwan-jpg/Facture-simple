package com.mge.facturesimple;

import android.content.Context;
import android.net.Uri;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Reads the structured OzonExpress Virement PDF and extracts its header + colis rows. */
public final class VirementPdfParser {
    private VirementPdfParser() {}

    public static final class Row {
        public int number;
        public String code = "";
        public String pickupDate = "";
        public String deliveryDate = "";
        public String status = "";
        public String city = "";
        public double crbt;
        public double fees;
        public double total;
    }

    public static final class Result {
        public String virementCode = "";
        public String date = "";
        public int colisCount;
        public double totalCrbt;
        public double totalFees;
        public double totalNet;
        public String client = "";
        public String bank = "";
        public final ArrayList<Row> rows = new ArrayList<>();
        public String rawText = "";
    }

    public static Result parse(Context context, Uri uri) throws Exception {
        PDFBoxResourceLoader.init(context.getApplicationContext());
        try (InputStream in = context.getContentResolver().openInputStream(uri);
             PDDocument doc = PDDocument.load(in)) {
            PDFTextStripper stripper = new PDFTextStripper();
            stripper.setSortByPosition(true);
            String text = stripper.getText(doc);
            Result result = parseText(text);
            // Some OzonExpress PDFs are extracted in a column order that prevents
            // the row parser from seeing code/date/status on one logical line.
            // Retry with content-stream order before declaring the Virement empty.
            if (result.rows.isEmpty() && result.colisCount > 0) {
                PDFTextStripper fallback = new PDFTextStripper();
                fallback.setSortByPosition(false);
                Result retry = parseText(fallback.getText(doc));
                if (!retry.rows.isEmpty()) result = retry;
            }
            return result;
        }
    }

    public static Result parseText(String text) {
        Result r = new Result();
        r.rawText = text == null ? "" : text;
        String normalized = r.rawText.replace('\u00A0',' ');

        r.virementCode = firstGroup(normalized, "(?m)Virement\\s*:\\s*([^\\r\\n]+)");
        r.date = firstGroup(normalized, "(?m)Date\\s*:\\s*([^\\r\\n]+)");
        r.client = firstGroup(normalized, "(?m)Client\\s*:\\s*([^\\r\\n]+)");
        r.bank = firstGroup(normalized, "(?m)Nom de la banque\\s*:\\s*([^\\r\\n]+)");
        r.colisCount = intValue(firstGroup(normalized, "(?m)Colis\\s*:\\s*(\\d+)"));
        r.totalCrbt = moneyValue(firstGroup(normalized, "(?m)Total CRBT\\s*:\\s*([0-9.,]+)\\s*DH"));
        r.totalFees = moneyValue(firstGroup(normalized, "(?m)Total Frais Colis\\s*([0-9.,]+)\\s*DH"));
        r.totalNet = moneyValue(firstGroup(normalized, "(?m)Total Net\\s*([0-9.,]+)\\s*DH"));

        // PDFBox can wrap the code (e.g. SALE072630545636 + OA) onto the next line.
        String[] lines = normalized.split("\\R");
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i].trim();
            Matcher start = Pattern.compile("^(\\d+)\\s+(.+)$").matcher(line);
            if (!start.find()) continue;
            int number;
            try { number = Integer.parseInt(start.group(1)); } catch (Exception e) { continue; }
            StringBuilder block = new StringBuilder(start.group(2));
            int j = i + 1;
            while (j < lines.length && !lines[j].trim().matches("^\\d+\\s+[A-Za-z]+\\d+[A-Za-z0-9]*\\b.*$")) {
                String extra = lines[j].trim();
                if (!extra.isEmpty() && !extra.equals("1/1")) block.append(' ').append(extra);
                j++;
            }
            Row row = parseRow(number, block.toString());
            if (row != null) r.rows.add(row);
            i = j - 1;
        }
        if (r.colisCount == 0) r.colisCount = r.rows.size();
        return r;
    }

    private static Row parseRow(int number, String block) {
        String s = block.replaceAll("\\s+", " ").trim();
        Matcher dates = Pattern.compile("(\\d{4}-\\d{2}-\\d{2})\\s+(\\d{4}-\\d{2}-\\d{2})\\s+(.+)$").matcher(s);
        if (!dates.find()) return null;
        String before = s.substring(0, dates.start()).trim();
        String after = dates.group(3).trim();
        String[] bt = before.split(" ");
        if (bt.length < 1) return null;

        // IMPORTANT: OzonExpress PDFs do not have a stable text layout.
        // The shipment suffix (for example GK / EX / GF / XL) may be:
        //   BML082631029228 GK
        //   BML082631029228GK
        //   BML082631029228\nGK
        // and PDFBox may place it before or after the date columns.
        // Therefore do NOT rely on the position of the suffix relative to the dates.
        // First identify the tracking base (letters + digits), then take a short
        // alphabetic suffix immediately following it, whether separated by spaces
        // or a line break. Known route tokens are explicitly excluded.
        String code = extractTrackingCode(s, bt[0]);

        Matcher money = Pattern.compile("([0-9][0-9.,]*)\\s*DH\\s+([0-9][0-9.,]*)\\s*DH\\s+([0-9][0-9.,]*)\\s*DH").matcher(after);
        if (!money.find()) return null;
        String prefix = after.substring(0, money.start()).trim();
        String[] at = prefix.split(" ");
        if (at.length < 1) return null;
        Row row = new Row();
        row.number = number;
        row.code = code;
        row.pickupDate = dates.group(1);
        row.deliveryDate = dates.group(2);
        row.status = at[0];
        StringBuilder city = new StringBuilder();
        for (int k = 1; k < at.length; k++) {
            if (city.length() > 0) city.append(' ');
            city.append(at[k]);
        }
        row.city = city.toString();
        row.crbt = moneyValue(money.group(1));
        row.fees = moneyValue(money.group(2));
        row.total = moneyValue(money.group(3));
        return row;
    }


    private static String extractTrackingCode(String block, String fallback) {
        String source = block == null ? "" : block.replace('\u00A0', ' ');
        // Typical OzonExpress code: carrier prefix + 8..14 digits, optionally
        // followed by a 1..4 letter suffix.
        Matcher m = Pattern.compile("([A-Za-z]{2,12}\\d{8,14})(?:\\s*([A-Za-z]{1,4}))?").matcher(source);
        if (m.find()) {
            String base = m.group(1);
            String suffix = m.group(2);
            if (suffix != null && !suffix.matches("OA|RI|AP|SE|DH")) {
                return base + suffix;
            }
            return base;
        }
        return fallback == null ? "" : fallback.trim();
    }
    private static String firstGroup(String text, String regex) {
        Matcher m = Pattern.compile(regex, Pattern.CASE_INSENSITIVE).matcher(text);
        return m.find() ? m.group(1).trim() : "";
    }
    private static int intValue(String x) { try { return Integer.parseInt(x.trim()); } catch (Exception e) { return 0; } }
    private static double moneyValue(String x) {
        if (x == null || x.trim().isEmpty()) return 0;
        String s=x.trim().replace("DH","").replace(" ","");
        try {
            int comma=s.lastIndexOf(','); int dot=s.lastIndexOf('.');
            if(comma>=0 && dot>=0){
                if(comma>dot) s=s.replace(".","").replace(",",".");
                else s=s.replace(",","");
            }else if(comma>=0){
                s=s.replace(",",".");
            }
            return Double.parseDouble(s);
        } catch(Exception e){ return 0; }
    }
}
