package com.mge.facturesimple;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends Activity {
    CloudManager cloud; Store db;
    int blue=Color.rgb(20,103,205), green=Color.rgb(18,155,72), bg=Color.rgb(246,248,252);
    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    EditText input(String h){EditText e=new EditText(this);e.setHint(h);e.setTextSize(15);e.setSingleLine(true);e.setPadding(dp(14),0,dp(14),0);e.setBackground(round(Color.WHITE,Color.rgb(220,226,235),14,1));return e;}
    GradientDrawable round(int fill,int stroke,int r,int sw){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(r));if(sw>0)g.setStroke(dp(sw),stroke);return g;}
    Button btn(String s,int color){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setTextSize(15);b.setBackground(round(color,color,14,0));return b;}
    @Override public void onCreate(Bundle b){super.onCreate(b);db=new Store(this);cloud=new CloudManager(this,db);if(cloud.isLoggedIn()){cloud.loadProfileAndRun(()->openApp(),()->showLogin());}else showLogin();}
    void showLogin(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER);root.setPadding(dp(22),dp(22),dp(22),dp(22));root.setBackgroundColor(bg);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.logo_mge);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);root.addView(logo,new LinearLayout.LayoutParams(-1,dp(100)));
        TextView title=new TextView(this);title.setText("FactureSimple Cloud");title.setTextSize(24);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);title.setTextColor(Color.rgb(31,41,55));title.setGravity(Gravity.CENTER);root.addView(title);
        TextView info=new TextView(this);info.setText("تسجيل الدخول للوصول إلى بياناتك السحابية");info.setTextSize(14);info.setGravity(Gravity.CENTER);info.setTextColor(Color.GRAY);root.addView(info,new LinearLayout.LayoutParams(-1,dp(45)));
        EditText email=input("البريد الإلكتروني");EditText pass=input("كلمة المرور");pass.setInputType(0x81);root.addView(email,lp( -1,54,0,7));root.addView(pass,lp(-1,54,0,12));
        Button login=btn("🔐 تسجيل الدخول",blue);root.addView(login,lp(-1,52,0,8));
        Button register=btn("➕ إنشاء حساب شريك",green);root.addView(register,lp(-1,52,0,8));
        TextView note=new TextView(this);note.setText("ملاحظة: حساب المدير يتم ضبط دوره من لوحة Firebase، وحسابات الشركاء تربط بحساب الشريك في النظام.");note.setTextSize(12);note.setTextColor(Color.GRAY);note.setGravity(Gravity.CENTER);root.addView(note,lp(-1,70,0,0));
        login.setOnClickListener(v->{String e=email.getText().toString().trim(),p=pass.getText().toString();if(e.isEmpty()||p.isEmpty()){Toast.makeText(this,"أدخل البريد وكلمة المرور",Toast.LENGTH_SHORT).show();return;}login.setEnabled(false);cloud.login(e,p).addOnSuccessListener(x->cloud.loadProfileAndRun(()->openApp(),()->{login.setEnabled(true);Toast.makeText(this,"حسابك موجود لكن لم يتم إعداد صلاحياته في السحابة",Toast.LENGTH_LONG).show();})).addOnFailureListener(x->{login.setEnabled(true);Toast.makeText(this,"فشل الدخول: "+x.getMessage(),Toast.LENGTH_LONG).show();});});
        register.setOnClickListener(v->{String e=email.getText().toString().trim(),p=pass.getText().toString();if(e.isEmpty()||p.length()<6){Toast.makeText(this,"أدخل بريدًا وكلمة مرور من 6 أحرف على الأقل",Toast.LENGTH_SHORT).show();return;}cloud.registerPartner(e,p).addOnSuccessListener(x->cloud.saveProfile(e,"partner",0).addOnSuccessListener(y->{Toast.makeText(this,"تم إنشاء حساب الشريك. اربطه بالشريك من Firebase ثم أعد تسجيل الدخول.",Toast.LENGTH_LONG).show();openApp();})).addOnFailureListener(x->Toast.makeText(this,"فشل إنشاء الحساب: "+x.getMessage(),Toast.LENGTH_LONG).show());});
        setContentView(root);
    }
    LinearLayout.LayoutParams lp(int w,int h,int l,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(dp(l),0,dp(0),dp(b));return p;}
    void openApp(){startActivity(new android.content.Intent(this,MainActivity.class));finish();}
}
