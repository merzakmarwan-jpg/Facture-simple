package com.mge.facturesimple;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import android.text.*;
import java.io.*;
import java.util.*;
import android.provider.Settings;

public class MainActivity extends Activity {
    Store db;
    LinearLayout root,content;
    TextView title;
    EditText pendingImageField;
    final int BLUE=Color.rgb(25,118,210), GREEN=Color.rgb(22,163,74), RED=Color.rgb(220,38,38), BG=Color.rgb(245,247,250);

    @Override public void onCreate(Bundle b){super.onCreate(b);db=new Store(this);showHome();}

    TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(Color.rgb(32,33,36));t.setPadding(14,10,14,10);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;}
    EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setPadding(12,5,12,5);return e;}

    void base(String name){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(5,3,5,3);bar.setBackgroundColor(BLUE);
        Button menu=btn("☰");menu.setTextColor(Color.WHITE);menu.setBackgroundColor(Color.TRANSPARENT);menu.setOnClickListener(v->showHome());
        title=new TextView(this);title.setText(name);title.setTextColor(Color.WHITE);title.setTextSize(20);title.setGravity(Gravity.CENTER);
        bar.addView(menu,new LinearLayout.LayoutParams(52,58));bar.addView(title,new LinearLayout.LayoutParams(0,58,1));root.addView(bar);
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(10,10,10,20);
        ScrollView sv=new ScrollView(this);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
    }

    void showHome(){
        base("FactureSimple 2.3");
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.logo_mge);logo.setPadding(10,8,10,8);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        content.addView(logo,new LinearLayout.LayoutParams(-1,90));
        TextView sub=tv("الفواتير + المنتجات + الزبائن",22);sub.setGravity(Gravity.CENTER);content.addView(sub);
        addCard("🧾  الفواتير","حفظ • بحث • تعديل • PDF • مدفوعة / غير مدفوعة",v->showInvoices());
        addCard("📦  المنتجات","إضافة • تعديل • حذف • بحث مباشر • صورة المنتج",v->showProducts());
        addCard("👤  الزبائن","الاسم • الهاتف • المدينة • العنوان • بحث وتعديل",v->showCustomers());
        addCard("⚙  إعدادات الشركة","شعار الشركة ورقم الهاتف الظاهر في الفاتورة",v->showSettings());
        Button n=btn("＋  إنشاء فاتورة جديدة");n.setOnClickListener(v->showInvoiceEditor(-1));content.addView(n);
    }

    void addCard(String a,String b,View.OnClickListener l){
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(8,5,8,5);c.setBackgroundColor(Color.WHITE);c.setOnClickListener(l);
        c.addView(tv(a,19));c.addView(tv(b,14));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,105);p.setMargins(0,5,0,5);content.addView(c,p);
    }

    void showProducts(){
        base("المنتجات");
        EditText search=input("🔎 ابحث باسم المنتج أو الكود");content.addView(search);
        Button add=btn("＋ إضافة منتج");add.setOnClickListener(v->productDialog(-1));content.addView(add);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);
        Runnable refresh=()->{list.removeAllViews();for(Store.Product p:db.products(search.getText().toString()))productRow(list,p);};
        watch(search,refresh);refresh.run();
    }

    void productRow(LinearLayout list,Store.Product p){
        LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(7,5,7,5);r.setBackgroundColor(Color.WHITE);
        ImageView im=new ImageView(this);loadImage(im,p.image);r.addView(im,new LinearLayout.LayoutParams(68,68));
        LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.addView(tv(p.name,17));tx.addView(tv("Code: "+p.code+"   |   "+money(p.price)+" DH",14));
        r.addView(tx,new LinearLayout.LayoutParams(0,82,1));
        Button e=btn("✎");e.setOnClickListener(v->productDialog(p.id));r.addView(e);
        Button d=btn("🗑");d.setOnClickListener(v->{db.deleteProduct(p.id);showProducts();});r.addView(d);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,92);lp.setMargins(0,4,0,4);list.addView(r,lp);
    }

    void productDialog(int id){
        Store.Product o=id<0?null:db.product(id);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        EditText n=input("اسم المنتج"),c=input("الكود"),pr=input("السعر DH"),img=input("صورة المنتج (اختياري)");
        if(o!=null){n.setText(o.name);c.setText(o.code);pr.setText(money(o.price));img.setText(o.image==null?"":o.image);}
        Button pick=btn("🖼 اختيار صورة من الهاتف");pick.setOnClickListener(v->{
            pendingImageField=img;
            Intent in=new Intent(Intent.ACTION_OPEN_DOCUMENT);
            in.setType("image/*");
            in.addCategory(Intent.CATEGORY_OPENABLE);
            in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(in,9001);
        });
        box.addView(n);box.addView(c);box.addView(pr);box.addView(img);box.addView(pick);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(id<0?"إضافة منتج":"تعديل المنتج").setView(box)
            .setPositiveButton("حفظ",(d,w)->{String uri=img.getText().toString();db.saveProduct(id,n.getText().toString().trim(),c.getText().toString().trim(),toD(pr.getText().toString()),uri);showProducts();})
            .setNegativeButton("إلغاء",null).create();
        dialog.show();
    }

    void showCustomers(){
        base("الزبائن");
        EditText search=input("🔎 ابحث بالاسم أو الهاتف أو المدينة");content.addView(search);
        Button add=btn("＋ إضافة زبون");add.setOnClickListener(v->customerDialog(-1));content.addView(add);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);
        Runnable refresh=()->{list.removeAllViews();for(Store.Customer c:db.customers(search.getText().toString()))customerRow(list,c);};
        watch(search,refresh);refresh.run();
    }

    void customerRow(LinearLayout list,Store.Customer c){
        LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(10,6,10,6);r.setBackgroundColor(Color.WHITE);
        r.addView(tv("👤  "+c.name,18));r.addView(tv("📞 "+c.phone+"   |   "+c.city,14));r.addView(tv("📍 "+c.address,13));
        LinearLayout b=new LinearLayout(this);Button e=btn("✎ تعديل");e.setOnClickListener(v->customerDialog(c.id));Button d=btn("🗑");d.setOnClickListener(v->{db.deleteCustomer(c.id);showCustomers();});b.addView(e);b.addView(d);r.addView(b);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,145);lp.setMargins(0,5,0,5);list.addView(r,lp);
    }

    void customerDialog(int id){
        Store.Customer o=id<0?null:db.customer(id);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        EditText n=input("الاسم"),p=input("الهاتف"),city=input("المدينة"),a=input("العنوان");box.addView(n);box.addView(p);box.addView(city);box.addView(a);
        if(o!=null){n.setText(o.name);p.setText(o.phone);city.setText(o.city);a.setText(o.address);}
        new AlertDialog.Builder(this).setTitle(id<0?"إضافة زبون":"تعديل الزبون").setView(box)
            .setPositiveButton("حفظ",(d,w)->{db.saveCustomer(id,n.getText().toString(),p.getText().toString(),city.getText().toString(),a.getText().toString());showCustomers();})
            .setNegativeButton("إلغاء",null).show();
    }

    void showInvoices(){
        base("الفواتير");
        EditText search=input("🔎 رقم الفاتورة أو اسم الزبون");content.addView(search);
        Button add=btn("＋ فاتورة جديدة");add.setOnClickListener(v->showInvoiceEditor(-1));content.addView(add);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);
        Runnable refresh=()->{list.removeAllViews();for(Store.Invoice i:db.invoices(search.getText().toString()))invoiceRow(list,i);};
        watch(search,refresh);refresh.run();
    }

    void invoiceRow(LinearLayout list,Store.Invoice i){
        double total=0;for(Store.Item it:i.items)total+=it.price*it.qty;
        LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(8,5,8,5);r.setBackgroundColor(Color.WHITE);
        r.addView(tv("#"+i.id+"   "+i.client+"   "+money(total)+" DH",17));
        TextView st=tv(i.paid?"✓ مدفوعة":"✕ غير مدفوعة",14);st.setTextColor(i.paid?GREEN:RED);r.addView(st);
        LinearLayout b=new LinearLayout(this);
        Button e=btn("✎ تعديل");e.setOnClickListener(v->showInvoiceEditor(i.id));
        Button pdf=btn("PDF");pdf.setOnClickListener(v->makePdf(i.id));
        Button del=btn("🗑");del.setOnClickListener(v->{db.deleteInvoice(i.id);showInvoices();});
        b.addView(e);b.addView(pdf);b.addView(del);r.addView(b);
        list.addView(r,new LinearLayout.LayoutParams(-1,125));
    }

    void showInvoiceEditor(int id){
        base(id<0?"فاتورة جديدة":"تعديل الفاتورة");
        Store.Invoice old=id<0?null:db.invoice(id);
        EditText client=input("اسم الزبون");content.addView(client);
        Button choose=btn("👤 اختيار زبون");content.addView(choose);
        EditText search=input("🔎 اكتب اسم المنتج للبحث");content.addView(search);
        LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);content.addView(results);
        LinearLayout selected=new LinearLayout(this);selected.setOrientation(LinearLayout.VERTICAL);content.addView(selected);
        TextView total=tv("المجموع: 0.00 DH",20);content.addView(total);
        CheckBox paid=new CheckBox(this);paid.setText("الفاتورة مدفوعة");content.addView(paid);
        Button save=btn("حفظ الفاتورة");content.addView(save);

        ArrayList<Store.Item> items=new ArrayList<>();
        final int[] selectedCustomer={0};
        if(old!=null){client.setText(old.client);paid.setChecked(old.paid);selectedCustomer[0]=old.clientId;items.addAll(old.items);}

        choose.setOnClickListener(v->customerPicker(client,selectedCustomer));
        Runnable render=()->{
            results.removeAllViews();
            String q=search.getText().toString();
            if(q.trim().isEmpty()){updateTotal(total,items);renderItems(selected,items,total);return;}
            for(Store.Product p:db.products(q)){
                LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(6,4,6,4);r.setBackgroundColor(Color.WHITE);
                ImageView im=new ImageView(this);loadImage(im,p.image);r.addView(im,new LinearLayout.LayoutParams(55,55));
                TextView t=tv(p.name+"\n"+money(p.price)+" DH",15);r.addView(t,new LinearLayout.LayoutParams(0,68,1));
                Button plus=btn("＋");plus.setOnClickListener(v->{addItem(items,p);updateTotal(total,items);renderItems(selected,items,total);});r.addView(plus);
                results.addView(r,new LinearLayout.LayoutParams(-1,72));
            }
            updateTotal(total,items);renderItems(selected,items,total);
        };
        watch(search,render);render.run();

        save.setOnClickListener(v->{
            if(client.getText().toString().trim().isEmpty()){client.setError("أدخل اسم الزبون");return;}
            if(items.isEmpty()){Toast.makeText(this,"أضف منتجاً واحداً على الأقل",Toast.LENGTH_SHORT).show();return;}
            db.saveInvoice(id,selectedCustomer[0],client.getText().toString().trim(),paid.isChecked(),items);
            Toast.makeText(this,"تم حفظ الفاتورة",Toast.LENGTH_SHORT).show();showInvoices();
        });
    }

    void addItem(ArrayList<Store.Item> items,Store.Product p){
        for(Store.Item it:items)if(it.productId==p.id){it.qty++;return;}
        items.add(new Store.Item(p.id,p.name,p.price,1));
    }

    void renderItems(LinearLayout box,ArrayList<Store.Item> items,TextView total){
        box.removeAllViews();
        for(int k=0;k<items.size();k++){
            final int idx=k;Store.Item it=items.get(k);
            LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setBackgroundColor(Color.WHITE);
            TextView t=tv(it.name+"   × "+it.qty+"   "+money(it.price*it.qty)+" DH",14);r.addView(t,new LinearLayout.LayoutParams(0,55,1));
            Button minus=btn("−");minus.setOnClickListener(v->{if(it.qty>1)it.qty--;else items.remove(idx);renderItems(box,items,total);updateTotal(total,items);});r.addView(minus);
            Button plus=btn("+");plus.setOnClickListener(v->{it.qty++;renderItems(box,items,total);updateTotal(total,items);});r.addView(plus);
            box.addView(r,new LinearLayout.LayoutParams(-1,60));
        }
    }

    void customerPicker(EditText client,int[] id){
        EditText s=input("🔎 ابحث عن الزبون");LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);
        LinearLayout wrap=new LinearLayout(this);wrap.setOrientation(LinearLayout.VERTICAL);wrap.addView(s);ScrollView sv=new ScrollView(this);sv.addView(list);wrap.addView(sv,new LinearLayout.LayoutParams(-1,400));
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("اختيار الزبون").setView(wrap).setNegativeButton("إلغاء",null).create();
        Runnable refresh=()->{list.removeAllViews();for(Store.Customer c:db.customers(s.getText().toString())){Button b=btn(c.name+"  |  "+c.phone);b.setOnClickListener(v->{client.setText(c.name);id[0]=c.id;dlg.dismiss();});list.addView(b);}};
        watch(s,refresh);refresh.run();dlg.show();
    }

    void showSettings(){
        base("إعدادات الشركة");
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.logo_mge);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);content.addView(logo,new LinearLayout.LayoutParams(-1,90));
        EditText name=input("اسم الشركة");name.setText(db.get("company_name","MGE"));content.addView(name);
        EditText phone=input("هاتف الشركة");phone.setText(db.get("phone","+212666964731"));content.addView(phone);
        EditText footer=input("النص أسفل الفاتورة");footer.setText(db.get("footer","Merci pour votre confiance"));content.addView(footer);
        Button save=btn("حفظ الإعدادات");save.setOnClickListener(v->{db.put("company_name",name.getText().toString());db.put("phone",phone.getText().toString());db.put("footer",footer.getText().toString());Toast.makeText(this,"تم حفظ الإعدادات",Toast.LENGTH_SHORT).show();});content.addView(save);
    }

    void makePdf(int id){
        Store.Invoice inv=db.invoice(id);if(inv==null)return;
        PdfDocument doc=new PdfDocument();
        PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());
        Canvas c=page.getCanvas();Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);c.drawPaint(p);

        p.setColor(Color.BLACK);c.drawRect(45,35,150,90,p);p.setColor(Color.WHITE);p.setTextSize(26);p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("MGE",70,72,p);
        p.setColor(Color.BLACK);p.setTextSize(21);c.drawText("FACTURE / فاتورة",310,65,p);
        p.setTypeface(Typeface.DEFAULT);p.setTextSize(12);
        c.drawText("Tel : "+db.get("phone","+212666964731"),45,108,p);
        c.drawText("N° : "+inv.id,45,130,p);c.drawText("Date : "+inv.date,45,152,p);
        c.drawText("Client : "+inv.client,45,174,p);

        if(inv.clientId>0){
            Store.Customer cu=db.customer(inv.clientId);
            if(cu!=null){c.drawText("Tel : "+cu.phone,300,174,p);c.drawText("Ville : "+cu.city,45,194,p);c.drawText("Adresse : "+cu.address,300,194,p);}
        }

        p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(13);p.setColor(inv.paid?GREEN:RED);
        c.drawText(inv.paid?"Statut : PAYÉE / مدفوعة":"Statut : NON PAYÉE / غير مدفوعة",45,220,p);
        p.setColor(Color.BLACK);c.drawLine(45,240,550,240,p);
        c.drawText("Produit / البيان",55,260,p);c.drawText("Qté",350,260,p);c.drawText("Prix",410,260,p);c.drawText("Total",490,260,p);
        p.setTypeface(Typeface.DEFAULT);int y=285;double total=0;
        for(Store.Item it:inv.items){
            double z=it.price*it.qty;total+=z;
            c.drawText(trim(it.name,32),55,y,p);c.drawText(""+it.qty,350,y,p);c.drawText(money(it.price),410,y,p);c.drawText(money(z),490,y,p);y+=30;
            c.drawLine(45,y-12,550,y-12,p);
        }
        p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(16);c.drawText("TOTAL : "+money(total)+" DH",390,y+25,p);
        p.setTypeface(Typeface.DEFAULT);p.setTextSize(14);c.drawText(db.get("footer","Merci pour votre confiance"),215,y+70,p);

        doc.finishPage(page);
        File dir=new File(getExternalFilesDir(null),"Factures");if(!dir.exists())dir.mkdirs();
        File f=new File(dir,"Facture_"+id+".pdf");
        try(FileOutputStream out=new FileOutputStream(f)){doc.writeTo(out);doc.close();
            Toast.makeText(this,"تم إنشاء PDF: "+f.getAbsolutePath(),Toast.LENGTH_LONG).show();
        }catch(Exception e){try{doc.close();}catch(Exception ignored){}Toast.makeText(this,"خطأ PDF: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }

    void watch(EditText e,final Runnable r){
        e.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){r.run();}
            public void afterTextChanged(Editable s){}
        });
    }

    void loadImage(ImageView v,String uri){
        try{
            if(uri!=null && !uri.isEmpty()){v.setImageURI(Uri.parse(uri));}
            else v.setImageResource(R.drawable.ic_product);
        }catch(Exception e){v.setImageResource(R.drawable.ic_product);}
    }

    void updateTotal(TextView t,ArrayList<Store.Item> items){double x=0;for(Store.Item i:items)x+=i.price*i.qty;t.setText("المجموع: "+money(x)+" DH");}
    double toD(String s){try{return Double.parseDouble(s.replace(",","."));}catch(Exception e){return 0;}}
    String money(double x){return String.format(Locale.US,"%.2f",x);}
    String trim(String s,int n){if(s==null)return "";return s.length()>n?s.substring(0,n-1)+"…":s;}

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        // Image selection is intentionally kept local; Android grants the selected URI to the app.
        if(requestCode==9001 && resultCode==RESULT_OK && data!=null && data.getData()!=null){
            Uri u=data.getData();
            try{
                getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);
            }catch(Exception ignored){}
            if(pendingImageField!=null) pendingImageField.setText(u.toString());
            Toast.makeText(this,"تم اختيار صورة المنتج. اضغط حفظ.",Toast.LENGTH_SHORT).show();
        }
    }
}
