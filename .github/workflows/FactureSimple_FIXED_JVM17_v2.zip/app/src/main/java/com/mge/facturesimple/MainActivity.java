package com.mge.facturesimple;

import android.app.*;
import android.Manifest;
import android.os.*;
import android.os.Environment;
import android.content.*;
import android.database.Cursor;
import android.content.ContentValues;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.content.ContentUris;
import android.content.ClipData;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import android.text.*;
import java.io.*;
import java.util.*;
import java.text.SimpleDateFormat;
import java.util.zip.*;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;

public class MainActivity extends Activity {

    Store db;
    CloudManager cloud;
    LinearLayout root, body;
    ScrollView mainScroll;
    TextView screenTitle;
    EditText pendingImageField;
    Cursor imageCursor;
    AlertDialog imageGalleryDialog;
    Runnable invoicePartnerModeRefresh;
    boolean invoicePartnerMode=false;
    TextView activeInvoiceRemainingView=null;
    EditText activeInvoiceAdvanceField=null;
    int activeInvoicePartnerId=0;
    final HashSet<Integer> selectedProductIds = new HashSet<>();
    final HashSet<Integer> selectedSupplierProductIds = new HashSet<>();
    final HashMap<Integer,Integer> supplierOrderQty = new HashMap<>();
    int currentSupplierId = 0;
    int currentSelectedCustomerIdForInvoice=0;
    TextView selectedProductsCount;
    String currentScreen = "";
    int customerAdminFilter = 0;

    // فلاتر صفحة الفواتير يجب أن تبقى ثابتة أثناء مزامنة Firebase.
    // لا تُحفظ كمتغيرات محلية داخل showInvoices() لأن المزامنة تعيد بناء الشاشة.
    int invoiceScopeFilter = 0;      // 0 الكل، 1 الشركاء، 2 العادية
    int invoiceDeliveryFilter = 0;  // 0 كل الحالات، 1 لم يتم الاستلام، 2 تم الاستلام
    int invoicePartnerFilter = 0;   // partnerId، أو 0 لكل الشركاء
    String invoiceStoreFilter = ""; // shipping_account / Store، أو فارغ لكل الحسابات
    String invoiceSearchFilter = "";
    // When saving an edited invoice, rebuild the list but scroll back to that
    // exact invoice instead of returning the user to the top.
    int pendingInvoiceScrollId = 0;
    long lastMainScrollAt = 0L;
    static final int REQ_EXPORT_DB = 9101;
    static final int REQ_IMPORT_DB = 9102;
    static final int REQ_VIREMENT_PDF = 9103;
    String pendingVirementCompany = "";
    String pendingVirementStore = "";

    // فلاترات صفحة مداخيل Store: الشركة، الحساب، وحالة استلام المبلغ إلى البنك.
    String storeRevenueCompanyFilter = "";
    String storeRevenueAccountFilter = "";
    String storeRevenueStatusFilter = "all"; // all / received / pending

    final int BLUE = Color.rgb(20, 103, 205);
    final int BLUE_DARK = Color.rgb(13, 76, 161);
    final int GREEN = Color.rgb(18, 155, 72);
    final int RED = Color.rgb(220, 50, 50);
    final int BG = Color.rgb(246, 248, 252);
    final int TEXT = Color.rgb(31, 41, 55);
    final int MUTED = Color.rgb(100, 116, 139);
    final int BORDER = Color.rgb(225, 231, 239);

    int dp(float x){ return (int)(x * getResources().getDisplayMetrics().density + .5f); }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        db = new Store(this);
        cloud = new CloudManager(this,db);
        SyncScheduler.schedule(this);
        if(android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 3601);
        getWindow().setStatusBarColor(BLUE_DARK);
        if(!cloud.isLoggedIn()){ startActivity(new Intent(this,LoginActivity.class)); finish(); return; }
        cloud.loadProfileAndRun(()->{
            // Never block the first screen on a full cloud reconciliation.
            // The local database is immediately usable; synchronization continues in background.
            showHome();
            cloud.startRealtimeSync(this::refreshRealtimeScreen);
            if(cloud.isAdmin()){
                cloud.ensureGlobalInvoiceCounter()
                    .addOnSuccessListener(v->cloud.syncLocalToCloud(()->{},()->{}))
                    .addOnFailureListener(e->cloud.syncLocalToCloud(()->{},()->{}));
            } else cloud.syncCloudToLocalForPartner(()->{},()->{});
        },()->{ startActivity(new Intent(this,LoginActivity.class)); finish(); });
    }

    TextView text(String s, float size, int color){
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(dp(10),dp(5),dp(10),dp(5));
        return t;
    }

    Button button(String s){
        Button b = new Button(this);
        b.setText(s); b.setTextSize(14); b.setAllCaps(false);
        b.setPadding(dp(10),0,dp(10),0);
        return b;
    }

    EditText input(String hint){
        EditText e = new EditText(this);
        e.setHint(hint); e.setTextSize(14); e.setSingleLine(true);
        e.setTextColor(TEXT); e.setHintTextColor(Color.rgb(150,158,170));
        e.setPadding(dp(12),0,dp(12),0);
        e.setBackground(round(Color.WHITE, BORDER, 12, 1));
        e.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return e;
    }

    GradientDrawable round(int fill, int stroke, int radius, int sw){
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill); g.setCornerRadius(dp(radius));
        if(sw>0) g.setStroke(dp(sw),stroke);
        return g;
    }

    GradientDrawable solid(int fill, int radius){
        return round(fill, fill, radius, 0);
    }

    void base(String title){
        currentScreen = title == null ? "" : title;
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(7),0,dp(7),0);
        top.setBackgroundColor(BLUE);

        Button menu = button("☰");
        menu.setTextColor(Color.WHITE);
        menu.setTextSize(22);
        menu.setBackgroundColor(Color.TRANSPARENT);
        menu.setOnClickListener(v -> showHome());

        screenTitle = text(title,19,Color.WHITE);
        screenTitle.setGravity(Gravity.CENTER);
        screenTitle.setTypeface(Typeface.DEFAULT,Typeface.BOLD);

        top.addView(menu,new LinearLayout.LayoutParams(dp(54),dp(58)));
        top.addView(screenTitle,new LinearLayout.LayoutParams(0,dp(58),1));

        root.addView(top);

        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(12),dp(10),dp(12),dp(10));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(body);
        mainScroll = scroll;
        scroll.setOnScrollChangeListener((v,scrollX,scrollY,oldScrollX,oldScrollY) -> lastMainScrollAt = System.currentTimeMillis());
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        root.addView(bottomBar(title));
        setContentView(root);
    }

    void refreshRealtimeScreen(){
        runOnUiThread(() -> {
            if (isFinishing()) return;
            if ("الفواتير".equals(currentScreen)) {
                // Realtime updates must never throw the user back to the top while
                // browsing older invoices. Keep the exact scroll position.
                final int y = mainScroll == null ? 0 : mainScroll.getScrollY();
                Runnable refresh = () -> {
                    if (!"الفواتير".equals(currentScreen) || isFinishing()) return;
                    showInvoices();
                    if (mainScroll != null) mainScroll.post(() -> mainScroll.scrollTo(0, y));
                };
                long quiet = System.currentTimeMillis() - lastMainScrollAt;
                if (quiet < 1200L) {
                    new Handler(Looper.getMainLooper()).postDelayed(refresh, 1200L - quiet);
                } else {
                    refresh.run();
                }
            } else if ("الزبائن".equals(currentScreen) || "الزبائن والشركاء".equals(currentScreen)) {
                // Keep the selected Admin filter. The initial Firestore snapshot
                // used to rebuild this page and silently switch back to "الكل".
                showCustomers();
            }
        });
    }

    View bottomBar(String current){
        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setBackgroundColor(Color.WHITE);
        nav.setPadding(0,dp(3),0,dp(3));

        nav.addView(navItem("⌂","الرئيسية",current.equals("الرئيسية"),v->showHome()));
        nav.addView(navItem("▣","الفواتير",current.equals("الفواتير"),v->showInvoices()));
        nav.addView(navItem("▤","المنتجات",current.equals("المنتجات"),v->showProducts()));
        nav.addView(navItem("♙","الزبائن",current.equals("الزبائن"),v->showCustomers()));
        nav.addView(navItem("📊","التقارير",current.equals("التقارير"),v->showReports()));
        if(cloud != null && cloud.isAdmin()) nav.addView(navItem("⚙","الإعدادات",current.equals("الإعدادات"),v->showSettings()));
        return nav;
    }

    View navItem(String icon,String label,boolean active,View.OnClickListener l){
        LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setGravity(Gravity.CENTER);
        TextView i=text(icon,20,active?BLUE:MUTED);i.setGravity(Gravity.CENTER);
        TextView t=text(label,10,active?BLUE:MUTED);t.setGravity(Gravity.CENTER);
        x.addView(i,new LinearLayout.LayoutParams(-1,dp(26)));
        x.addView(t,new LinearLayout.LayoutParams(-1,dp(24)));
        x.setOnClickListener(l);
        x.setBackground(active?solid(Color.rgb(239,246,255),10):ColorDrawable(Color.TRANSPARENT));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(54),1);p.setMargins(dp(3),0,dp(3),0);
        x.setLayoutParams(p);
        return x;
    }

    Drawable ColorDrawable(int c){ return new android.graphics.drawable.ColorDrawable(c); }

    TextView section(String s){
        TextView t=text(s,16,TEXT);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        t.setPadding(dp(4),dp(12),dp(4),dp(6));return t;
    }

    LinearLayout card(){
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(10),dp(9),dp(10),dp(9));c.setBackground(round(Color.WHITE,BORDER,15,1));
        return c;
    }

    void showHome(){
        base("الرئيسية");

        LinearLayout brand=card();
        brand.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.logo_mge);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        brand.addView(logo,new LinearLayout.LayoutParams(-1,dp(82)));
        TextView sub=text("تطبيق الفواتير + المنتجات + الزبائن",18,TEXT);sub.setGravity(Gravity.CENTER);
        brand.addView(sub);
        TextView ver=text("MGE Cloud • إدارة الحسابات والصلاحيات السحابية",12,MUTED);ver.setGravity(Gravity.CENTER);
        brand.addView(ver);
        body.addView(brand,margin(-1,dp(142),0,dp(8)));

        LinearLayout quick=new LinearLayout(this);
        quick.setOrientation(LinearLayout.HORIZONTAL);
        quick.addView(stat("🧾","الفواتير","إدارة الفواتير",v->showInvoices()),new LinearLayout.LayoutParams(0,dp(170),1));
        quick.addView(stat("📦","المنتجات","إدارة المنتجات",v->showProducts()),new LinearLayout.LayoutParams(0,dp(170),1));
        body.addView(quick);

        LinearLayout quick2=new LinearLayout(this);
        quick2.setOrientation(LinearLayout.HORIZONTAL);
        quick2.addView(stat("👤","الزبائن",cloud.isAdmin()?"إدارة الزبائن والشركاء":"زبائنك فقط",v->showCustomers()),new LinearLayout.LayoutParams(0,dp(170),1));
        if(cloud.isAdmin()) quick2.addView(stat("⚙","الإعدادات","إعدادات الشركة والإدارة",v->showSettings()),new LinearLayout.LayoutParams(0,dp(170),1));
        else quick2.addView(stat("👤","الحساب","حساب الشريك",v->showPartnerAccount()),new LinearLayout.LayoutParams(0,dp(128),1));
        body.addView(quick2);

        if(cloud.isAdmin()){
        LinearLayout supplierCard=card();
        supplierCard.setGravity(Gravity.CENTER);
        TextView si=text("🏭",30,BLUE);si.setGravity(Gravity.CENTER);supplierCard.addView(si,new LinearLayout.LayoutParams(-1,dp(40)));
        TextView st=text("الموردين",18,TEXT);st.setTypeface(Typeface.DEFAULT,Typeface.BOLD);st.setGravity(Gravity.CENTER);supplierCard.addView(st);
        TextView sd=text("شركات الموردين • منتجاتهم • إنشاء طلبية PDF",12,MUTED);sd.setGravity(Gravity.CENTER);supplierCard.addView(sd);
        Button sb=button("📦 فتح إدارة الموردين");sb.setTextColor(Color.WHITE);sb.setBackground(solid(BLUE,12));sb.setOnClickListener(v->showSuppliers());supplierCard.addView(sb,margin(-1,dp(48),0,0));
        body.addView(supplierCard,margin(-1,dp(154),0,dp(10)));
        }

        if(cloud.isAdmin()){
            Button create=button("＋   إنشاء فاتورة جديدة");
            create.setTextColor(Color.WHITE);create.setTextSize(16);create.setBackground(solid(GREEN,14));
            create.setOnClickListener(v->showInvoiceEditor(-1));
            body.addView(create,margin(-1,dp(54),0,dp(10)));
        }

        LinearLayout reportsCard=card();
        TextView reportsTitle=text("📊  التقارير والتحليلات",18,TEXT);
        reportsTitle.setTypeface(Typeface.DEFAULT,Typeface.BOLD);reportsTitle.setGravity(Gravity.CENTER);
        reportsCard.addView(reportsTitle);
        TextView reportsDesc=text("المبيعات • أكثر المنتجات مبيعاً • الزبناء الأوفياء • تحليل مشتريات كل زبون",12,MUTED);
        reportsDesc.setGravity(Gravity.CENTER);reportsCard.addView(reportsDesc);
        Button reportsBtn=button("📊 فتح مركز التقارير");
        reportsBtn.setTextColor(Color.WHITE);reportsBtn.setBackground(solid(BLUE,12));
        reportsBtn.setOnClickListener(v->showReports());
        reportsCard.addView(reportsBtn,margin(-1,dp(50),0,0));
        body.addView(reportsCard,margin(-1,-2,0,dp(10)));

        TextView note=text("PDF احترافي • حالة الدفع • بحث مباشر • صور المنتجات",13,MUTED);
        note.setGravity(Gravity.CENTER);body.addView(note);
    }

    View stat(String icon,String title,String desc,View.OnClickListener l){
        LinearLayout c=card();c.setGravity(Gravity.CENTER);
        TextView i=text(icon,27,BLUE);i.setGravity(Gravity.CENTER);
        TextView a=text(title,17,TEXT);a.setTypeface(Typeface.DEFAULT,Typeface.BOLD);a.setGravity(Gravity.CENTER);
        TextView b=text(desc,12,MUTED);b.setGravity(Gravity.CENTER);
        b.setMaxLines(3);
        b.setEllipsize(null);
        b.setIncludeFontPadding(true);
        b.setPadding(dp(3),dp(2),dp(3),dp(2));
        c.addView(i,new LinearLayout.LayoutParams(-1,dp(38)));
        c.addView(a,new LinearLayout.LayoutParams(-1,dp(38)));
        c.addView(b,new LinearLayout.LayoutParams(-1,dp(52)));
        c.setOnClickListener(l);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(166));p.setMargins(dp(4),dp(4),dp(4),dp(4));c.setLayoutParams(p);
        return c;
    }

    void showProducts(){
        base("المنتجات");
        EditText search=input("🔎  ابحث باسم المنتج أو الكود");body.addView(search,margin(-1,dp(48),0,dp(8)));

        LinearLayout shareBar=new LinearLayout(this); shareBar.setOrientation(LinearLayout.HORIZONTAL); shareBar.setGravity(Gravity.CENTER_VERTICAL);
        Button shareSelected=button("📄 مشاركة المحدد PDF"); shareSelected.setTextColor(Color.WHITE); shareSelected.setBackground(solid(BLUE,12));
        shareSelected.setOnClickListener(v->shareSelectedProductsPdf());
        shareBar.addView(shareSelected,new LinearLayout.LayoutParams(0,dp(46),1));
        Button selectAll=button("تحديد الكل"); selectAll.setTextColor(BLUE); selectAll.setBackground(round(Color.WHITE,BORDER,10,1));
        selectAll.setOnClickListener(v->{for(Store.Product p:db.products(search.getText().toString())) selectedProductIds.add(p.id); showProducts();});
        LinearLayout.LayoutParams salp=new LinearLayout.LayoutParams(dp(105),dp(46)); salp.setMargins(dp(6),0,0,0); shareBar.addView(selectAll,salp);
        Button clearAll=button("إلغاء"); clearAll.setTextColor(RED); clearAll.setBackground(round(Color.WHITE,BORDER,10,1));
        clearAll.setOnClickListener(v->{selectedProductIds.clear(); showProducts();});
        LinearLayout.LayoutParams calp=new LinearLayout.LayoutParams(dp(75),dp(46)); calp.setMargins(dp(6),0,0,0); shareBar.addView(clearAll,calp);
        body.addView(shareBar,margin(-1,dp(50),0,dp(4)));
        selectedProductsCount=text("لم يتم اختيار منتجات",12,MUTED); selectedProductsCount.setGravity(Gravity.RIGHT); body.addView(selectedProductsCount,margin(-1,dp(24),0,dp(8)));

        if(cloud == null || cloud.isAdmin()){
            Button add=button("＋  إضافة منتج");add.setTextColor(Color.WHITE);add.setBackground(solid(BLUE,12));
            add.setOnClickListener(v->productDialog(-1));body.addView(add,margin(-1,dp(48),0,dp(8)));

            Button cloudSync=button("☁️  رفع المنتجات والصور إلى السحابة");
            cloudSync.setTextColor(Color.WHITE);cloudSync.setBackground(solid(GREEN,12));
            cloudSync.setOnClickListener(v->{
                cloudSync.setEnabled(false);
                cloud.syncProductsToCloud(
                    ()->{cloudSync.setEnabled(true);Toast.makeText(this,"تم رفع المنتجات والصور إلى Firebase",Toast.LENGTH_LONG).show();},
                    ()->{cloudSync.setEnabled(true);Toast.makeText(this,"تعذر رفع بعض المنتجات أو الصور",Toast.LENGTH_LONG).show();}
                );
            });
            body.addView(cloudSync,margin(-1,dp(48),0,dp(8)));
        } else if(cloud != null){
            Button cloudSync=button("☁️  تحديث المنتجات والصور");
            cloudSync.setTextColor(Color.WHITE);cloudSync.setBackground(solid(BLUE,12));
            cloudSync.setOnClickListener(v->{
                cloudSync.setEnabled(false);
                cloud.syncCloudToLocalForPartner(
                    ()->{cloudSync.setEnabled(true);showProducts();Toast.makeText(this,"تم تحديث المنتجات والصور",Toast.LENGTH_LONG).show();},
                    ()->{cloudSync.setEnabled(true);Toast.makeText(this,"تعذر تحديث المنتجات",Toast.LENGTH_LONG).show();}
                );
            });
            body.addView(cloudSync,margin(-1,dp(48),0,dp(8)));
        }

        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);body.addView(list);
        Runnable refresh=()->{list.removeAllViews();for(Store.Product p:db.products(search.getText().toString()))productRow(list,p);refreshProductSelectionCount();};
        watch(search,refresh);refresh.run();
    }

    void productRow(LinearLayout list,Store.Product p){
        // بطاقة منتجات مرنة: لا تقص اسم المنتج أو السعر عند البحث.
        LinearLayout r=card();
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(6),dp(6),dp(6),dp(6));

        CheckBox pickBox=new CheckBox(this);
        pickBox.setChecked(selectedProductIds.contains(p.id));
        pickBox.setText("");
        pickBox.setContentDescription("اختيار "+safe(p.name)+" للمشاركة");
        pickBox.setOnCheckedChangeListener((buttonView,isChecked)->{ if(isChecked) selectedProductIds.add(p.id); else selectedProductIds.remove(p.id); refreshProductSelectionCount(); });
        r.addView(pickBox,new LinearLayout.LayoutParams(dp(42),dp(52)));

        LinearLayout imageBox=new LinearLayout(this);
        imageBox.setOrientation(LinearLayout.VERTICAL);
        imageBox.setGravity(Gravity.CENTER);
        imageBox.setPadding(dp(3),dp(3),dp(3),dp(3));

        ImageView im=new ImageView(this);
        loadImage(im,p.image);
        im.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        im.setBackground(round(Color.rgb(249,251,255),Color.rgb(220,228,240),12,1));
        im.setContentDescription("صورة المنتج "+safe(p.name));
        im.setOnClickListener(v->showProductImageZoom(p.name,p.image));
        imageBox.addView(im,new LinearLayout.LayoutParams(dp(118),dp(118)));

        TextView zoomHint=text("اضغط للتكبير",10,MUTED);
        zoomHint.setGravity(Gravity.CENTER);
        imageBox.addView(zoomHint,new LinearLayout.LayoutParams(dp(118),dp(24)));
        r.addView(imageBox,new LinearLayout.LayoutParams(dp(126),-2));

        LinearLayout info=new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(10),dp(2),dp(8),dp(2));

        TextView n=text(safe(p.name),18,TEXT);
        n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        n.setMaxLines(4);
        n.setEllipsize(android.text.TextUtils.TruncateAt.END);
        n.setGravity(Gravity.RIGHT);
        info.addView(n,new LinearLayout.LayoutParams(-1,-2));

        TextView code=text("Code: "+safe(p.code),13,MUTED);
        code.setMaxLines(1);
        code.setEllipsize(android.text.TextUtils.TruncateAt.END);
        info.addView(code,margin(-1,dp(25),0,dp(4)));

        TextView price=text((p.available?money(p.price)+" DH":"غير متوفر حالياً"),22,p.available?BLUE:RED);
        price.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        price.setGravity(Gravity.CENTER);
        price.setSingleLine(true);
        price.setMaxLines(1);
        price.setIncludeFontPadding(false);
        price.setBackground(round(Color.rgb(239,246,255),Color.rgb(211,226,246),10,1));
        info.addView(price,margin(-1,dp(44),0,dp(6)));

        TextView actionHint=text((p.available?"عرض الصورة • اضغط للتكبير":"⛔ غير متوفر حالياً • عرض الصورة"),11,p.available?MUTED:RED);
        actionHint.setGravity(Gravity.RIGHT);
        info.addView(actionHint,margin(-1,dp(22),0,dp(3)));

        if(cloud == null || cloud.isAdmin()){
            LinearLayout actions=new LinearLayout(this);
            Button partnerPrices=button("🤝 أسعار الشركاء"); partnerPrices.setTextSize(11); partnerPrices.setTextColor(BLUE); partnerPrices.setBackground(round(Color.rgb(239,246,255),Color.rgb(211,226,246),10,1));
            partnerPrices.setOnClickListener(v->partnerProductPricesDialog(p));
            actions.addView(partnerPrices,new LinearLayout.LayoutParams(0,dp(42),1));

            actions.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
            actions.setPadding(0,dp(2),0,0);

            ImageButton edit=productActionButton(R.drawable.ic_edit_product,"تعديل المنتج",BLUE);
            edit.setOnClickListener(v->productDialog(p.id));

            ImageButton del=productActionButton(R.drawable.ic_delete_product,"حذف المنتج",RED);
            del.setOnClickListener(v->{
                new AlertDialog.Builder(this)
                    .setTitle("حذف المنتج")
                    .setMessage("هل تريد حذف المنتج «"+safe(p.name)+"»؟")
                    .setNegativeButton("إلغاء",null)
                    .setPositiveButton("حذف",(d,w)->{db.deleteProduct(p.id);showProducts();})
                    .show();
            });
            actions.addView(edit,new LinearLayout.LayoutParams(dp(48),dp(44)));
            LinearLayout.LayoutParams delLp=new LinearLayout.LayoutParams(dp(48),dp(44));delLp.setMargins(dp(8),0,0,0);
            actions.addView(del,delLp);
            info.addView(actions,new LinearLayout.LayoutParams(-1,dp(46)));
        } else if(cloud != null && cloud.partnerId>0){
            Store.PartnerProductSetting ps=db.partnerProductSetting((int)cloud.partnerId,p.id);
            double ownPrice=ps!=null&&ps.partnerPrice>0?ps.priceForQty(1):p.price;
            TextView own=text("سعرك الخاص: "+money(ownPrice)+" DH"+(ps!=null&&!safe(ps.priceTiers).isEmpty()?" • أسعار الكمية مفعلة":""),14,GREEN); own.setGravity(Gravity.RIGHT); own.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
            info.addView(own,margin(-1,dp(30),0,dp(3)));
            if(ps!=null&&!safe(ps.priceTiers).isEmpty()){
                TextView tiers=text("📦 أسعار الكمية: "+safe(ps.priceTiers),11,MUTED);tiers.setGravity(Gravity.RIGHT);info.addView(tiers,margin(-1,dp(22),0,dp(3)));
            }
            TextView imgStatus=text(ps!=null&&!safe(ps.customerImage).isEmpty()?"🖼 صورة خاصة للزبائن جاهزة للمشاركة":"🖼 أضف صورة بدون سعر لمشاركتها مع زبائنك",11,MUTED); imgStatus.setGravity(Gravity.RIGHT); info.addView(imgStatus,margin(-1,dp(24),0,dp(4)));
            LinearLayout actions=new LinearLayout(this); actions.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
            Button priceBtn=button("💰 تعديل سعرك"); priceBtn.setTextColor(GREEN); priceBtn.setBackground(round(Color.rgb(239,251,244),Color.rgb(190,231,204),10,1)); priceBtn.setOnClickListener(v->partnerOwnPriceDialog(p));
            actions.addView(priceBtn,new LinearLayout.LayoutParams(0,dp(42),1));
            Button imgBtn=button(ps!=null&&!safe(ps.customerImage).isEmpty()?"🖼 تعديل صورة الزبائن":"🖼 إضافة صورة الزبائن"); imgBtn.setTextColor(BLUE); imgBtn.setBackground(round(Color.rgb(239,246,255),Color.rgb(211,226,246),10,1)); imgBtn.setOnClickListener(v->partnerProductImageDialog(p));
            LinearLayout.LayoutParams ilp=new LinearLayout.LayoutParams(0,dp(42),1);ilp.setMargins(dp(6),0,0,0);actions.addView(imgBtn,ilp);
            if(ps!=null&&!safe(ps.customerImage).isEmpty()){ Button share=button("📤 مشاركة"); share.setTextColor(GREEN); share.setBackgroundColor(Color.TRANSPARENT); share.setOnClickListener(v->shareProductCustomerImage(p.name,ps.customerImage)); actions.addView(share,new LinearLayout.LayoutParams(dp(95),dp(42))); }
            info.addView(actions,new LinearLayout.LayoutParams(-1,dp(46)));
        }

        r.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        list.addView(r,margin(-1,-2,0,dp(8)));
    }

    void refreshProductSelectionCount(){
        if(selectedProductsCount==null)return;
        int n=selectedProductIds.size();
        selectedProductsCount.setText(n==0?"لم يتم اختيار منتجات":"تم اختيار "+n+" منتج للمشاركة كـ PDF");
        selectedProductsCount.setTextColor(n==0?MUTED:GREEN);
    }

    void shareSelectedProductsPdf(){
        if(selectedProductIds.isEmpty()){
            Toast.makeText(this,"اختر منتجًا واحدًا على الأقل أولاً",Toast.LENGTH_SHORT).show();
            return;
        }
        ArrayList<Store.Product> products=new ArrayList<>();
        for(Integer id:selectedProductIds){Store.Product p=db.product(id);if(p!=null)products.add(p);}
        if(products.isEmpty()){
            Toast.makeText(this,"المنتجات المحددة غير موجودة",Toast.LENGTH_SHORT).show();
            return;
        }
        buildSelectedProductsPdf(products);
    }

    String productShareImage(Store.Product product){
        if(cloud!=null&&cloud.partnerId>0){
            Store.PartnerProductSetting ps=db.partnerProductSetting((int)cloud.partnerId,product.id);
            if(ps!=null&&!safe(ps.customerImage).trim().isEmpty())return ps.customerImage;
        }
        return safe(product.image);
    }

    String productSharePriceText(Store.Product product){
        double base=product.price;
        String tiers=safe(product.priceTiers).trim();
        if(cloud!=null&&cloud.partnerId>0){
            Store.PartnerProductSetting ps=db.partnerProductSetting((int)cloud.partnerId,product.id);
            if(ps!=null&&ps.partnerPrice>0){base=ps.partnerPrice;tiers=safe(ps.priceTiers).trim();}
        }
        StringBuilder out=new StringBuilder("السعر: ").append(money(base)).append(" DH");
        if(!tiers.isEmpty()){
            ArrayList<String> rows=new ArrayList<>();
            for(String row:tiers.split(";")){
                try{String[] x=row.trim().split("=");if(x.length>=2){int q=Integer.parseInt(x[0].trim());double pr=Double.parseDouble(x[1].trim());if(q>0)rows.add(q+" قطعة = "+money(pr)+" DH");}}catch(Exception ignored){}
            }
            if(!rows.isEmpty())out.append("\nسعر الكمية: ").append(String.join(" • ",rows));
        }
        return out.toString();
    }

    void buildSelectedProductsPdf(ArrayList<Store.Product> products){
        final HashMap<Integer,Bitmap> images=new HashMap<>();
        final int[] remaining={products.size()};
        if(products.isEmpty())return;
        for(int i=0;i<products.size();i++){
            final int index=i; Store.Product product=products.get(i); String imageUri=productShareImage(product);
            if(imageUri.isEmpty()){
                if(--remaining[0]==0)buildSelectedProductsPdfPages(products,images);
                continue;
            }
            try{
                com.bumptech.glide.Glide.with(this).asBitmap().load(imageUri).override(dp(500),dp(420)).into(new CustomTarget<Bitmap>(){
                    @Override public void onResourceReady(Bitmap bitmap,Transition<? super Bitmap> transition){
                        if(bitmap!=null)images.put(index,bitmap);
                        if(--remaining[0]==0)buildSelectedProductsPdfPages(products,images);
                    }
                    @Override public void onLoadCleared(Drawable placeholder){}
                    @Override public void onLoadFailed(Drawable errorDrawable){if(--remaining[0]==0)buildSelectedProductsPdfPages(products,images);}
                });
            }catch(Exception e){if(--remaining[0]==0)buildSelectedProductsPdfPages(products,images);}
        }
    }

    void buildSelectedProductsPdfPages(ArrayList<Store.Product> products,HashMap<Integer,Bitmap> images){
        PdfDocument doc=new PdfDocument(); Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        PdfDocument.Page page=null; Canvas c=null; int pageNo=0,y=0;
        final int pageW=595,pageH=842,cardW=255,cardH=255,gapX=15,gapY=14;
        try{
            for(int i=0;i<products.size();i++){
                if(page==null||y+cardH>805){
                    if(page!=null)doc.finishPage(page);
                    page=doc.startPage(new PdfDocument.PageInfo.Builder(pageW,pageH,++pageNo).create());
                    c=page.getCanvas();p.setColor(Color.WHITE);c.drawPaint(p);
                    p.setColor(BLUE);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(18);c.drawText("Catalogue / كتالوج المنتجات",40,38,p);
                    p.setColor(MUTED);p.setTypeface(Typeface.DEFAULT);p.setTextSize(10);c.drawText("Produits sélectionnés / المنتجات المحددة",40,57,p);y=75;
                }
                int col=i%2;int x=40+col*(cardW+gapX);int rowY=y;
                p.setColor(Color.rgb(250,251,253));c.drawRoundRect(x,rowY,x+cardW,rowY+cardH,10,10,p);
                p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);p.setColor(BORDER);c.drawRoundRect(x,rowY,x+cardW,rowY+cardH,10,10,p);p.setStyle(Paint.Style.FILL);
                Bitmap bm=images.get(i);int il=x+10,it=rowY+10,ir=x+245,ib=rowY+142;
                p.setColor(Color.WHITE);c.drawRect(il,it,ir,ib,p);
                if(bm!=null&&!bm.isRecycled())c.drawBitmap(bm,new Rect(0,0,bm.getWidth(),bm.getHeight()),fitBitmapRect(bm,il,it,ir,ib),p);
                else{p.setColor(MUTED);p.setTextSize(10);c.drawText("Image non disponible",il+70,it+65,p);}
                Store.Product product=products.get(i);
                p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(11);c.drawText(trim(safe(product.name),38),x+12,rowY+160,p);
                p.setTypeface(Typeface.DEFAULT);p.setTextSize(10);
                String priceText=productSharePriceText(product);String[] lines=priceText.split("\\n",-1);int ty=rowY+181;
                for(String line:lines){
                    ArrayList<String> wrapped=new ArrayList<>();String cur="";for(String word:line.split(" ")){String test=cur.isEmpty()?word:cur+" "+word;if(test.length()>39){wrapped.add(cur);cur=word;}else cur=test;}if(!cur.isEmpty())wrapped.add(cur);
                    for(String wl:wrapped){c.drawText(wl,x+12,ty,p);ty+=16;}
                }
                if(col==1||i==products.size()-1)y+=cardH+gapY;
            }
            if(page!=null)doc.finishPage(page);
            saveAndSharePdfDocument(doc,"Catalogue_Produits_"+new java.text.SimpleDateFormat("yyyyMMdd_HHmm",Locale.US).format(new java.util.Date())+".pdf","مشاركة كتالوج المنتجات PDF");
        }catch(Exception e){try{if(page!=null)doc.finishPage(page);}catch(Exception ignored){}try{doc.close();}catch(Exception ignored){}Toast.makeText(this,"خطأ إنشاء PDF المنتجات: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }

    void partnerProductPricesDialog(Store.Product product){
        ArrayList<Store.Customer> partners=new ArrayList<>();
        for(Store.Customer c:db.customers("")) if(c.reseller) partners.add(c);
        if(partners.isEmpty()){Toast.makeText(this,"لا يوجد شركاء بعد",Toast.LENGTH_SHORT).show();return;}
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(6),dp(6),dp(6),dp(6));
        ScrollView sv=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);sv.addView(list);box.addView(sv,new LinearLayout.LayoutParams(-1,dp(470)));
        ArrayList<EditText> prices=new ArrayList<>(),tiers=new ArrayList<>();
        for(Store.Customer partner:partners){
            Store.PartnerProductSetting ps=db.partnerProductSetting(partner.partnerId,product.id);
            TextView title=text("🤝 "+partner.name,15,TEXT);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);list.addView(title,margin(-1,dp(24),0,dp(2)));
            EditText price=input("سعر الشريك الأساسي DH");price.setInputType(2|8192);if(ps!=null&&ps.partnerPrice>0)price.setText(money(ps.partnerPrice));prices.add(price);list.addView(price,margin(-1,dp(48),0,dp(5)));
            EditText tier=input("أسعار الكمية للشريك — مثال: 10=50;20=45");tier.setSingleLine(true);if(ps!=null)tier.setText(safe(ps.priceTiers));tiers.add(tier);list.addView(tier,margin(-1,dp(48),0,dp(8)));
        }
        new AlertDialog.Builder(this).setTitle("أسعار الشركاء • "+safe(product.name)).setView(box).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",(d,w)->{
            for(int idx=0;idx<partners.size();idx++){Store.Customer partner=partners.get(idx);double price=toD(prices.get(idx).getText().toString());String pt=tiers.get(idx).getText().toString().trim();Store.PartnerProductSetting old=db.partnerProductSetting(partner.partnerId,product.id);String image=old==null?"":safe(old.customerImage);db.savePartnerProductSetting(partner.partnerId,product.id,price,pt,image);}
            if(cloud!=null&&cloud.isAdmin())cloud.syncPartnerProductSettingsToCloud(()->{},()->{});showProducts();
        }).show();
    }

    void partnerOwnPriceDialog(Store.Product product){
        if(cloud==null||cloud.partnerId<=0)return;
        int partnerId=(int)cloud.partnerId;Store.PartnerProductSetting old=db.partnerProductSetting(partnerId,product.id);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(8),dp(4),dp(8),dp(4));
        EditText price=input("سعر البيع الأساسي لزبائنك DH");price.setInputType(2|8192);if(old!=null&&old.partnerPrice>0)price.setText(money(old.partnerPrice));box.addView(price,margin(-1,dp(48),0,dp(8)));
        EditText tiers=input("أسعار الكمية — مثال: 10=50;20=45");if(old!=null)tiers.setText(safe(old.priceTiers));box.addView(tiers,margin(-1,dp(48),0,dp(8)));
        TextView hint=text("السعر هنا خاص بزبائنك فقط ولا يغيّر سعر المتجر. عند إضافة 10 قطع أو أكثر سيطبق السعر المحدد في أسعار الكمية تلقائيًا.",12,MUTED);hint.setGravity(Gravity.CENTER);box.addView(hint);
        new AlertDialog.Builder(this).setTitle("سعر البيع الخاص • "+safe(product.name)).setView(box).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",(d,w)->{
            double v=toD(price.getText().toString());String pt=tiers.getText().toString().trim();String image=old==null?"":safe(old.customerImage);db.savePartnerProductSetting(partnerId,product.id,v,pt,image);
            if(cloud!=null)cloud.syncPartnerProductSettingsToCloud(()->{},()->{});showProducts();Toast.makeText(this,"تم حفظ سعرك الخاص وأسعار الكمية",Toast.LENGTH_SHORT).show();
        }).show();
    }

    void partnerProductImageDialog(Store.Product product){
        if(cloud==null||cloud.partnerId<=0)return;
        int partnerId=(int)cloud.partnerId;Store.PartnerProductSetting old=db.partnerProductSetting(partnerId,product.id);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(8),dp(4),dp(8),dp(4));
        EditText image=input("صورة الزبائن (بدون سعر)");image.setSingleLine(true);image.setText(old==null?"":safe(old.customerImage));box.addView(image,margin(-1,dp(48),0,dp(8)));
        Button pick=button("🖼 اختيار صورة من الهاتف");pick.setTextColor(Color.WHITE);pick.setBackground(solid(BLUE,10));pick.setOnClickListener(v->openProductGallery(image));box.addView(pick,margin(-1,dp(46),0,dp(8)));
        TextView hint=text("هذه الصورة خاصة بحسابك وتستعمل فقط لمشاركتها مع زبائنك. لن نغير صورة المنتج الأصلية التي تحتوي على سعر المتجر.",12,MUTED);hint.setGravity(Gravity.CENTER);box.addView(hint);
        new AlertDialog.Builder(this).setTitle("صورة المنتج للزبائن").setView(box).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",(d,w)->{
            String path=image.getText().toString().trim();double price=old!=null?old.partnerPrice:db.partnerPrice(partnerId,product.id);String tiers=old==null?"":safe(old.priceTiers);db.savePartnerProductSetting(partnerId,product.id,price,tiers,path);
            if(cloud!=null)cloud.syncPartnerProductSettingsToCloud(()->{},()->{});showProducts();Toast.makeText(this,"تم حفظ صورة الزبائن",Toast.LENGTH_SHORT).show();
        }).show();
    }

    void shareProductCustomerImage(String title,String imageUri){
        if(imageUri==null||imageUri.trim().isEmpty()){Toast.makeText(this,"أضف صورة خاصة للزبائن أولاً",Toast.LENGTH_SHORT).show();return;}
        try{
            final String fileName="MGE_"+safeFileName(title)+"_client.jpg";
            final Bitmap[] holder={null};
            com.bumptech.glide.Glide.with(this).asBitmap().load(imageUri).override(dp(1200),dp(1200)).into(new CustomTarget<Bitmap>(){
                @Override public void onResourceReady(Bitmap bitmap,Transition<? super Bitmap> transition){
                    try{Uri uri=saveShareImage(bitmap,fileName);Intent share=new Intent(Intent.ACTION_SEND);share.setType("image/jpeg");share.putExtra(Intent.EXTRA_STREAM,uri);share.putExtra(Intent.EXTRA_TEXT,title);share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);share.setClipData(ClipData.newRawUri("image",uri));startActivity(Intent.createChooser(share,"مشاركة صورة المنتج مع الزبون"));}catch(Exception e){Toast.makeText(MainActivity.this,"تعذر مشاركة الصورة: "+e.getMessage(),Toast.LENGTH_LONG).show();}
                }
                @Override public void onLoadCleared(Drawable placeholder){}
                @Override public void onLoadFailed(Drawable errorDrawable){Toast.makeText(MainActivity.this,"تعذر تحميل صورة الزبائن",Toast.LENGTH_SHORT).show();}
            });
        }catch(Exception e){Toast.makeText(this,"تعذر مشاركة الصورة",Toast.LENGTH_SHORT).show();}
    }

    Uri saveShareImage(Bitmap bitmap,String fileName)throws Exception{
        ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,fileName);v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");if(Build.VERSION.SDK_INT>=29)v.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/MGE");Uri uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);if(uri==null)throw new IOException("تعذر إنشاء ملف الصورة");try(OutputStream os=getContentResolver().openOutputStream(uri)){if(os==null)throw new IOException("تعذر فتح ملف الصورة");bitmap.compress(Bitmap.CompressFormat.JPEG,92,os);}return uri;
    }

    ImageButton productActionButton(int iconRes,String description,int tint){
        ImageButton b=new ImageButton(this);
        b.setImageResource(iconRes);
        b.setColorFilter(tint);
        b.setContentDescription(description);
        b.setPadding(dp(11),dp(11),dp(11),dp(11));
        b.setBackground(round(Color.WHITE,BORDER,12,1));
        b.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        if(Build.VERSION.SDK_INT>=21)b.setStateListAnimator(null);
        return b;
    }

    void showProductImageZoom(String title,String imageUri){
        if(imageUri==null || imageUri.trim().isEmpty()){
            Toast.makeText(this,"لا توجد صورة لهذا المنتج",Toast.LENGTH_SHORT).show();
            return;
        }

        Dialog dialog=new Dialog(this,android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        LinearLayout wrap=new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setBackgroundColor(Color.rgb(12,18,28));

        LinearLayout top=new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(8),dp(8),dp(8),dp(8));

        TextView close=text("×",34,Color.WHITE);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v->dialog.dismiss());
        top.addView(close,new LinearLayout.LayoutParams(dp(54),dp(54)));

        TextView titleView=text(safe(title),17,Color.WHITE);
        titleView.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        titleView.setMaxLines(2);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        titleView.setGravity(Gravity.CENTER);
        top.addView(titleView,new LinearLayout.LayoutParams(0,dp(54),1));

        TextView counter=text("تكبير / تصغير بإصبعين",11,Color.LTGRAY);
        counter.setGravity(Gravity.CENTER);
        top.addView(counter,new LinearLayout.LayoutParams(dp(120),dp(54)));
        wrap.addView(top);

        ZoomImageView zoom=new ZoomImageView(this);
        zoom.setBackgroundColor(Color.rgb(8,12,18));
        zoom.setScaleType(ImageView.ScaleType.MATRIX);
        zoom.setOnClickListener(v->{ if(zoom.isAtBaseScale()) dialog.dismiss(); });
        loadImage(zoom,imageUri);
        wrap.addView(zoom,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout bottom=new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        bottom.setPadding(dp(12),dp(8),dp(12),dp(14));

        TextView info=text("اسحب الصورة للتحريك • قرّب إصبعين للتكبير",12,Color.LTGRAY);
        info.setGravity(Gravity.CENTER);
        bottom.addView(info,new LinearLayout.LayoutParams(0,dp(42),1));

        Button download=button("⬇ تحميل");
        download.setTextColor(Color.WHITE);
        download.setBackground(solid(BLUE,10));
        download.setOnClickListener(v->downloadProductImage(title,imageUri));
        bottom.addView(download,new LinearLayout.LayoutParams(dp(112),dp(44)));
        wrap.addView(bottom);

        dialog.setContentView(wrap);
        Window w=dialog.getWindow();
        if(w!=null){w.setStatusBarColor(Color.rgb(8,12,18));w.setNavigationBarColor(Color.rgb(8,12,18));}
        dialog.show();
    }

    void downloadProductImage(String title,String imageUri){
        if(imageUri==null || imageUri.trim().isEmpty()){
            Toast.makeText(this,"لا توجد صورة لتحميلها",Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(this,"جاري تحميل الصورة…",Toast.LENGTH_SHORT).show();
        com.bumptech.glide.Glide.with(this)
                .asBitmap()
                .load(imageUri)
                .into(new CustomTarget<Bitmap>(){
                    @Override public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition){
                        saveDownloadedProductImage(title,bitmap);
                    }
                    @Override public void onLoadCleared(Drawable placeholder){}
                    @Override public void onLoadFailed(Drawable errorDrawable){
                        Toast.makeText(MainActivity.this,"تعذر تحميل الصورة",Toast.LENGTH_LONG).show();
                    }
                });
    }

    void saveDownloadedProductImage(String title,Bitmap bitmap){
        if(bitmap==null){
            Toast.makeText(this,"تعذر تحميل الصورة",Toast.LENGTH_LONG).show();
            return;
        }
        String name=safeFileName(title);
        if(name.isEmpty())name="product";
        name=name+"_"+System.currentTimeMillis()+".jpg";
        try{
            if(Build.VERSION.SDK_INT>=29){
                ContentValues values=new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME,name);
                values.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
                values.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/MGE");
                values.put(MediaStore.Images.Media.IS_PENDING,1);
                Uri uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);
                if(uri==null)throw new IOException("تعذر إنشاء ملف الصورة");
                try(OutputStream out=getContentResolver().openOutputStream(uri)){
                    if(out==null)throw new IOException("تعذر فتح ملف الصورة");
                    if(!bitmap.compress(Bitmap.CompressFormat.JPEG,95,out))throw new IOException("تعذر حفظ الصورة");
                }
                ContentValues done=new ContentValues();done.put(MediaStore.Images.Media.IS_PENDING,0);
                getContentResolver().update(uri,done,null,null);
                Toast.makeText(this,"تم تحميل الصورة إلى Pictures/MGE",Toast.LENGTH_LONG).show();
            }else{
                File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),"MGE");
                if(!dir.exists()&&!dir.mkdirs())throw new IOException("تعذر إنشاء مجلد الصور");
                File file=new File(dir,name);
                try(FileOutputStream out=new FileOutputStream(file)){
                    if(!bitmap.compress(Bitmap.CompressFormat.JPEG,95,out))throw new IOException("تعذر حفظ الصورة");
                }
                sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,Uri.fromFile(file)));
                Toast.makeText(this,"تم تحميل الصورة إلى Pictures/MGE",Toast.LENGTH_LONG).show();
            }
        }catch(Exception e){
            Toast.makeText(this,"خطأ في تحميل الصورة: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    class ZoomImageView extends ImageView{
        private final Matrix matrix=new Matrix();
        private final float[] values=new float[9];
        private float scale=1f,lastX,lastY;
        private boolean dragging=false;
        private android.view.ScaleGestureDetector detector;
        ZoomImageView(Context c){
            super(c);
            detector=new android.view.ScaleGestureDetector(c,new android.view.ScaleGestureDetector.SimpleOnScaleGestureListener(){
                public boolean onScale(android.view.ScaleGestureDetector d){
                    float next=scale*d.getScaleFactor();
                    next=Math.max(1f,Math.min(next,5f));
                    float factor=next/scale;
                    matrix.postScale(factor,factor,d.getFocusX(),d.getFocusY());
                    scale=next;
                    setImageMatrix(matrix);
                    return true;
                }
            });
        }
        boolean isAtBaseScale(){return scale<=1.01f;}
        protected void onSizeChanged(int w,int h,int ow,int oh){super.onSizeChanged(w,h,ow,oh);centerImage();}
        protected void onDraw(Canvas c){super.onDraw(c);}
        void centerImage(){
            Drawable d=getDrawable();
            if(d==null || getWidth()<=0 || getHeight()<=0)return;
            float dw=d.getIntrinsicWidth(),dh=d.getIntrinsicHeight();
            if(dw<=0||dh<=0)return;
            float s=Math.min(getWidth()/dw,getHeight()/dh);
            matrix.reset();
            matrix.postScale(s,s);
            matrix.postTranslate((getWidth()-dw*s)/2f,(getHeight()-dh*s)/2f);
            scale=1f;
            setImageMatrix(matrix);
        }
        protected void drawableStateChanged(){super.drawableStateChanged();postDelayed(()->{if(scale==1f)centerImage();},50);}
        public boolean onTouchEvent(android.view.MotionEvent e){
            detector.onTouchEvent(e);
            switch(e.getActionMasked()){
                case android.view.MotionEvent.ACTION_DOWN:
                    lastX=e.getX();lastY=e.getY();dragging=true;return true;
                case android.view.MotionEvent.ACTION_MOVE:
                    if(!detector.isInProgress() && dragging){
                        float dx=e.getX()-lastX,dy=e.getY()-lastY;
                        if(scale>1.01f){matrix.postTranslate(dx,dy);setImageMatrix(matrix);}
                        lastX=e.getX();lastY=e.getY();
                    }
                    return true;
                case android.view.MotionEvent.ACTION_UP:
                case android.view.MotionEvent.ACTION_CANCEL:
                    dragging=false;return true;
            }
            return true;
        }
    }

    void deleteReplacedLocalImage(String oldImage,String newImage){
        if(oldImage==null||oldImage.isEmpty()||oldImage.equals(newImage))return;
        try{if(oldImage.startsWith("file://")){File f=new File(Uri.parse(oldImage).getPath());File base=new File(getFilesDir(),"product_images").getCanonicalFile();if(f.getCanonicalPath().startsWith(base.getCanonicalPath()+File.separator))f.delete();}}catch(Exception ignored){}
    }

    void productDialog(int id){
        Store.Product o=id<0?null:db.product(id);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(5),0,dp(5),0);
        EditText n=input("اسم المنتج"),c=input("الكود"),pr=input("السعر الأساسي DH"),img=input("الصورة (يتم اختيارها من الهاتف)"),tiers=input("أسعار الكمية — مثال: 10=60;20=55");
        CheckBox available=new CheckBox(this); available.setText("المنتج متوفر للبيع وإظهاره في الفاتورة"); available.setGravity(Gravity.RIGHT); available.setChecked(o==null || o.available);
        if(o!=null){n.setText(o.name);c.setText(o.code);pr.setText(money(o.price));img.setText(safe(o.image));tiers.setText(safe(o.priceTiers));}
        box.addView(n,margin(-1,dp(48),0,dp(7)));box.addView(c,margin(-1,dp(48),0,dp(7)));
        box.addView(pr,margin(-1,dp(48),0,dp(7)));box.addView(tiers,margin(-1,dp(48),0,dp(7)));box.addView(available,margin(-1,dp(48),0,dp(7)));
        box.addView(img,margin(-1,dp(48),0,dp(7)));

        Button pick=button("🖼  اختيار صورة المنتج");
        pick.setTextSize(14);
        pick.setOnClickListener(v->openProductGallery(img));
        box.addView(pick,margin(-1,dp(48),0,dp(6)));
        if(o!=null && cloud!=null && cloud.isAdmin()){ Button partnerPrices=button("🤝  تحديد سعر خاص للشركاء");partnerPrices.setTextColor(BLUE);partnerPrices.setBackground(round(Color.rgb(239,246,255),Color.rgb(211,226,246),10,1));partnerPrices.setOnClickListener(v->partnerProductPricesDialog(o));box.addView(partnerPrices,margin(-1,dp(46),0,dp(6))); }
        TextView imageHint=text("الصورة الأصلية للمنتج تبقى كما هي. صورة الشريك للزبائن تضاف من حساب الشريك.",11,MUTED);
        imageHint.setGravity(Gravity.CENTER);
        box.addView(imageHint);

        AlertDialog d=new AlertDialog.Builder(this).setTitle(id<0?"إضافة منتج":"تعديل المنتج").setView(box)
            .setPositiveButton("حفظ",(x,w)->{String oldImage=o==null?"":safe(o.image);String newImage=img.getText().toString().trim();db.saveProduct(id,n.getText().toString().trim(),c.getText().toString().trim(),toD(pr.getText().toString()),newImage,available.isChecked(),tiers.getText().toString().trim());deleteReplacedLocalImage(oldImage,newImage);showProducts();if(cloud!=null&&cloud.isAdmin())cloud.syncProductsToCloud(()->{},()->{});})
            .setNegativeButton("إلغاء",null).create();
        d.show();
    }

    void showSuppliers(){
        base("الموردين");
        TextView hint=text("إدارة شركات الموردين ومنتجات كل مورد وإنشاء طلبيات جاهزة للإرسال",13,MUTED);hint.setGravity(Gravity.CENTER);body.addView(hint,margin(-1,dp(42),0,dp(4)));
        EditText search=input("🔎  ابحث باسم المورد أو الهاتف");body.addView(search,margin(-1,dp(48),0,dp(8)));
        Button add=button("＋  إضافة شركة مورد جديدة");add.setTextColor(Color.WHITE);add.setBackground(solid(BLUE,12));add.setOnClickListener(v->supplierDialog(-1));body.addView(add,margin(-1,dp(48),0,dp(8)));
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);body.addView(list);
        Runnable refresh=()->{list.removeAllViews();for(Store.Supplier sp:db.suppliers(search.getText().toString()))supplierRow(list,sp);};watch(search,refresh);refresh.run();
    }

    void supplierRow(LinearLayout list,Store.Supplier sp){
        LinearLayout r=card();r.setPadding(dp(10),dp(9),dp(10),dp(9));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon=text("🏭",28,BLUE);icon.setGravity(Gravity.CENTER);top.addView(icon,new LinearLayout.LayoutParams(dp(58),dp(58)));
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(8),0,dp(8),0);
        TextView n=text(sp.name,17,TEXT);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);info.addView(n);
        if(sp.phone!=null&&!sp.phone.isEmpty())info.addView(text("📞 "+sp.phone,12,MUTED));
        if(sp.address!=null&&!sp.address.isEmpty())info.addView(text("📍 "+sp.address,12,MUTED));
        top.addView(info,new LinearLayout.LayoutParams(0,dp(78),1));
        Button edit=button("✎");edit.setTextColor(BLUE);edit.setBackgroundColor(Color.TRANSPARENT);edit.setOnClickListener(v->supplierDialog(sp.id));top.addView(edit,new LinearLayout.LayoutParams(dp(44),dp(50)));
        Button del=button("🗑");del.setTextColor(RED);del.setBackgroundColor(Color.TRANSPARENT);del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف المورد").setMessage("سيتم حذف المورد ومنتجاته وطلبياته المحفوظة. هل تريد المتابعة؟").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(d,w)->{db.deleteSupplier(sp.id);showSuppliers();}).show());top.addView(del,new LinearLayout.LayoutParams(dp(44),dp(50)));
        r.addView(top);
        Button open=button("📦  فتح منتجات المورد وإنشاء طلبية");open.setTextColor(Color.WHITE);open.setBackground(solid(BLUE,10));open.setOnClickListener(v->{currentSupplierId=sp.id;selectedSupplierProductIds.clear();supplierOrderQty.clear();showSupplierProducts(sp.id);});r.addView(open,margin(-1,dp(46),0,0));
        list.addView(r,margin(-1,-2,0,dp(7)));
    }

    void supplierDialog(int id){
        Store.Supplier o=id<0?null:db.supplier(id);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(5),0,dp(5),0);
        EditText n=input("اسم شركة المورد"),ph=input("الهاتف"),em=input("البريد الإلكتروني"),ad=input("العنوان"),no=input("ملاحظات");
        if(o!=null){n.setText(safe(o.name));ph.setText(safe(o.phone));em.setText(safe(o.email));ad.setText(safe(o.address));no.setText(safe(o.notes));}
        box.addView(n,margin(-1,dp(48),0,dp(7)));box.addView(ph,margin(-1,dp(48),0,dp(7)));box.addView(em,margin(-1,dp(48),0,dp(7)));box.addView(ad,margin(-1,dp(48),0,dp(7)));box.addView(no,margin(-1,dp(48),0,dp(7)));
        new AlertDialog.Builder(this).setTitle(id<0?"إضافة مورد":"تعديل المورد").setView(box).setPositiveButton("حفظ",(d,w)->{String name=n.getText().toString().trim();if(name.isEmpty()){Toast.makeText(this,"أدخل اسم المورد",Toast.LENGTH_SHORT).show();return;}db.saveSupplier(id,name,ph.getText().toString().trim(),em.getText().toString().trim(),ad.getText().toString().trim(),no.getText().toString().trim());showSuppliers();}).setNegativeButton("إلغاء",null).show();
    }

    void showSupplierProducts(int supplierId){
        Store.Supplier sp=db.supplier(supplierId);if(sp==null){showSuppliers();return;}currentSupplierId=supplierId;
        base("منتجات المورد");
        TextView hint=text("المورد: "+safe(sp.name)+" — اختر المنتجات واكتب الكمية المطلوبة",13,MUTED);hint.setGravity(Gravity.CENTER);body.addView(hint,margin(-1,dp(34),0,dp(5)));
        EditText search=input("🔎  ابحث باسم المنتج أو الكود");body.addView(search,margin(-1,dp(48),0,dp(7)));
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
        Button add=button("＋ إضافة منتج");add.setTextColor(Color.WHITE);add.setBackground(solid(BLUE,10));add.setOnClickListener(v->supplierProductDialog(-1,supplierId));actions.addView(add,new LinearLayout.LayoutParams(0,dp(46),1));
        Button history=button("📚 الطلبيات المحفوظة");history.setTextColor(Color.WHITE);history.setBackground(solid(BLUE_DARK,10));history.setOnClickListener(v->showSupplierOrders(supplierId));LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(0,dp(46),1);hp.setMargins(dp(6),0,0,0);actions.addView(history,hp);
        Button order=button("📄 تصدير وحفظ الطلبية");order.setTextColor(Color.WHITE);order.setBackground(solid(GREEN,10));order.setOnClickListener(v->exportSupplierOrderPdf(supplierId));LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(-1,dp(46));op.setMargins(0,dp(7),0,0);body.addView(actions,margin(-1,dp(46),0,0));body.addView(order,op);
        TextView sel=text("☑️ الطلبية سيتم حفظها تلقائيًا عند التصدير ويمكن تعديلها أو حذفها لاحقًا",12,MUTED);sel.setGravity(Gravity.CENTER);body.addView(sel,margin(-1,dp(30),0,dp(6)));
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);body.addView(list);
        Runnable refresh=()->{list.removeAllViews();for(Store.SupplierProduct p:db.supplierProducts(supplierId,search.getText().toString()))supplierProductRow(list,p);};watch(search,refresh);refresh.run();
    }

    void supplierProductRow(LinearLayout list,Store.SupplierProduct p){
        // بطاقة المنتج: اسم المنتج في سطر مستقل بعرض البطاقة بالكامل حتى لا يتم اقتطاعه.
        LinearLayout r=card();
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(dp(10),dp(8),dp(10),dp(8));

        TextView n=text(safe(p.name),16,TEXT);
        n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        n.setGravity(Gravity.CENTER);
        n.setMaxLines(0);
        n.setSingleLine(false);
        n.setEllipsize(null);
        n.setIncludeFontPadding(true);
        r.addView(n,margin(-1,-2,0,dp(5)));

        LinearLayout row= new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        CheckBox cb=new CheckBox(this);
        cb.setChecked(selectedSupplierProductIds.contains(p.id));
        cb.setText("");
        cb.setOnCheckedChangeListener((b,is)->{
            if(is) selectedSupplierProductIds.add(p.id); else selectedSupplierProductIds.remove(p.id);
        });
        row.addView(cb,new LinearLayout.LayoutParams(dp(42),dp(72)));

        String supplierImage=safe(p.image).trim();
        if(supplierImage.isEmpty()) supplierImage=db.productImageForSupplier(p.code,p.name);
        ImageView productImage=new ImageView(this);
        loadImage(productImage,supplierImage);
        productImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        productImage.setBackground(round(Color.rgb(249,251,255),Color.rgb(220,228,240),10,1));
        productImage.setContentDescription("صورة المنتج "+safe(p.name));
        final String zoomImage=supplierImage;
        productImage.setOnClickListener(v->{if(!zoomImage.isEmpty())showProductImageZoom(p.name,zoomImage);});
        row.addView(productImage,new LinearLayout.LayoutParams(dp(70),dp(70)));

        LinearLayout info=new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setGravity(Gravity.CENTER_VERTICAL);
        TextView meta=text("Code: "+safe(p.code)+"  •  "+money(p.price)+" DH",12,MUTED);
        meta.setGravity(Gravity.CENTER);
        info.addView(meta,margin(-1,dp(24),0,dp(3)));

        EditText qty=input("الكمية");
        qty.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        qty.setText(supplierOrderQty.containsKey(p.id)?String.valueOf(supplierOrderQty.get(p.id)):"");
        qty.setGravity(Gravity.CENTER);
        qty.setSelectAllOnFocus(false);
        qty.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int a,int b,int c){}
            public void onTextChanged(CharSequence s,int a,int b,int c){
                try{int q=Integer.parseInt(s.toString().trim());if(q>0){supplierOrderQty.put(p.id,q);selectedSupplierProductIds.add(p.id);}else supplierOrderQty.remove(p.id);}
                catch(Exception e){supplierOrderQty.remove(p.id);}
            }
            public void afterTextChanged(Editable e){}
        });
        info.addView(qty,margin(-1,dp(42),0,0));
        row.addView(info,new LinearLayout.LayoutParams(0,-2,1));

        Button edit=button("✎");
        edit.setTextColor(BLUE);edit.setBackgroundColor(Color.TRANSPARENT);
        edit.setOnClickListener(v->supplierProductDialog(p.id,p.supplierId));
        row.addView(edit,new LinearLayout.LayoutParams(dp(40),dp(50)));

        Button del=button("🗑");
        del.setTextColor(RED);del.setBackgroundColor(Color.TRANSPARENT);
        del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف المنتج").setMessage("هل تريد حذف هذا المنتج من المورد؟").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(d,w)->{db.deleteSupplierProduct(p.id);selectedSupplierProductIds.remove(p.id);supplierOrderQty.remove(p.id);showSupplierProducts(p.supplierId);}).show());
        row.addView(del,new LinearLayout.LayoutParams(dp(40),dp(50)));

        r.addView(row,margin(-1,-2,0,0));
        list.addView(r,margin(-1,-2,0,dp(7)));
    }

    void supplierProductDialog(int id,int supplierId){
        Store.SupplierProduct o=id<0?null:db.supplierProduct(id);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(5),0,dp(5),0);
        EditText n=input("اسم المنتج"),c=input("كود المنتج"),pr=input("سعر المورد DH"),img=input("الصورة"),no=input("ملاحظات");
        if(o!=null){n.setText(safe(o.name));c.setText(safe(o.code));pr.setText(money(o.price));img.setText(safe(o.image));no.setText(safe(o.notes));}
        box.addView(n,margin(-1,dp(48),0,dp(7)));box.addView(c,margin(-1,dp(48),0,dp(7)));box.addView(pr,margin(-1,dp(48),0,dp(7)));box.addView(img,margin(-1,dp(48),0,dp(7)));
        Button pick=button("🖼 اختيار صورة المنتج");pick.setTextColor(BLUE);pick.setOnClickListener(v->openProductGallery(img));box.addView(pick,margin(-1,dp(46),0,dp(7)));box.addView(no,margin(-1,dp(48),0,dp(7)));
        new AlertDialog.Builder(this).setTitle(id<0?"إضافة منتج للمورد":"تعديل منتج المورد").setView(box).setPositiveButton("حفظ",(d,w)->{String name=n.getText().toString().trim();if(name.isEmpty()){Toast.makeText(this,"أدخل اسم المنتج",Toast.LENGTH_SHORT).show();return;}db.saveSupplierProduct(id,supplierId,name,c.getText().toString().trim(),toD(pr.getText().toString()),img.getText().toString().trim(),no.getText().toString().trim());showSupplierProducts(supplierId);}).setNegativeButton("إلغاء",null).show();
    }

    ArrayList<Store.SupplierOrderItem> selectedSupplierOrderItems(int supplierId){
        ArrayList<Store.SupplierOrderItem> rows=new ArrayList<>();
        for(Store.SupplierProduct x:db.supplierProducts(supplierId,"")){
            if(selectedSupplierProductIds.contains(x.id)&&supplierOrderQty.containsKey(x.id)&&supplierOrderQty.get(x.id)>0){int q=supplierOrderQty.get(x.id);rows.add(new Store.SupplierOrderItem(0,0,x.id,x.name,x.code,x.price,q,x.price*q));}
        }
        return rows;
    }

    void exportSupplierOrderPdf(int supplierId){
        Store.Supplier sp=db.supplier(supplierId);if(sp==null)return;
        ArrayList<Store.SupplierOrderItem> rows=selectedSupplierOrderItems(supplierId);
        if(rows.isEmpty()){Toast.makeText(this,"حدد المنتجات وأدخل الكمية أولاً",Toast.LENGTH_LONG).show();return;}
        String date=new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.US).format(new Date());
        int orderId;
        try{orderId=db.createSupplierOrder(supplierId,rows,date);}catch(Exception e){Toast.makeText(this,"تعذر حفظ الطلبية: "+e.getMessage(),Toast.LENGTH_LONG).show();return;}
        Toast.makeText(this,"تم حفظ الطلبية رقم #"+orderId,Toast.LENGTH_SHORT).show();
        askSupplierPdfCompanyOption(orderId);
    }

    void askSupplierPdfCompanyOption(int orderId){
        CheckBox showCompany=new CheckBox(this);showCompany.setText("إظهار اسم شركتي في PDF");showCompany.setChecked(false);showCompany.setPadding(dp(8),dp(8),dp(8),dp(8));
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(12),0,dp(12),0);box.addView(showCompany);
        new AlertDialog.Builder(this).setTitle("تصدير طلبية المورد").setMessage("يمكنك اختيار إظهار اسم شركتك أو ترك الفاتورة بدون اسم شركة.").setView(box).setPositiveButton("📄 تصدير PDF",(d,w)->exportSavedSupplierOrderPdf(orderId,showCompany.isChecked())).setNegativeButton("لاحقًا",null).show();
    }

    void showSupplierOrders(int supplierId){
        Store.Supplier sp=db.supplier(supplierId);if(sp==null){showSuppliers();return;}
        base("الطلبيات المحفوظة");TextView h=text("📚 طلبيات المورد: "+safe(sp.name),15,TEXT);h.setGravity(Gravity.CENTER);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);body.addView(h,margin(-1,dp(42),0,dp(7)));
        Button back=button("← العودة إلى منتجات المورد");back.setTextColor(BLUE);back.setOnClickListener(v->showSupplierProducts(supplierId));body.addView(back,margin(-1,dp(44),0,dp(8)));
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);body.addView(list);
        ArrayList<Store.SupplierOrder> orders=db.supplierOrders(supplierId);
        if(orders.isEmpty()){TextView empty=text("لا توجد طلبيات محفوظة لهذا المورد بعد",14,MUTED);empty.setGravity(Gravity.CENTER);list.addView(empty,margin(-1,dp(70),0,0));return;}
        for(Store.SupplierOrder o:orders){
            LinearLayout r=card();r.setOrientation(LinearLayout.VERTICAL);
            TextView title=text("طلبية #"+o.id+"  •  "+safe(o.date),16,TEXT);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);title.setGravity(Gravity.RIGHT);r.addView(title,margin(-1,dp(30),0,dp(3)));
            TextView total=text("الإجمالي: "+money(o.total)+" DH",14,BLUE);total.setGravity(Gravity.RIGHT);r.addView(total,margin(-1,dp(26),0,dp(5)));
            LinearLayout a=new LinearLayout(this);a.setOrientation(LinearLayout.HORIZONTAL);
            Button review=button("✎ مراجعة / تعديل");review.setTextColor(BLUE);review.setOnClickListener(v->showSupplierOrderEdit(o.id));a.addView(review,new LinearLayout.LayoutParams(0,dp(44),1));
            Button pdf=button("📄 PDF");pdf.setTextColor(GREEN);pdf.setOnClickListener(v->askSupplierPdfCompanyOption(o.id));LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(0,dp(44),1);pp.setMargins(dp(5),0,0,0);a.addView(pdf,pp);
            Button del=button("🗑 حذف");del.setTextColor(RED);del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف الطلبية #"+o.id).setMessage("سيتم حذف الطلبية المحفوظة نهائيًا. هل تريد المتابعة؟").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(d,w)->{db.deleteSupplierOrder(o.id);showSupplierOrders(supplierId);}).show());LinearLayout.LayoutParams dp2=new LinearLayout.LayoutParams(0,dp(44),1);dp2.setMargins(dp(5),0,0,0);a.addView(del,dp2);
            r.addView(a);list.addView(r,margin(-1,-2,0,dp(8)));
        }
    }

    void showSupplierOrderEdit(int orderId){
        Store.SupplierOrder order=db.supplierOrder(orderId);if(order==null)return;Store.Supplier sp=db.supplier(order.supplierId);if(sp==null)return;
        base("تعديل طلبية #"+order.id);TextView h=text("المورد: "+safe(sp.name)+"  •  الطلبية #"+order.id,15,TEXT);h.setGravity(Gravity.CENTER);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);body.addView(h,margin(-1,dp(42),0,dp(6)));
        TextView hint=text("يمكنك تعديل الكميات ثم حفظ التعديل. المنتجات محفوظة كنسخة داخل الطلبية.",12,MUTED);hint.setGravity(Gravity.CENTER);body.addView(hint,margin(-1,dp(34),0,dp(7)));
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);body.addView(list);
        ArrayList<Store.SupplierOrderItem> items=db.supplierOrderItems(orderId);ArrayList<EditText> qtyFields=new ArrayList<>();
        for(Store.SupplierOrderItem it:items){LinearLayout r=card();r.setOrientation(LinearLayout.HORIZONTAL);LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);TextView n=text(safe(it.name),14,TEXT);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);n.setGravity(Gravity.RIGHT);info.addView(n,margin(-1,dp(28),0,0));TextView m=text("Code: "+safe(it.code)+" • "+money(it.price)+" DH",12,MUTED);m.setGravity(Gravity.RIGHT);info.addView(m,margin(-1,dp(24),0,0));r.addView(info,new LinearLayout.LayoutParams(0,-2,1));EditText q=input("الكمية");q.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);q.setText(String.valueOf(it.qty));q.setGravity(Gravity.CENTER);qtyFields.add(q);r.addView(q,new LinearLayout.LayoutParams(dp(90),dp(48)));list.addView(r,margin(-1,-2,0,dp(6)));}
        Button save=button("💾 حفظ التعديل");save.setTextColor(Color.WHITE);save.setBackground(solid(GREEN,10));save.setOnClickListener(v->{ArrayList<Store.SupplierOrderItem> updated=new ArrayList<>();for(int i=0;i<items.size();i++){int q=0;try{q=Integer.parseInt(qtyFields.get(i).getText().toString().trim());}catch(Exception ignored){}if(q>0){Store.SupplierOrderItem old=items.get(i);updated.add(new Store.SupplierOrderItem(0,orderId,old.productId,old.name,old.code,old.price,q,old.price*q));}}if(updated.isEmpty()){Toast.makeText(this,"يجب أن تحتوي الطلبية على منتج واحد على الأقل",Toast.LENGTH_LONG).show();return;}db.updateSupplierOrder(orderId,updated);Toast.makeText(this,"تم حفظ تعديل الطلبية",Toast.LENGTH_SHORT).show();showSupplierOrderEdit(orderId);});body.addView(save,margin(-1,dp(48),0,dp(7)));
        LinearLayout a=new LinearLayout(this);a.setOrientation(LinearLayout.HORIZONTAL);Button pdf=button("📄 تصدير PDF");pdf.setTextColor(BLUE);pdf.setOnClickListener(v->askSupplierPdfCompanyOption(orderId));a.addView(pdf,new LinearLayout.LayoutParams(0,dp(46),1));Button back=button("← الطلبيات");back.setTextColor(BLUE);back.setOnClickListener(v->showSupplierOrders(order.supplierId));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(46),1);bp.setMargins(dp(6),0,0,0);a.addView(back,bp);body.addView(a,margin(-1,dp(46),0,0));
    }

    void exportSavedSupplierOrderPdf(int orderId,boolean showCompany){
        Store.SupplierOrder order=db.supplierOrder(orderId);if(order==null)return;Store.Supplier sp=db.supplier(order.supplierId);if(sp==null)return;ArrayList<Store.SupplierOrderItem> rows=db.supplierOrderItems(orderId);if(rows.isEmpty()){Toast.makeText(this,"الطلبية فارغة",Toast.LENGTH_LONG).show();return;}
        PdfDocument doc=new PdfDocument();Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);PdfDocument.Page page=null;Canvas c=null;int pageNo=0,y=0;double grand=0;
        String date=safe(order.date);
        try{
            for(Store.SupplierOrderItem x:rows){
                double total=x.price*x.qty;
                if(page==null||y>755){
                    if(page!=null)doc.finishPage(page);page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,++pageNo).create());c=page.getCanvas();p.setColor(Color.WHITE);c.drawPaint(p);
                    p.setColor(BLUE);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(showCompany?22:20);c.drawText(showCompany?safe(db.get("company_name","MGE")):"COMMANDE FOURNISSEUR",40,50,p);
                    p.setColor(TEXT);p.setTextSize(15);c.drawText("COMMANDE FOURNISSEUR #"+order.id,40,78,p);c.drawText("Supplier: "+safe(sp.name),40,100,p);c.drawText("Date: "+date,40,122,p);
                    p.setColor(BLUE);p.setTextSize(12);c.drawText("Product",40,152,p);c.drawText("Code",250,152,p);c.drawText("Price",350,152,p);c.drawText("Qty",425,152,p);c.drawText("Total",485,152,p);p.setColor(BORDER);c.drawRect(35,162,560,164,p);y=182;
                }
                p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT);p.setTextSize(12);c.drawText(trimPdf(safe(x.name),30),40,y,p);c.drawText(trimPdf(safe(x.code),18),250,y,p);c.drawText(money(x.price),350,y,p);c.drawText(String.valueOf(x.qty),425,y,p);c.drawText(money(total),485,y,p);p.setColor(BORDER);c.drawRect(35,y+10,560,y+11,p);y+=34;grand+=total;
            }
            if(page!=null){p.setColor(BLUE);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(16);c.drawText("TOTAL COMMANDE: "+money(grand)+" DH",300,800,p);doc.finishPage(page);}
            sharePdfDocument(doc,"Commande_Fournisseur_"+safeFileName(sp.name)+"_"+order.id+".pdf");
        }catch(Exception e){try{if(page!=null)doc.finishPage(page);doc.close();}catch(Exception ignored){}Toast.makeText(this,"خطأ في إنشاء الطلبية: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }

    String trimPdf(String s,int max){if(s==null)return "";return s.length()>max?s.substring(0,max-1)+"…":s;}

    void showCustomers(){
        base(cloud != null && cloud.isAdmin()?"الزبائن والشركاء":"زبائني");
        boolean admin = cloud != null && cloud.isAdmin();
        TextView hint=text(admin?"إدارة الزبائن والشركاء وحساب أرباح الشركاء بشكل تلقائي":"إدارة زبائنك — يمكنك إضافة وتعديل وحذف زبائنك فقط",13,MUTED);hint.setGravity(Gravity.CENTER);body.addView(hint,margin(-1,dp(34),0,dp(3)));
        EditText search=input("🔎  ابحث بالاسم أو الهاتف أو المدينة");body.addView(search,margin(-1,dp(48),0,dp(8)));
        if(admin){
            Button add=button("＋  إضافة زبون جديد");add.setTextColor(Color.WHITE);add.setBackground(solid(BLUE,12));add.setOnClickListener(v->customerDialog(-1));body.addView(add,margin(-1,dp(48),0,dp(8)));
        }else{
            Button add=button("＋  إضافة زبون جديد");add.setTextColor(Color.WHITE);add.setBackground(solid(BLUE,12));add.setOnClickListener(v->partnerCustomerDialog(-1,(int)cloud.partnerId));body.addView(add,margin(-1,dp(48),0,dp(8)));
        }
        LinearLayout filters=new LinearLayout(this);filters.setGravity(Gravity.CENTER);final int[] filter={admin?customerAdminFilter:1};
        Button all=button("الكل"),normal=button("الزبائن"),partners=button("🤝 الشركاء");
        if(admin){
            filters.addView(all,new LinearLayout.LayoutParams(0,dp(42),1));
            filters.addView(normal,new LinearLayout.LayoutParams(0,dp(42),1));
            filters.addView(partners,new LinearLayout.LayoutParams(0,dp(42),1));
            body.addView(filters,margin(-1,dp(46),0,dp(8)));
        }
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);body.addView(list);
        Runnable refresh=()->{
            list.removeAllViews();
            ArrayList<Store.Customer> source=admin?db.customers(search.getText().toString()):db.partnerCustomers((int)cloud.partnerId,search.getText().toString());
            for(Store.Customer c:source){
                if(admin){
                    if(filter[0]==2 && !c.reseller) continue;
                    // Partner-owned customers are intentionally hidden from the
                    // main Admin customer list. They are visible only through
                    // the partner's "زبائنه" button.
                    if((filter[0]==0 || filter[0]==1) && (c.reseller || c.partnerId>0)) continue;
                }
                customerRow(list,c);
            }
        };
        if(admin){
            all.setOnClickListener(v->{filter[0]=0;customerAdminFilter=0;refreshCustomerButtons(all,normal,partners,0);refresh.run();});
            normal.setOnClickListener(v->{filter[0]=1;customerAdminFilter=1;refreshCustomerButtons(all,normal,partners,1);refresh.run();});
            partners.setOnClickListener(v->{filter[0]=2;customerAdminFilter=2;refreshCustomerButtons(all,normal,partners,2);refresh.run();});
            refreshCustomerButtons(all,normal,partners,0);
        }
        watch(search,refresh);refresh.run();
        if(cloud!=null){
            if(admin){
                cloud.ensureAllPartnerCustomers().addOnSuccessListener(v->cloud.syncLocalToCloud(()->refresh.run(),()->refresh.run())).addOnFailureListener(e->refresh.run());
            }else{
                cloud.syncCloudToLocalForPartner(()->refresh.run(),()->refresh.run());
            }
        }
    }

    void refreshCustomerButtons(Button all,Button normal,Button partners,int active){Button[] bs={all,normal,partners};for(int i=0;i<bs.length;i++){bs[i].setTextColor(i==active?Color.WHITE:BLUE);bs[i].setBackground(solid(i==active?BLUE:Color.rgb(239,246,255),10));}}

    void customerRow(LinearLayout list,Store.Customer c){
        LinearLayout r=card();r.setOrientation(LinearLayout.VERTICAL);r.setPadding(dp(12),dp(10),dp(12),dp(10));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        TextView avatar=text(c.reseller?"🤝":"👤",24,c.reseller?GREEN:BLUE);avatar.setGravity(Gravity.CENTER);avatar.setBackground(solid(c.reseller?Color.rgb(236,253,245):Color.rgb(239,246,255),40));top.addView(avatar,new LinearLayout.LayoutParams(dp(54),dp(54)));
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(9),0,dp(6),0);
        TextView n=text(c.name,17,TEXT);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);info.addView(n);
        info.addView(text(c.reseller?"شريك إحالة • حساب مرتبط":"زبون عادي"+(c.partnerId>0?" • تابع لشريك":""),11,c.reseller?GREEN:MUTED));
        if(c.reseller && c.partnerEmail!=null && !c.partnerEmail.isEmpty()) info.addView(text("📧 "+safe(c.partnerEmail),12,MUTED));
        else info.addView(text("📞 "+safe(c.phone)+"   •   📍 "+safe(c.city),12,MUTED));
        if(c.reseller) info.addView(text("🚚 شحن افتراضي: "+money(c.defaultShipping)+" DH",11,BLUE));
        top.addView(info,new LinearLayout.LayoutParams(0,dp(82),1));
        if(cloud != null && cloud.isAdmin() && !c.reseller){
            Button edit=button("✎");edit.setTextColor(BLUE);edit.setBackgroundColor(Color.TRANSPARENT);edit.setOnClickListener(v->customerDialog(c.id));
            Button del=button("🗑");del.setTextColor(RED);del.setBackgroundColor(Color.TRANSPARENT);
            del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف الزبون").setMessage("هل تريد حذف هذا الزبون؟").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(di,w)->{
                db.deleteCustomer(c.id);
                if(cloud!=null)cloud.syncLocalToCloud(()->showCustomers(),()->showCustomers()); else showCustomers();
            }).show());
            top.addView(edit,new LinearLayout.LayoutParams(dp(42),dp(52)));top.addView(del,new LinearLayout.LayoutParams(dp(42),dp(52)));
        }else if(cloud != null && cloud.isAdmin() && c.reseller){
            // Partner accounts are managed only from Settings → إدارة الشركاء.
        }else if(cloud != null && cloud.partnerId>0 && !c.reseller && c.partnerId==(int)cloud.partnerId){
            Button edit=button("✎");edit.setTextColor(BLUE);edit.setBackgroundColor(Color.TRANSPARENT);edit.setOnClickListener(v->partnerCustomerDialog(c.id,(int)cloud.partnerId));
            Button del=button("🗑");del.setTextColor(RED);del.setBackgroundColor(Color.TRANSPARENT);del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف الزبون").setMessage("سيتم حذف هذا الزبون من قائمة زبائنك. هل تريد المتابعة؟").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(d,w)->{db.deleteCustomer(c.id);if(cloud!=null)cloud.syncCloudToLocalForPartner(()->showCustomers(),()->showCustomers());else showCustomers();} ).show());
            top.addView(edit,new LinearLayout.LayoutParams(dp(42),dp(52)));top.addView(del,new LinearLayout.LayoutParams(dp(42),dp(52)));
        }
        r.addView(top);
        TextView addr=text("📍 "+safe(c.address),11,MUTED);r.addView(addr);
        if(c.reseller && cloud != null && cloud.isAdmin()){
            LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER);
            Button clients=button("👥 زبائنه");clients.setTextColor(BLUE);clients.setOnClickListener(v->showPartnerCustomers(c.partnerId));
            Button profits=button("💰 الأرباح");profits.setTextColor(GREEN);profits.setOnClickListener(v->showPartnerProfits(c.partnerId));
            actions.addView(clients,new LinearLayout.LayoutParams(0,dp(44),1));actions.addView(profits,new LinearLayout.LayoutParams(0,dp(44),1));r.addView(actions);
        }
        list.addView(r,margin(-1,-2,0,dp(7)));
    }

    void customerDialog(int id){
        Store.Customer o=id<0?null:db.customer(id);
        if(o!=null && o.partnerId>0){
            Toast.makeText(this,"زبائن الشريك تتم إدارتهم من زر «زبائنه» الخاص بالشريك.",Toast.LENGTH_LONG).show();
            return;
        }
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(4),0,dp(4),0);
        EditText n=input("الاسم"),p=input("الهاتف"),city=input("المدينة"),a=input("العنوان");
        if(o!=null){n.setText(o.name);p.setText(o.phone);city.setText(o.city);a.setText(o.address);}
        box.addView(n,margin(-1,dp(48),0,dp(5)));box.addView(p,margin(-1,dp(48),0,dp(5)));
        box.addView(city,margin(-1,dp(48),0,dp(5)));box.addView(a,margin(-1,dp(48),0,dp(5)));
        new AlertDialog.Builder(this).setTitle(id<0?"إضافة زبون":"تعديل بيانات الزبون").setView(box)
            .setPositiveButton("حفظ",(d,w)->{
                String name=n.getText().toString().trim();
                if(name.isEmpty()){Toast.makeText(this,"أدخل اسم الزبون",Toast.LENGTH_SHORT).show();return;}
                int savedId=db.saveCustomer(id,name,p.getText().toString().trim(),city.getText().toString().trim(),a.getText().toString().trim(),false,0,30);
                showCustomers();
                if(cloud!=null && savedId>0) cloud.pushCustomerNow(savedId,()->{},()->{});
            })
            .setNegativeButton("إلغاء",null).show();
    }

    void partnerPicker(EditText target,int[] selected){partnerPicker(target,selected,null);}
    void partnerPicker(EditText target,int[] selected,Runnable onSelected){
        EditText s=input("🔎 ابحث عن شريك");LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);ScrollView sv=new ScrollView(this);sv.addView(list);LinearLayout wrap=new LinearLayout(this);wrap.setOrientation(LinearLayout.VERTICAL);wrap.setPadding(dp(5),dp(5),dp(5),dp(5));wrap.addView(s);wrap.addView(sv,new LinearLayout.LayoutParams(-1,dp(400)));
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("اختيار الشريك").setView(wrap).setNegativeButton("إلغاء",null).create();Runnable r=()->{list.removeAllViews();for(Store.Customer c:db.customers(s.getText().toString()))if(c.reseller){Button b=button("🤝 "+c.name+"\n"+safe(c.phone));b.setOnClickListener(v->{target.setText(c.name);selected[0]=c.partnerId;dlg.dismiss();if(onSelected!=null)onSelected.run();});list.addView(b);}};watch(s,r);r.run();dlg.show();
    }

    void showPartnerCustomers(int partnerId){
        Store.Customer partner=db.partnerAccountCustomer(partnerId);if(partner==null)return;
        base("زبائن "+partner.name);
        TextView head=text("👥 جميع زبائن الشريك • "+partner.name,18,TEXT);head.setTypeface(Typeface.DEFAULT,Typeface.BOLD);head.setGravity(Gravity.CENTER);body.addView(head,margin(-1,dp(44),0,dp(6)));
        EditText search=input("🔎 ابحث عن زبون الشريك");body.addView(search,margin(-1,dp(48),0,dp(8)));
        Button add=button("＋ إضافة زبون لهذا الشريك");add.setTextColor(Color.WHITE);add.setBackground(solid(BLUE,12));add.setOnClickListener(v->customerDialogForPartner(partnerId));body.addView(add,margin(-1,dp(48),0,dp(8)));
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);body.addView(list);
        Runnable refresh=()->{list.removeAllViews();for(Store.Customer c:db.partnerCustomers(partnerId,search.getText().toString()))customerRow(list,c);};watch(search,refresh);refresh.run();
        if(cloud!=null && cloud.isAdmin()){
            cloud.syncPartnerCustomersForAdmin(partnerId,refresh,refresh);
        }
    }

    void customerDialogForPartner(int partnerId){
        Store.Customer partner=db.partnerAccountCustomer(partnerId);if(partner==null)return;
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(4),0,dp(4),0);
        EditText n=input("اسم الزبون"),p=input("الهاتف"),city=input("المدينة"),a=input("العنوان");box.addView(n,margin(-1,dp(48),0,dp(5)));box.addView(p,margin(-1,dp(48),0,dp(5)));box.addView(city,margin(-1,dp(48),0,dp(5)));box.addView(a,margin(-1,dp(48),0,dp(5)));
        new AlertDialog.Builder(this).setTitle("إضافة زبون للشريك: "+partner.name).setView(box).setPositiveButton("حفظ",(d,w)->{
            int savedId=db.saveCustomer(-1,n.getText().toString().trim(),p.getText().toString().trim(),city.getText().toString().trim(),a.getText().toString().trim(),false,partnerId,30);
            showPartnerCustomers(partnerId);
            if(cloud!=null && savedId>0) cloud.pushCustomerNow(savedId,()->{},()->{});
        }).setNegativeButton("إلغاء",null).show();
    }

    void partnerCustomerDialog(int id,int partnerId){
        Store.Customer old=id<0?null:db.customer(id);
        if(old!=null && (old.reseller || old.partnerId!=partnerId)){Toast.makeText(this,"هذا الزبون لا ينتمي إلى حسابك",Toast.LENGTH_SHORT).show();return;}
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(4),0,dp(4),0);
        EditText n=input("اسم الزبون"),p=input("الهاتف"),city=input("المدينة"),a=input("العنوان");
        if(old!=null){n.setText(old.name);p.setText(old.phone);city.setText(old.city);a.setText(old.address);}
        box.addView(n,margin(-1,dp(48),0,dp(5)));box.addView(p,margin(-1,dp(48),0,dp(5)));box.addView(city,margin(-1,dp(48),0,dp(5)));box.addView(a,margin(-1,dp(48),0,dp(5)));
        new AlertDialog.Builder(this).setTitle(id<0?"إضافة زبون جديد":"تعديل بيانات الزبون").setView(box).setPositiveButton("حفظ",(d,w)->{
            String name=n.getText().toString().trim();if(name.isEmpty()){Toast.makeText(this,"أدخل اسم الزبون",Toast.LENGTH_SHORT).show();return;}
            int savedId=db.saveCustomer(id,name,p.getText().toString().trim(),city.getText().toString().trim(),a.getText().toString().trim(),false,partnerId,30);
            showCustomers();
            if(cloud!=null && savedId>0) cloud.pushCustomerNow(savedId,()->{},()->{});
        }).setNegativeButton("إلغاء",null).show();
    }

    void showPartnerProfits(int partnerId){
        Store.Customer partner=db.partnerAccountCustomer(partnerId);if(partner==null)return;
        base("أرباح الشريك");

        TextView title=text("💰 أرباح "+partner.name,20,TEXT);
        title.setGravity(Gravity.CENTER);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        body.addView(title,margin(-1,dp(44),0,dp(6)));

        LinearLayout summary=card();summary.setOrientation(LinearLayout.VERTICAL);
        summary.addView(text("🚚 الشحن الافتراضي للشريك: "+money(partner.defaultShipping)+" DH",14,BLUE));
        TextView total=text("",18,TEXT),paid=text("",14,GREEN),pending=text("",14,RED);
        summary.addView(total);summary.addView(paid);summary.addView(pending);
        body.addView(summary,margin(-1,-2,0,dp(9)));

        LinearLayout tools=new LinearLayout(this);tools.setOrientation(LinearLayout.VERTICAL);
        Button settle=button("☑  تحديد الطلبات المستلمة ودفع الأرباح");
        settle.setTextColor(Color.WHITE);settle.setBackground(solid(GREEN,12));
        settle.setOnClickListener(v->showPartnerSettlement(partnerId));
        Button pdfReceived=button("📄 PDF أرباح الطلبات المستلمة");
        pdfReceived.setTextColor(Color.WHITE);pdfReceived.setBackground(solid(BLUE,12));
        pdfReceived.setOnClickListener(v->makePartnerProfitPdf(partnerId,true));
        Button pdfFailed=button("📄 PDF الطلبات غير المستلمة");
        pdfFailed.setTextColor(Color.WHITE);pdfFailed.setBackground(solid(Color.rgb(180,60,60),12));
        pdfFailed.setOnClickListener(v->makePartnerProfitPdf(partnerId,false));
        Button archives=button("📚 أرشيف تسويات الأرباح");
        archives.setTextColor(BLUE);archives.setBackground(round(Color.rgb(239,246,255),Color.rgb(205,220,240),12,1));
        archives.setOnClickListener(v->showPartnerSettlementArchive(partnerId));
        tools.addView(settle,new LinearLayout.LayoutParams(-1,dp(50)));
        LinearLayout pdfs=new LinearLayout(this);
        pdfs.addView(pdfReceived,new LinearLayout.LayoutParams(0,dp(48),1));
        pdfs.addView(pdfFailed,new LinearLayout.LayoutParams(0,dp(48),1));
        tools.addView(pdfs);
        tools.addView(archives,new LinearLayout.LayoutParams(-1,dp(46)));
        body.addView(tools,margin(-1,-2,0,dp(10)));

        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);body.addView(list);
        double[] sums={0,0,0}; int receivedCount=0,failedCount=0;
        for(Store.Invoice i:db.invoices("")){
            if(i.partnerId!=partnerId)continue;
            double net=i.commission;sums[0]+=net;
            if(i.partnerProfitPaid)sums[1]+=net;else sums[2]+=net;
            if(i.deliveryReceived)receivedCount++;else failedCount++;

            LinearLayout r=card();r.setTag(i.id);r.setPadding(dp(10),dp(8),dp(10),dp(8));
            Store.Customer cu=i.clientId>0?db.customer(i.clientId):null;
            String clientLine=i.client+(cu!=null?" • "+safe(cu.city):"");
            r.addView(text("#"+invoiceNo(i)+"  •  "+clientLine+"  •  "+i.date,15,TEXT));
            if(cu!=null)r.addView(text("📞 "+safe(cu.phone)+"  •  📍 "+safe(cu.address),11,MUTED));
            r.addView(text("ربح المنتجات: "+money(productProfit(i))+" DH  |  شحن الزبون: "+money(i.shippingCharge)+" DH  |  التكلفة الفعلية: "+money(i.shippingCost)+" DH",11,MUTED));
            r.addView(text("💰 صافي ربح الشريك: "+money(net)+" DH",13,net>=0?GREEN:RED));
            r.addView(text(i.deliveryReceived?"📦 تم الاستلام":"📦 لم يتم الاستلام",11,i.deliveryReceived?GREEN:RED));
            if(!i.deliveryReceived && i.deliveryFailureReason!=null && !i.deliveryFailureReason.isEmpty())
                r.addView(text("سبب عدم الاستلام: "+i.deliveryFailureReason,11,RED));
            if(i.partnerProfitPaid)
                r.addView(text("💵 تم دفع أرباح الشريك • "+safe(i.partnerProfitPaidDate),11,GREEN));
            else if(i.deliveryReceived)
                r.addView(text("⏳ أرباح الشريك مستحقة وغير مدفوعة",11,RED));
            list.addView(r,margin(-1,-2,0,dp(7)));
        }
        total.setText("إجمالي أرباح الشريك: "+money(sums[0])+" DH");
        paid.setText("💵 تم دفعه: "+money(sums[1])+" DH");
        pending.setText("⏳ متبقي: "+money(sums[2])+" DH");
        body.addView(text("📦 مستلمة: "+receivedCount+"   •   ❌ غير مستلمة: "+failedCount,12,MUTED),margin(-1,dp(28),0,dp(8)));
    }

    void showPartnerSettlementArchive(int partnerId){
        Store.Customer partner=db.partnerAccountCustomer(partnerId);if(partner==null)return;
        base("أرشيف تسويات الأرباح");
        body.addView(text("📚 أرشيف تسويات "+partner.name,19,TEXT),margin(-1,dp(42),0,dp(8)));
        body.addView(text("الفواتير الموجودة هنا تمت محاسبتها وأزيلت من قائمة التسوية الجديدة. يمكنك استرجاع فاتورة محددة عند الحاجة.",12,MUTED),margin(-1,-2,0,dp(10)));
        ArrayList<Store.PartnerSettlement> rows=db.partnerSettlements(partnerId);
        if(rows.isEmpty())body.addView(text("لا توجد تسويات محفوظة بعد.",15,MUTED),margin(-1,dp(60),0,dp(8)));
        for(Store.PartnerSettlement x:rows){
            LinearLayout r=card();r.addView(text("🧾 تسوية #"+x.id+" • "+safe(x.date),15,TEXT));
            r.addView(text("الفواتير: "+x.invoiceCount+" • مجموع الفواتير: "+money(x.totalInvoices)+" DH",12,MUTED));
            r.addView(text("أرباح الشريك: "+money(x.totalProfit)+" DH • التسبيقات: -"+money(x.totalAdvances)+" DH",12,MUTED));
            r.addView(text("💵 المبلغ المدفوع: "+money(x.amountPaid)+" DH",15,GREEN));
            LinearLayout actions=new LinearLayout(this);
            Button pdf=button("📄 تحميل / مشاركة PDF"); pdf.setTextColor(BLUE);
            final int settlementId=x.id; pdf.setOnClickListener(v->makePartnerSettlementPdf(partnerId,settlementId));
            Button restore=button("↩ استرجاع فاتورة"); restore.setTextColor(Color.rgb(180,90,40));
            restore.setOnClickListener(v->showRestoreSettlementItems(partnerId,settlementId));
            actions.addView(pdf,new LinearLayout.LayoutParams(0,dp(46),1));actions.addView(restore,new LinearLayout.LayoutParams(0,dp(46),1));
            r.addView(actions); body.addView(r,margin(-1,-2,0,dp(7)));
        }
    }

    void showRestoreSettlementItems(int partnerId,int settlementId){
        ArrayList<Store.PartnerSettlementItem> rows=db.partnerSettlementItems(settlementId);
        if(rows.isEmpty()){Toast.makeText(this,"لا توجد فواتير في هذه التسوية",Toast.LENGTH_SHORT).show();showPartnerSettlementArchive(partnerId);return;}
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(4),0,dp(4),0);
        ArrayList<Integer> selected=new ArrayList<>(); ArrayList<CheckBox> checks=new ArrayList<>();
        for(Store.PartnerSettlementItem r:rows){
            CheckBox cb=new CheckBox(this);
            cb.setText("#"+r.invoiceNumber+" • "+safe(r.client)+" • "+money(r.profit-r.advance)+" DH");cb.setTextSize(14);cb.setTextColor(TEXT);
            cb.setOnCheckedChangeListener((b,checked)->{if(checked){if(!selected.contains(r.invoiceId))selected.add(r.invoiceId);}else selected.remove((Integer)r.invoiceId);});
            checks.add(cb);box.addView(cb,new LinearLayout.LayoutParams(-1,dp(48)));
        }
        new AlertDialog.Builder(this).setTitle("استرجاع فواتير من التسوية #"+settlementId).setMessage("اختر الفواتير التي تريد إلغاء محاسبتها وإعادتها إلى قائمة التسوية.").setView(box).setPositiveButton("↩ استرجاع المحدد",null).setNegativeButton("إلغاء",null).create();
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("استرجاع فواتير من التسوية #"+settlementId).setView(box).setPositiveButton("↩ استرجاع المحدد",(d,w)->{}).setNegativeButton("إلغاء",null).create();
        dialog.setOnShowListener(v->{Button b=dialog.getButton(AlertDialog.BUTTON_POSITIVE);b.setOnClickListener(z->{
            if(selected.isEmpty()){Toast.makeText(this,"حدد فاتورة واحدة على الأقل",Toast.LENGTH_SHORT).show();return;}
            if(!db.restorePartnerSettlementItems(settlementId,selected)){Toast.makeText(this,"تعذر استرجاع الفواتير",Toast.LENGTH_SHORT).show();return;}
            Toast.makeText(this,"تم استرجاع "+selected.size()+" فاتورة وإعادتها إلى قائمة التسوية",Toast.LENGTH_LONG).show();dialog.dismiss();showPartnerSettlementArchive(partnerId);
        });});
        dialog.show();
    }

    double productProfit(Store.Invoice i){
        double x=0;for(Store.Item it:i.items)x+=(it.salePrice-it.price)*it.qty;return x;
    }

    void showPartnerSettlement(int partnerId){
        Store.Customer partner=db.partnerAccountCustomer(partnerId);if(partner==null)return;
        base("تسوية أرباح "+partner.name);

        TextView head=text("☑ اختر الطلبات التي تم استلامها ليتم جمع أرباحها ودفعها معاً",15,TEXT);
        head.setGravity(Gravity.CENTER);body.addView(head,margin(-1,dp(44),0,dp(6)));

        LinearLayout list= new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv=new ScrollView(this);sv.addView(list);
        body.addView(sv,new LinearLayout.LayoutParams(-1,0,1));

        ArrayList<Integer> selectedIds=new ArrayList<>();
        ArrayList<CheckBox> boxes=new ArrayList<>();
        ArrayList<Store.Invoice> eligible=new ArrayList<>();
        double[] selectedTotal={0};
        double[] selectedInvoiceTotal={0};
        double[] selectedAdvance={0};
        final TextView[] sumHolder={null};

        for(Store.Invoice i:db.invoices("")){
            if(i.partnerId!=partnerId || !i.deliveryReceived || i.partnerProfitPaid || db.invoiceAlreadyInPartnerSettlement(i.id))continue;
            eligible.add(i);
            LinearLayout r=card();r.setPadding(dp(8),dp(7),dp(8),dp(7));
            CheckBox cb=new CheckBox(this);cb.setText("☑  #"+invoiceNo(i)+"  "+i.client);cb.setTextSize(15);cb.setTextColor(TEXT);
            r.addView(cb);
            Store.Customer cu=i.clientId>0?db.customer(i.clientId):null;
            r.addView(text("📞 "+(cu==null?"":safe(cu.phone))+"   •   📍 "+(cu==null?"":safe(cu.city)),11,MUTED));
            double invoiceValue=invoiceTotal(i);
            double advanceForPartner=i.advanceReceivedByPartnerId==partnerId?Math.max(0,i.advancePayment):0;
            r.addView(text("💰 ربح الشريك: "+money(i.commission)+" DH   •   تسبيق استلمه الشريك: "+money(advanceForPartner)+" DH",12,i.commission>=0?GREEN:RED));
            cb.setOnCheckedChangeListener((b,checked)->{
                if(checked){if(!selectedIds.contains(i.id)){selectedIds.add(i.id);selectedTotal[0]+=i.commission;selectedInvoiceTotal[0]+=invoiceValue;selectedAdvance[0]+=advanceForPartner;}}
                else{selectedIds.remove((Integer)i.id);selectedTotal[0]-=i.commission;selectedInvoiceTotal[0]-=invoiceValue;selectedAdvance[0]-=advanceForPartner;}
                if(sumHolder[0]!=null) sumHolder[0].setText("مجموع الفواتير: "+money(selectedInvoiceTotal[0])+" DH\nمجموع ربح الشريك: "+money(selectedTotal[0])+" DH\nالتسبيقات المستلمة من الشريك: -"+money(selectedAdvance[0])+" DH\nالمبلغ المستحق للدفع: "+money(Math.max(0,selectedTotal[0]-selectedAdvance[0]))+" DH");
            });
            boxes.add(cb);list.addView(r,margin(-1,-2,0,dp(6)));
        }

        if(eligible.isEmpty()){
            list.addView(text("لا توجد طلبات مستلمة غير مسددة للشريك.",15,MUTED),margin(-1,dp(60),0,dp(10)));
        }

        LinearLayout bottom=card();
        TextView sum=text("مجموع الفواتير: 0.00 DH\nمجموع ربح الشريك: 0.00 DH\nالتسبيقات المستلمة من الشريك: -0.00 DH\nالمبلغ المستحق للدفع: 0.00 DH",16,TEXT);sum.setGravity(Gravity.CENTER);sumHolder[0]=sum;bottom.addView(sum);
        Button all=button("☑ تحديد الكل");all.setTextColor(BLUE);
        all.setOnClickListener(v->{for(CheckBox cb:boxes)if(!cb.isChecked())cb.setChecked(true);});
        bottom.addView(all);
        Button confirm=button("💵 تأكيد دفع الأرباح المحددة");confirm.setTextColor(Color.WHITE);confirm.setBackground(solid(GREEN,12));
        confirm.setOnClickListener(v->{
            if(selectedIds.isEmpty()){Toast.makeText(this,"حدد طلبية واحدة على الأقل",Toast.LENGTH_SHORT).show();return;}
            int settlementId=(int)db.createPartnerSettlement(partnerId,partner.name,selectedIds);
            if(settlementId<=0){ Toast.makeText(this,"لم يتم إنشاء التسوية: هذه الفواتير تمت محاسبتها سابقاً أو لم تعد مؤهلة.",Toast.LENGTH_LONG).show(); return; }
            ArrayList<Integer> fresh=new ArrayList<>(); for(Integer id:selectedIds) if(id!=null && db.invoiceAlreadyInPartnerSettlement(id)) fresh.add(id);
            db.setPartnerProfitPaidBulk(fresh,true);
            double payable=Math.max(0,selectedTotal[0]-selectedAdvance[0]);
            Toast.makeText(this,"تمت أرشفة "+fresh.size()+" فاتورة في التسوية #"+settlementId+" بقيمة "+money(payable)+" DH",Toast.LENGTH_LONG).show();
            // مشاركة PDF للتسوية الحالية فقط، وليس كل فواتير الشريك.
            makePartnerSettlementPdf(partnerId,settlementId);
            showPartnerProfits(partnerId);
        });
        bottom.addView(confirm,new LinearLayout.LayoutParams(-1,dp(50)));
        body.addView(bottom,margin(-1,-2,0,dp(8)));

        TextView failedTitle=text("❌ الطلبات التي لم يتم استلامها",17,RED);
        failedTitle.setTypeface(Typeface.DEFAULT,Typeface.BOLD);body.addView(failedTitle,margin(-1,dp(42),0,dp(4)));
        for(Store.Invoice i:db.invoices("")){
            if(i.partnerId!=partnerId||i.deliveryReceived)continue;
            Store.Customer cu=i.clientId>0?db.customer(i.clientId):null;
            LinearLayout r=card();
            r.addView(text("#"+invoiceNo(i)+" • "+i.client,14,TEXT));
            r.addView(text("📞 "+(cu==null?"":safe(cu.phone))+" • 📍 "+(cu==null?"":safe(cu.city)),11,MUTED));
            r.addView(text("🚚 التتبع: "+safe(i.trackingNumber),11,MUTED));
            r.addView(text("سبب عدم الاستلام: "+(i.deliveryFailureReason==null||i.deliveryFailureReason.isEmpty()?"غير محدد":i.deliveryFailureReason),12,RED));
            body.addView(r,margin(-1,-2,0,dp(6)));
        }
    }

    String firstNonEmpty(String... values){
        if(values==null)return "";
        for(String v:values)if(v!=null&&!v.trim().isEmpty())return v.trim();
        return "";
    }

    void makePartnerSettlementPdf(int partnerId,int settlementId){
        Store.Customer partner=db.partnerAccountCustomer(partnerId); if(partner==null)return;
        Store.PartnerSettlement target=null; for(Store.PartnerSettlement x:db.partnerSettlements(partnerId)) if(x.id==settlementId){target=x;break;}
        if(target==null){Toast.makeText(this,"التسوية غير موجودة",Toast.LENGTH_SHORT).show();return;}
        ArrayList<Store.PartnerSettlementItem> rows=db.partnerSettlementItems(settlementId);
        PdfDocument doc=new PdfDocument(); Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); PdfDocument.Page page=null; Canvas c=null; int pageNo=0,y=0;
        for(int index=0;index<rows.size();index++){
            if(page==null||y>700){ if(page!=null)doc.finishPage(page); page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,++pageNo).create()); c=page.getCanvas(); p.setColor(Color.WHITE);c.drawPaint(p); p.setColor(BLUE);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(20);c.drawText("MGE",40,45,p);p.setColor(TEXT);p.setTextSize(17);c.drawText("PARTNER SETTLEMENT / تسوية أرباح الشريك",115,45,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(11);c.drawText("الشريك : "+safe(partner.name),40,68,p);c.drawText("التسوية #"+target.id+"   •   "+safe(target.date),40,86,p);y=120; }
            Store.PartnerSettlementItem r=rows.get(index);
            // بعض التسويات القديمة كانت تحفظ بيانات الزبون فارغة لأن الهاتف/المدينة
            // موجودان في جدول customers وليس داخل invoice. نستعمل snapshot المحفوظ أولاً،
            // ثم نرجع إلى الفاتورة والزبون الحالي كـ fallback. هذا يصلح التسويات القديمة
            // أيضاً دون إعادة إنشاء التسوية.
            Store.Invoice sourceInvoice=db.invoice(r.invoiceId);
            Store.Customer sourceCustomer=sourceInvoice!=null&&sourceInvoice.clientId>0?db.customer(sourceInvoice.clientId):null;
            String pdfClient=firstNonEmpty(r.client,sourceInvoice!=null?sourceInvoice.client:null,sourceCustomer!=null?sourceCustomer.name:null);
            String pdfPhone=firstNonEmpty(r.phone,sourceInvoice!=null?sourceInvoice.customerPhone:null,sourceCustomer!=null?sourceCustomer.phone:null);
            String pdfCity=firstNonEmpty(r.city,sourceInvoice!=null?sourceInvoice.customerCity:null,sourceCustomer!=null?sourceCustomer.city:null);
            String pdfAddress=firstNonEmpty(r.address,sourceInvoice!=null?sourceInvoice.customerAddress:null,sourceCustomer!=null?sourceCustomer.address:null);
            String pdfTracking=firstNonEmpty(r.tracking,sourceInvoice!=null?sourceInvoice.trackingNumber:null);
            String pdfCompany=firstNonEmpty(r.shippingCompany,sourceInvoice!=null?sourceInvoice.shippingCompany:null);
            String pdfStore=firstNonEmpty(r.shippingAccount,sourceInvoice!=null?sourceInvoice.shippingAccount:null);
            p.setColor(Color.rgb(245,247,250));c.drawRoundRect(32,y-18,563,y+118,8,8,p);p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(12);c.drawText("#"+r.invoiceNumber+"  "+trim(pdfClient,35),45,y,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(9);c.drawText("Téléphone : "+trim(pdfPhone,22),45,y+19,p);c.drawText("Ville : "+trim(pdfCity,22),310,y+19,p);c.drawText("Adresse : "+trim(pdfAddress,31),45,y+36,p);c.drawText("N° suivi : "+trim(pdfTracking,27),310,y+36,p);c.drawText("Société : "+trim(pdfCompany,24),45,y+53,p);c.drawText("Store : "+trim(pdfStore,24),310,y+53,p);c.drawText("Expédition : "+money(r.shippingCharge)+" DH   •   Réel : "+money(r.shippingCost)+" DH",45,y+70,p);p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("Profit : "+money(r.profit)+" DH",45,y+91,p);c.drawText("Avance : -"+money(r.advance)+" DH",310,y+91,p);c.drawText("Net payé au partenaire : "+money(Math.max(0,r.profit-r.advance))+" DH",45,y+108,p);y+=150;
        }
        if(page==null){page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());c=page.getCanvas();p.setColor(Color.WHITE);c.drawPaint(p);p.setColor(TEXT);p.setTextSize(16);c.drawText("لا توجد فواتير في هذه التسوية",60,100,p);}
        if(page!=null)doc.finishPage(page);
        PdfDocument.Page sum=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,++pageNo).create());Canvas sc=sum.getCanvas();p.setColor(Color.WHITE);sc.drawPaint(p);p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(20);sc.drawText("SUMMARY / ملخص التسوية",45,60,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(14);sc.drawText("الشريك : "+safe(partner.name),45,105,p);sc.drawText("رقم التسوية : #"+target.id,45,130,p);sc.drawText("عدد الفواتير : "+target.invoiceCount,45,155,p);sc.drawText("مجموع الفواتير : "+money(target.totalInvoices)+" DH",45,180,p);sc.drawText("أرباح الشريك : "+money(target.totalProfit)+" DH",45,205,p);sc.drawText("التسبيقات : -"+money(target.totalAdvances)+" DH",45,230,p);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(17);sc.drawText("المبلغ المدفوع : "+money(target.amountPaid)+" DH",45,265,p);doc.finishPage(sum);
        sharePdfDocument(doc,"تسوية_الشريك_"+safeFileName(partner.name)+"_"+settlementId+".pdf");
    }

    void makePartnerProfitPdf(int partnerId,boolean receivedOnly){
        Store.Customer partner=db.partnerAccountCustomer(partnerId);if(partner==null)return;
        ArrayList<Store.Invoice> rows=new ArrayList<>();
        for(Store.Invoice i:db.invoices("")){
            if(i.partnerId!=partnerId)continue;
            if(receivedOnly && !i.deliveryReceived)continue;
            if(!receivedOnly && i.deliveryReceived)continue;
            rows.add(i);
        }
        String title=receivedOnly?"أرباح_الشريك_"+safeFileName(partner.name):"طلبات_غير_مستلمة_"+safeFileName(partner.name);
        PdfDocument doc=new PdfDocument();
        int pageNo=0;PdfDocument.Page page=null;Canvas canvas=null;Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);int y=0;
        for(int index=0;index<rows.size();index++){
            if(page==null||y>770){
                if(page!=null)doc.finishPage(page);
                page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,++pageNo).create());
                canvas=page.getCanvas();p.setColor(Color.WHITE);canvas.drawPaint(p);
                p.setColor(BLUE);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(20);canvas.drawText("MGE",40,45,p);
                p.setColor(TEXT);p.setTextSize(18);canvas.drawText(receivedOnly?"PARTNER PROFIT REPORT / أرباح الشريك":"UNDELIVERED ORDERS / الطلبات غير المستلمة",160,45,p);
                p.setTypeface(Typeface.DEFAULT);p.setTextSize(12);
                canvas.drawText("Partenaire / الشريك : "+safe(partner.name),40,70,p);
                canvas.drawText("Date : "+new java.text.SimpleDateFormat("dd/MM/yyyy",Locale.US).format(new java.util.Date()),40,88,p);
                y=120;
            }
            Store.Invoice i=rows.get(index);Store.Customer cu=i.clientId>0?db.customer(i.clientId):null;
            p.setColor(Color.rgb(245,247,250));canvas.drawRect(35,y-17,560,y+60,p);
            p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(12);
            canvas.drawText("#"+invoiceNo(i)+"  "+trim(i.client,30),45,y,p);
            p.setTypeface(Typeface.DEFAULT);p.setTextSize(10);
            canvas.drawText("Phone: "+(cu==null?"":safe(cu.phone)),45,y+18,p);
            canvas.drawText("City: "+(cu==null?"":safe(cu.city)),205,y+18,p);
            canvas.drawText("Address: "+(cu==null?"":trim(cu.address,35)),350,y+18,p);
            if(receivedOnly){
                canvas.drawText("Net partner profit: "+money(i.commission)+" DH",45,y+38,p);
                canvas.drawText("Shipping: "+money(i.shippingCharge)+" DH / Actual: "+money(i.shippingCost)+" DH",270,y+38,p);
                canvas.drawText("Delivery: RECEIVED / تم الاستلام",45,y+55,p);
            }else{
                canvas.drawText("Tracking: "+safe(i.trackingNumber),45,y+38,p);
                canvas.drawText("Reason: "+trim(i.deliveryFailureReason==null?"غير محدد":i.deliveryFailureReason,55),270,y+38,p);
                canvas.drawText("Delivery: NOT RECEIVED / لم يتم الاستلام",45,y+55,p);
            }
            y+=86;
        }
        if(page==null){
            page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());canvas=page.getCanvas();p.setColor(Color.WHITE);canvas.drawPaint(p);p.setColor(TEXT);p.setTextSize(16);
            canvas.drawText(receivedOnly?"لا توجد أرباح مستحقة في هذه القائمة":"لا توجد طلبات غير مستلمة",60,100,p);
        }
        if(page!=null)doc.finishPage(page);
        if(receivedOnly){
            // Add a final summary page with totals.
            PdfDocument.Page sumPage=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,++pageNo).create());
            Canvas sc=sumPage.getCanvas();p.setColor(Color.WHITE);sc.drawPaint(p);p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(20);sc.drawText("SUMMARY / ملخص الأرباح",45,60,p);
            double total=0,paidTotal=0,pendingTotal=0;int count=0;
            for(Store.Invoice i:rows){total+=i.commission;count++;if(i.partnerProfitPaid)paidTotal+=i.commission;else pendingTotal+=i.commission;}
            p.setTypeface(Typeface.DEFAULT);p.setTextSize(15);sc.drawText("Partner: "+safe(partner.name),45,105,p);sc.drawText("Orders received: "+count,45,135,p);sc.drawText("Total profit: "+money(total)+" DH",45,165,p);sc.drawText("Paid: "+money(paidTotal)+" DH",45,195,p);sc.drawText("Remaining: "+money(pendingTotal)+" DH",45,225,p);
            doc.finishPage(sumPage);
        }
        sharePdfDocument(doc,title+".pdf");
    }

    void sharePdfDocument(PdfDocument doc,String fileName){
        try{
            ByteArrayOutputStream buffer=new ByteArrayOutputStream();doc.writeTo(buffer);doc.close();byte[] bytes=buffer.toByteArray();
            Uri uri=savePdfToDownloads(bytes,fileName);
            Intent share=new Intent(Intent.ACTION_SEND);share.setType("application/pdf");share.putExtra(Intent.EXTRA_STREAM,uri);share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);share.setClipData(ClipData.newRawUri("PDF",uri));
            startActivity(Intent.createChooser(share,"إرسال PDF عبر واتساب أو أي تطبيق"));
            Toast.makeText(this,"تم حفظ الملف في Download/FactureSimple",Toast.LENGTH_LONG).show();
        }catch(Exception e){try{doc.close();}catch(Exception ignored){}Toast.makeText(this,"خطأ PDF: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }

    Uri savePdfToDownloads(byte[] bytes,String fileName)throws Exception{
        if(Build.VERSION.SDK_INT>=29){
            ContentValues values=new ContentValues();values.put(MediaStore.Downloads.DISPLAY_NAME,fileName);values.put(MediaStore.Downloads.MIME_TYPE,"application/pdf");values.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/FactureSimple");values.put(MediaStore.Downloads.IS_PENDING,1);
            Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new IOException("تعذر إنشاء الملف");
            try(OutputStream out=getContentResolver().openOutputStream(uri)){out.write(bytes);}
            ContentValues done=new ContentValues();done.put(MediaStore.Downloads.IS_PENDING,0);getContentResolver().update(uri,done,null,null);return uri;
        }
        File dir=new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),"FactureSimple");if(!dir.exists()&&!dir.mkdirs())throw new IOException("تعذر إنشاء المجلد");
        File f=new File(dir,fileName);try(OutputStream out=new FileOutputStream(f)){out.write(bytes);}return Uri.fromFile(f);
    }

    int selectedPartnerForRestore(int partnerId, ArrayList<Store.Customer> rows){
        if(partnerId<=0 || rows==null) return -1;
        for(int k=0;k<rows.size();k++) if(rows.get(k).partnerId==partnerId) return k;
        return -1;
    }

    void showInvoices(){
        base("الفواتير");
        EditText search=input("🔎  ابحث برقم الفاتورة أو اسم الزبون أو رقم الهاتف");
        body.addView(search,margin(-1,dp(48),0,dp(8)));
        if(!invoiceSearchFilter.isEmpty()) search.setText(invoiceSearchFilter);

        // فلاتر الفواتير — مهمة خصوصاً لمحاسبة فواتير الشركاء بعد استلام الزبون للطلب.
        LinearLayout filters=card();
        TextView filterTitle=text("🔎 فلترة الفواتير",15,TEXT);filterTitle.setTypeface(Typeface.DEFAULT_BOLD);filterTitle.setGravity(Gravity.RIGHT);
        filters.addView(filterTitle,margin(-1,dp(30),0,dp(5)));

        LinearLayout partnerScopeRow=new LinearLayout(this);partnerScopeRow.setGravity(Gravity.CENTER);partnerScopeRow.setOrientation(LinearLayout.HORIZONTAL);
        Button allInvoices=button("الكل"), partnerInvoices=button("🤝 فواتير الشركاء"), normalInvoices=button("👤 عادية");
        partnerScopeRow.addView(allInvoices,new LinearLayout.LayoutParams(0,dp(42),1));
        partnerScopeRow.addView(partnerInvoices,new LinearLayout.LayoutParams(0,dp(42),1));
        partnerScopeRow.addView(normalInvoices,new LinearLayout.LayoutParams(0,dp(42),1));
        filters.addView(partnerScopeRow,margin(-1,dp(42),0,dp(5)));

        LinearLayout deliveryRow=new LinearLayout(this);deliveryRow.setGravity(Gravity.CENTER);deliveryRow.setOrientation(LinearLayout.HORIZONTAL);
        Button deliveryAll=button("كل الحالات"), notReceived=button("❌ لم يتم الاستلام"), received=button("📦 تم الاستلام");
        deliveryRow.addView(deliveryAll,new LinearLayout.LayoutParams(0,dp(42),1));
        deliveryRow.addView(notReceived,new LinearLayout.LayoutParams(0,dp(42),1));
        deliveryRow.addView(received,new LinearLayout.LayoutParams(0,dp(42),1));
        filters.addView(deliveryRow,margin(-1,dp(42),0,dp(5)));

        // اختيار شريك محدد — يساعد عند تسوية أرباح شريك واحد وسط عدد كبير من الفواتير.
        Spinner partnerFilter=new Spinner(this);
        ArrayList<Store.Customer> partnerRows=new ArrayList<>();
        ArrayList<String> partnerNames=new ArrayList<>();
        partnerNames.add("🤝 كل الشركاء");
        if(cloud==null || cloud.isAdmin()){
            for(Store.Customer c:db.customers("")) if(c.reseller && c.partnerId>0){
                partnerRows.add(c);partnerNames.add(c.name==null||c.name.trim().isEmpty()?"شريك #"+c.partnerId:c.name);
            }
        }
        ArrayAdapter<String> partnerAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,partnerNames);
        partnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        partnerFilter.setAdapter(partnerAdapter);
        // إعادة تحديد الشريك حسب partnerId وليس حسب موضعه في القائمة، لأن
        // ترتيب القائمة قد يتغير بعد وصول بيانات Firebase.
        int restorePartnerPos=0;
        if(selectedPartnerForRestore(invoicePartnerFilter, partnerRows)>=0){
            restorePartnerPos=selectedPartnerForRestore(invoicePartnerFilter, partnerRows)+1;
        }
        partnerFilter.setSelection(Math.min(restorePartnerPos, Math.max(0, partnerNames.size()-1)), false);
        if(partnerNames.size()>1) filters.addView(partnerFilter,margin(-1,dp(48),0,dp(2))); else partnerFilter.setVisibility(View.GONE);

        // فلترة حسب حساب Store الذي تم الشحن إليه.
        // يتم الحفظ بالاسم حتى تبقى الفلترة ثابتة بعد مزامنة Firebase وإعادة بناء القائمة.
        Spinner storeFilter=new Spinner(this);
        ArrayList<String> storeNames=new ArrayList<>();
        storeNames.add("🏦 كل حسابات Store");
        java.util.LinkedHashSet<String> uniqueStores=new java.util.LinkedHashSet<>();
        for(Store.ShippingAccount a:db.shippingAccountsAll()){
            if(a!=null && a.name!=null && !a.name.trim().isEmpty()) uniqueStores.add(a.name.trim());
        }
        storeNames.addAll(uniqueStores);
        ArrayAdapter<String> storeAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,storeNames);
        storeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        storeFilter.setAdapter(storeAdapter);
        int restoreStorePos=0;
        if(invoiceStoreFilter!=null && !invoiceStoreFilter.trim().isEmpty()){
            for(int k=1;k<storeNames.size();k++) if(invoiceStoreFilter.equals(storeNames.get(k))){restoreStorePos=k;break;}
        }
        storeFilter.setSelection(Math.min(restoreStorePos,Math.max(0,storeNames.size()-1)),false);
        if(cloud==null || cloud.isAdmin()) {
            filters.addView(storeFilter,margin(-1,dp(48),0,dp(2)));
        }
        body.addView(filters,margin(-1,-2,0,dp(8)));

        Button add=button(cloud != null && cloud.isAdmin()?"＋  فاتورة جديدة":"＋  إنشاء فاتورة للشريك");
        add.setTextColor(Color.WHITE);
        add.setBackground(solid(BLUE,12));
        add.setOnClickListener(v->showInvoiceEditor(-1));
        body.addView(add,margin(-1,dp(48),0,dp(8)));

        TextView resultCount=text("",12,MUTED);resultCount.setGravity(Gravity.CENTER);body.addView(resultCount,margin(-1,dp(24),0,dp(5)));
        LinearLayout accountPanel=new LinearLayout(this);accountPanel.setOrientation(LinearLayout.VERTICAL);body.addView(accountPanel);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);body.addView(list);

        // استرجاع آخر اختيارات المستخدم بدلاً من البدء دائماً من الصفر.
        final int[] scope={invoiceScopeFilter};       // 0 الكل، 1 الشركاء، 2 العاديون
        final int[] delivery={invoiceDeliveryFilter}; // 0 الكل، 1 لم يتم الاستلام، 2 تم الاستلام
        final int[] selectedPartner={invoicePartnerFilter};
        final String[] selectedStore={invoiceStoreFilter==null?"":invoiceStoreFilter};

        Runnable styleFilters=()->{
            Button[] sbs={allInvoices,partnerInvoices,normalInvoices};
            for(int j=0;j<sbs.length;j++){
                boolean active=j==scope[0];sbs[j].setTextColor(active?Color.WHITE:BLUE);sbs[j].setBackground(solid(active?BLUE:Color.rgb(239,246,255),10));
            }
            Button[] dbs={deliveryAll,notReceived,received};
            for(int j=0;j<dbs.length;j++){
                boolean active=j==delivery[0];dbs[j].setTextColor(active?Color.WHITE:BLUE);dbs[j].setBackground(solid(active?BLUE:Color.rgb(239,246,255),10));
            }
        };

        Runnable refresh=()->{
            accountPanel.removeAllViews();
            list.removeAllViews();
            String q=search.getText().toString().trim();
            invoiceSearchFilter=q;

            // بطاقة كشف الزبون تظهر فقط في العرض العام حتى لا تتعارض مع الفلاتر.
            if(scope[0]==0 && delivery[0]==0 && selectedPartner[0]==0 && !q.isEmpty()){
                int shown=0;
                for(Store.Customer c:(cloud!=null && !cloud.isAdmin()?db.partnerCustomers((int)cloud.partnerId,q):db.customers(q))){
                    if(c.reseller)continue;
                    ArrayList<Store.Invoice> unpaid=db.customerInvoices(c.id,c.name,true);
                    if(unpaid.isEmpty())continue;
                    addCustomerPaymentCard(accountPanel,c,unpaid);
                    shown++;
                    if(shown>=3)break;
                }
            }

            int count=0;
            ArrayList<Store.Invoice> source=(cloud!=null && !cloud.isAdmin())?db.partnerInvoices((int)cloud.partnerId,q):db.invoices(q);
            for(Store.Invoice i:source){
                if(cloud!=null && !cloud.isAdmin() && i.partnerId!=(int)cloud.partnerId)continue;
                if(scope[0]==1 && i.partnerId<=0)continue;
                if(scope[0]==2 && i.partnerId>0)continue;
                if(selectedPartner[0]>0 && i.partnerId!=selectedPartner[0])continue;
                if(selectedStore[0]!=null && !selectedStore[0].trim().isEmpty()){
                    if(i.shippingAccount==null || !selectedStore[0].equalsIgnoreCase(i.shippingAccount.trim()))continue;
                }
                if(delivery[0]==1 && i.deliveryReceived)continue;
                if(delivery[0]==2 && !i.deliveryReceived)continue;
                invoiceRow(list,i);count++;
            }
            resultCount.setText("عدد الفواتير الظاهرة: "+count);
            styleFilters.run();
            if(pendingInvoiceScrollId>0){
                final int targetInvoiceId=pendingInvoiceScrollId;
                pendingInvoiceScrollId=0;
                list.post(()->{
                    for(int k=0;k<list.getChildCount();k++){
                        View child=list.getChildAt(k);
                        Object tag=child.getTag();
                        if(tag instanceof Integer && ((Integer)tag)==targetInvoiceId){
                            int y=list.getTop()+child.getTop()-dp(12);
                            if(mainScroll!=null) mainScroll.scrollTo(0,Math.max(0,y));
                            break;
                        }
                    }
                });
            }
        };

        allInvoices.setOnClickListener(v->{scope[0]=0;invoiceScopeFilter=0;refresh.run();});
        partnerInvoices.setOnClickListener(v->{scope[0]=1;invoiceScopeFilter=1;refresh.run();});
        normalInvoices.setOnClickListener(v->{scope[0]=2;invoiceScopeFilter=2;refresh.run();});
        deliveryAll.setOnClickListener(v->{delivery[0]=0;invoiceDeliveryFilter=0;refresh.run();});
        notReceived.setOnClickListener(v->{delivery[0]=1;invoiceDeliveryFilter=1;refresh.run();});
        received.setOnClickListener(v->{delivery[0]=2;invoiceDeliveryFilter=2;refresh.run();});
        partnerFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(AdapterView<?> p){}
            public void onItemSelected(AdapterView<?> p,View v,int pos,long id){
                selectedPartner[0]=(pos<=0||pos-1>=partnerRows.size())?0:partnerRows.get(pos-1).partnerId;
                invoicePartnerFilter=selectedPartner[0];
                refresh.run();
            }
        });
        storeFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(AdapterView<?> p){}
            public void onItemSelected(AdapterView<?> p,View v,int pos,long id){
                selectedStore[0]=(pos<=0||pos>=storeNames.size())?"":storeNames.get(pos);
                invoiceStoreFilter=selectedStore[0];
                refresh.run();
            }
        });
        watch(search,refresh);
        refresh.run();

        // تحديث فواتير الشريك عند فتح الصفحة حتى تظهر الفواتير التي أنشأها المدير
        // على جهاز آخر، وكذلك الفواتير الجديدة التي أنشأها الشريك نفسه.
        if(cloud != null && !cloud.isAdmin()){
            cloud.syncCloudToLocalForPartner(
                refresh,
                ()->Toast.makeText(this,
                    "تعذر تحديث فواتير الشريك: " + (cloud.lastSyncError==null || cloud.lastSyncError.isEmpty() ? "تحقق من اتصال Firebase والصلاحيات" : cloud.lastSyncError),
                    Toast.LENGTH_LONG).show()
            );
        }
    }

    void addCustomerPaymentCard(LinearLayout host,Store.Customer customer,ArrayList<Store.Invoice> unpaid){
        LinearLayout card=card();
        TextView title=text("💳 حساب الزبون: "+customer.name,18,TEXT);
        title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        card.addView(title);

        double outstanding=0;
        for(Store.Invoice i:unpaid)outstanding+=invoiceOutstanding(i);

        TextView summary=text("الفواتير غير المدفوعة: "+unpaid.size()+"   •   المبلغ المتبقي: "+money(outstanding)+" DH",13,RED);
        summary.setGravity(Gravity.CENTER);
        card.addView(summary);

        TextView instruction=text("حدد الفواتير التي يريد الزبون دفعها الآن",13,MUTED);
        instruction.setGravity(Gravity.CENTER);
        card.addView(instruction);

        LinearLayout rows=new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        ArrayList<Integer> selected=new ArrayList<>();
        double[] selectedTotal={0};

        for(Store.Invoice inv:unpaid){
            LinearLayout row=new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(4),dp(3),dp(4),dp(3));
            row.setBackground(round(Color.rgb(249,251,255),BORDER,10,1));

            CheckBox cb=new CheckBox(this);
            cb.setText("#"+invoiceNo(inv)+"  •  "+inv.date);
            cb.setTextSize(14);
            cb.setTextColor(TEXT);

            TextView amount=text(money(invoiceOutstanding(inv))+" DH",14,TEXT);
            amount.setGravity(Gravity.CENTER);
            amount.setTypeface(Typeface.DEFAULT,Typeface.BOLD);

            row.addView(cb,new LinearLayout.LayoutParams(0,dp(48),1));
            row.addView(amount,new LinearLayout.LayoutParams(dp(115),dp(48)));

            cb.setOnCheckedChangeListener((buttonView,isChecked)->{
                if(isChecked){
                    if(!selected.contains(inv.id)){
                        selected.add(inv.id);
                        selectedTotal[0]+=invoiceOutstanding(inv);
                    }
                }else{
                    selected.remove((Integer)inv.id);
                    selectedTotal[0]-=invoiceOutstanding(inv);
                }
            });
            rows.addView(row,margin(-1,dp(50),0,dp(5)));
        }
        card.addView(rows);

        TextView chosen=text("المحدد: 0 فاتورة • 0.00 DH",16,TEXT);
        chosen.setGravity(Gravity.CENTER);
        card.addView(chosen);

        Button all=button("☑ تحديد كل الفواتير");
        all.setTextColor(BLUE);
        all.setOnClickListener(v->{
            for(int k=0;k<rows.getChildCount();k++){
                View rv=rows.getChildAt(k);
                if(rv instanceof LinearLayout){
                    View first=((LinearLayout)rv).getChildAt(0);
                    if(first instanceof CheckBox){
                        CheckBox cb=(CheckBox)first;
                        if(!cb.isChecked())cb.setChecked(true);
                    }
                }
            }
            chosen.setText("المحدد: "+selected.size()+" فاتورة • "+money(selectedTotal[0])+" DH");
        });
        card.addView(all);

        // تحديث المجموع مباشرة عند كل تحديد.
        for(int k=0;k<rows.getChildCount();k++){
            View rv=rows.getChildAt(k);
            if(rv instanceof LinearLayout){
                View first=((LinearLayout)rv).getChildAt(0);
                if(first instanceof CheckBox){
                    ((CheckBox)first).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
                        @Override public void onCheckedChanged(CompoundButton buttonView,boolean isChecked){
                            // يتم حسابه من الحالة الحالية لتفادي أي خطأ في التحديد.
                            selected.clear();
                            selectedTotal[0]=0;
                            for(int j=0;j<rows.getChildCount();j++){
                                View rr=rows.getChildAt(j);
                                if(rr instanceof LinearLayout){
                                    View f=((LinearLayout)rr).getChildAt(0);
                                    if(f instanceof CheckBox && ((CheckBox)f).isChecked()){
                                        int invoiceId=unpaid.get(j).id;
                                        selected.add(invoiceId);
                                        selectedTotal[0]+=invoiceOutstanding(unpaid.get(j));
                                    }
                                }
                            }
                            chosen.setText("المحدد: "+selected.size()+" فاتورة • "+money(selectedTotal[0])+" DH");
                        }
                    });
                }
            }
        }

        if(cloud == null || cloud.isAdmin()){
        Button pay=button("💵 تسديد الفواتير المحددة");
        pay.setTextColor(Color.WHITE);
        pay.setBackground(solid(GREEN,12));
        pay.setOnClickListener(v->{
            if(selected.isEmpty()){
                Toast.makeText(this,"حدد فاتورة واحدة على الأقل",Toast.LENGTH_SHORT).show();
                return;
            }
            new AlertDialog.Builder(this)
                    .setTitle("تأكيد التسديد")
                    .setMessage("سيتم تسجيل دفع "+selected.size()+" فاتورة بمجموع "+money(selectedTotal[0])+" DH بتاريخ اليوم.")
                    .setNegativeButton("إلغاء",null)
                    .setPositiveButton("تأكيد الدفع",(d,w)->{
                        ArrayList<Integer> paidIds=new ArrayList<>(selected);
                        db.setInvoicesPaidBulk(paidIds);
                        Toast.makeText(this,"تم تسديد الفواتير المحددة وتسجيل تاريخ الدفع",Toast.LENGTH_LONG).show();
                        makeBulkPaymentPdf(paidIds,customer);
                        showInvoices();
                    }).show();
        });
        card.addView(pay,new LinearLayout.LayoutParams(-1,dp(50)));
        } else {
            TextView ro=text("للعرض فقط — لا يمكن للشريك تعديل أو تسديد الفاتورة",12,MUTED);
            ro.setGravity(Gravity.CENTER);
            card.addView(ro,new LinearLayout.LayoutParams(-1,dp(42)));
        }
        host.addView(card,margin(-1,-2,0,dp(8)));
    }

    double invoiceTotal(Store.Invoice i){
        double total=0;
        for(Store.Item it:i.items)total+=it.salePrice*it.qty;
        if(i.shippingEnabled)total+=i.shippingCharge;
        return total;
    }

    int invoiceNo(Store.Invoice i){return i==null?0:(i.invoiceNumber>0?i.invoiceNumber:i.id);}

    double invoiceOutstanding(Store.Invoice i){return Math.max(0,invoiceTotal(i)-Math.max(0,i.advancePayment));}

    void invoiceRow(LinearLayout list,Store.Invoice i){
        double products=0;for(Store.Item it:i.items)products+=it.salePrice*it.qty;double total=products+(i.shippingEnabled?i.shippingCharge:0);
        LinearLayout r=card();r.setPadding(dp(10),dp(8),dp(10),dp(8));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        TextView no=text("#"+invoiceNo(i),16,BLUE);no.setTypeface(Typeface.DEFAULT,Typeface.BOLD);top.addView(no,new LinearLayout.LayoutParams(dp(60),dp(36)));
        TextView cl=text(i.client,16,TEXT);cl.setTypeface(Typeface.DEFAULT,Typeface.BOLD);top.addView(cl,new LinearLayout.LayoutParams(0,dp(36),1));
        TextView amount=text(money(total)+" DH",15,TEXT);amount.setGravity(Gravity.CENTER);top.addView(amount,new LinearLayout.LayoutParams(dp(105),dp(36)));r.addView(top);

        LinearLayout mid=new LinearLayout(this);mid.setGravity(Gravity.CENTER_VERTICAL);
        mid.addView(text("📅 "+i.date+(i.partnerId>0?"   • 🤝 شريك":""),11,MUTED),new LinearLayout.LayoutParams(0,dp(28),1));
        boolean partiallyPaid=i.advancePayment>0 && !i.paid && invoiceOutstanding(i)>0.009;
        TextView status=text(i.paid?"مدفوعة":(partiallyPaid?"مدفوعة جزئياً":"غير مدفوعة"),11,i.paid?GREEN:(partiallyPaid?BLUE:RED));status.setGravity(Gravity.CENTER);
        status.setBackground(round(i.paid?Color.rgb(232,249,238):(partiallyPaid?Color.rgb(239,246,255):Color.rgb(254,239,239)),i.paid?Color.rgb(177,230,193):(partiallyPaid?Color.rgb(195,215,240):Color.rgb(247,188,188)),20,1));
        status.setOnClickListener(v->showPaymentDate(i));mid.addView(status,new LinearLayout.LayoutParams(dp(92),dp(28)));r.addView(mid);

        TextView assemblyStatus=text(i.assemblyCompleted?"📦  تم تجميع الطلبية بالكامل":"📦  لم يتم تجميع الطلبية بعد",13,i.assemblyCompleted?GREEN:RED);
        assemblyStatus.setTypeface(Typeface.DEFAULT_BOLD);assemblyStatus.setGravity(Gravity.CENTER);
        assemblyStatus.setPadding(dp(8),dp(7),dp(8),dp(7));
        assemblyStatus.setBackground(round(i.assemblyCompleted?Color.rgb(232,249,238):Color.rgb(254,239,239),i.assemblyCompleted?Color.rgb(177,230,193):Color.rgb(247,188,188),10,1));
        r.addView(assemblyStatus,margin(-1,dp(36),0,dp(5)));

        if(i.partnerId>0){
            String accountingText=i.partnerProfitPaid?"💵  تمت محاسبة الشريك ودفع الربح"+(i.partnerProfitPaidDate!=null&&!i.partnerProfitPaidDate.isEmpty()?" • "+i.partnerProfitPaidDate:""):"⏳  لم تتم محاسبة الشريك بعد";
            TextView accountingStatus=text(accountingText,13,i.partnerProfitPaid?GREEN:RED);
            accountingStatus.setTypeface(Typeface.DEFAULT_BOLD);accountingStatus.setGravity(Gravity.CENTER);
            accountingStatus.setPadding(dp(8),dp(7),dp(8),dp(7));
            accountingStatus.setBackground(round(i.partnerProfitPaid?Color.rgb(232,249,238):Color.rgb(254,239,239),i.partnerProfitPaid?Color.rgb(177,230,193):Color.rgb(247,188,188),10,1));
            r.addView(accountingStatus,margin(-1,dp(38),0,dp(5)));
        }

        if(i.customerPhone!=null&&!i.customerPhone.isEmpty())r.addView(text("📞 "+safe(i.customerPhone)+(i.customerCity!=null&&!i.customerCity.isEmpty()?"  •  📍 "+safe(i.customerCity):""),11,MUTED));
        if(i.customerAddress!=null&&!i.customerAddress.isEmpty())r.addView(text("🏠 "+safe(i.customerAddress),11,MUTED));
        if(i.paid&&i.paidDate!=null&&!i.paidDate.isEmpty())r.addView(text("💳 تاريخ دفع الفاتورة: "+i.paidDate,11,GREEN));
        if(i.advancePayment>0){r.addView(text("💳 التسبيق: "+money(i.advancePayment)+" DH"+(i.advancePaymentDate!=null&&!i.advancePaymentDate.isEmpty()?" • "+i.advancePaymentDate:""),11,GREEN));r.addView(text("💰 المبلغ المتبقي عند الاستلام: "+money(invoiceOutstanding(i))+" DH",11,BLUE));}
        if(i.shippingEnabled){
            boolean adminView=cloud==null||cloud.isAdmin();
            r.addView(text(adminView?"🚚 شحن: "+money(i.shippingCharge)+" DH • التكلفة الفعلية: "+money(i.shippingCost)+" DH":"🚚 شحن: "+money(i.shippingCharge)+" DH",11,BLUE));
            if(i.shippingCompany!=null&&!i.shippingCompany.isEmpty())r.addView(text("🏢 شركة الشحن: "+safe(i.shippingCompany),11,BLUE));
        }
        if(i.partnerId>0){
            TextView cm=text("💰 صافي ربح الشريك: "+money(i.commission)+" DH",11,i.commission>=0?GREEN:RED);r.addView(cm);
        }
        if(i.trackingNumber!=null&&!i.trackingNumber.isEmpty())r.addView(text("🚚 تتبع: "+i.trackingNumber+" • "+(i.deliveryReceived?"تم الاستلام":"لم يتم الاستلام"),11,i.deliveryReceived?GREEN:RED));
        if(i.deliveryReceived&&i.deliveryReceivedDate!=null&&!i.deliveryReceivedDate.isEmpty())r.addView(text("📦 تاريخ الاستلام: "+i.deliveryReceivedDate,11,GREEN));
        if((cloud==null || cloud.isAdmin()) && i.shippingEnabled && i.shippingAccount!=null && !i.shippingAccount.isEmpty()) {
            r.addView(text("🏦 حساب Store: "+safe(i.shippingAccount),11,BLUE));
            r.addView(text(i.bankReceived?"🏦 تم الاستلام من شركة الشحن إلى البنك"+(i.bankReceivedDate!=null&&!i.bankReceivedDate.isEmpty()?" • "+i.bankReceivedDate:""):"⏳ لم يتم استلام المبلغ من شركة الشحن إلى البنك",11,i.bankReceived?GREEN:RED));
        }
        if(!i.deliveryReceived&&i.deliveryFailureReason!=null&&!i.deliveryFailureReason.isEmpty())r.addView(text("❌ سبب عدم الاستلام: "+i.deliveryFailureReason,11,RED));

        // جميع ملفات المشاركة تبقى ظاهرة دائمًا، لكن في صفوف منفصلة حتى لا تختفي أو تنقطع على الهاتف.
        LinearLayout shareBox=new LinearLayout(this);shareBox.setOrientation(LinearLayout.VERTICAL);shareBox.setPadding(dp(8),dp(6),dp(8),dp(6));
        shareBox.setBackground(round(Color.rgb(248,251,255),Color.rgb(218,228,241),12,1));
        TextView shareTitle=text("📤 ملفات المشاركة",13,BLUE);shareTitle.setTypeface(Typeface.DEFAULT_BOLD);shareTitle.setGravity(Gravity.RIGHT);shareBox.addView(shareTitle,margin(-1,dp(28),0,dp(4)));
        Button pdf=button("📄  مشاركة PDF الفاتورة");pdf.setTextColor(BLUE);pdf.setBackground(round(Color.WHITE,Color.rgb(205,220,238),10,1));pdf.setOnClickListener(v->makePdf(i.id));shareBox.addView(pdf,margin(-1,dp(46),0,dp(5)));
        Button photoPdf=button(i.partnerId>0?"🖼  مشاركة PDF صور الزبائن":"🖼  مشاركة PDF صور المنتجات");photoPdf.setTextColor(BLUE);photoPdf.setBackground(round(Color.WHITE,Color.rgb(205,220,238),10,1));photoPdf.setOnClickListener(v->makeProductPhotosPdf(i.id));shareBox.addView(photoPdf,margin(-1,dp(46),0,dp(5)));
        if(i.partnerId>0){Button partnerShare=button("🤝  مشاركة PDF الشريك");partnerShare.setTextColor(GREEN);partnerShare.setBackground(round(Color.WHITE,Color.rgb(190,231,204),10,1));partnerShare.setOnClickListener(v->makePartnerInvoicePdf(i.id));shareBox.addView(partnerShare,margin(-1,dp(46),0,dp(3)));}
        LinearLayout.LayoutParams shareBoxLp=new LinearLayout.LayoutParams(-1,-2);shareBoxLp.setMargins(0,dp(8),0,dp(8));r.addView(shareBox,shareBoxLp);

        LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER);actions.setOrientation(LinearLayout.HORIZONTAL);
        if(cloud==null||cloud.isAdmin()){
            Button edit=button("✎ تعديل الفاتورة");edit.setTextColor(BLUE);edit.setBackgroundColor(Color.TRANSPARENT);edit.setOnClickListener(v->showInvoiceEditor(i.id));actions.addView(edit,new LinearLayout.LayoutParams(0,dp(44),1));
            if(i.partnerId>0&&!i.partnerProfitPaid&&i.deliveryReceived){Button pay=button("💵 دفع الربح");pay.setTextColor(GREEN);pay.setBackgroundColor(Color.TRANSPARENT);pay.setOnClickListener(v->{db.setPartnerProfitPaid(i.id,true);showInvoices();});actions.addView(pay,new LinearLayout.LayoutParams(0,dp(44),1));}
            Button del=button("🗑 حذف");del.setTextColor(RED);del.setBackgroundColor(Color.TRANSPARENT);del.setOnClickListener(v->{db.deleteInvoice(i.id);showInvoices();});actions.addView(del,new LinearLayout.LayoutParams(0,dp(44),1));
        }else if(i.partnerId==(int)cloud.partnerId&&!i.shippedByAdmin){
            Button edit=button("✎ تعديل الفاتورة");edit.setTextColor(BLUE);edit.setBackgroundColor(Color.TRANSPARENT);edit.setOnClickListener(v->showInvoiceEditor(i.id));actions.addView(edit,new LinearLayout.LayoutParams(0,dp(44),1));
            actions.addView(text("قبل الشحن فقط",10,MUTED),new LinearLayout.LayoutParams(dp(110),dp(36)));
        }else if(i.partnerId==(int)cloud.partnerId&&i.shippedByAdmin){
            actions.addView(text("🔒 تم الشحن — التعديل مقفل",10,RED),new LinearLayout.LayoutParams(-2,dp(36)));
        }
        r.addView(actions);list.addView(r,margin(-1,-2,0,dp(7)));
    }

    void showPartnerInvoiceShare(int invoiceId){
        Store.Invoice inv=db.invoice(invoiceId);if(inv==null)return;
        new AlertDialog.Builder(this).setTitle("مشاركة الفاتورة مع الشريك").setItems(new String[]{"🤝 إرسال PDF الشريك","🖼 إرسال PDF صور الزبائن"},(d,which)->{if(which==0)makePartnerInvoicePdf(invoiceId);else makeProductPhotosPdf(invoiceId);}).setNegativeButton("إلغاء",null).show();
    }

    void makeBulkPaymentPdf(ArrayList<Integer> invoiceIds,Store.Customer customer){
        if(invoiceIds==null||invoiceIds.isEmpty())return;
        ArrayList<Store.Invoice> paidInvoices=new ArrayList<>();
        for(Integer id:invoiceIds){if(id!=null){Store.Invoice inv=db.invoice(id);if(inv!=null)paidInvoices.add(inv);}}
        if(paidInvoices.isEmpty())return;

        PdfDocument doc=new PdfDocument();
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        PdfDocument.Page page=null;Canvas c=null;int pageNo=0,y=0;
        double grandTotal=0;
        String paymentTime=new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.US).format(new java.util.Date());

        for(Store.Invoice inv:paidInvoices){
            int blockHeight=115+(inv.items.size()*16)+(inv.shippingEnabled?16:0);
            if(page==null||y+blockHeight>770){
                if(page!=null)doc.finishPage(page);
                page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,++pageNo).create());
                c=page.getCanvas();p.setColor(Color.WHITE);c.drawPaint(p);
                p.setColor(BLUE);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(21);c.drawText("MGE",40,45,p);
                p.setColor(TEXT);p.setTextSize(18);c.drawText("REÇU DE PAIEMENT / وصل الأداء",145,45,p);
                p.setTypeface(Typeface.DEFAULT);p.setTextSize(11);
                c.drawText("Client / الزبون : "+safe(customer==null?inv.client:customer.name),40,70,p);
                c.drawText("Date et heure / تاريخ ووقت الدفع : "+safe(inv.paidDate==null||inv.paidDate.isEmpty()?paymentTime:inv.paidDate),40,88,p);
                y=125;
            }
            p.setColor(Color.rgb(245,247,250));c.drawRoundRect(35,y-20,560,y+blockHeight,10,10,p);
            p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(13);
            c.drawText("FACTURE #"+invoiceNo(inv),48,y,p);
            p.setTypeface(Typeface.DEFAULT);p.setTextSize(10);
            c.drawText("Date facture : "+safe(inv.date),48,y+18,p);
            c.drawText("Paiement : "+safe(inv.paidDate==null?paymentTime:inv.paidDate),300,y+18,p);
            int iy=y+42;double invTotal=0;
            p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(9);
            c.drawText("Produit",48,iy,p);c.drawText("Qté",315,iy,p);c.drawText("Prix",380,iy,p);c.drawText("Total",475,iy,p);
            p.setTypeface(Typeface.DEFAULT);
            iy+=18;
            for(Store.Item it:inv.items){
                double line=it.salePrice*it.qty;invTotal+=line;
                c.drawText(trim(it.name,34),48,iy,p);c.drawText(""+it.qty,315,iy,p);c.drawText(money(it.salePrice),380,iy,p);c.drawText(money(line),475,iy,p);iy+=16;
            }
            if(inv.shippingEnabled){invTotal+=inv.shippingCharge;c.drawText("الشحن",48,iy,p);c.drawText(money(inv.shippingCharge),475,iy,p);iy+=16;}
            p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("مجموع الفاتورة: "+money(invTotal)+" DH",340,iy+8,p);
            grandTotal+=invTotal;y=iy+45;
        }
        if(page==null){page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());c=page.getCanvas();p.setColor(Color.WHITE);c.drawPaint(p);pageNo=1;}
        if(y>700){doc.finishPage(page);page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,++pageNo).create());c=page.getCanvas();p.setColor(Color.WHITE);c.drawPaint(p);y=90;}
        p.setColor(GREEN);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(17);c.drawText("TOTAL PAYÉ / مجموع المدفوعات : "+money(grandTotal)+" DH",55,y+20,p);
        p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT);p.setTextSize(11);c.drawText("Nombre de factures / عدد الفواتير : "+paidInvoices.size(),55,y+45,p);c.drawText("Merci pour votre confiance",225,y+75,p);
        doc.finishPage(page);
        sharePdfDocument(doc,"Paiement_"+safeFileName(customer==null?paidInvoices.get(0).client:customer.name)+"_"+new java.text.SimpleDateFormat("yyyyMMdd_HHmm",Locale.US).format(new java.util.Date())+".pdf");
    }

    void showPaymentDate(Store.Invoice i){
        String d=(i.paidDate==null||i.paidDate.isEmpty())?"غير مسجل":i.paidDate;
        String status=i.paid?"مدفوعة":(i.advancePayment>0?"مدفوعة جزئياً":"غير مدفوعة");
        String extra=i.advancePayment>0?"\nالتسبيق: "+money(i.advancePayment)+" DH\nالمبلغ المتبقي عند الاستلام: "+money(invoiceOutstanding(i))+" DH":"";
        new AlertDialog.Builder(this)
                .setTitle("💳 حالة دفع الفاتورة")
                .setMessage("الفاتورة رقم #"+invoiceNo(i)+"\n\nحالة الدفع: "+status+extra+(i.paid?"\nتاريخ الدفع الكامل: "+d:""))
                .setPositiveButton("حسناً",null)
                .show();
    }

    void showInvoiceEditor(int id){
        boolean adminUser=cloud != null && cloud.isAdmin();
        boolean partnerUser=cloud != null && !adminUser && cloud.partnerId>0;
        if(!adminUser && !partnerUser){
            Toast.makeText(this,"حساب الشريك غير صالح",Toast.LENGTH_SHORT).show();
            return;
        }
        // في هذه المرحلة الشريك ينشئ فاتورة جديدة فقط. تعديل/حذف فواتير الشريك يبقى للمدير.
        base(id<0?"فاتورة جديدة":"تعديل الفاتورة");Store.Invoice old=id<0?null:db.invoice(id);
        if(partnerUser && old!=null){
            if(old.partnerId!=(int)cloud.partnerId){Toast.makeText(this,"هذه الفاتورة ليست ضمن حسابك",Toast.LENGTH_SHORT).show();return;}
            if(old.shippedByAdmin){Toast.makeText(this,"تم شحن الطلبية من طرف الأدمن، لا يمكن تعديلها بعد الشحن",Toast.LENGTH_LONG).show();return;}
        }
        LinearLayout invoiceHead=card();TextView head=text("بيانات الشريك والزبون",16,TEXT);head.setTypeface(Typeface.DEFAULT,Typeface.BOLD);invoiceHead.addView(head);
        EditText partner=input("الشريك (اختياري)");Button choosePartner=button("🤝 اختيار الشريك");
        final int[] selectedPartner={partnerUser?((int)cloud.partnerId):(old==null?0:old.partnerId)};
        final int[] advanceReceivedPartner={partnerUser?((int)cloud.partnerId):(old==null?0:old.advanceReceivedByPartnerId)};
        activeInvoicePartnerId=selectedPartner[0];
        if(selectedPartner[0]>0){
            if(partnerUser) partner.setText((cloud.displayName==null||cloud.displayName.trim().isEmpty())?"الشريك الحالي":cloud.displayName);
            else {Store.Customer pc=db.customer(selectedPartner[0]);if(pc!=null)partner.setText(pc.name);}
        }
        if(partnerUser){
            partner.setEnabled(false);
            partner.setHint("الشريك الحالي");
            choosePartner.setVisibility(View.GONE);
        }
        invoiceHead.addView(partner,margin(-1,dp(48),0,dp(6)));
        invoiceHead.addView(choosePartner);
        EditText client=input("اسم الزبون *");
        EditText customerPhone=input("هاتف الزبون *");
        EditText customerCity=input("مدينة الزبون");
        EditText customerAddress=input("عنوان الزبون");
        TextView customerType=text("👤 نوع الزبون: زبون عادي",12,MUTED);customerType.setGravity(Gravity.CENTER);
        Button choose=button("🔎 اختيار زبون من القائمة");
        Button normalCustomer=button("👤 إدخال زبون عادي");normalCustomer.setTextColor(BLUE);normalCustomer.setBackground(round(Color.rgb(239,246,255),Color.rgb(195,215,240),12,1));
        final int[] selectedCustomer={old==null?0:old.clientId};
        currentSelectedCustomerIdForInvoice=selectedCustomer[0];
        if(old!=null){
            client.setText(safe(old.client));customerPhone.setText(safe(old.customerPhone));customerCity.setText(safe(old.customerCity));customerAddress.setText(safe(old.customerAddress));
            if((old.customerPhone==null||old.customerPhone.isEmpty()) && old.clientId>0){Store.Customer oc=db.customer(old.clientId);if(oc!=null){customerPhone.setText(safe(oc.phone));customerCity.setText(safe(oc.city));customerAddress.setText(safe(oc.address));}}
            customerType.setText(old.clientId>0?"🤝 زبون دائم من قائمة الزبائن":"👤 زبون عادي");
        }
        invoiceHead.addView(client,margin(-1,dp(48),0,dp(6)));
        invoiceHead.addView(customerPhone,margin(-1,dp(48),0,dp(6)));
        invoiceHead.addView(customerCity,margin(-1,dp(48),0,dp(6)));
        invoiceHead.addView(customerAddress,margin(-1,dp(48),0,dp(6)));
        LinearLayout customerActions=new LinearLayout(this);customerActions.setGravity(Gravity.CENTER);
        customerActions.addView(choose,new LinearLayout.LayoutParams(0,dp(48),1));customerActions.addView(normalCustomer,new LinearLayout.LayoutParams(0,dp(48),1));
        invoiceHead.addView(customerActions);invoiceHead.addView(customerType,margin(-1,dp(28),0,dp(2)));
        body.addView(invoiceHead,margin(-1,-2,0,dp(9)));
        choosePartner.setOnClickListener(v->partnerPicker(partner,selectedPartner,()->{
            // Changing the partner invalidates the previously selected customer.
            // This prevents a customer from Partner A remaining attached to an
            // invoice after switching to Partner B or back to the company.
            selectedCustomer[0]=0;
            currentSelectedCustomerIdForInvoice=0;
            activeInvoicePartnerId=selectedPartner[0];
            client.setText("");
            customerPhone.setText("");
            customerCity.setText("");
            customerAddress.setText("");
            customerType.setText("👤 زبون عادي");
            if(selectedPartner[0]>0 && advanceReceivedPartner[0]==0) advanceReceivedPartner[0]=selectedPartner[0];
            if(invoicePartnerModeRefresh!=null)invoicePartnerModeRefresh.run();
        }));
        final Runnable[] invoiceCustomerPriceRefresh={null};
        choose.setOnClickListener(v->customerPicker(client,customerPhone,customerCity,customerAddress,customerType,selectedCustomer,selectedPartner,()->{
            currentSelectedCustomerIdForInvoice=selectedCustomer[0];
            if(invoiceCustomerPriceRefresh[0]!=null)invoiceCustomerPriceRefresh[0].run();
        }));
        normalCustomer.setOnClickListener(v->{selectedCustomer[0]=0;currentSelectedCustomerIdForInvoice=0;customerType.setText("👤 زبون عادي");if(invoiceCustomerPriceRefresh[0]!=null)invoiceCustomerPriceRefresh[0].run();});

        LinearLayout productsCard=card();productsCard.addView(section("البحث عن منتج"));EditText search=input("🔎 اكتب اسم المنتج أو الكود");productsCard.addView(search,margin(-1,dp(48),0,dp(7)));LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);productsCard.addView(results);body.addView(productsCard,margin(-1,-2,0,dp(9)));
        LinearLayout selectedCard=card();selectedCard.addView(section("المنتجات داخل الفاتورة"));TextView selectedHint=text("المنتج                         السعر",11,MUTED);
        selectedHint.setGravity(Gravity.CENTER);
        selectedCard.addView(selectedHint);LinearLayout selected=new LinearLayout(this);selected.setOrientation(LinearLayout.VERTICAL);selectedCard.addView(selected);body.addView(selectedCard,margin(-1,-2,0,dp(9)));

        LinearLayout delivery=card();
        delivery.addView(section("التوصيل والشحن"));
        CheckBox shipping=new CheckBox(this);
        shipping.setText("🚚 هذه الفاتورة سيتم شحنها");
        shipping.setTextSize(15);
        delivery.addView(shipping);

        CheckBox assemblyCompleted=new CheckBox(this);
        assemblyCompleted.setText("📦 تم تجميع الطلبية بالكامل");
        assemblyCompleted.setTextSize(15);
        assemblyCompleted.setEnabled(adminUser);
        delivery.addView(assemblyCompleted);

        // شركة الشحن والحساب: يتم تحميلهما من الإعدادات ويمكن إضافة شركات وحسابات جديدة لاحقاً.
        LinearLayout carrierBox=new LinearLayout(this);
        carrierBox.setOrientation(LinearLayout.VERTICAL);
        carrierBox.addView(section(partnerUser?"شركة الشحن":"شركة الشحن والحساب"));
        TextView companyLabel=text("شركة الشحن",13,MUTED);
        companyLabel.setGravity(Gravity.RIGHT);
        carrierBox.addView(companyLabel,margin(-1,dp(28),0,dp(2)));
        Spinner shippingCompany=new Spinner(this);
        TextView accountLabel=text("حساب Store",13,MUTED);
        accountLabel.setGravity(Gravity.RIGHT);
        Spinner shippingAccount=new Spinner(this);
        ArrayList<Store.ShippingCompany> carrierCompanies=db.shippingCompanies();
        ArrayList<String> carrierNames=new ArrayList<>();
        for(Store.ShippingCompany c:carrierCompanies)carrierNames.add(c.name);
        ArrayAdapter<String> companyAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,carrierNames);
        companyAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        shippingCompany.setAdapter(companyAdapter);
        ArrayList<String> accountNames=new ArrayList<>();
        ArrayAdapter<String> accountAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,accountNames);
        accountAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        shippingAccount.setAdapter(accountAdapter);
        Runnable refreshCarrierAccounts=()->{
            accountAdapter.clear();
            int pos=shippingCompany.getSelectedItemPosition();
            if(pos>=0&&pos<carrierCompanies.size()){
                for(Store.ShippingAccount a:db.shippingAccounts(carrierCompanies.get(pos).id))accountAdapter.add(a.name);
            }
            accountAdapter.notifyDataSetChanged();
        };
        Runnable refreshCarrierCompanies=()->{
            carrierCompanies.clear();
            carrierCompanies.addAll(db.shippingCompanies());
            carrierNames.clear();
            for(Store.ShippingCompany c:carrierCompanies)carrierNames.add(c.name);
            companyAdapter.notifyDataSetChanged();
            if(carrierCompanies.isEmpty()){
                accountAdapter.clear();
                accountAdapter.notifyDataSetChanged();
            }else{
                if(shippingCompany.getSelectedItemPosition()<0||shippingCompany.getSelectedItemPosition()>=carrierCompanies.size())shippingCompany.setSelection(0);
                refreshCarrierAccounts.run();
            }
        };
        shippingCompany.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(AdapterView<?> p){}
            public void onItemSelected(AdapterView<?> p,View v,int position,long id){refreshCarrierAccounts.run();}
        });
        carrierBox.addView(shippingCompany,margin(-1,dp(50),0,dp(7)));
        if(!partnerUser){
            carrierBox.addView(accountLabel,margin(-1,dp(28),0,dp(2)));
            carrierBox.addView(shippingAccount,margin(-1,dp(50),0,dp(9)));
        }

        // إدارة الشحن داخل الفاتورة: أزرار منفصلة بعرض كامل حتى لا تتداخل الكتابة على الشاشات الصغيرة.
        LinearLayout shippingManage=new LinearLayout(this);
        shippingManage.setOrientation(LinearLayout.VERTICAL);
        shippingManage.setPadding(0,dp(2),0,dp(2));

        Button quickAddCompany=button("＋  إضافة شركة شحن");
        quickAddCompany.setTextSize(13);
        quickAddCompany.setGravity(Gravity.CENTER);
        quickAddCompany.setTextColor(Color.WHITE);
        quickAddCompany.setBackground(solid(BLUE,12));
        quickAddCompany.setMinHeight(0);
        quickAddCompany.setMinimumHeight(0);

        Button quickAddAccount=button("＋  إضافة حساب Store");
        quickAddAccount.setTextSize(13);
        quickAddAccount.setGravity(Gravity.CENTER);
        quickAddAccount.setTextColor(Color.WHITE);
        quickAddAccount.setBackground(solid(GREEN,12));
        quickAddAccount.setMinHeight(0);
        quickAddAccount.setMinimumHeight(0);

        shippingManage.addView(quickAddCompany,margin(-1,dp(48),0,dp(7)));
        shippingManage.addView(quickAddAccount,new LinearLayout.LayoutParams(-1,dp(48)));
        shippingManage.setVisibility(partnerUser?View.GONE:View.VISIBLE);
        carrierBox.addView(shippingManage,margin(-1,dp(3),0,dp(6)));
        delivery.addView(carrierBox);

        quickAddCompany.setOnClickListener(v->{
            EditText n=input("اسم شركة الشحن الجديدة");
            new AlertDialog.Builder(this)
                .setTitle("إضافة شركة شحن")
                .setView(n)
                .setNegativeButton("إلغاء",null)
                .setPositiveButton("حفظ",(d,w)->{
                    String x=n.getText().toString().trim();
                    if(x.isEmpty()){Toast.makeText(this,"أدخل اسم الشركة",Toast.LENGTH_SHORT).show();return;}
                    if(db.addShippingCompany(x)==-1){
                        Toast.makeText(this,"هذه الشركة موجودة مسبقاً",Toast.LENGTH_SHORT).show();
                    }else{
                        refreshCarrierCompanies.run();
                        if(shippingCompany.getCount()>0)shippingCompany.setSelection(shippingCompany.getCount()-1);
                        Toast.makeText(this,"تمت إضافة شركة الشحن",Toast.LENGTH_SHORT).show();
                    }
                }).show();
        });
        quickAddAccount.setOnClickListener(v->{
            ArrayList<Store.ShippingCompany> companies=db.shippingCompanies();
            if(companies.isEmpty()){
                Toast.makeText(this,"أضف شركة شحن أولاً",Toast.LENGTH_SHORT).show();
                return;
            }
            LinearLayout wrap=new LinearLayout(this);
            wrap.setOrientation(LinearLayout.VERTICAL);
            wrap.setPadding(dp(8),dp(4),dp(8),dp(4));
            Spinner company=new Spinner(this);
            ArrayList<String> names=new ArrayList<>();
            for(Store.ShippingCompany x:companies)names.add(x.name);
            ArrayAdapter<String> ca=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,names);
            ca.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            company.setAdapter(ca);
            EditText account=input("اسم الحساب مثل Store MGE02");
            wrap.addView(company);
            wrap.addView(account,margin(-1,dp(48),0,0));
            new AlertDialog.Builder(this)
                .setTitle("إضافة حساب Store")
                .setView(wrap)
                .setNegativeButton("إلغاء",null)
                .setPositiveButton("حفظ",(d,w)->{
                    String x=account.getText().toString().trim();
                    if(x.isEmpty()){Toast.makeText(this,"أدخل اسم الحساب",Toast.LENGTH_SHORT).show();return;}
                    int pos=company.getSelectedItemPosition();
                    if(pos>=0&&db.addShippingAccount(companies.get(pos).id,x)==-1){
                        Toast.makeText(this,"هذا الحساب موجود لهذه الشركة",Toast.LENGTH_SHORT).show();
                    }else{
                        refreshCarrierAccounts.run();
                        Toast.makeText(this,"تمت إضافة حساب Store",Toast.LENGTH_SHORT).show();
                    }
                }).show();
        });

        LinearLayout shippingOptions=new LinearLayout(this);
        shippingOptions.setOrientation(LinearLayout.VERTICAL);

        EditText shippingCharge=input("مبلغ الشحن الذي يدفعه الزبون DH");
        EditText shippingCost=input("تكلفة الشحن الفعلية من شركة التوصيل DH");
        shippingCharge.setInputType(2|8192);
        shippingCost.setInputType(2|8192);
        shippingOptions.addView(shippingCharge,margin(-1,dp(48),0,dp(6)));
        shippingOptions.addView(shippingCost,margin(-1,dp(48),0,dp(6)));

        EditText tracking=input("رقم تتبع الطلبية (اختياري)");
        shippingOptions.addView(tracking,margin(-1,dp(48),0,dp(6)));

        CheckBox shippedByAdmin=new CheckBox(this);
        shippedByAdmin.setText("🚚 تم شحن الطلبية من طرف الأدمن — يمنع الشريك من تعديلها");
        shippedByAdmin.setTextSize(14);
        shippedByAdmin.setVisibility(partnerUser?View.GONE:View.VISIBLE);
        shippingOptions.addView(shippedByAdmin);

        CheckBox received=new CheckBox(this);
        received.setText("📦 تم الاستلام من طرف الزبون");
        shippingOptions.addView(received);

        CheckBox notReceived=new CheckBox(this);
        notReceived.setText("❌ لم يتم الاستلام من طرف الزبون");
        shippingOptions.addView(notReceived);

        LinearLayout failureBox=new LinearLayout(this);
        failureBox.setOrientation(LinearLayout.VERTICAL);
        TextView reasonLabel=section("سبب عدم الاستلام");
        Spinner failureReason=new Spinner(this);
        String[] reasons={"رقم الهاتف خاطئ","الزبون غير مهتم","العنوان خاطئ","المنتوج ليس الذي طلبه","رفض الدفع عند الاستلام","لم يتوصل بالطلب","طلب إرجاع","سبب آخر"};
        ArrayAdapter<String> reasonAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,reasons);
        reasonAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        failureReason.setAdapter(reasonAdapter);
        failureBox.addView(reasonLabel);
        failureBox.addView(failureReason,new LinearLayout.LayoutParams(-1,dp(48)));
        shippingOptions.addView(failureBox);

        if(partnerUser){
            shippingCost.setVisibility(View.GONE);
            tracking.setVisibility(View.GONE);
            received.setVisibility(View.GONE);
            notReceived.setVisibility(View.GONE);
            failureBox.setVisibility(View.GONE);
        }
        delivery.addView(shippingOptions);
        body.addView(delivery,margin(-1,-2,0,dp(9)));

        LinearLayout advanceCard=card();
        advanceCard.addView(section("التسبيق المالي"));
        TextView advanceRecipient=text("الشريك الذي استلم التسبيق: "+(advanceReceivedPartner[0]>0?"محدد":"لم يتم تحديده"),14,TEXT);
        advanceRecipient.setGravity(Gravity.RIGHT);
        Button chooseAdvanceRecipient=button("🤝 تحديد الشريك الذي استلم التسبيق");
        chooseAdvanceRecipient.setTextColor(BLUE);
        chooseAdvanceRecipient.setVisibility(partnerUser?View.GONE:View.VISIBLE);
        chooseAdvanceRecipient.setOnClickListener(v->{
            if(selectedPartner[0]<=0){Toast.makeText(this,"اختر الشريك أولاً",Toast.LENGTH_SHORT).show();return;}
            Store.Customer pc=db.partnerAccountCustomer(selectedPartner[0]);
            advanceReceivedPartner[0]=selectedPartner[0];
            advanceRecipient.setText("الشريك الذي استلم التسبيق: "+(pc==null?"الشريك":pc.name));
        });
        if(partnerUser){ advanceReceivedPartner[0]=(int)cloud.partnerId; advanceRecipient.setText("الشريك الذي استلم التسبيق: "+(cloud.displayName==null?"الشريك":cloud.displayName)); }
        else if(advanceReceivedPartner[0]>0){Store.Customer apc=db.partnerAccountCustomer(advanceReceivedPartner[0]);advanceRecipient.setText("الشريك الذي استلم التسبيق: "+(apc==null?"الشريك":apc.name));}
        advanceCard.addView(advanceRecipient,margin(-1,dp(34),0,dp(3)));
        advanceCard.addView(chooseAdvanceRecipient,margin(-1,dp(44),0,dp(4)));
        EditText advancePayment=input("مبلغ التسبيق الذي دفعه الزبون مسبقاً DH");
        advancePayment.setInputType(2|8192);
        advancePayment.setVisibility(partnerUser?View.GONE:View.VISIBLE);
        advanceCard.addView(advancePayment,margin(-1,dp(48),0,dp(4)));
        TextView advanceHint=text("💳 التسبيق يُقتطع من المبلغ الذي سيدفعه الزبون عند الاستلام عبر شركة الشحن.",11,MUTED);
        advanceHint.setGravity(Gravity.RIGHT);
        advanceHint.setVisibility(partnerUser?View.GONE:View.VISIBLE);
        advanceCard.addView(advanceHint,margin(-1,dp(36),0,dp(3)));
        body.addView(advanceCard,margin(-1,-2,0,dp(9)));

        LinearLayout totalCard=card();TextView total=text("المجموع على الزبون\n0.00 DH",19,TEXT);total.setGravity(Gravity.CENTER);total.setTypeface(Typeface.DEFAULT,Typeface.BOLD);totalCard.addView(total);TextView remaining=text("المبلغ عند الاستلام: 0.00 DH",16,BLUE);remaining.setGravity(Gravity.CENTER);totalCard.addView(remaining);activeInvoiceRemainingView=remaining;activeInvoiceAdvanceField=advancePayment;TextView commission=text("صافي ربح الشريك بعد الشحن: 0.00 DH",15,GREEN);commission.setGravity(Gravity.CENTER);totalCard.addView(commission);CheckBox profitPaid=new CheckBox(this);profitPaid.setText("💵 تم دفع أرباح الشريك");profitPaid.setTextSize(15);profitPaid.setEnabled(false);totalCard.addView(profitPaid);
        CompoundButton.OnCheckedChangeListener deliveryStateListener=(button,checked)->{
            if(button==received && checked){
                if(notReceived.isChecked())notReceived.setChecked(false);
            }else if(button==notReceived && checked){
                if(received.isChecked())received.setChecked(false);
            }
            boolean showReason=notReceived.isChecked();
            failureBox.setVisibility(showReason?View.VISIBLE:View.GONE);
            profitPaid.setEnabled(received.isChecked());
            if(!received.isChecked())profitPaid.setChecked(false);
        };
        received.setOnCheckedChangeListener(deliveryStateListener);
        notReceived.setOnCheckedChangeListener(deliveryStateListener);
        failureBox.setVisibility(View.GONE);
        CheckBox paid=new CheckBox(this);paid.setText("الفاتورة مدفوعة");paid.setTextSize(15);paid.setVisibility(partnerUser?View.GONE:View.VISIBLE);totalCard.addView(paid);LinearLayout actions=new LinearLayout(this);Button save=button("حفظ الفاتورة");save.setTextColor(Color.WHITE);save.setBackground(solid(GREEN,12));Button pdf=button("تصدير PDF");pdf.setTextColor(Color.WHITE);pdf.setBackground(solid(BLUE,12));pdf.setEnabled(id>=0);actions.addView(save,new LinearLayout.LayoutParams(0,dp(52),1));actions.addView(pdf,new LinearLayout.LayoutParams(0,dp(52),1));totalCard.addView(actions);body.addView(totalCard,margin(-1,-2,0,dp(12)));

        ArrayList<Store.Item> items=new ArrayList<>();
        final boolean editingExistingInvoice = old != null;
        // On edit, the invoice itself is the source of truth. Never replace its
        // Store account, customer shipping amount, or actual shipping cost with
        // current defaults. These values may differ from today's settings.
        final String originalShippingCompany = old == null ? "" : safe(old.shippingCompany).trim();
        final String originalShippingAccount = old == null ? "" : safe(old.shippingAccount).trim();
        final double originalShippingCharge = old == null ? 0 : old.shippingCharge;
        final double originalShippingCost = old == null ? 0 : old.shippingCost;
        invoicePartnerModeRefresh=null;
        invoicePartnerMode=selectedPartner[0]>0;
        if(old!=null){
            items.addAll(old.items);
            paid.setChecked(old.paid);
            shipping.setChecked(old.shippingEnabled);
            shippingCharge.setText(money(old.shippingCharge));
            shippingCost.setText(money(old.shippingCost));
            advancePayment.setText(money(old.advancePayment));
            advanceReceivedPartner[0]=old.advanceReceivedByPartnerId;
            if(advanceReceivedPartner[0]>0){Store.Customer apc=db.partnerAccountCustomer(advanceReceivedPartner[0]);advanceRecipient.setText("الشريك الذي استلم التسبيق: "+(apc==null?"الشريك":apc.name));}
            tracking.setText(safe(old.trackingNumber));
            received.setChecked(old.deliveryReceived);
            notReceived.setChecked(old.shippingEnabled&&!old.deliveryReceived&&old.deliveryFailureReason!=null&&!old.deliveryFailureReason.isEmpty());
            profitPaid.setChecked(old.partnerProfitPaid);
            assemblyCompleted.setChecked(old.assemblyCompleted);
            selectFailureReason(failureReason,old.deliveryFailureReason,reasons);
            failureBox.setVisibility(notReceived.isChecked()?View.VISIBLE:View.GONE);
            // The account list depends on the selected shipping company. Restore
            // company first, rebuild its accounts, then restore the exact account.
            selectSpinnerValue(shippingCompany,originalShippingCompany);
            refreshCarrierAccounts.run();
            if(!originalShippingAccount.isEmpty()){
                boolean found=false;
                for(int ai=0;ai<shippingAccount.getCount();ai++){Object av=shippingAccount.getItemAtPosition(ai);if(originalShippingAccount.equals(av==null?"":av.toString())){found=true;break;}}
                if(!found){accountAdapter.add(originalShippingAccount);accountAdapter.notifyDataSetChanged();}
            }
            selectSpinnerValue(shippingAccount,originalShippingAccount);
            shippedByAdmin.setChecked(old.shippedByAdmin);
        }else{
            shippingCharge.setText(db.get("default_shipping","30"));
            shippingCost.setText(db.get("default_shipping","30"));
            failureBox.setVisibility(View.GONE);
            shippingCompany.setSelection(0);
            refreshCarrierAccounts.run();
            shippingAccount.setSelection(0);
        }
        if(selectedPartner[0]>0){ for(Store.Item it:items){ Store.Product pp=db.product(it.productId); if(pp!=null){ if(it.partnerPrice<=0)it.partnerPrice=partnerSettlementPrice(pp,it.qty,selectedPartner[0]); } } }
        Runnable refreshShipping=()->{
            boolean en=shipping.isChecked();
            shippingOptions.setVisibility(en?View.VISIBLE:View.GONE);
            carrierBox.setVisibility(en?View.VISIBLE:View.GONE);
            shippingCharge.setEnabled(en);
            shippingCost.setEnabled(en);
            if(en&&toD(shippingCharge.getText().toString())<=0){
                // Existing invoices keep their stored values. Defaults are only
                // allowed for a brand-new invoice (or an explicitly empty value).
                if(!editingExistingInvoice){
                    double d=selectedPartner[0]>0?partnerDefaultShipping(selectedPartner[0]):toD(db.get("default_shipping","30"));
                    shippingCharge.setText(money(d));
                    shippingCost.setText(money(d));
                } else {
                    shippingCharge.setText(money(originalShippingCharge));
                    shippingCost.setText(money(originalShippingCost));
                }
            }
            if(!en){
                shippingCharge.setText("0");
                shippingCost.setText("0");
                received.setChecked(false);
                notReceived.setChecked(false);
                failureBox.setVisibility(View.GONE);
                profitPaid.setChecked(false);
            }
            updateFinancials(total,commission,items,en,toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));updateAdvanceSummary(total,remaining,items,en,toD(shippingCharge.getText().toString()),toD(advancePayment.getText().toString()));
        };
        shipping.setOnCheckedChangeListener((b,c)->refreshShipping.run());
        TextWatcher financeWatcher=new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));updateAdvanceSummary(total,remaining,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(advancePayment.getText().toString()));}public void afterTextChanged(Editable e){}};shippingCharge.addTextChangedListener(financeWatcher);shippingCost.addTextChangedListener(financeWatcher);
        TextWatcher advanceWatcher=new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){updateAdvanceSummary(total,remaining,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(advancePayment.getText().toString()));}public void afterTextChanged(Editable e){}};
        advancePayment.addTextChangedListener(advanceWatcher);
        invoicePartnerModeRefresh=()->{
            invoicePartnerMode=selectedPartner[0]>0;
            activeInvoicePartnerId=selectedPartner[0];
            for(Store.Item it:items){
                Store.Product pp=db.product(it.productId);
                if(pp!=null){
                    // Never turn the partner settlement price into the customer
                    // sale price. On edit, keep the invoice's stored customer
                    // sale price exactly as it was. Remembered customer pricing
                    // is applied when a customer is explicitly selected or when
                    // a new product is added.
                    if(!editingExistingInvoice) it.salePrice=preferredSalePrice(pp,it.qty,selectedCustomer[0],false);
                    if(invoicePartnerMode && it.partnerPrice<=0) it.partnerPrice=partnerSettlementPrice(pp,it.qty,selectedPartner[0]);
                }
            }
            selectedHint.setText("المنتج                         السعر");
            renderItems(selected,items,total,commission,shipping,shippingCharge,shippingCost,invoicePartnerMode);
            updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));
            updateAdvanceSummary(total,remaining,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(advancePayment.getText().toString()));
        };
        invoiceCustomerPriceRefresh[0]=()->{for(Store.Item it:items){Store.Product pp=db.product(it.productId);if(pp!=null)it.salePrice=preferredSalePrice(pp,it.qty,selectedCustomer[0],selectedPartner[0]>0);}renderItems(selected,items,total,commission,shipping,shippingCharge,shippingCost,selectedPartner[0]>0);updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));updateAdvanceSummary(total,remaining,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(advancePayment.getText().toString()));};
        Runnable update=()->{results.removeAllViews();String q=search.getText().toString().trim();if(!q.isEmpty())for(Store.Product p:db.products(q))if(p.available)productSearchRow(results,p,items,total,commission,selected,shipping,shippingCharge,shippingCost,selectedPartner[0]>0);renderItems(selected,items,total,commission,shipping,shippingCharge,shippingCost,selectedPartner[0]>0);updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));updateAdvanceSummary(total,remaining,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(advancePayment.getText().toString()));};watch(search,update);update.run();refreshShipping.run();
        final boolean[] savingInvoice = {false};
        // For a new invoice, one number is reserved atomically in Firestore and
        // reused when the local invoice is inserted. This prevents Admin +
        // Partner devices from generating the same invoice number concurrently.
        final int[] allocatedInvoiceNumber = {0};
        final boolean[] allocatedInvoiceNumberFinal = {false};
        save.setOnClickListener(v->{
            if(savingInvoice[0]) return;
            savingInvoice[0] = true;
            if(client.getText().toString().trim().isEmpty()){savingInvoice[0]=false;client.setError("أدخل اسم الزبون");return;}
            if(items.isEmpty()){savingInvoice[0]=false;Toast.makeText(this,"أضف منتجاً واحداً على الأقل",Toast.LENGTH_SHORT).show();return;}
            boolean ship=shipping.isChecked();
            boolean rec=ship&&received.isChecked();
            boolean notRec=ship&&notReceived.isChecked();
            boolean pp=ship&&profitPaid.isChecked();
            if(selectedPartner[0]>0&&pp&&!rec){
                savingInvoice[0]=false;
                Toast.makeText(this,"لا يمكن دفع ربح الشريك قبل استلام الزبون للطلبية",Toast.LENGTH_LONG).show();
                return;
            }
            double sc=ship?toD(shippingCharge.getText().toString()):0;
            double actual=ship?toD(shippingCost.getText().toString()):0;
            String tr=ship?tracking.getText().toString().trim():"";
            String reason=(notRec&&failureReason.getSelectedItem()!=null)?failureReason.getSelectedItem().toString():"";
            int invoicePartnerId=partnerUser?((int)cloud.partnerId):selectedPartner[0];
            double finalAdvance=partnerUser?((old!=null)?old.advancePayment:0):Math.max(0,toD(advancePayment.getText().toString()));
            double grossForPayment=0;for(Store.Item it:items)grossForPayment+=it.salePrice*it.qty;if(ship)grossForPayment+=sc;
            finalAdvance=Math.min(finalAdvance,Math.max(0,grossForPayment));
            boolean finalPaid=paid.isChecked() || finalAdvance>=Math.max(0,grossForPayment-0.01);
            boolean finalRec=rec, finalNotRec=notRec, finalPp=pp;
            boolean finalShipped=shippedByAdmin.isChecked();
            String finalTracking=partnerUser?"":tr, finalReason=reason, finalCompany=ship&&shippingCompany.getSelectedItem()!=null?shippingCompany.getSelectedItem().toString():"", finalAccount=partnerUser?"":(ship&&shippingAccount.getSelectedItem()!=null?shippingAccount.getSelectedItem().toString():"");
            double finalActual=partnerUser?0:actual;
            if(partnerUser && old!=null){
                finalPaid=old.paid; finalRec=old.deliveryReceived; finalNotRec=ship&&!old.deliveryReceived&&old.deliveryFailureReason!=null&&!old.deliveryFailureReason.isEmpty(); finalPp=old.partnerProfitPaid;
                finalShipped=old.shippedByAdmin; finalTracking=""; finalReason=old.deliveryFailureReason; finalActual=0; finalAccount=""; finalAdvance=old.advancePayment; advancePayment.setText(money(old.advancePayment));
            }
            if(customerPhone.getText().toString().trim().isEmpty()){savingInvoice[0]=false;customerPhone.setError("أدخل هاتف الزبون");return;}
            String customerTypeValue=selectedCustomer[0]>0?"registered":"normal";

            // New invoice numbers use the shared Firestore counter when online.
            // If Firebase is temporarily unreachable, save immediately with a
            // provisional local number. The invoice has its own UUID/cloud_key,
            // so it cannot overwrite another invoice. On the next successful
            // sync the provisional number is replaced by the next global number.
            if(id<0 && allocatedInvoiceNumber[0]<=0){
                save.setEnabled(false);
                if(cloud!=null && cloud.isLoggedIn()){
                    cloud.allocateInvoiceNumber()
                        .addOnSuccessListener(number->{
                            allocatedInvoiceNumber[0]=number==null?0:number;
                            allocatedInvoiceNumberFinal[0]=allocatedInvoiceNumber[0]>0;
                            if(allocatedInvoiceNumber[0]<=0) allocatedInvoiceNumber[0]=db.nextLocalInvoiceNumber();
                            if(allocatedInvoiceNumber[0]>0){
                                savingInvoice[0]=false;
                                save.setEnabled(true);
                                save.performClick();
                            }else{
                                savingInvoice[0]=false;save.setEnabled(true);
                                Toast.makeText(this,"تعذر إنشاء رقم الفاتورة",Toast.LENGTH_LONG).show();
                            }
                        })
                        .addOnFailureListener(e->{
                            allocatedInvoiceNumber[0]=db.nextLocalInvoiceNumber();
                            allocatedInvoiceNumberFinal[0]=false;
                            savingInvoice[0]=false;
                            save.setEnabled(true);
                            save.performClick();
                        });
                }else{
                    allocatedInvoiceNumber[0]=db.nextLocalInvoiceNumber();
                    allocatedInvoiceNumberFinal[0]=false;
                    savingInvoice[0]=false;
                    save.setEnabled(true);
                    save.performClick();
                }
                return;
            }

            // Save locally first, disable the button immediately, then push only this invoice.
            // This prevents double invoices caused by tapping Save repeatedly while a full sync is running.
            save.setEnabled(false);
            int savedInvoiceId=db.saveInvoice(id,selectedCustomer[0],client.getText().toString().trim(),customerPhone.getText().toString().trim(),customerCity.getText().toString().trim(),customerAddress.getText().toString().trim(),customerTypeValue,finalPaid,invoicePartnerId,ship,sc,finalActual,finalAdvance,advanceReceivedPartner[0],finalTracking,finalCompany,finalAccount,finalRec,finalReason,finalPp,finalShipped,items,allocatedInvoiceNumber[0],allocatedInvoiceNumberFinal[0]);
            if(savedInvoiceId>0) db.setInvoiceAssemblyCompleted(savedInvoiceId,assemblyCompleted.isChecked());
            // Remember the last manually used sale price per registered customer/product.
            // For partner invoices, the partner-specific price is remembered separately.
            if(savedInvoiceId>0){
                for(Store.Item it:items){
                    // Remember the customer-facing sale price for BOTH normal
                    // customers and customers belonging to a partner. The
                    // partner settlement price is stored separately in
                    // partner_price and must never overwrite this value.
                    if(selectedCustomer[0]>0 && it.salePrice>0) db.saveCustomerProductPrice(selectedCustomer[0],it.productId,it.salePrice);
                    if(adminUser && invoicePartnerId>0 && it.partnerPrice>0){
                        Store.PartnerProductSetting ps=db.partnerProductSetting(invoicePartnerId,it.productId);
                        db.savePartnerProductSetting(invoicePartnerId,it.productId,it.partnerPrice,ps==null?"":ps.priceTiers,ps==null?"":ps.customerImage);
                    }
                }
            }
            // Editing: return to the same invoice card instead of jumping to the top.
            // Creating a new invoice keeps the normal list position.
            pendingInvoiceScrollId = id>=0 ? savedInvoiceId : 0;
            showInvoices();
            if(cloud!=null && savedInvoiceId>0){
                Toast.makeText(this,"تم حفظ الفاتورة، جارٍ إرسالها للسحابة…",Toast.LENGTH_SHORT).show();
                cloud.pushInvoiceNow(savedInvoiceId,
                    ()->{
                        cloud.syncRememberedSalePrices(()->Toast.makeText(this,"تمت مزامنة الفاتورة والأسعار المحفوظة بنجاح",Toast.LENGTH_SHORT).show(),()->Toast.makeText(this,"تمت مزامنة الفاتورة، وسيتم مزامنة الأسعار لاحقاً.",Toast.LENGTH_SHORT).show());
                    },
                    ()->Toast.makeText(this,"تم حفظ الفاتورة محلياً. ستتم مزامنتها تلقائياً عند توفر الإنترنت.",Toast.LENGTH_LONG).show());
            } else {
                Toast.makeText(this,"تم حفظ الفاتورة بنجاح",Toast.LENGTH_SHORT).show();
            }
        });
        pdf.setOnClickListener(v->{if(id>=0)makePdf(id);});
    }

    void selectFailureReason(Spinner spinner,String value,String[] reasons){
        if(value==null||value.isEmpty())return;
        for(int i=0;i<reasons.length;i++)if(reasons[i].equals(value)){spinner.setSelection(i);return;}
    }

    void selectSpinnerValue(Spinner spinner,String value){
        if(spinner==null||value==null||value.isEmpty())return;
        for(int i=0;i<spinner.getCount();i++){
            Object item=spinner.getItemAtPosition(i);
            if(item!=null&&value.equals(item.toString())){spinner.setSelection(i);return;}
        }
    }

    double partnerDefaultShipping(int partnerId){Store.Customer p=db.partnerAccountCustomer(partnerId);return p==null?30:p.defaultShipping;}

    void productSearchRow(LinearLayout box,Store.Product p,ArrayList<Store.Item> items,TextView total,TextView commission,LinearLayout selected,CheckBox shipping,EditText shippingCharge,EditText shippingCost){productSearchRow(box,p,items,total,commission,selected,shipping,shippingCharge,shippingCost,invoicePartnerMode);}
    void productSearchRow(LinearLayout box,Store.Product p,ArrayList<Store.Item> items,TextView total,TextView commission,LinearLayout selected,CheckBox shipping,EditText shippingCharge,EditText shippingCost,boolean partnerMode){
        LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(5),dp(4),dp(5),dp(4));r.setBackground(round(Color.rgb(249,251,255),Color.rgb(219,228,240),10,1));ImageView im=new ImageView(this);loadImage(im,p.image);im.setScaleType(ImageView.ScaleType.CENTER_CROP);r.addView(im,new LinearLayout.LayoutParams(dp(55),dp(55)));LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(7),0,dp(7),0);TextView n=text(p.name,14,TEXT);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);info.addView(n);double displayPrice=preferredSalePrice(p,1,currentSelectedCustomerIdForInvoice,false);
        String priceLabel=(currentSelectedCustomerIdForInvoice>0?"آخر سعر للزبون: ":"السعر للزبون: ");
        info.addView(text("Code: "+safe(p.code)+" • "+priceLabel+money(displayPrice)+" DH",11,MUTED));r.addView(info,new LinearLayout.LayoutParams(0,dp(64),1));Button plus=button("＋");plus.setTextColor(Color.WHITE);plus.setBackground(solid(BLUE,10));plus.setOnClickListener(v->{addItem(items,p,partnerMode);renderItems(selected,items,total,commission,shipping,shippingCharge,shippingCost,partnerMode);updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));});r.addView(plus,new LinearLayout.LayoutParams(dp(52),dp(50)));box.addView(r,margin(-1,dp(70),0,dp(5)));
    }

    void renderItems(LinearLayout box,ArrayList<Store.Item> items,TextView total,TextView commission,CheckBox shipping,EditText shippingCharge,EditText shippingCost){renderItems(box,items,total,commission,shipping,shippingCharge,shippingCost,invoicePartnerMode);}
    void renderItems(LinearLayout box,ArrayList<Store.Item> items,TextView total,TextView commission,CheckBox shipping,EditText shippingCharge,EditText shippingCost,boolean partnerMode){
        box.removeAllViews();
        for(int k=0;k<items.size();k++){
            final int idx=k; Store.Item it=items.get(k);
            LinearLayout r=card(); r.setPadding(dp(10),dp(8),dp(10),dp(8)); r.setOrientation(LinearLayout.VERTICAL);
            TextView n=text("📦 "+safe(it.name),15,TEXT); n.setTypeface(Typeface.DEFAULT,Typeface.BOLD); n.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
            r.addView(n,new LinearLayout.LayoutParams(-1,dp(38)));
            TextView qty=text("الكمية: "+it.qty+" • سعر الكمية: "+money(it.salePrice)+" DH",11,MUTED); qty.setGravity(Gravity.RIGHT); r.addView(qty,new LinearLayout.LayoutParams(-1,dp(28)));

            LinearLayout controls=new LinearLayout(this); controls.setGravity(Gravity.CENTER_VERTICAL);
            Button minus=button("−"), plus=button("+"), del=button("×");
            minus.setTextSize(16); plus.setTextSize(16); del.setTextColor(RED);
            controls.addView(minus,new LinearLayout.LayoutParams(dp(42),dp(44)));
            controls.addView(plus,new LinearLayout.LayoutParams(dp(42),dp(44)));
            controls.addView(del,new LinearLayout.LayoutParams(dp(42),dp(44)));
            EditText sale=input(partnerMode?"سعر البيع للزبون":"السعر"); sale.setText(money(it.salePrice)); sale.setInputType(2|8192);
            controls.addView(sale,new LinearLayout.LayoutParams(0,dp(48),1));
            r.addView(controls,new LinearLayout.LayoutParams(-1,dp(54)));
            if(partnerMode){
                LinearLayout partnerRow=new LinearLayout(this); partnerRow.setGravity(Gravity.CENTER_VERTICAL);
                TextView lbl=text("💼 سعر محاسبة الشريك",12,MUTED); lbl.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
                partnerRow.addView(lbl,new LinearLayout.LayoutParams(0,dp(42),1));
                EditText partnerPrice=input("سعر الشريك"); if(it.partnerPrice<=0)it.partnerPrice=partnerSettlementPrice(db.product(it.productId),it.qty,selectedPartnerIdForPricing()); partnerPrice.setText(money(it.partnerPrice)); partnerPrice.setInputType(2|8192);
                partnerRow.addView(partnerPrice,new LinearLayout.LayoutParams(dp(150),dp(44)));
                r.addView(partnerRow,new LinearLayout.LayoutParams(-1,dp(46)));
                partnerPrice.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){} public void onTextChanged(CharSequence s,int a,int b,int c){it.partnerPrice=toD(s.toString()); updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));} public void afterTextChanged(Editable e){}});
            }
            box.addView(r,margin(-1,-2,0,dp(7)));

            minus.setOnClickListener(v->{ if(it.qty>1) { it.qty--; Store.Product pp=db.product(it.productId); if(pp!=null){ it.salePrice=preferredSalePrice(pp,it.qty,currentSelectedCustomerIdForInvoice,false); } } else items.remove(idx); renderItems(box,items,total,commission,shipping,shippingCharge,shippingCost,partnerMode); updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString())); });
            plus.setOnClickListener(v->{ it.qty++; Store.Product pp=db.product(it.productId); if(pp!=null){ it.salePrice=preferredSalePrice(pp,it.qty,currentSelectedCustomerIdForInvoice,false); } renderItems(box,items,total,commission,shipping,shippingCharge,shippingCost,partnerMode); updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString())); });
            del.setOnClickListener(v->{ items.remove(idx); renderItems(box,items,total,commission,shipping,shippingCharge,shippingCost,partnerMode); updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString())); });
            sale.addTextChangedListener(new TextWatcher(){
                public void beforeTextChanged(CharSequence s,int a,int b,int c){}
                public void onTextChanged(CharSequence s,int a,int b,int c){ it.salePrice=toD(s.toString()); updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString())); }
                public void afterTextChanged(Editable e){}
            });
        }
    }

    void updateAdvanceSummary(TextView totalView,TextView remainingView,ArrayList<Store.Item> items,boolean shippingEnabled,double shippingCharge,double advance){double gross=0;for(Store.Item it:items)gross+=it.salePrice*it.qty;if(shippingEnabled)gross+=shippingCharge;double a=Math.min(Math.max(0,advance),Math.max(0,gross));double due=Math.max(0,gross-a);totalView.setText("المجموع على الزبون\n"+money(gross)+" DH"+(shippingEnabled?"\nشحن: "+money(shippingCharge)+" DH":"\nاستلام من المتجر — بدون شحن"));remainingView.setText("المبلغ عند الاستلام: "+money(due)+" DH"+(a>0?"\nالتسبيق: "+money(a)+" DH":""));}

    void updateFinancials(TextView total,TextView commission,ArrayList<Store.Item> items,boolean shippingEnabled,double shippingCharge,double shippingCost){double sell=0,partnerMargin=0,productProfit=0;for(Store.Item i:items){sell+=i.salePrice*i.qty;productProfit+=(i.salePrice-i.price)*i.qty;double pp=i.partnerPrice>0?i.partnerPrice:i.salePrice;partnerMargin+=(i.salePrice-pp)*i.qty;}double customerTotal=sell+(shippingEnabled?shippingCharge:0);double net=invoicePartnerMode?(partnerMargin+(shippingEnabled?shippingCharge:0)-(shippingEnabled?shippingCost:0)):(shippingEnabled?0:0);total.setText("المجموع على الزبون\n"+money(customerTotal)+" DH"+(shippingEnabled?"\nشحن: "+money(shippingCharge)+" DH":"\nاستلام من المتجر — بدون شحن"));if(activeInvoiceRemainingView!=null&&activeInvoiceAdvanceField!=null)updateAdvanceSummary(total,activeInvoiceRemainingView,items,shippingEnabled,shippingCharge,toD(activeInvoiceAdvanceField.getText().toString()));commission.setText("صافي ربح الشريك بعد الشحن: "+money(net)+" DH"+(invoicePartnerMode?"\nسعر الشريك: يتم احتسابه بشكل منفصل عن سعر الزبون":""));commission.setTextColor(net>=0?GREEN:RED);}
    double partnerSettlementPrice(Store.Product p,int qty,int partnerId){
        if(partnerId>0){ double own=db.partnerPriceForQty(partnerId,p.id,qty); if(own>0)return own; }
        return p.priceForQty(qty);
    }
    int selectedPartnerIdForPricing(){ return invoicePartnerMode ? activeInvoicePartnerId : 0; }
    double preferredSalePrice(Store.Product p,int qty,int customerId,boolean partnerMode){
        if(customerId>0){double remembered=db.customerProductPrice(customerId,p.id);if(remembered>0)return remembered;}
        return p.priceForQty(qty);
    }
    void addItem(ArrayList<Store.Item> items,Store.Product p){addItem(items,p,invoicePartnerMode);}
    void addItem(ArrayList<Store.Item> items,Store.Product p,boolean partnerMode){
        int pid=selectedPartnerIdForPricing();
        for(Store.Item it:items)if(it.productId==p.id){it.qty++;it.salePrice=preferredSalePrice(p,it.qty,currentSelectedCustomerIdForInvoice,false);return;}
        double sale=preferredSalePrice(p,1,currentSelectedCustomerIdForInvoice,false);double pp=partnerMode?partnerSettlementPrice(p,1,pid):sale;items.add(new Store.Item(p.id,p.name,p.price,sale,pp,1));
    }

    void customerPicker(EditText client,EditText phone,EditText city,EditText address,TextView type,int[] selected,int[] partner){customerPicker(client,phone,city,address,type,selected,partner,null);}
    void customerPicker(EditText client,EditText phone,EditText city,EditText address,TextView type,int[] selected,int[] partner,Runnable onSelected){
        EditText s=input("🔎 ابحث عن الزبون");LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);ScrollView sv=new ScrollView(this);sv.addView(list);LinearLayout wrap=new LinearLayout(this);wrap.setOrientation(LinearLayout.VERTICAL);wrap.setPadding(dp(5),dp(5),dp(5),dp(5));wrap.addView(s);wrap.addView(sv,new LinearLayout.LayoutParams(-1,dp(400)));
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle(partner[0]>0?"زبائن الشريك":"اختيار الزبون الدائم").setView(wrap).setNegativeButton("إلغاء",null).create();
        Runnable r=()->{
            list.removeAllViews();
            ArrayList<Store.Customer> cs=partner[0]>0
                    ?db.partnerCustomers(partner[0],s.getText().toString())
                    :db.companyCustomers(s.getText().toString());
            for(Store.Customer c:cs){
                Button b=button("👤 "+c.name+"\n📞 "+safe(c.phone)+(c.city==null||c.city.isEmpty()?"":" • 📍 "+c.city));
                b.setOnClickListener(v->{client.setText(c.name);phone.setText(safe(c.phone));city.setText(safe(c.city));address.setText(safe(c.address));selected[0]=c.id;type.setText("🤝 زبون دائم من قائمة الزبائن");dlg.dismiss();if(onSelected!=null)onSelected.run();});
                list.addView(b);
            }
        };
        watch(s,r);r.run();dlg.show();
    }

    void exportDatabase(){
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/zip");
        i.putExtra(Intent.EXTRA_TITLE,"MGE_backup_"+new java.text.SimpleDateFormat("yyyyMMdd_HHmm",Locale.US).format(new Date())+".zip");
        startActivityForResult(i,REQ_EXPORT_DB);
    }

    void importDatabase(){
        new AlertDialog.Builder(this)
            .setTitle("استيراد النسخة الاحتياطية")
            .setMessage("سيتم استبدال قاعدة البيانات واستعادة صور المنتجات الموجودة داخل النسخة. هل تريد المتابعة؟")
            .setNegativeButton("إلغاء",null)
            .setPositiveButton("متابعة",(d,w)->{
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/zip");
                i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/zip","application/octet-stream"});
                startActivityForResult(i,REQ_IMPORT_DB);
            }).show();
    }

    void copyUriToFile(Uri uri, File target) throws IOException{
        File parent=target.getParentFile();
        if(parent!=null && !parent.exists()) parent.mkdirs();
        try(InputStream in=getContentResolver().openInputStream(uri); OutputStream out=new FileOutputStream(target)){
            if(in==null) throw new IOException("تعذر فتح الملف");
            byte[] buf=new byte[8192]; int n;
            while((n=in.read(buf))!=-1) out.write(buf,0,n);
            out.flush();
        }
    }

    void copyFile(File source, File target) throws IOException{
        try(InputStream in=new FileInputStream(source); OutputStream out=new FileOutputStream(target)){
            byte[] buf=new byte[8192]; int n;
            while((n=in.read(buf))!=-1) out.write(buf,0,n);
            out.flush();
        }
    }

    @Override protected void onDestroy(){
        activeInvoiceRemainingView=null;activeInvoiceAdvanceField=null;
        if(cloud!=null) cloud.stopRealtimeSync();
        super.onDestroy();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK || data==null || data.getData()==null) return;
        Uri uri=data.getData();
        if(requestCode==9001){
            try{
                String saved=copyImageToApp(uri);
                if(pendingImageField!=null) pendingImageField.setText(saved);
                Toast.makeText(this,"تم اختيار الصورة",Toast.LENGTH_SHORT).show();
            }catch(Exception e){
                if(pendingImageField!=null) pendingImageField.setText(uri.toString());
                Toast.makeText(this,"تم اختيار الصورة",Toast.LENGTH_SHORT).show();
            }
            return;
        }
        try{
            if(requestCode==REQ_VIREMENT_PDF){
                processVirementPdf(uri);
                return;
            }else if(requestCode==REQ_EXPORT_DB){
                File zipTemp=new File(getCacheDir(),"mge_backup_export.zip");
                createBackupZip(zipTemp);
                try(InputStream in=new FileInputStream(zipTemp); OutputStream out=getContentResolver().openOutputStream(uri)){
                    if(out==null) throw new IOException("تعذر إنشاء ملف النسخة الاحتياطية");
                    byte[] buf=new byte[8192]; int n; while((n=in.read(buf))!=-1) out.write(buf,0,n); out.flush();
                }
                zipTemp.delete();
                Toast.makeText(this,"تم تصدير قاعدة البيانات + صور المنتجات بنجاح",Toast.LENGTH_LONG).show();
            }else if(requestCode==REQ_IMPORT_DB){
                File incoming=new File(getCacheDir(),"mge_backup_import.bin");
                copyUriToFile(uri,incoming);
                File current=getDatabasePath("facturesimple.db");
                File safety=new File(getCacheDir(),"facturesimple_before_import.db");
                if(current.exists()) copyFile(current,safety);
                File importDb=new File(getCacheDir(),"facturesimple_import.db");
                File importImages=new File(getCacheDir(),"mge_import_images");
                if(importImages.exists()) deleteRecursively(importImages);
                importImages.mkdirs();
                boolean isZip=isZipFile(incoming);
                if(isZip){
                    extractBackupZip(incoming,importDb,importImages);
                }else{
                    copyFile(incoming,importDb);
                }
                validateDatabaseFile(importDb);
                db.close();
                copyFile(importDb,current);
                importDb.delete(); incoming.delete();
                File targetImages=new File(getFilesDir(),"product_images");
                if(importImages.exists()){
                    if(targetImages.exists()) deleteRecursively(targetImages);
                    copyDirectory(importImages,targetImages);
                }
                deleteRecursively(importImages);
                safety.delete();
                db=new Store(this);
                // Fix absolute image paths stored by the old phone before any
                // cloud reconciliation. This prevents restored images from
                // disappearing simply because the application UID/path changed.
                repairRestoredProductImagePaths();
                compressAllLocalProductImages();
                markAllProductsDirtyAfterImport();
                Toast.makeText(this,"تم استيراد البيانات وصور المنتجات بنجاح — ستتم مطابقة الصور المحلية مع Firebase Storage تلقائياً",Toast.LENGTH_LONG).show();
                if(cloud!=null&&cloud.isAdmin()) cloud.syncLocalToCloud(()->{},()->{});
                showSettings();
            }
        }catch(Exception e){
            // محاولة إعادة فتح قاعدة البيانات الحالية إذا فشل الاستيراد.
            try{ if(db==null) db=new Store(this); }catch(Exception ignored){}
            Toast.makeText(this,"تعذر تنفيذ العملية: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    void confirmLogout(){
        new AlertDialog.Builder(this)
            .setTitle("تسجيل الخروج")
            .setMessage("هل تريد تسجيل الخروج من حساب MGE؟")
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("تسجيل الخروج", (d,w)->{
                cloud.logout();
                Intent i=new Intent(this,LoginActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
                finish();
            }).show();
    }

    void showPartnerAccount(){
        base("حسابي");
        LinearLayout c=card();
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.logo_mge);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        c.addView(logo,new LinearLayout.LayoutParams(-1,dp(82)));
        String name=(cloud.displayName==null||cloud.displayName.isEmpty())?"الشريك":cloud.displayName;
        c.addView(text("👤 "+name,18,TEXT));
        c.addView(text("📧 "+safe(cloud.email()),13,MUTED));
        c.addView(text("🔐 الصلاحية: شريك",13,BLUE));
        c.addView(text("🤝 Partner ID: "+cloud.partnerId,13,BLUE));
        c.addView(text("يمكنك رؤية المنتجات وصور المنتجات وزبائنك وفواتيرك وبيانات التتبع فقط.",12,MUTED));
        Button logout=button("🚪 تسجيل الخروج");logout.setTextColor(RED);logout.setBackground(round(Color.rgb(254,239,239),Color.rgb(247,188,188),12,1));logout.setOnClickListener(v->confirmLogout());
        c.addView(logout,new LinearLayout.LayoutParams(-1,dp(50)));
        body.addView(c,margin(-1,-2,0,dp(10)));
    }


    void showPartners(){
        if(cloud == null || !cloud.isAdmin()){
            Toast.makeText(this,"هذه الصفحة متاحة للمدير فقط",Toast.LENGTH_SHORT).show();
            return;
        }
        base("إدارة الشركاء");

        LinearLayout head=card();
        TextView title=text("👥 إدارة حسابات الشركاء",19,TEXT); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); title.setGravity(Gravity.CENTER);
        head.addView(title);
        TextView hint=text("إضافة • تعديل • تفعيل/تعطيل • إعادة تعيين كلمة المرور • Partner ID",12,MUTED); hint.setGravity(Gravity.CENTER);
        head.addView(hint);

        Button add=button("＋  إضافة حساب شريك");
        add.setTextColor(Color.WHITE); add.setTextSize(15); add.setBackground(solid(GREEN,12));
        add.setOnClickListener(v->partnerDialog(null));
        head.addView(add,margin(-1,dp(50),0,dp(8)));

        EditText search=input("🔎  البحث بالاسم أو البريد أو Partner ID");
        head.addView(search,margin(-1,dp(48),0,0));
        body.addView(head,margin(-1,-2,0,dp(10)));

        LinearLayout stats= new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        TextView total=text("إجمالي الشركاء: 0",12,TEXT); total.setGravity(Gravity.CENTER);
        TextView active=text("مفعل: 0",12,GREEN); active.setGravity(Gravity.CENTER);
        TextView disabled=text("معطل: 0",12,RED); disabled.setGravity(Gravity.CENTER);
        stats.addView(total,new LinearLayout.LayoutParams(0,dp(42),1));
        stats.addView(active,new LinearLayout.LayoutParams(0,dp(42),1));
        stats.addView(disabled,new LinearLayout.LayoutParams(0,dp(42),1));
        body.addView(stats,margin(-1,-2,0,dp(8)));

        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); body.addView(list);

        final ArrayList<com.google.firebase.firestore.DocumentSnapshot> all=new ArrayList<>();
        Runnable render=()->{
            list.removeAllViews();
            String q=search.getText().toString().trim().toLowerCase(Locale.ROOT);
            int count=0,on=0,off=0;
            for(com.google.firebase.firestore.DocumentSnapshot d:all){
                String name=d.getString("name")==null?"":d.getString("name");
                String email=d.getString("email")==null?"":d.getString("email");
                Long pid=d.getLong("partnerId"); String ps=pid==null?"":String.valueOf(pid);
                Boolean deleted=d.getBoolean("deleted"); if(Boolean.TRUE.equals(deleted)) continue;
                Boolean a=d.getBoolean("active"); boolean enabled=a==null||a;
                if(enabled) on++; else off++;
                if(q.isEmpty() || name.toLowerCase(Locale.ROOT).contains(q) || email.toLowerCase(Locale.ROOT).contains(q) || ps.contains(q)){
                    count++; partnerCard(list,d);
                }
            }
            total.setText("إجمالي الشركاء: "+on+off);
            active.setText("مفعل: "+on);
            disabled.setText("معطل: "+off);
            if(count==0){
                TextView empty=text(all.isEmpty()?"لا يوجد شركاء حاليًا":"لا توجد نتائج مطابقة للبحث",14,MUTED);
                empty.setGravity(Gravity.CENTER); list.addView(empty,margin(-1,dp(60),0,0));
            }
        };
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){render.run();}public void afterTextChanged(Editable e){}});

        cloud.listPartners().addOnSuccessListener(q->{
            all.clear(); all.addAll(q.getDocuments());
            all.sort((a,b)->{
                String na=a.getString("name")==null?"":a.getString("name");
                String nb=b.getString("name")==null?"":b.getString("name");
                return na.compareToIgnoreCase(nb);
            });
            render.run();
            cloud.ensureAllPartnerCustomers().addOnSuccessListener(v->{}).addOnFailureListener(e->{});
        }).addOnFailureListener(e->Toast.makeText(this,"تعذر تحميل الشركاء: "+e.getMessage(),Toast.LENGTH_LONG).show());
    }

    void partnerCard(LinearLayout list, com.google.firebase.firestore.DocumentSnapshot d){
        String uid=d.getId();
        String name=d.getString("name")==null?"":d.getString("name");
        String email=d.getString("email")==null?"":d.getString("email");
        String phone=d.getString("phone")==null?"":d.getString("phone");
        Long pid=d.getLong("partnerId"); long partnerId=pid==null?0:pid;
        Boolean active=d.getBoolean("active"); boolean enabled=active==null||active;
        LinearLayout c=card();
        TextView n=text("👤 "+(name.isEmpty()?"بدون اسم":name),17,TEXT); n.setTypeface(Typeface.DEFAULT,Typeface.BOLD); c.addView(n);
        c.addView(text("📧 "+email,13,MUTED));
        if(!phone.trim().isEmpty()) c.addView(text("📞 "+phone,13,MUTED));
        c.addView(text("🤝 Partner ID: "+partnerId,13,BLUE));
        TextView status=text(enabled?"🟢 الحساب مفعل":"🔴 الحساب معطل",13,enabled?GREEN:RED); c.addView(status);

        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.VERTICAL); actions.setPadding(0,dp(5),0,0);
        Button edit=button("✏️  تعديل الشريك"); edit.setTextColor(Color.WHITE); edit.setBackground(solid(BLUE,10)); edit.setOnClickListener(v->partnerDialog(d));
        Button reset=button("🔑  إرسال رابط تغيير كلمة المرور"); reset.setTextColor(Color.WHITE); reset.setBackground(solid(Color.rgb(108,92,231),10));
        reset.setOnClickListener(v->{reset.setEnabled(false);cloud.sendPartnerPasswordReset(email).addOnSuccessListener(x->{reset.setEnabled(true);Toast.makeText(this,"تم إرسال رابط تغيير كلمة المرور إلى "+email,Toast.LENGTH_LONG).show();}).addOnFailureListener(x->{reset.setEnabled(true);Toast.makeText(this,"تعذر إرسال الرابط: "+x.getMessage(),Toast.LENGTH_LONG).show();});});
        Button toggle=button(enabled?"⛔  تعطيل الحساب":"✅  تفعيل الحساب"); toggle.setTextColor(Color.WHITE); toggle.setBackground(solid(enabled?RED:GREEN,10));
        toggle.setOnClickListener(v->{
            String action=enabled?"تعطيل":"تفعيل";
            new AlertDialog.Builder(this).setTitle(action+" حساب الشريك").setMessage((enabled?"سيمنع الشريك من الدخول إلى التطبيق.":"سيسمح للشريك بالدخول من جديد.")+"\nهل تريد المتابعة؟").setNegativeButton("إلغاء",null).setPositiveButton("نعم",(di,w)->{
                cloud.updatePartnerProfile(uid,name,partnerId,!enabled,phone).addOnSuccessListener(x->{Toast.makeText(this,"تم "+action+" الحساب",Toast.LENGTH_SHORT).show();showPartners();}).addOnFailureListener(x->Toast.makeText(this,"فشلت العملية: "+x.getMessage(),Toast.LENGTH_LONG).show());
            }).show();
        });
        Button del=button("🗑  حذف الشريك والحساب المرتبط"); del.setTextColor(Color.WHITE); del.setBackground(solid(Color.rgb(190,45,45),10));
        del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف الشريك").setMessage("سيتم حذف حساب الشريك وسجل الشريك من صفحة الزبائن معًا. لا يمكن التراجع عن هذه العملية.").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(di,w)->{
            del.setEnabled(false);
            cloud.deletePartnerAndLinkedCustomer(uid,partnerId).addOnSuccessListener(x->{Toast.makeText(this,"تم حذف الحساب والشريك المرتبط",Toast.LENGTH_LONG).show();showPartners();}).addOnFailureListener(e->{del.setEnabled(true);Toast.makeText(this,"فشل الحذف: "+e.getMessage(),Toast.LENGTH_LONG).show();});
        }).show());
        actions.addView(edit,margin(-1,dp(48),0,dp(5))); actions.addView(reset,margin(-1,dp(48),0,dp(5))); actions.addView(toggle,margin(-1,dp(48),0,dp(5))); actions.addView(del,new LinearLayout.LayoutParams(-1,dp(48)));
        c.addView(actions);
        list.addView(c,margin(-1,-2,0,dp(8)));
    }

    void partnerDialog(com.google.firebase.firestore.DocumentSnapshot existing){
        boolean edit=existing!=null;
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(8),dp(4),dp(8),dp(2)); box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        EditText name=input("اسم الشريك");
        EditText email=input("البريد الإلكتروني");
        EditText phone=input("رقم هاتف الشريك");
        EditText password=input("كلمة المرور (6 أحرف على الأقل)"); password.setInputType(0x81);
        EditText pid=input("Partner ID (رقم فريد)"); pid.setInputType(2);
        CheckBox active=new CheckBox(this); active.setText("الحساب مفعل"); active.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); active.setChecked(true);
        if(edit){
            name.setText(existing.getString("name")); email.setText(existing.getString("email")); email.setEnabled(false); phone.setText(existing.getString("phone")==null?"":existing.getString("phone"));
            Long x=existing.getLong("partnerId"); if(x!=null) pid.setText(String.valueOf(x));
            Boolean a=existing.getBoolean("active"); active.setChecked(a==null||a);
        }
        box.addView(name,margin(-1,dp(50),0,dp(7))); box.addView(email,margin(-1,dp(50),0,dp(7))); box.addView(phone,margin(-1,dp(50),0,dp(7)));
        if(!edit) box.addView(password,margin(-1,dp(50),0,dp(7)));
        box.addView(pid,margin(-1,dp(50),0,dp(4))); box.addView(active,margin(-1,dp(42),0,0));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(edit?"تعديل حساب الشريك":"إضافة حساب شريك").setView(box).setNegativeButton("إلغاء",null).setPositiveButton(edit?"حفظ":"إنشاء",null).create();
        dialog.setOnShowListener(x->{
            Button ok=dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            ok.setOnClickListener(v->{
                String nm=name.getText().toString().trim(), em=email.getText().toString().trim(), ph=phone.getText().toString().trim(), pw=password.getText().toString(), ps=pid.getText().toString().trim();
                if(nm.isEmpty()||em.isEmpty()||ps.isEmpty()){Toast.makeText(this,"أكمل جميع الحقول المطلوبة",Toast.LENGTH_SHORT).show();return;}
                long partnerId; try{partnerId=Long.parseLong(ps);}catch(Exception e){Toast.makeText(this,"Partner ID يجب أن يكون رقمًا",Toast.LENGTH_SHORT).show();return;}
                if(partnerId<1){Toast.makeText(this,"Partner ID يجب أن يكون أكبر من 0",Toast.LENGTH_SHORT).show();return;}
                ok.setEnabled(false);
                if(!edit){
                    if(pw.length()<6){ok.setEnabled(true);Toast.makeText(this,"كلمة المرور يجب أن تكون 6 أحرف على الأقل",Toast.LENGTH_SHORT).show();return;}
                    cloud.createPartnerAccount(nm,em,pw,partnerId,ph).addOnSuccessListener(doc->{dialog.dismiss();Toast.makeText(this,"تم إنشاء حساب الشريك بنجاح",Toast.LENGTH_LONG).show();showPartners();}).addOnFailureListener(e->{ok.setEnabled(true);Toast.makeText(this,"فشل إنشاء الحساب: "+e.getMessage(),Toast.LENGTH_LONG).show();});
                }else{
                    cloud.updatePartnerProfile(existing.getId(),nm,partnerId,active.isChecked(),ph).addOnSuccessListener(vv->{dialog.dismiss();Toast.makeText(this,"تم حفظ بيانات الشريك",Toast.LENGTH_SHORT).show();showPartners();}).addOnFailureListener(e->{ok.setEnabled(true);Toast.makeText(this,"فشل الحفظ: "+e.getMessage(),Toast.LENGTH_LONG).show();});
                }
            });
        });
        dialog.show();
    }


    // ========================= التقارير =========================
    static class ReportProduct {
        String name; int qty; double revenue;
        ReportProduct(String n){name=n;}
    }
    static class ReportCustomer {
        int id; String name; int invoices; double total;
        ReportCustomer(int i,String n){id=i;name=n;}
    }

    Date reportStart(int period){
        Calendar c=Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);
        if(period==0){
            int day=c.get(Calendar.DAY_OF_WEEK);
            int diff=(day==Calendar.SUNDAY)?6:day-Calendar.MONDAY;
            c.add(Calendar.DAY_OF_MONTH,-diff);
        }else if(period==1){
            c.set(Calendar.DAY_OF_MONTH,1);
        }else if(period==2){
            c.add(Calendar.MONTH,-2);c.set(Calendar.DAY_OF_MONTH,1);
        }else{
            c.set(Calendar.DAY_OF_YEAR,1);
        }
        return c.getTime();
    }

    Date parseInvoiceDate(String value){
        if(value==null||value.trim().isEmpty())return null;
        String[] formats={"dd/MM/yyyy HH:mm","dd/MM/yyyy","yyyy-MM-dd","yyyy-MM-dd HH:mm:ss"};
        for(String f:formats){try{return new java.text.SimpleDateFormat(f,Locale.US).parse(value.trim());}catch(Exception ignored){}}
        return null;
    }

    ArrayList<Store.Invoice> reportInvoices(int period){
        Date start=reportStart(period), now=new Date();
        int partnerFilter=(cloud!=null&&!cloud.isAdmin())?(int)cloud.partnerId:0;
        ArrayList<Store.Invoice> out=new ArrayList<>();
        for(Store.Invoice inv:(partnerFilter>0?db.partnerInvoices(partnerFilter,""):db.invoices(""))){
            Date d=parseInvoiceDate(inv.date);
            if(d!=null&&!d.before(start)&&!d.after(now))out.add(inv);
        }
        return out;
    }

    int nextReportMonth(){
        Calendar c=Calendar.getInstance();
        return c.get(Calendar.MONTH)+2>12?1:c.get(Calendar.MONTH)+2;
    }

    ArrayList<Store.Invoice> allReportInvoices(){
        int partnerFilter=(cloud!=null&&!cloud.isAdmin())?(int)cloud.partnerId:0;
        return partnerFilter>0?db.partnerInvoices(partnerFilter,""):db.invoices("");
    }

    LinearLayout seasonalDemandHolder;

    void renderSeasonalDemand(int month){
        if(seasonalDemandHolder==null)return;
        seasonalDemandHolder.removeAllViews();
        seasonalDemandHolder.addView(section("📦  توقع الطلب الموسمي — "+monthName(month)));
        ArrayList<Store.Invoice> all=allReportInvoices();
        HashMap<Integer,Integer> qtyByProduct=new HashMap<>();
        HashMap<Integer,Double> revenueByProduct=new HashMap<>();
        HashMap<Integer,Integer> yearsByProduct=new HashMap<>();
        HashMap<Integer,HashSet<Integer>> productYears=new HashMap<>();
        Calendar cal=Calendar.getInstance();
        for(Store.Invoice inv:all){
            Date d=parseInvoiceDate(inv.date); if(d==null)continue;
            cal.setTime(d);
            if(cal.get(Calendar.MONTH)+1!=month)continue;
            int year=cal.get(Calendar.YEAR);
            for(Store.Item it:inv.items){
                qtyByProduct.put(it.productId,qtyByProduct.getOrDefault(it.productId,0)+it.qty);
                revenueByProduct.put(it.productId,revenueByProduct.getOrDefault(it.productId,0.0)+it.salePrice*it.qty);
                HashSet<Integer> ys=productYears.get(it.productId);
                if(ys==null){ys=new HashSet<>();productYears.put(it.productId,ys);}
                ys.add(year);
            }
        }
        for(Integer pid:productYears.keySet())yearsByProduct.put(pid,productYears.get(pid).size());

        ArrayList<Integer> ids=new ArrayList<>(qtyByProduct.keySet());
        Collections.sort(ids,(a,b)->{
            double sa=seasonalScore(a,qtyByProduct,yearsByProduct,all,month);
            double sb=seasonalScore(b,qtyByProduct,yearsByProduct,all,month);
            return Double.compare(sb,sa);
        });
        if(ids.isEmpty()){
            seasonalDemandHolder.addView(text("لا توجد مبيعات تاريخية كافية لهذا الشهر لتوقع الطلب.",13,MUTED));
            return;
        }
        seasonalDemandHolder.addView(text("يعتمد الترتيب على الكمية المباعة في هذا الشهر عبر السنوات السابقة، مع مراعاة تكرار الطلب حديثاً.",11,MUTED));
        int rank=1;
        for(Integer pid:ids){
            if(rank>12)break;
            Store.Product p=db.product(pid); if(p==null)continue;
            int total=qtyByProduct.get(pid), years=yearsByProduct.getOrDefault(pid,1);
            double avg=(double)total/Math.max(1,years);
            double score=seasonalScore(pid,qtyByProduct,yearsByProduct,all,month);
            String status=score>=avg*1.15?"🔥 طلب قوي":score>=avg*0.8?"📈 طلب جيد":"📊 طلب متوسط";
            LinearLayout row=card();row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);
            TextView r=text("#"+rank,17,BLUE);r.setTypeface(Typeface.DEFAULT,Typeface.BOLD);r.setGravity(Gravity.CENTER);
            TextView n=text(safe(p.name),14,TEXT);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);n.setMaxLines(2);
            TextView d=text("إجمالي: "+total+" قطعة  •  متوسط/سنة: "+String.format(Locale.US,"%.1f",avg)+"\n"+status+(p.available?"":"  •  ⛔ غير متوفر"),11,p.available?MUTED:RED);
            LinearLayout mid=new LinearLayout(this);mid.setOrientation(LinearLayout.VERTICAL);mid.addView(n);mid.addView(d);
            row.addView(r,new LinearLayout.LayoutParams(dp(42),dp(70)));row.addView(mid,new LinearLayout.LayoutParams(0,dp(70),1));
            row.addView(text(money(revenueByProduct.getOrDefault(pid,0.0))+" DH",12,BLUE),new LinearLayout.LayoutParams(dp(105),dp(70)));
            seasonalDemandHolder.addView(row,margin(-1,-2,0,dp(5)));rank++;
        }

        seasonalDemandHolder.addView(section("🛒  ماذا أجلب لهذا الشهر؟"));
        TextView hint=text("يمكنك اختيار أي شهر من يناير إلى ديسمبر. المنتجات ذات الطلب المتكرر تاريخياً تظهر أولاً، حتى لو لم تكن مبيعاتها في الشهر الحالي فقط.",11,MUTED);seasonalDemandHolder.addView(hint,margin(-1,dp(8),0,dp(8)));
    }

    double seasonalScore(int pid,HashMap<Integer,Integer> monthQty,HashMap<Integer,Integer> years,ArrayList<Store.Invoice> all,int month){
        int total=monthQty.getOrDefault(pid,0); int y=Math.max(1,years.getOrDefault(pid,1));
        double historical=(double)total/y;
        Calendar c=Calendar.getInstance(); c.add(Calendar.MONTH,-3); Date since=c.getTime(); int recent=0;
        for(Store.Invoice inv:all){Date d=parseInvoiceDate(inv.date);if(d==null||d.before(since))continue;for(Store.Item it:inv.items)if(it.productId==pid)recent+=it.qty;}
        double recentMonthly=(double)recent/3.0;
        return historical*0.7+recentMonthly*0.3;
    }

    String monthName(int month){
        String[] m={"يناير","فبراير","مارس","أبريل","ماي","يونيو","يوليوز","غشت","شتنبر","أكتوبر","نونبر","دجنبر"};
        return month>=1&&month<=12?m[month-1]:"";
    }

    String reportPeriodName(int period){
        return period==0?"هذا الأسبوع":period==1?"هذا الشهر":period==2?"آخر 3 أشهر":"هذه السنة";
    }

    void showReports(){
        base("التقارير");
        TextView intro=text("📊 مركز التقارير — اختر الفترة لعرض أداء المبيعات والمنتجات والزبناء",14,MUTED);intro.setGravity(Gravity.CENTER);intro.setLineSpacing(0f,1.15f);intro.setPadding(dp(10),dp(8),dp(10),dp(8));body.addView(intro,new LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT));((LinearLayout.LayoutParams)intro.getLayoutParams()).setMargins(0,dp(8),0,dp(8));
        if(cloud!=null && cloud.isAdmin()){
            LinearLayout revenueCard=card();
            TextView revenueTitle=text("🏦 مداخيل حسابات Store",17,TEXT);revenueTitle.setTypeface(Typeface.DEFAULT,Typeface.BOLD);revenueTitle.setGravity(Gravity.CENTER);revenueCard.addView(revenueTitle);
            TextView revenueDesc=text("متابعة مداخيل كل حساب، والمبالغ التي تم تحويلها من شركة الشحن إلى البنك",12,MUTED);revenueDesc.setGravity(Gravity.CENTER);revenueCard.addView(revenueDesc);
            Button revenueBtn=button("🏦 فتح مداخيل الحسابات");revenueBtn.setTextColor(Color.WHITE);revenueBtn.setBackground(solid(GREEN,12));revenueBtn.setOnClickListener(v->showStoreAccountsRevenue());
            revenueCard.addView(revenueBtn,margin(-1,dp(50),0,0));
            body.addView(revenueCard,margin(-1,-2,0,dp(10)));
        }

        LinearLayout periods=new LinearLayout(this);periods.setGravity(Gravity.CENTER);
        final int[] selected={0};
        Button[] pb=new Button[4];
        String[] labels={"الأسبوع","الشهر","3 أشهر","السنة"};
        for(int k=0;k<4;k++){final int period=k;pb[k]=button(labels[k]);pb[k].setTextSize(12);pb[k].setOnClickListener(v->{selected[0]=period;for(int j=0;j<4;j++)pb[j].setBackground(solid(j==period?BLUE:Color.rgb(235,241,249),10));for(int j=0;j<4;j++)pb[j].setTextColor(j==period?Color.WHITE:TEXT);renderReports(reportPeriodName(period),reportInvoices(period),selected);});periods.addView(pb[k],new LinearLayout.LayoutParams(0,dp(46),1));}
        body.addView(periods,margin(-1,-2,0,dp(8)));
        for(int k=0;k<4;k++){pb[k].setBackground(solid(k==0?BLUE:Color.rgb(235,241,249),10));pb[k].setTextColor(k==0?Color.WHITE:TEXT);}

        LinearLayout reportBody=new LinearLayout(this);reportBody.setOrientation(LinearLayout.VERTICAL);body.addView(reportBody);
        // renderReports uses this container through a temporary field to avoid rebuilding the top bar.
        final LinearLayout holder=reportBody;
        reportRenderHolder=holder;
        renderReports(reportPeriodName(0),reportInvoices(0),selected);
    }

    LinearLayout reportRenderHolder;

    void renderReports(String periodName,ArrayList<Store.Invoice> rows,int[] selected){
        if(reportRenderHolder==null)return;
        reportRenderHolder.removeAllViews();
        reportRenderHolder.addView(section("📅  تقرير "+periodName));

        double sales=0,paid=0,unpaid=0,shipping=0,profit=0;
        for(Store.Invoice i:rows){double total=invoiceTotal(i);sales+=total;if(i.paid)paid+=total;else unpaid+=total;shipping+=i.shippingCharge;profit+=i.commission;}
        LinearLayout stats=new LinearLayout(this);
        stats.addView(reportStat("💰","المبيعات",money(sales)+" DH"),new LinearLayout.LayoutParams(0,dp(92),1));
        stats.addView(reportStat("💳","المدفوع",money(paid)+" DH"),new LinearLayout.LayoutParams(0,dp(92),1));
        stats.addView(reportStat("⏳","غير مدفوع",money(unpaid)+" DH"),new LinearLayout.LayoutParams(0,dp(92),1));
        reportRenderHolder.addView(stats);
        LinearLayout stats2=new LinearLayout(this);
        stats2.addView(reportStat("🧾","عدد الفواتير",""+rows.size()),new LinearLayout.LayoutParams(0,dp(92),1));
        stats2.addView(reportStat("🚚","الشحن",money(shipping)+" DH"),new LinearLayout.LayoutParams(0,dp(92),1));
        stats2.addView(reportStat("💵","ربح الشركاء",money(profit)+" DH"),new LinearLayout.LayoutParams(0,dp(92),1));
        reportRenderHolder.addView(stats2);

        renderTopProducts(rows);
        renderTopCustomers(rows);
        renderCustomerAnalysis(rows);
        renderRecommendedReports(rows);
        renderSeasonalMonthPicker();
    }

    View reportStat(String icon,String title,String value){
        LinearLayout c=card();c.setGravity(Gravity.CENTER);
        TextView i=text(icon,20,BLUE);i.setGravity(Gravity.CENTER);
        TextView t=text(title,11,MUTED);t.setGravity(Gravity.CENTER);
        TextView v=text(value,14,TEXT);v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setGravity(Gravity.CENTER);
        c.addView(i);c.addView(t);c.addView(v);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(88));p.setMargins(dp(3),dp(3),dp(3),dp(3));c.setLayoutParams(p);return c;
    }

    void renderTopProducts(ArrayList<Store.Invoice> rows){
        reportRenderHolder.addView(section("🏆  أكثر المنتجات مبيعاً"));
        HashMap<String,ReportProduct> map=new HashMap<>();
        for(Store.Invoice inv:rows)for(Store.Item it:inv.items){
            String key=it.productId+"|"+(it.name==null?"":it.name);ReportProduct r=map.get(key);if(r==null){r=new ReportProduct(it.name);map.put(key,r);}r.qty+=it.qty;r.revenue+=it.salePrice*it.qty;
        }
        ArrayList<ReportProduct> list=new ArrayList<>(map.values());Collections.sort(list,(a,b)->b.qty!=a.qty?Integer.compare(b.qty,a.qty):Double.compare(b.revenue,a.revenue));
        if(list.isEmpty()){reportRenderHolder.addView(text("لا توجد مبيعات في هذه الفترة.",13,MUTED));return;}
        int rank=1;for(ReportProduct r:list){if(rank>10)break;LinearLayout c=card();c.setOrientation(LinearLayout.HORIZONTAL);
            TextView left=text("#"+rank,16,BLUE);left.setTypeface(Typeface.DEFAULT_BOLD);left.setGravity(Gravity.CENTER);
            TextView mid=text(safe(r.name),14,TEXT);mid.setTypeface(Typeface.DEFAULT,Typeface.BOLD);mid.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
            TextView right=text(r.qty+" قطعة\n"+money(r.revenue)+" DH",12,MUTED);right.setGravity(Gravity.CENTER);
            c.addView(left,new LinearLayout.LayoutParams(dp(45),dp(60)));c.addView(mid,new LinearLayout.LayoutParams(0,dp(60),1));c.addView(right,new LinearLayout.LayoutParams(dp(115),dp(60)));reportRenderHolder.addView(c,margin(-1,-2,0,dp(5)));rank++;}
    }

    void renderTopCustomers(ArrayList<Store.Invoice> rows){
        reportRenderHolder.addView(section("👑  الزبناء الأوفياء — الأكثر شراءً"));
        HashMap<Integer,ReportCustomer> map=new HashMap<>();
        for(Store.Invoice inv:rows){if(inv.clientId<=0)continue;ReportCustomer r=map.get(inv.clientId);if(r==null){r=new ReportCustomer(inv.clientId,safe(inv.client));map.put(inv.clientId,r);}r.invoices++;r.total+=invoiceTotal(inv);}
        ArrayList<ReportCustomer> list=new ArrayList<>(map.values());Collections.sort(list,(a,b)->Double.compare(b.total,a.total));
        if(list.isEmpty()){reportRenderHolder.addView(text("لا توجد بيانات زبناء في هذه الفترة.",13,MUTED));return;}
        int rank=1;for(ReportCustomer r:list){if(rank>10)break;LinearLayout c=card();c.setOrientation(LinearLayout.HORIZONTAL);
            TextView a=text("#"+rank,16,BLUE);a.setGravity(Gravity.CENTER);TextView b=text("👤 "+safe(r.name),14,TEXT);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);TextView d=text(r.invoices+" فاتورة\n"+money(r.total)+" DH",12,MUTED);d.setGravity(Gravity.CENTER);
            c.addView(a,new LinearLayout.LayoutParams(dp(45),dp(60)));c.addView(b,new LinearLayout.LayoutParams(0,dp(60),1));c.addView(d,new LinearLayout.LayoutParams(dp(120),dp(60)));reportRenderHolder.addView(c,margin(-1,-2,0,dp(5)));rank++;}
    }

    void renderCustomerAnalysis(ArrayList<Store.Invoice> rows){
        reportRenderHolder.addView(section("🔎  تحليل مشتريات كل زبون"));
        EditText search=input("🔎 ابحث عن الزبون بالاسم أو الهاتف");reportRenderHolder.addView(search,margin(-1,dp(48),0,dp(7)));
        LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);reportRenderHolder.addView(results);
        Runnable refresh=()->{results.removeAllViews();String q=search.getText().toString().trim();HashMap<Integer,ReportCustomer> cm=new HashMap<>();
            for(Store.Invoice inv:rows){if(inv.clientId<=0)continue;Store.Customer cu=db.customer(inv.clientId);String nm=cu==null?inv.client:cu.name;String ph=cu==null?inv.customerPhone:cu.phone;if(q.isEmpty()||(nm!=null&&nm.toLowerCase(Locale.ROOT).contains(q.toLowerCase(Locale.ROOT)))||(ph!=null&&ph.contains(q))){ReportCustomer rc=cm.get(inv.clientId);if(rc==null){rc=new ReportCustomer(inv.clientId,nm);cm.put(inv.clientId,rc);}rc.invoices++;rc.total+=invoiceTotal(inv);}}
            ArrayList<ReportCustomer> cs=new ArrayList<>(cm.values());Collections.sort(cs,(a,b)->Double.compare(b.total,a.total));if(cs.isEmpty()){results.addView(text("اكتب اسم الزبون أو اختر زبوناً من النتائج.",12,MUTED));return;}
            int n=0;for(ReportCustomer rc:cs){if(n++>=8)break;Button b=button("👤 "+safe(rc.name)+"  •  "+money(rc.total)+" DH");b.setTextColor(TEXT);b.setBackground(round(Color.WHITE,BORDER,12,1));b.setOnClickListener(v->showCustomerReportDialog(rc,rows));results.addView(b,margin(-1,dp(48),0,dp(5)));}
        };watch(search,refresh);refresh.run();
    }

    void showCustomerReportDialog(ReportCustomer rc,ArrayList<Store.Invoice> rows){
        HashMap<Integer,ReportProduct> bought=new HashMap<>();
        for(Store.Invoice inv:rows)if(inv.clientId==rc.id)for(Store.Item it:inv.items){ReportProduct p=bought.get(it.productId);if(p==null){p=new ReportProduct(it.name);bought.put(it.productId,p);}p.qty+=it.qty;p.revenue+=it.salePrice*it.qty;}
        ArrayList<ReportProduct> best=new ArrayList<>(bought.values());Collections.sort(best,(a,b)->b.qty-a.qty);
        HashSet<Integer> boughtIds=new HashSet<>(bought.keySet());ArrayList<Store.Product> suggestions=new ArrayList<>();
        HashMap<Integer,Integer> global=new HashMap<>();for(Store.Invoice inv:rows)for(Store.Item it:inv.items)global.put(it.productId,global.getOrDefault(it.productId,0)+it.qty);
        ArrayList<Integer> ids=new ArrayList<>(global.keySet());Collections.sort(ids,(a,b)->Integer.compare(global.get(b),global.get(a)));
        for(Integer pid:ids){if(boughtIds.contains(pid))continue;Store.Product p=db.product(pid);if(p!=null&&p.available){suggestions.add(p);if(suggestions.size()>=5)break;}}
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(4),0,dp(4),0);
        box.addView(text("👤 "+safe(rc.name),18,TEXT));box.addView(text("إجمالي الشراء: "+money(rc.total)+" DH  •  "+rc.invoices+" فاتورة",13,MUTED));
        box.addView(section("⭐ أفضل منتجاته"));
        if(best.isEmpty())box.addView(text("لا توجد منتجات مسجلة.",12,MUTED));else{int k=1;for(ReportProduct p:best){if(k>8)break;box.addView(text(k+". "+safe(p.name)+" — "+p.qty+" قطعة — "+money(p.revenue)+" DH",13,TEXT));k++;}}
        box.addView(section("💡 منتجات يمكن اقتراحها عليه"));
        if(suggestions.isEmpty())box.addView(text("لا توجد اقتراحات كافية في هذه الفترة.",12,MUTED));else for(Store.Product p:suggestions)box.addView(text("• "+safe(p.name)+" — "+money(p.price)+" DH",13,TEXT));
        new AlertDialog.Builder(this).setTitle("تحليل الزبون").setView(box).setPositiveButton("إغلاق",null).show();
    }

    void renderSeasonalMonthPicker(){
        reportRenderHolder.addView(section("📅  الطلب المتوقع حسب الشهر"));
        LinearLayout months=new LinearLayout(this);months.setOrientation(LinearLayout.VERTICAL);
        int next=nextReportMonth();
        for(int start=1;start<=12;start+=4){
            LinearLayout line=new LinearLayout(this);line.setGravity(Gravity.CENTER);
            for(int j=start;j<start+4&&j<=12;j++){
                final int m=j;Button b=button(j==next?"⭐ "+monthName(j):monthName(j));b.setTextSize(11);b.setTextColor(j==next?Color.WHITE:TEXT);b.setBackground(solid(j==next?GREEN:Color.rgb(235,241,249),9));
                b.setOnClickListener(v->{renderSeasonalDemand(m);});line.addView(b,new LinearLayout.LayoutParams(0,dp(44),1));
            }
            months.addView(line,margin(-1,-2,0,dp(4)));
        }
        reportRenderHolder.addView(months,margin(-1,dp(4),0,dp(8)));
        seasonalDemandHolder=new LinearLayout(this);
        seasonalDemandHolder.setOrientation(LinearLayout.VERTICAL);
        reportRenderHolder.addView(seasonalDemandHolder);
        renderSeasonalDemand(next);
    }

    void renderRecommendedReports(ArrayList<Store.Invoice> rows){
        reportRenderHolder.addView(section("💡  تقارير موصى بها"));
        LinearLayout c=card();
        c.addView(text("• المبيعات اليومية واتجاه المبيعات خلال الفترة",13,TEXT));
        c.addView(text("• الفواتير غير المدفوعة وإجمالي الديون",13,TEXT));
        c.addView(text("• أداء كل شريك: المبيعات، الربح، الطلبات المستلمة وغير المستلمة",13,TEXT));
        c.addView(text("• المنتجات التي لم تُبع خلال الفترة للمساعدة في قرار التوفر والتسعير",13,TEXT));
        c.addView(text("• أكثر المنتجات ربحاً وليس فقط الأكثر مبيعاً",13,TEXT));
        c.addView(text("• متوسط قيمة الفاتورة وعدد الفواتير لكل زبون",13,TEXT));
        reportRenderHolder.addView(c);
    }

    boolean invoiceInRevenuePeriod(Store.Invoice inv,int days){
        if(days<=0)return true;
        try{
            // Store revenue may be settled by a later Virement. When a Virement
            // exists, use its date for the report period; otherwise use the
            // original invoice date. This makes imported shipping-company
            // settlements visible in the correct accounting period.
            String d=(inv.virementDate!=null&&!inv.virementDate.trim().isEmpty())?inv.virementDate.trim():(inv.date==null?"":inv.date.trim());
            Date target=null;
            String[] formats={"yyyy-MM-dd HH:mm","yyyy-MM-dd","dd/MM/yyyy HH:mm","dd/MM/yyyy"};
            for(String f:formats){try{target=new SimpleDateFormat(f,Locale.US).parse(d);if(target!=null)break;}catch(Exception ignored){}}
            if(target==null)return true;
            Calendar cal=Calendar.getInstance();cal.set(Calendar.HOUR_OF_DAY,0);cal.set(Calendar.MINUTE,0);cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);
            long end=cal.getTimeInMillis();cal.add(Calendar.DAY_OF_YEAR,-(days-1));long start=cal.getTimeInMillis();
            return target.getTime()>=start && target.getTime()<=end+86399999L;
        }catch(Exception e){return true;}
    }

    void showStoreAccountsRevenue(){
        if(cloud==null||!cloud.isAdmin()){Toast.makeText(this,"هذه الصفحة متاحة للمدير فقط",Toast.LENGTH_SHORT).show();return;}
        base("مداخيل حسابات Store");
        TextView intro=text("🏦 مداخيل كل حساب Store — تظهر جميع الفواتير، مع تحديد ما تم استلامه من شركة الشحن إلى البنك.",13,MUTED);intro.setGravity(Gravity.CENTER);intro.setLineSpacing(0f,1.15f);intro.setPadding(dp(10),dp(8),dp(10),dp(8));body.addView(intro,margin(-1,dp(8),0,dp(8)));
        LinearLayout periods=new LinearLayout(this);periods.setGravity(Gravity.CENTER);final int[] selected={0};
        Button[] pb=new Button[3];String[] labels={"آخر 7 أيام","آخر 14 يوماً","كل الفترة"};int[] vals={7,14,0};LinearLayout holder=new LinearLayout(this);holder.setOrientation(LinearLayout.VERTICAL);
        for(int k=0;k<3;k++){final int idx=k;pb[k]=button(labels[k]);pb[k].setTextSize(12);pb[k].setSingleLine(false);pb[k].setOnClickListener(v->{selected[0]=vals[idx];for(int j=0;j<3;j++){pb[j].setBackground(solid(j==idx?BLUE:Color.rgb(235,241,249),10));pb[j].setTextColor(j==idx?Color.WHITE:TEXT);}refreshStoreRevenue(holder,selected[0]);});periods.addView(pb[k],new LinearLayout.LayoutParams(0,dp(50),1));}
        for(int k=0;k<3;k++){pb[k].setBackground(solid(k==2?BLUE:Color.rgb(235,241,249),10));pb[k].setTextColor(k==2?Color.WHITE:TEXT);}body.addView(periods,margin(-1,-2,0,dp(8)));
        Button importVirement=button("📥 استيراد PDF Virement شركة الشحن");importVirement.setTextColor(Color.WHITE);importVirement.setBackground(solid(BLUE,12));importVirement.setOnClickListener(v->chooseVirementStoreAndPickPdf());body.addView(importVirement,margin(-1,dp(50),0,dp(8)));
        body.addView(holder,margin(-1,-2,0,dp(8)));
        // صفحة مداخيل Store تعتمد على قاعدة SQLite المحلية بعد حفظ/استيراد الفواتير.
        // لا نقوم بمزامنة كل فواتير Firebase عند فتح الصفحة، لأن فشل فاتورة واحدة
        // أو مهمة فرعية لا يجب أن يمنع عرض بقية المداخيل أو يظهر رسالة خطأ للمستخدم.
        refreshStoreRevenue(holder,selected[0]);
    }

    void refreshStoreRevenue(LinearLayout holder,int days){
        holder.removeAllViews();ArrayList<Store.Invoice> all=db.invoices("");
        ArrayList<String> companies=new ArrayList<>(),accounts=new ArrayList<>();
        for(Store.Invoice inv:all){if(inv==null)continue;String co=safe(inv.shippingCompany).trim(),ac=safe(inv.shippingAccount).trim();if(!co.isEmpty()&&!companies.contains(co))companies.add(co);if(!ac.isEmpty()&&!accounts.contains(ac))accounts.add(ac);}
        Collections.sort(companies,String.CASE_INSENSITIVE_ORDER);Collections.sort(accounts,String.CASE_INSENSITIVE_ORDER);
        LinearLayout filterCard=card();filterCard.setPadding(dp(12),dp(12),dp(12),dp(14));TextView ft=text("🔎 فلترة المداخيل",16,TEXT);ft.setTypeface(Typeface.DEFAULT,Typeface.BOLD);ft.setGravity(Gravity.CENTER);filterCard.addView(ft);
        Spinner companySpinner=new Spinner(this);ArrayList<String> companyOptions=new ArrayList<>();companyOptions.add("كل شركات الشحن");companyOptions.addAll(companies);ArrayAdapter<String> companyAdapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,companyOptions);companyAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);companySpinner.setAdapter(companyAdapter);companySpinner.setSelection(storeRevenueCompanyFilter.isEmpty()?0:Math.max(0,companyOptions.indexOf(storeRevenueCompanyFilter)),false);filterCard.addView(text("شركة الشحن",12,MUTED));filterCard.addView(companySpinner,margin(-1,dp(46),0,dp(5)));
        Spinner accountSpinner=new Spinner(this);ArrayList<String> accountOptions=new ArrayList<>();accountOptions.add("كل حسابات Store");accountOptions.addAll(accounts);ArrayAdapter<String> accountAdapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,accountOptions);accountAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);accountSpinner.setAdapter(accountAdapter);accountSpinner.setSelection(storeRevenueAccountFilter.isEmpty()?0:Math.max(0,accountOptions.indexOf(storeRevenueAccountFilter)),false);filterCard.addView(text("حساب Store",12,MUTED));filterCard.addView(accountSpinner,margin(-1,dp(46),0,dp(5)));
        Spinner statusSpinner=new Spinner(this);ArrayList<String> statusOptions=new ArrayList<>(Arrays.asList("كل الحالات","🟢 تم استلام المبلغ إلى البنك","🔴 لم يتم استلام المبلغ إلى البنك"));ArrayAdapter<String> statusAdapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,statusOptions);statusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);statusSpinner.setAdapter(statusAdapter);statusSpinner.setSelection("received".equals(storeRevenueStatusFilter)?1:"pending".equals(storeRevenueStatusFilter)?2:0,false);filterCard.addView(text("حالة البنك",12,MUTED));filterCard.addView(statusSpinner,margin(-1,dp(46),0,dp(5)));
        AdapterView.OnItemSelectedListener fl=new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> p,View v,int pos,long id){if(p==companySpinner){String x=pos==0?"":companyOptions.get(pos);if(!x.equals(storeRevenueCompanyFilter)){storeRevenueCompanyFilter=x;refreshStoreRevenue(holder,days);}}else if(p==accountSpinner){String x=pos==0?"":accountOptions.get(pos);if(!x.equals(storeRevenueAccountFilter)){storeRevenueAccountFilter=x;refreshStoreRevenue(holder,days);}}else if(p==statusSpinner){String x=pos==1?"received":pos==2?"pending":"all";if(!x.equals(storeRevenueStatusFilter)){storeRevenueStatusFilter=x;refreshStoreRevenue(holder,days);}}}public void onNothingSelected(AdapterView<?> p){}};
        companySpinner.setOnItemSelectedListener(fl);accountSpinner.setOnItemSelectedListener(fl);statusSpinner.setOnItemSelectedListener(fl);holder.addView(filterCard,margin(-1,-2,0,dp(8)));

        HashMap<String,ArrayList<Store.Invoice>> groups=new HashMap<>();HashMap<String,String> labels=new HashMap<>();int periodInvoices=0,visibleInvoices=0,missingAccount=0;
        for(Store.Invoice inv:all){if(inv==null||inv.companyAccounted||!invoiceInRevenuePeriod(inv,days))continue;periodInvoices++;String company=safe(inv.shippingCompany).trim(),account=safe(inv.shippingAccount).trim();if(!storeRevenueCompanyFilter.isEmpty()&&!storeRevenueCompanyFilter.equals(company))continue;if(!storeRevenueAccountFilter.isEmpty()&&!storeRevenueAccountFilter.equals(account))continue;if("received".equals(storeRevenueStatusFilter)&&!inv.bankReceived)continue;if("pending".equals(storeRevenueStatusFilter)&&inv.bankReceived)continue;if(account.isEmpty()){missingAccount++;account="غير محدد — يحتاج تعيين حساب Store";}String key=company+"\u0001"+account;ArrayList<Store.Invoice> list=groups.get(key);if(list==null){list=new ArrayList<>();groups.put(key,list);}list.add(inv);labels.put(key,(company.isEmpty()?"شركة الشحن":company)+" • "+account);visibleInvoices++;}
        if(groups.isEmpty()){LinearLayout empty=card();empty.setGravity(Gravity.CENTER);empty.addView(text("لا توجد فواتير مطابقة للفلاتر الحالية.",15,TEXT));empty.addView(text("إجمالي الفواتير في الفترة: "+periodInvoices+" • الظاهرة: "+visibleInvoices,12,MUTED));empty.addView(text("جرّب «كل الحالات» أو «كل الفترة». ",12,MUTED));holder.addView(empty,margin(-1,-2,0,dp(8)));return;}
        if(missingAccount>0){TextView w=text("⚠ يوجد "+missingAccount+" فاتورة بدون حساب Store؛ ظهرت في «غير محدد» حتى لا تضيع من التقرير.",12,RED);w.setGravity(Gravity.CENTER);holder.addView(w,margin(-1,-2,0,dp(7)));}
        double grandGross=0,grandFees=0,grandNet=0,grandReceived=0,grandPending=0;int grandCount=0,grandReceivedCount=0;ArrayList<String> keys=new ArrayList<>(groups.keySet());Collections.sort(keys);
        for(String key:keys){ArrayList<Store.Invoice> list=groups.get(key);double gross=0,fees=0,net=0,received=0;int rc=0;for(Store.Invoice inv:list){boolean settled=inv.virementCode!=null&&!inv.virementCode.trim().isEmpty();double g=settled&&inv.virementTotalCrbt>0?inv.virementTotalCrbt:invoiceOutstanding(inv);double fee=settled?Math.max(0,inv.virementTotalFees):Math.max(0,inv.shippingCost);double n=settled&&inv.virementNet>0?inv.virementNet:Math.max(0,g-fee);gross+=g;fees+=fee;net+=n;if(inv.bankReceived){received+=n;rc++;}}double pending=Math.max(0,net-received);grandGross+=gross;grandFees+=fees;grandNet+=net;grandReceived+=received;grandPending+=pending;grandCount+=list.size();grandReceivedCount+=rc;
            LinearLayout c=card();c.setPadding(dp(10),dp(10),dp(10),dp(10));TextView title=text("🏦 "+safe(labels.get(key)),17,TEXT);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);title.setGravity(Gravity.CENTER);c.addView(title);TextView count=text("الفواتير / Colis: "+list.size()+" • 🟢 المستلمة: "+rc+" • 🔴 المعلقة: "+(list.size()-rc),12,MUTED);count.setGravity(Gravity.CENTER);c.addView(count);c.addView(text("💰 المبلغ عند الاستلام: "+money(gross)+" DH",14,TEXT),margin(-1,-2,0,0));c.addView(text("🚚 اقتطاع شركة الشحن: "+money(fees)+" DH",13,BLUE));c.addView(text("🏦 الصافي: "+money(net)+" DH",14,TEXT));c.addView(text("🟢 تم استلامه في البنك: "+money(received)+" DH",13,GREEN));c.addView(text("🔴 لم يصل بعد: "+money(pending)+" DH",13,pending>0?RED:MUTED));Button open=button("📋 فتح الفواتير وإعداد PDF");open.setTextColor(Color.WHITE);open.setBackground(solid(BLUE,10));open.setOnClickListener(v->showStoreAccountDetails(safe(labels.get(key)),list));c.addView(open,margin(-1,dp(46),0,dp(2)));holder.addView(c,margin(-1,-2,0,dp(7)));}
        LinearLayout totalCard=card();totalCard.setGravity(Gravity.CENTER);totalCard.setBackground(round(Color.rgb(239,246,255),Color.rgb(190,215,244),12,1));TextView tt=text("📊 الإجمالي حسب الفلاتر الحالية",17,TEXT);tt.setTypeface(Typeface.DEFAULT,Typeface.BOLD);tt.setGravity(Gravity.CENTER);totalCard.addView(tt);totalCard.addView(text("المبلغ عند الاستلام: "+money(grandGross)+" DH",14,TEXT),margin(-1,-2,0,0));totalCard.addView(text("اقتطاع الشحن: "+money(grandFees)+" DH",13,BLUE));totalCard.addView(text("الصافي: "+money(grandNet)+" DH",15,TEXT));totalCard.addView(text("🟢 تم استلامه في البنك: "+money(grandReceived)+" DH",14,GREEN));totalCard.addView(text("🔴 المتبقي: "+money(grandPending)+" DH",14,grandPending>0?RED:MUTED));totalCard.addView(text("الفواتير: "+grandCount+" • المستلمة: "+grandReceivedCount,12,MUTED));holder.addView(totalCard,margin(-1,dp(4),0,dp(10)));
    }

    TextView cardText(String s){TextView t=text(s,13,MUTED);t.setGravity(Gravity.CENTER);t.setBackground(round(Color.WHITE,BORDER,12,1));return t;}

    void showStoreAccountDetails(String title,ArrayList<Store.Invoice> invoices){
        base("فواتير حساب Store");
        String storeName=title;int sep=storeName.indexOf(" • ");if(sep>=0)storeName=storeName.substring(sep+3).trim();
        final String finalStoreName=storeName;

        TextView h=text("🏦 حساب Store: "+safe(finalStoreName),19,TEXT);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);h.setGravity(Gravity.CENTER);
        body.addView(h,margin(-1,dp(48),0,dp(4)));
        TextView sub=text("تحديد فواتير استلام البنك ثم إنشاء PDF ومشاركتها عبر WhatsApp. الفواتير المؤرشفة لا تظهر هنا مرة أخرى.",12,MUTED);sub.setGravity(Gravity.CENTER);sub.setLineSpacing(0f,1.1f);
        body.addView(sub,margin(-1,-2,0,dp(8)));

        // Store accounting toolbar: use fixed-height rows directly in the main
        // ScrollView.  The previous card-based toolbar could collapse to a thin
        // horizontal line on some Android/phone layouts, making all controls
        // appear hidden.  Keep the controls explicit and visible.
        LinearLayout actions=new LinearLayout(this);
        actions.setOrientation(LinearLayout.VERTICAL);
        actions.setGravity(Gravity.CENTER_HORIZONTAL);
        actions.setPadding(dp(10),dp(10),dp(10),dp(10));
        actions.setBackground(round(Color.WHITE,BLUE,12,1));
        actions.setMinimumHeight(dp(218));
        actions.setVisibility(View.VISIBLE);

        TextView actionsTitle=text("📄 محاسبة فواتير Store",16,TEXT);
        actionsTitle.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        actionsTitle.setGravity(Gravity.CENTER);
        actions.addView(actionsTitle,new LinearLayout.LayoutParams(-1,dp(30)));

        final ArrayList<Store.Invoice> active=new ArrayList<>();
        for(Store.Invoice inv:invoices)if(inv!=null&&!inv.companyAccounted)active.add(inv);

        double total=0,fees=0,received=0;int receivedCount=0;
        for(Store.Invoice i:active){
            boolean settled=i.virementCode!=null&&!i.virementCode.trim().isEmpty();
            double g=settled&&i.virementTotalCrbt>0?i.virementTotalCrbt:invoiceOutstanding(i);
            double f=settled?Math.max(0,i.virementTotalFees):Math.max(0,i.shippingCost);
            double n=settled&&i.virementNet>0?i.virementNet:Math.max(0,g-f);
            total+=g;fees+=f;if(i.bankReceived){received+=n;receivedCount++;}
        }
        final double finalTotal=total, finalFees=fees, finalNet=Math.max(0,total-fees);
        TextView summary=text("المبلغ: "+money(finalTotal)+" DH • الشحن: "+money(finalFees)+" DH • الصافي: "+money(finalNet)+" DH\n🟢 المستلم: "+money(received)+" DH ("+receivedCount+") • المتاح: "+active.size(),11,MUTED);
        summary.setGravity(Gravity.CENTER);
        summary.setLineSpacing(0f,1.05f);
        actions.addView(summary,new LinearLayout.LayoutParams(-1,dp(42)));

        LinearLayout row1=new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.setGravity(Gravity.CENTER);
        Button selectAll=button("☑ تحديد المستلمة");
        selectAll.setTextColor(BLUE);
        selectAll.setTextSize(12);
        row1.addView(selectAll,new LinearLayout.LayoutParams(0,dp(46),1));
        Button clear=button("☐ إلغاء التحديد");
        clear.setTextColor(MUTED);
        clear.setTextSize(12);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(46),1);
        cp.setMargins(dp(6),0,0,0);
        row1.addView(clear,cp);
        actions.addView(row1,new LinearLayout.LayoutParams(-1,dp(48)));

        LinearLayout row2=new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setGravity(Gravity.CENTER);
        Button export=button("📄 PDF المحدد + WhatsApp");
        export.setTextColor(Color.WHITE);
        export.setTextSize(12);
        export.setBackground(solid(GREEN,12));
        row2.addView(export,new LinearLayout.LayoutParams(0,dp(52),1));
        Button archive=button("📚 أرشيف Store");
        archive.setTextColor(BLUE);
        archive.setTextSize(12);
        archive.setBackground(solid(Color.rgb(235,241,249),12));
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(52),1);
        ap.setMargins(dp(6),0,0,0);
        row2.addView(archive,ap);
        actions.addView(row2,new LinearLayout.LayoutParams(-1,dp(54)));

        final TextView selectedCount=text("المحدد: 0 فاتورة",11,MUTED);
        selectedCount.setGravity(Gravity.CENTER);
        actions.addView(selectedCount,new LinearLayout.LayoutParams(-1,dp(24)));
        body.addView(actions,margin(-1,-2,0,dp(12)));

        ArrayList<Integer> pdfIds=new ArrayList<>();ArrayList<CheckBox> pdfChecks=new ArrayList<>();
        for(Store.Invoice inv:active){
            boolean settled=inv.virementCode!=null&&!inv.virementCode.trim().isEmpty();
            double g=settled&&inv.virementTotalCrbt>0?inv.virementTotalCrbt:invoiceOutstanding(inv);
            double f=settled?Math.max(0,inv.virementTotalFees):Math.max(0,inv.shippingCost);
            double n=settled&&inv.virementNet>0?inv.virementNet:Math.max(0,g-f);
            LinearLayout card=card();card.setPadding(dp(8),dp(8),dp(8),dp(8));
            TextView tr=text("#"+invoiceNo(inv)+" • "+safe(inv.client)+"\n💵 "+money(g)+" DH • 🚚 "+money(f)+" DH • الصافي: "+money(n)+" DH",14,TEXT);tr.setTypeface(Typeface.DEFAULT,Typeface.BOLD);tr.setGravity(Gravity.RIGHT);card.addView(tr);
            String status=inv.bankReceived?"🟢 تم استلام المبلغ إلى البنك":"🔴 لم يتم استلام المبلغ إلى البنك";
            TextView inf=text(status+"\n📞 "+safe(inv.customerPhone)+" • 📍 "+safe(inv.customerCity)+"\n🚚 "+safe(inv.shippingCompany)+" • 🏪 "+safe(inv.shippingAccount)+"\n📦 "+safe(inv.trackingNumber)+"\n💳 Virement: "+safe(inv.virementCode),11,inv.bankReceived?GREEN:RED);inf.setGravity(Gravity.RIGHT);card.addView(inf,margin(-1,dp(72),0,dp(3)));
            CheckBox pdf=new CheckBox(this);pdf.setText(inv.bankReceived?"تحديد هذه الفاتورة لإضافتها إلى PDF":"غير متاحة — لم يصل المبلغ إلى البنك");pdf.setTextSize(12);pdf.setTextColor(inv.bankReceived?TEXT:MUTED);pdf.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);pdf.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);pdf.setEnabled(inv.bankReceived);pdf.setChecked(false);
            pdf.setOnCheckedChangeListener((b,checked)->{int count=0;for(CheckBox x:pdfChecks)if(x.isChecked())count++;selectedCount.setText("المحدد: "+count);});
            card.addView(pdf,new LinearLayout.LayoutParams(-1,dp(48)));
            body.addView(card,margin(-1,-2,0,dp(6)));pdfChecks.add(pdf);pdfIds.add(inv.id);
        }

        selectAll.setOnClickListener(v->{for(CheckBox cb:pdfChecks)if(cb.isEnabled())cb.setChecked(true);});
        clear.setOnClickListener(v->{for(CheckBox cb:pdfChecks)cb.setChecked(false);});
        archive.setOnClickListener(v->showStoreAccountingArchive(finalStoreName));
        export.setOnClickListener(v->{
            ArrayList<Store.Invoice> selected=new ArrayList<>();
            for(int k=0;k<pdfChecks.size();k++)if(pdfChecks.get(k).isChecked()&&pdfChecks.get(k).isEnabled()){
                Store.Invoice inv=db.invoice(pdfIds.get(k));if(inv!=null&&!inv.companyAccounted&&inv.bankReceived)selected.add(inv);
            }
            if(selected.isEmpty()){Toast.makeText(this,"حدد فاتورة واحدة على الأقل تم استلام مبلغها إلى البنك",Toast.LENGTH_SHORT).show();return;}
            buildStoreBankReceivedPdf(finalStoreName,selected,"BANK-"+new SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(new Date()));
        });

        if(active.isEmpty()){
            LinearLayout empty=card();empty.setGravity(Gravity.CENTER);empty.addView(text("لا توجد فواتير متاحة للمحاسبة في هذا الحساب.\nالفواتير التي تمت محاسبتها محفوظة في الأرشيف.",14,MUTED));body.addView(empty,margin(-1,-2,0,dp(8)));
        }
    }

    void showStoreAccountingArchive(String storeName){
        base("أرشيف محاسبة Store");
        final String finalStoreName=safe(storeName).trim();
        TextView h=text("📚 أرشيف حساب Store: "+finalStoreName,19,TEXT);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);h.setGravity(Gravity.CENTER);
        body.addView(h,margin(-1,dp(48),0,dp(8)));

        LinearLayout intro=card();intro.setGravity(Gravity.CENTER);
        TextView it=text("كل مرة يتم فيها محاسبة فواتير Store يتم إنشاء أرشيف مستقل برقم وتاريخ ثابتين.\nيمكنك فتح أي أرشيف لاسترجاع بعض الفواتير أو استخراج PDF منها.",13,MUTED);it.setGravity(Gravity.CENTER);it.setLineSpacing(0f,1.15f);intro.addView(it,new LinearLayout.LayoutParams(-1,-2));
        body.addView(intro,margin(-1,-2,0,dp(10)));

        ArrayList<Store.StoreAccountingArchive> archives=db.storeAccountingArchives(finalStoreName);
        if(archives.isEmpty()){
            LinearLayout empty=card();empty.setGravity(Gravity.CENTER);TextView e=text("لا توجد أرشيفات محاسبة لهذا الحساب حتى الآن.",15,MUTED);e.setGravity(Gravity.CENTER);empty.addView(e);body.addView(empty,margin(-1,-2,0,dp(10)));
            Button back=button("← العودة إلى فواتير الحساب");back.setTextColor(BLUE);back.setOnClickListener(v->showStoreAccountsRevenue());body.addView(back,new LinearLayout.LayoutParams(-1,dp(48)));return;
        }

        TextView countTitle=text("عدد عمليات الأرشفة: "+archives.size(),13,TEXT);countTitle.setGravity(Gravity.CENTER);countTitle.setTypeface(Typeface.DEFAULT,Typeface.BOLD);body.addView(countTitle,margin(-1,-2,0,dp(8)));
        for(Store.StoreAccountingArchive a:archives){
            ArrayList<Store.Invoice> rows=db.companyAccountedInvoicesByExport(finalStoreName,a.exportId);
            int currentCount=rows.size();
            LinearLayout c=card();
            TextView title=text("📚 أرشيف "+a.archiveNo,18,TEXT);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);title.setGravity(Gravity.CENTER);c.addView(title);
            TextView meta=text("📅 "+safe(a.archivedAt)+"  •  📄 "+currentCount+" فاتورة حالياً\n🔖 "+safe(a.exportId),12,MUTED);meta.setGravity(Gravity.CENTER);meta.setLineSpacing(0f,1.1f);c.addView(meta,new LinearLayout.LayoutParams(-1,-2));
            LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);r.setGravity(Gravity.CENTER);
            Button open=button("📂 فتح الأرشيف "+a.archiveNo);open.setTextColor(Color.WHITE);open.setBackground(solid(BLUE,10));r.addView(open,new LinearLayout.LayoutParams(0,dp(48),1));
            Button pdf=button("📄 PDF");pdf.setTextColor(Color.WHITE);pdf.setBackground(solid(GREEN,10));LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(0,dp(48),1);pp.setMargins(dp(6),0,0,0);r.addView(pdf,pp);c.addView(r,margin(-1,dp(8),0,0));
            final String exportId=a.exportId;final int archiveNo=a.archiveNo;final String archivedAt=a.archivedAt;
            open.setOnClickListener(v->showStoreAccountingArchiveBatch(finalStoreName,exportId,archiveNo,archivedAt));
            pdf.setOnClickListener(v->{ArrayList<Store.Invoice> chosen=db.companyAccountedInvoicesByExport(finalStoreName,exportId);if(chosen.isEmpty()){Toast.makeText(this,"لا توجد فواتير حالياً في أرشيف "+archiveNo,Toast.LENGTH_SHORT).show();return;}buildStoreBankReceivedPdf(finalStoreName,chosen,"ARCH-"+archiveNo+"-"+exportId,false);});
            body.addView(c,margin(-1,-2,0,dp(8)));
        }
        Button back=button("← العودة إلى مداخيل حسابات Store");back.setTextColor(BLUE);back.setOnClickListener(v->showStoreAccountsRevenue());body.addView(back,margin(-1,dp(8),0,dp(10)));
    }

    void showStoreAccountingArchiveBatch(String storeName,String exportId,int archiveNo,String archivedAt){
        base("أرشيف Store "+archiveNo);
        final String finalStoreName=safe(storeName).trim();
        ArrayList<Store.Invoice> rows=db.companyAccountedInvoicesByExport(finalStoreName,exportId);
        TextView h=text("📚 أرشيف "+archiveNo+" — حساب Store: "+finalStoreName,18,TEXT);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);h.setGravity(Gravity.CENTER);body.addView(h,margin(-1,dp(42),0,dp(4)));
        TextView info=text("📅 تاريخ الأرشفة: "+safe(archivedAt)+"\n🔖 "+safe(exportId),12,MUTED);info.setGravity(Gravity.CENTER);body.addView(info,new LinearLayout.LayoutParams(-1,-2));
        if(rows.isEmpty()){
            LinearLayout empty=card();empty.setGravity(Gravity.CENTER);TextView e=text("هذا الأرشيف لا يحتوي حالياً على فواتير.\nتم استرجاع جميع فواتيره إلى قائمة المحاسبة.",14,MUTED);e.setGravity(Gravity.CENTER);empty.addView(e);body.addView(empty,margin(-1,dp(10),0,dp(8)));
        }else{
            ArrayList<Integer> selected=new ArrayList<>();ArrayList<CheckBox> checks=new ArrayList<>();
            LinearLayout tools=card();tools.setPadding(dp(10),dp(10),dp(10),dp(10));
            TextView count=text("المحدد: 0 • فواتير الأرشيف: "+rows.size(),12,MUTED);count.setGravity(Gravity.CENTER);tools.addView(count,new LinearLayout.LayoutParams(-1,-2));
            LinearLayout r1=new LinearLayout(this);r1.setOrientation(LinearLayout.HORIZONTAL);r1.setGravity(Gravity.CENTER);
            Button all=button("☑ تحديد الكل");all.setTextColor(BLUE);r1.addView(all,new LinearLayout.LayoutParams(0,dp(46),1));
            Button none=button("☐ إلغاء");none.setTextColor(MUTED);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,dp(46),1);np.setMargins(dp(6),0,0,0);r1.addView(none,np);tools.addView(r1,margin(-1,dp(8),0,0));
            LinearLayout r2=new LinearLayout(this);r2.setOrientation(LinearLayout.HORIZONTAL);r2.setGravity(Gravity.CENTER);
            Button pdf=button("📄 PDF المحدد");pdf.setTextColor(Color.WHITE);pdf.setBackground(solid(BLUE,10));r2.addView(pdf,new LinearLayout.LayoutParams(0,dp(50),1));
            Button restore=button("↩ استرجاع المحدد");restore.setTextColor(Color.WHITE);restore.setBackground(solid(Color.rgb(190,75,55),10));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,dp(50),1);rp.setMargins(dp(6),0,0,0);r2.addView(restore,rp);tools.addView(r2,margin(-1,dp(8),0,0));
            body.addView(tools,margin(-1,dp(10),0,dp(8)));
            for(Store.Invoice inv:rows){
                CheckBox cb=new CheckBox(this);cb.setText("#"+invoiceNo(inv)+" • "+safe(inv.client)+"\n📞 "+safe(inv.customerPhone)+" • 📍 "+safe(inv.customerCity)+"\n📅 "+safe(inv.companyAccountedDate)+" • 🏪 "+safe(inv.companyAccountingStore));cb.setTextSize(12);cb.setTextColor(TEXT);cb.setGravity(Gravity.RIGHT);cb.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);cb.setPadding(dp(8),dp(7),dp(8),dp(7));
                cb.setOnCheckedChangeListener((b,checked)->{if(checked){if(!selected.contains(inv.id))selected.add(inv.id);}else selected.remove((Integer)inv.id);count.setText("المحدد: "+selected.size()+" • فواتير الأرشيف: "+rows.size());});checks.add(cb);body.addView(cb,new LinearLayout.LayoutParams(-1,-2));
            }
            all.setOnClickListener(v->{for(CheckBox cb:checks)cb.setChecked(true);});none.setOnClickListener(v->{for(CheckBox cb:checks)cb.setChecked(false);});
            pdf.setOnClickListener(v->{if(selected.isEmpty()){Toast.makeText(this,"حدد فاتورة واحدة على الأقل",Toast.LENGTH_SHORT).show();return;}ArrayList<Store.Invoice> chosen=new ArrayList<>();for(Integer id:selected){Store.Invoice inv=db.invoice(id);if(inv!=null&&inv.companyAccounted)chosen.add(inv);}if(chosen.isEmpty()){Toast.makeText(this,"تعذر قراءة الفواتير المحددة",Toast.LENGTH_SHORT).show();return;}buildStoreBankReceivedPdf(finalStoreName,chosen,"ARCH-"+archiveNo+"-"+new SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(new Date()),false);});
            restore.setOnClickListener(v->{if(selected.isEmpty()){Toast.makeText(this,"حدد فاتورة واحدة على الأقل",Toast.LENGTH_SHORT).show();return;}if(db.restoreCompanyAccounting(selected)){Toast.makeText(this,"تم استرجاع "+selected.size()+" فاتورة من أرشيف "+archiveNo+" إلى قائمة المحاسبة",Toast.LENGTH_LONG).show();showStoreAccountingArchiveBatch(finalStoreName,exportId,archiveNo,archivedAt);}else Toast.makeText(this,"تعذر استرجاع الفواتير",Toast.LENGTH_LONG).show();});
        }
        Button back=button("← العودة إلى أرشيف Store");back.setTextColor(BLUE);back.setOnClickListener(v->showStoreAccountingArchive(finalStoreName));body.addView(back,margin(-1,dp(16),0,dp(10)));
    }

    String finalStoreArchiveName(String storeName){return storeName==null?"":storeName.trim();}

    void chooseVirementStoreAndPickPdf(){
        ArrayList<Store.ShippingCompany> companies=db.shippingCompanies();
        if(companies.isEmpty()){Toast.makeText(this,"أضف شركة شحن أولاً",Toast.LENGTH_SHORT).show();return;}
        LinearLayout wrap=new LinearLayout(this);wrap.setOrientation(LinearLayout.VERTICAL);wrap.setPadding(dp(5),dp(5),dp(5),dp(5));
        Spinner company=new Spinner(this);ArrayList<String> names=new ArrayList<>();for(Store.ShippingCompany c:companies)names.add(c.name);ArrayAdapter<String> ca=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,names);ca.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);company.setAdapter(ca);
        Spinner account=new Spinner(this);ArrayList<String> accounts=new ArrayList<>();ArrayList<Store.ShippingAccount> accountRows=new ArrayList<>();
        Runnable reload=()->{accounts.clear();accountRows.clear();int pos=company.getSelectedItemPosition();if(pos>=0){accountRows.addAll(db.shippingAccounts(companies.get(pos).id));for(Store.ShippingAccount a:accountRows)accounts.add(a.name);}ArrayAdapter<String> aa=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,accounts);aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);account.setAdapter(aa);};
        company.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){reload.run();}public void onNothingSelected(android.widget.AdapterView<?> p){}});wrap.addView(text("شركة الشحن",13,TEXT));wrap.addView(company);wrap.addView(text("حساب Store الذي ينتمي إليه هذا Virement",13,TEXT));wrap.addView(account);
        new AlertDialog.Builder(this).setTitle("استيراد PDF Virement").setView(wrap).setNegativeButton("إلغاء",null).setPositiveButton("اختيار PDF",(d,w)->{int cp=company.getSelectedItemPosition();int ap=account.getSelectedItemPosition();if(cp<0||ap<0||accountRows.isEmpty()){Toast.makeText(this,"اختر شركة الشحن وحساب Store",Toast.LENGTH_SHORT).show();return;}pendingVirementCompany=companies.get(cp).name;pendingVirementStore=accountRows.get(ap).name;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/pdf");startActivityForResult(i,REQ_VIREMENT_PDF);}).show();
        reload.run();
    }

    void processVirementPdf(Uri uri){
        Toast.makeText(this,"جاري قراءة PDF Virement…",Toast.LENGTH_SHORT).show();
        new Thread(()->{
            try{
                VirementPdfParser.Result result=VirementPdfParser.parse(this,uri);
                runOnUiThread(()->showVirementReview(result));
            }catch(Exception e){runOnUiThread(()->Toast.makeText(this,"تعذر قراءة PDF Virement: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }).start();
    }

    void showVirementReview(VirementPdfParser.Result r){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(4),dp(4),dp(4),dp(4));
        box.addView(text("Virement: "+safe(r.virementCode),14,TEXT));box.addView(text("التاريخ: "+safe(r.date)+" • Colis: "+r.rows.size()+" • CRBT: "+money(r.totalCrbt)+" DH • Frais: "+money(r.totalFees)+" DH",12,MUTED));
        int matched=0;StringBuilder detail=new StringBuilder();ArrayList<VirementPdfParser.Row> rows=r.rows;for(VirementPdfParser.Row row:rows){Store.Invoice inv=db.invoiceByTracking(row.code);if(inv!=null)matched++;detail.append(inv!=null?"✅ ":"❌ ").append(row.code).append(" → ").append(inv==null?"لم يتم العثور على الفاتورة #":"فاتورة #"+(inv.invoiceNumber>0?inv.invoiceNumber:inv.id)).append(" • Frais ").append(money(row.fees)).append(" DH\n");}
        TextView d=text(detail.toString(),11,MUTED);d.setGravity(Gravity.RIGHT);ScrollView sv=new ScrollView(this);sv.addView(d);box.addView(sv,new LinearLayout.LayoutParams(-1,dp(240)));box.addView(text("تم العثور على "+matched+" من "+rows.size()+" فواتير. سيتم تحديث تكلفة الشحن الحقيقية فقط للفواتير التي تم العثور عليها.",12,matched==rows.size()?GREEN:RED));
        new AlertDialog.Builder(this).setTitle("مراجعة Virement قبل الحفظ").setView(box).setNegativeButton("إلغاء",null).setPositiveButton("تطبيق البيانات",(dlg,w)->applyVirementResult(r)).show();
    }

    void applyVirementResult(VirementPdfParser.Result r){
        int matched=0;for(VirementPdfParser.Row row:r.rows){Store.Invoice inv=db.invoiceByTracking(row.code);if(inv==null)continue;db.applyVirementToInvoice(inv.id,r.virementCode,r.date,row.crbt,row.fees,row.total,pendingVirementCompany,pendingVirementStore);matched++;}
        Toast.makeText(this,"تم تحديث "+matched+" فاتورة من Virement "+safe(r.virementCode)+" • حساب Store "+safe(pendingVirementStore)+" • 🟢 تم استلام المبلغ إلى البنك",Toast.LENGTH_LONG).show();cloud.syncLocalToCloud(()->showStoreAccountsRevenue(),()->showStoreAccountsRevenue());
    }

    void buildStoreBankReceivedPdf(String storeName,ArrayList<Store.Invoice> invoices,String exportId){buildStoreBankReceivedPdf(storeName,invoices,exportId,true);}

    void buildStoreBankReceivedPdf(String storeName,ArrayList<Store.Invoice> invoices,String exportId,boolean markAccounting){
        try{
            PdfDocument doc=new PdfDocument();Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));int pageNo=1;PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create());Canvas c=page.getCanvas();int y=45;double totalCrbt=0,totalFees=0,totalNet=0;
            for(Store.Invoice inv:invoices){boolean settled=inv.virementCode!=null&&!inv.virementCode.trim().isEmpty();double crbt=settled&&inv.virementTotalCrbt>0?inv.virementTotalCrbt:invoiceOutstanding(inv);double fee=settled?Math.max(0,inv.virementTotalFees):Math.max(0,inv.shippingCost);double net=settled&&inv.virementNet>0?inv.virementNet:Math.max(0,crbt-fee);totalCrbt+=crbt;totalFees+=fee;totalNet+=net;}
            p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(22);c.drawText("MGE",40,y,p);c.drawText("— BANK SETTLEMENT",100,y,p);y+=27;p.setTextSize(13);c.drawText("Store : "+trim(storeName,42),40,y,p);y+=20;p.setTypeface(Typeface.DEFAULT);p.setTextSize(10);c.drawText("Rapport des virements reçus • Date : "+new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.US).format(new Date()),40,y,p);y+=16;c.drawText("Référence : "+exportId,40,y,p);y+=22;p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(11);c.drawText("FACTURES AVEC MONTANT REÇU À LA BANQUE",40,y,p);y+=17;
            for(Store.Invoice inv:invoices){boolean settled=inv.virementCode!=null&&!inv.virementCode.trim().isEmpty();double crbt=settled&&inv.virementTotalCrbt>0?inv.virementTotalCrbt:invoiceOutstanding(inv);double fee=settled?Math.max(0,inv.virementTotalFees):Math.max(0,inv.shippingCost);double net=settled&&inv.virementNet>0?inv.virementNet:Math.max(0,crbt-fee);if(y>735){p.setTypeface(Typeface.DEFAULT);p.setTextSize(9);c.drawText("Page "+pageNo,500,810,p);doc.finishPage(page);pageNo++;page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create());c=page.getCanvas();y=45;p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(13);c.drawText("MGE — BANK SETTLEMENT (suite)",40,y,p);y+=28;}p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);p.setColor(BORDER);c.drawRoundRect(32,y-4,563,y+118,8,8,p);p.setStyle(Paint.Style.FILL);p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(12);c.drawText("#"+invoiceNo(inv)+"   "+trim(inv.client,35),45,y+16,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(9);c.drawText("Téléphone : "+trim(safe(inv.customerPhone),22),45,y+34,p);c.drawText("Ville : "+trim(safe(inv.customerCity),22),310,y+34,p);c.drawText("N° suivi : "+trim(safe(inv.trackingNumber),27),45,y+51,p);c.drawText("Société : "+trim(safe(inv.shippingCompany),24),310,y+51,p);c.drawText("Store : "+trim(safe(inv.shippingAccount),24),45,y+68,p);c.drawText("Virement : "+trim(safe(inv.virementCode),27),310,y+68,p);c.drawText("Date Virement : "+trim(safe(inv.virementDate),18),45,y+85,p);c.drawText("Coût / frais : "+money(fee)+" DH",310,y+85,p);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(10);c.drawText("CRBT : "+money(crbt)+" DH",45,y+104,p);c.drawText("MONTANT NET REÇU : "+money(net)+" DH",310,y+104,p);y+=132;}
            if(y>740){p.setTypeface(Typeface.DEFAULT);p.setTextSize(9);c.drawText("Page "+pageNo,500,810,p);doc.finishPage(page);pageNo++;page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create());c=page.getCanvas();y=55;}
            p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(13);c.drawText("RÉCAPITULATIF",40,y,p);y+=22;p.setTypeface(Typeface.DEFAULT);p.setTextSize(11);c.drawText("Nombre de factures : "+invoices.size(),40,y,p);y+=18;c.drawText("Total CRBT : "+money(totalCrbt)+" DH",40,y,p);y+=18;c.drawText("Total frais de livraison : "+money(totalFees)+" DH",40,y,p);y+=18;c.drawText("TOTAL MONTANT NET REÇU : "+money(totalNet)+" DH",40,y,p);y+=24;p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("✓ Tous les montants de ce rapport sont marqués comme reçus à la banque.",40,y,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(9);c.drawText("Page "+pageNo,500,810,p);doc.finishPage(page);
            ByteArrayOutputStream out=new ByteArrayOutputStream();doc.writeTo(out);doc.close();byte[] bytes=out.toByteArray();String safeStore=storeName.replaceAll("[^A-Za-z0-9_-]","_");String fileName="MGE_Bank_Received_"+safeStore+"_"+exportId+".pdf";Uri uri;
            if(Build.VERSION.SDK_INT>=29){ContentValues values=new ContentValues();values.put(MediaStore.Downloads.DISPLAY_NAME,fileName);values.put(MediaStore.Downloads.MIME_TYPE,"application/pdf");values.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/FactureSimple");uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new IOException("تعذر إنشاء ملف PDF");try(OutputStream os=getContentResolver().openOutputStream(uri)){os.write(bytes);}}else{File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"FactureSimple");if(!dir.exists()&&!dir.mkdirs())throw new IOException("تعذر إنشاء مجلد PDF");File f=new File(dir,fileName);try(OutputStream os=new FileOutputStream(f)){os.write(bytes);}uri=Uri.fromFile(f);}
            if(markAccounting){ArrayList<Integer> accountedIds=new ArrayList<>();for(Store.Invoice inv:invoices)accountedIds.add(inv.id);db.markCompanyAccounting(accountedIds,storeName,exportId);int archiveNo=db.createStoreAccountingArchive(storeName,exportId,accountedIds.size());Toast.makeText(this,"تم إنشاء أرشيف Store #"+archiveNo+" بتاريخ "+new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.US).format(new Date()),Toast.LENGTH_LONG).show();}
            Intent share=new Intent(Intent.ACTION_SEND);share.setType("application/pdf");share.putExtra(Intent.EXTRA_STREAM,uri);share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);share.setClipData(ClipData.newRawUri("PDF",uri));try{share.setPackage("com.whatsapp");startActivity(share);}catch(Exception e){share.setPackage(null);startActivity(Intent.createChooser(share,"إرسال PDF عبر WhatsApp أو تطبيق آخر"));}Toast.makeText(this,"تم إنشاء PDF: "+invoices.size()+" فاتورة • الإجمالي الصافي "+money(totalNet)+" DH",Toast.LENGTH_LONG).show();
        }catch(Exception e){Toast.makeText(this,"خطأ في إنشاء PDF المداخيل: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }

    void buildStoreAccountingPdf(String storeName,ArrayList<Store.Invoice> invoices,ArrayList<Integer> ids,String exportId){
        try{
            PdfDocument doc=new PdfDocument();Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);int pageNo=1;PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create());Canvas c=page.getCanvas();
            double total=0,fees=0,net=0;int y=45;
            p.setColor(TEXT);p.setTextSize(22);p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("MGE — محاسبة حساب Store",40,y,p);y+=30;p.setTextSize(15);c.drawText("حساب Store: "+storeName,40,y,p);y+=22;p.setTextSize(11);p.setTypeface(Typeface.DEFAULT);c.drawText("تاريخ التصدير: "+new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.US).format(new Date()),40,y,p);y+=18;c.drawText("رقم العملية: "+exportId,40,y,p);y+=30;
            p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(10);c.drawText("Facture",40,y,p);c.drawText("Client",95,y,p);c.drawText("Code d'envoi",220,y,p);c.drawText("CRBT",360,y,p);c.drawText("Frais",430,y,p);c.drawText("Net",480,y,p);y+=18;p.setTypeface(Typeface.DEFAULT);
            for(Store.Invoice inv:invoices){if(y>790){doc.finishPage(page);pageNo++;page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create());c=page.getCanvas();y=45;p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(10);c.drawText("MGE — محاسبة حساب Store "+storeName+" (suite)",40,y,p);y+=28;c.drawText("Facture",40,y,p);c.drawText("Client",95,y,p);c.drawText("Code d'envoi",220,y,p);c.drawText("CRBT",360,y,p);c.drawText("Frais",430,y,p);c.drawText("Net",480,y,p);y+=18;p.setTypeface(Typeface.DEFAULT);}
                double g=invoiceOutstanding(inv),f=Math.max(0,inv.shippingCost),n=Math.max(0,g-f);total+=g;fees+=f;net+=n;p.setTextSize(9);c.drawText("#"+invoiceNo(inv),40,y,p);c.drawText(trim(inv.client,18),95,y,p);c.drawText(trim(safe(inv.trackingNumber),20),220,y,p);c.drawText(money(g),360,y,p);c.drawText(money(f),430,y,p);c.drawText(money(n),480,y,p);y+=20;
            }
            y+=15;p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(12);c.drawText("الإجمالي",40,y,p);c.drawText("CRBT: "+money(total)+" DH",200,y,p);c.drawText("Frais: "+money(fees)+" DH",330,y,p);c.drawText("Net: "+money(net)+" DH",450,y,p);y+=25;p.setTypeface(Typeface.DEFAULT);p.setTextSize(10);c.drawText("تمت المحاسبة مع حساب Store "+storeName,40,y,p);doc.finishPage(page);
            byte[] bytes;ByteArrayOutputStream out=new ByteArrayOutputStream();doc.writeTo(out);doc.close();bytes=out.toByteArray();String fileName="Comptabilite_Store_"+storeName.replaceAll("[^A-Za-z0-9_-]","_")+"_"+exportId+".pdf";Uri uri;if(Build.VERSION.SDK_INT>=29){ContentValues values=new ContentValues();values.put(MediaStore.Downloads.DISPLAY_NAME,fileName);values.put(MediaStore.Downloads.MIME_TYPE,"application/pdf");values.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/FactureSimple");uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new IOException("تعذر إنشاء ملف PDF");try(OutputStream os=getContentResolver().openOutputStream(uri)){os.write(bytes);}}else{File dir=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS+"/FactureSimple");if(!dir.exists())dir.mkdirs();File f=new File(dir,fileName);try(OutputStream os=new FileOutputStream(f)){os.write(bytes);}uri=Uri.fromFile(f);}db.markCompanyAccounting(ids,storeName,exportId);Toast.makeText(this,"تم تصدير ملف المحاسبة وتسجيل "+ids.size()+" فاتورة على حساب Store "+storeName,Toast.LENGTH_LONG).show();Intent share=new Intent(Intent.ACTION_SEND);share.setType("application/pdf");share.putExtra(Intent.EXTRA_STREAM,uri);share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);share.setClipData(ClipData.newRawUri("PDF",uri));startActivity(Intent.createChooser(share,"إرسال ملف المحاسبة"));
        }catch(Exception e){Toast.makeText(this,"خطأ في PDF المحاسبة: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }

    void showSettings(){
        if(cloud == null || !cloud.isAdmin()){
            Toast.makeText(this,"هذه الصفحة متاحة للمدير فقط",Toast.LENGTH_SHORT).show();
            return;
        }
        base("الإعدادات");
        LinearLayout c=card();
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.logo_mge);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);c.addView(logo,new LinearLayout.LayoutParams(-1,dp(82)));
        EditText name=input("اسم الشركة");name.setText(db.get("company_name","MGE"));
        EditText phone=input("هاتف الشركة");phone.setText(db.get("phone","+212666964731"));
        EditText footer=input("نص أسفل الفاتورة");footer.setText(db.get("footer","Merci pour votre confiance"));
        c.addView(name,margin(-1,dp(48),0,dp(7)));c.addView(phone,margin(-1,dp(48),0,dp(7)));c.addView(footer,margin(-1,dp(48),0,dp(8)));
        Button save=button("حفظ الإعدادات");save.setTextColor(Color.WHITE);save.setBackground(solid(GREEN,12));
        save.setOnClickListener(v->{db.put("company_name",name.getText().toString());db.put("phone",phone.getText().toString());db.put("footer",footer.getText().toString());Toast.makeText(this,"تم حفظ الإعدادات",Toast.LENGTH_SHORT).show();});
        c.addView(save,new LinearLayout.LayoutParams(-1,dp(52)));
        body.addView(c,margin(-1,-2,0,dp(10)));

        LinearLayout partnersCard=card();
        TextView partnersTitle=text("👥 إدارة حسابات الشركاء",17,TEXT); partnersTitle.setTypeface(Typeface.DEFAULT,Typeface.BOLD); partnersTitle.setGravity(Gravity.CENTER); partnersCard.addView(partnersTitle);
        partnersCard.addView(text("إنشاء حسابات الشركاء وربط Partner ID وتفعيل أو تعطيل الحسابات وإرسال روابط تغيير كلمة المرور.",12,MUTED));
        Button partnersBtn=button("👥 فتح إدارة الشركاء"); partnersBtn.setTextColor(Color.WHITE); partnersBtn.setBackground(solid(BLUE,12)); partnersBtn.setOnClickListener(v->showPartners());
        partnersCard.addView(partnersBtn,margin(-1,dp(50),0,0));
        body.addView(partnersCard,margin(-1,-2,0,dp(10)));

        LinearLayout cloudCard=card();
        TextView cloudTitle=text("☁️ MGE Cloud — مركز المزامنة",17,TEXT);cloudTitle.setTypeface(Typeface.DEFAULT,Typeface.BOLD);cloudTitle.setGravity(Gravity.CENTER);cloudCard.addView(cloudTitle);
        TextView cloudUser=text("المستخدم: "+safe(cloud.email())+"\nالصلاحية: "+(cloud.isAdmin()?"مدير — وصول كامل":"شريك — زبائنك فقط"),12,MUTED);cloudUser.setGravity(Gravity.CENTER);cloudCard.addView(cloudUser);
        TextView network=text("",13,MUTED);network.setGravity(Gravity.CENTER);cloudCard.addView(network,margin(-1,dp(28),0,dp(5)));
        TextView syncSummary=text("",13,TEXT);syncSummary.setGravity(Gravity.CENTER);cloudCard.addView(syncSummary,margin(-1,dp(70),0,dp(5)));
        TextView syncDetails=text("",12,MUTED);syncDetails.setGravity(Gravity.CENTER);cloudCard.addView(syncDetails,margin(-1,dp(62),0,dp(8)));
        Button sync=button("🔄  مزامنة الآن");sync.setTextColor(Color.WHITE);sync.setTextSize(15);sync.setBackground(solid(BLUE,12));
        Runnable refreshSync=()->{
            boolean online=false; try{ ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE); NetworkInfo ni=cm==null?null:cm.getActiveNetworkInfo(); online=ni!=null&&ni.isConnected(); }catch(Exception ignored){}
            network.setText(online?"🟢 الإنترنت متصل":"🔴 لا يوجد اتصال بالإنترنت");
            int pd=db.syncDirtyCount("products"), cd=db.syncDirtyCount("customers"), id=db.syncDirtyCount("invoices");
            int pending=db.syncDirtyCount(); long last=db.syncLastAt();
            syncSummary.setText("المنتجات: "+(pd==0?"✅":"⏳ "+pd)+"   |   الزبائن: "+(cd==0?"✅":"⏳ "+cd)+"   |   الفواتير: "+(id==0?"✅":"⏳ "+id));
            String lastText=last>0?new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm",java.util.Locale.getDefault()).format(new java.util.Date(last)):"لم تتم مزامنة بعد";
            syncDetails.setText("تغييرات معلقة: "+pending+"\nآخر مزامنة: "+lastText);
            sync.setEnabled(online && cloud.isLoggedIn());
        };
        sync.setOnClickListener(v->{
            sync.setEnabled(false); refreshSync.run();
            Runnable ok=()->{
                db.put("cloud_sync_last_status","success");
                refreshSync.run();
                String msg=cloud.lastSyncWarning==null||cloud.lastSyncWarning.isEmpty()?"تمت المزامنة بنجاح":"تمت المزامنة مع ملاحظة: "+cloud.lastSyncWarning;
                Toast.makeText(this,msg,Toast.LENGTH_LONG).show();
            };
            Runnable bad=()->{
                db.put("cloud_sync_last_status","error");
                refreshSync.run();
                String reason=cloud.lastSyncError==null||cloud.lastSyncError.isEmpty()?"تحقق من الإنترنت والصلاحيات":cloud.lastSyncError;
                Toast.makeText(this,"فشلت المزامنة: "+reason,Toast.LENGTH_LONG).show();
            };
            if(cloud.isAdmin()) cloud.syncLocalToCloud(ok,bad); else cloud.syncCloudToLocalForPartner(ok,bad);
        });
        cloudCard.addView(sync,margin(-1,dp(50),0,dp(8)));
        if(cloud.isAdmin()){
            Button repairImages=button("🖼️ ضغط وتنظيف صور السحابة (≤ 200KB)");
            repairImages.setTextColor(Color.WHITE);repairImages.setTextSize(14);repairImages.setBackground(solid(GREEN,12));
            repairImages.setOnClickListener(v->{repairImages.setEnabled(false);Toast.makeText(this,"جاري فحص صور السحابة…",Toast.LENGTH_SHORT).show();cloud.repairProductImagesCloud(()->{repairImages.setEnabled(true);Toast.makeText(this,"تم فحص وضغط صور المنتجات التي تتجاوز 200KB",Toast.LENGTH_LONG).show();},()->{repairImages.setEnabled(true);Toast.makeText(this,"تعذر إكمال تنظيف الصور — تحقق من الإنترنت والصلاحيات",Toast.LENGTH_LONG).show();});});
            cloudCard.addView(repairImages,margin(-1,dp(50),0,dp(8)));
        }
        TextView status=text("",12,MUTED);status.setGravity(Gravity.CENTER);cloudCard.addView(status);
        Button logout=button("🚪 تسجيل الخروج");logout.setTextColor(RED);logout.setBackground(round(Color.rgb(254,239,239),Color.rgb(247,188,188),12,1));logout.setOnClickListener(v->confirmLogout());cloudCard.addView(logout,margin(-1,dp(50),0,0));
        refreshSync.run();
        String savedStatus=db.get("cloud_sync_last_status","");
        if("success".equals(savedStatus)){
            status.setText(cloud.lastSyncWarning==null||cloud.lastSyncWarning.isEmpty()?"آخر نتيجة: ✅ ناجحة":"آخر نتيجة: ⚠️ ناجحة مع ملاحظة: "+cloud.lastSyncWarning);
        }else if("error".equals(savedStatus)){
            String reason=cloud.lastSyncError==null||cloud.lastSyncError.isEmpty()?"تحقق من الإنترنت والصلاحيات":cloud.lastSyncError;
            status.setText("آخر نتيجة: ⚠️ فشلت\n"+reason);
        }else status.setText("آخر نتيجة: —");
        body.addView(cloudCard,margin(-1,-2,0,dp(10)));

        LinearLayout backup=card();
        TextView backupTitle=text("💾 النسخ الاحتياطي ونقل البيانات",17,TEXT);backupTitle.setTypeface(Typeface.DEFAULT,Typeface.BOLD);backupTitle.setGravity(Gravity.CENTER);backup.addView(backupTitle);
        TextView backupInfo=text("يمكنك حفظ المنتجات والزبائن والفواتير والمشتريات والأرباح وشركات الشحن مع صور المنتجات في ملف ZIP واحد، ثم استعادتها على هاتف آخر.",12,MUTED);backupInfo.setGravity(Gravity.CENTER);backup.addView(backupInfo);
        Button exportBtn=button("📤 تصدير النسخة الاحتياطية + الصور");exportBtn.setTextColor(Color.WHITE);exportBtn.setTextSize(15);exportBtn.setBackground(solid(BLUE,12));exportBtn.setOnClickListener(v->exportDatabase());
        Button importBtn=button("📥 استيراد النسخة الاحتياطية + الصور");importBtn.setTextColor(Color.WHITE);importBtn.setTextSize(15);importBtn.setBackground(solid(GREEN,12));importBtn.setOnClickListener(v->importDatabase());
        backup.addView(exportBtn,margin(-1,dp(50),0,dp(7)));backup.addView(importBtn,margin(-1,dp(50),0,0));
        body.addView(backup,margin(-1,-2,0,dp(10)));

        LinearLayout ship=card();
        TextView shipTitle=text("🚚 شركات الشحن وحسابات Store",17,TEXT);shipTitle.setTypeface(Typeface.DEFAULT,Typeface.BOLD);shipTitle.setGravity(Gravity.CENTER);ship.addView(shipTitle);
        ship.addView(text("يمكنك إضافة أي شركة شحن جديدة، ثم إضافة حسابات Store الخاصة بها. ستظهر تلقائياً داخل الفاتورة عند تفعيل الشحن.",12,MUTED));
        // أزرار إدارة شركات الشحن وحسابات Store: كل زر في سطر مستقل لمنع التداخل على الشاشات الصغيرة.
        LinearLayout actions=new LinearLayout(this);
        actions.setOrientation(LinearLayout.VERTICAL);
        actions.setGravity(Gravity.CENTER_HORIZONTAL);
        actions.setPadding(dp(2),dp(8),dp(2),dp(4));

        Button addCompany=button("🚚  إضافة شركة شحن");
        addCompany.setTextColor(Color.WHITE);
        addCompany.setTextSize(15);
        addCompany.setGravity(Gravity.CENTER);
        addCompany.setMinHeight(0);
        addCompany.setMinimumHeight(0);
        addCompany.setPadding(dp(12),0,dp(12),0);
        addCompany.setBackground(solid(BLUE,12));

        Button addAccount=button("🏪  إضافة حساب Store");
        addAccount.setTextColor(Color.WHITE);
        addAccount.setTextSize(15);
        addAccount.setGravity(Gravity.CENTER);
        addAccount.setMinHeight(0);
        addAccount.setMinimumHeight(0);
        addAccount.setPadding(dp(12),0,dp(12),0);
        addAccount.setBackground(solid(GREEN,12));

        LinearLayout.LayoutParams addButtonLp=new LinearLayout.LayoutParams(-1,dp(52));
        addButtonLp.setMargins(0,0,0,dp(8));
        actions.addView(addCompany,addButtonLp);

        LinearLayout.LayoutParams addAccountLp=new LinearLayout.LayoutParams(-1,dp(52));
        actions.addView(addAccount,addAccountLp);

        LinearLayout.LayoutParams actionsLp=new LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT); actionsLp.setMargins(0,dp(8),0,dp(8)); ship.addView(actions,actionsLp);
        LinearLayout shipList=new LinearLayout(this);shipList.setOrientation(LinearLayout.VERTICAL);ship.addView(shipList);
        body.addView(ship,margin(-1,-2,0,dp(10)));

        final Runnable[] refreshShippingSettings = new Runnable[1];
        refreshShippingSettings[0]=()->{
            shipList.removeAllViews();
            ArrayList<Store.ShippingCompany> companies=db.shippingCompanies();
            if(companies.isEmpty()){
                TextView empty=text("لا توجد شركات شحن حالياً. أضف شركة شحن من الزر أعلاه.",13,MUTED);
                empty.setGravity(Gravity.CENTER);
                shipList.addView(empty,new LinearLayout.LayoutParams(-1,dp(52)));
            }
            for(Store.ShippingCompany co:companies){
                LinearLayout companyRow=new LinearLayout(this);companyRow.setOrientation(LinearLayout.VERTICAL);companyRow.setPadding(dp(10),dp(8),dp(10),dp(8));companyRow.setBackground(round(Color.rgb(249,251,255),BORDER,10,1));
                LinearLayout topRow=new LinearLayout(this);topRow.setGravity(Gravity.CENTER_VERTICAL);
                TextView ct=text("🏢 "+co.name,15,TEXT);ct.setTypeface(Typeface.DEFAULT,Typeface.BOLD);topRow.addView(ct,new LinearLayout.LayoutParams(0,dp(42),1));
                Button editCompany=button("تعديل");editCompany.setTextColor(BLUE);topRow.addView(editCompany,new LinearLayout.LayoutParams(dp(72),dp(42)));
                Button delCompany=button("حذف");delCompany.setTextColor(RED);topRow.addView(delCompany,new LinearLayout.LayoutParams(dp(72),dp(42)));companyRow.addView(topRow);
                editCompany.setOnClickListener(v->{
                    EditText n=input("اسم شركة الشحن");n.setText(co.name);
                    new AlertDialog.Builder(this).setTitle("تعديل شركة الشحن").setView(n).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",(d,w)->{String x=n.getText().toString().trim();if(x.isEmpty()){Toast.makeText(this,"أدخل اسم الشركة",Toast.LENGTH_SHORT).show();return;}if(db.updateShippingCompany(co.id,x)){refreshShippingSettings[0].run();}else Toast.makeText(this,"تعذر تعديل الشركة",Toast.LENGTH_SHORT).show();}).show();
                });
                for(Store.ShippingAccount ac:db.shippingAccounts(co.id)){
                    LinearLayout ar=new LinearLayout(this);ar.setGravity(Gravity.CENTER_VERTICAL);ar.setPadding(dp(5),dp(2),dp(5),dp(2));
                    TextView at=text("🏪 "+ac.name,13,MUTED);ar.addView(at,new LinearLayout.LayoutParams(0,dp(38),1));
                    Button ea=button("تعديل");ea.setTextColor(BLUE);ar.addView(ea,new LinearLayout.LayoutParams(dp(70),dp(38)));
                    Button da=button("حذف");da.setTextColor(RED);ar.addView(da,new LinearLayout.LayoutParams(dp(70),dp(38)));
                    ea.setOnClickListener(v->{
                        ArrayList<Store.ShippingCompany> cs=db.shippingCompanies();
                        LinearLayout wrap=new LinearLayout(this);wrap.setOrientation(LinearLayout.VERTICAL);wrap.setPadding(dp(8),dp(4),dp(8),dp(4));
                        Spinner company=new Spinner(this);ArrayList<String> names=new ArrayList<>();for(Store.ShippingCompany x:cs)names.add(x.name);ArrayAdapter<String> ca=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,names);ca.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);company.setAdapter(ca);
                        int selected=0;for(int j=0;j<cs.size();j++)if(cs.get(j).id==co.id)selected=j;company.setSelection(selected);
                        EditText account=input("اسم الحساب Store");account.setText(ac.name);wrap.addView(company);wrap.addView(account,margin(-1,dp(48),0,0));
                        new AlertDialog.Builder(this).setTitle("تعديل حساب Store").setView(wrap).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",(d,w)->{String x=account.getText().toString().trim();int pos=company.getSelectedItemPosition();if(x.isEmpty()){Toast.makeText(this,"أدخل اسم الحساب",Toast.LENGTH_SHORT).show();return;}if(pos>=0&&db.updateShippingAccount(ac.id,cs.get(pos).id,x))refreshShippingSettings[0].run();else Toast.makeText(this,"تعذر تعديل الحساب أو الاسم موجود مسبقاً",Toast.LENGTH_SHORT).show();}).show();
                    });
                    da.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف حساب Store").setMessage("هل تريد حذف الحساب "+ac.name+"؟").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(d,w)->{db.deleteShippingAccount(ac.id);refreshShippingSettings[0].run();}).show());companyRow.addView(ar);
                }
                delCompany.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف شركة الشحن").setMessage("سيتم حذف الشركة وحساباتها من قائمة الاختيار. الفواتير القديمة ستحتفظ بالمعلومات المسجلة فيها.\n\nهل تريد المتابعة؟").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(d,w)->{db.deleteShippingCompany(co.id);refreshShippingSettings[0].run();}).show());
                shipList.addView(companyRow,margin(-1,ViewGroup.LayoutParams.WRAP_CONTENT,0,dp(8)));
            }
        };
        addCompany.setOnClickListener(v->{
            EditText n=input("اسم شركة الشحن الجديدة");
            new AlertDialog.Builder(this).setTitle("إضافة شركة شحن").setView(n).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",(d,w)->{String x=n.getText().toString().trim();if(x.isEmpty()){Toast.makeText(this,"أدخل اسم الشركة",Toast.LENGTH_SHORT).show();return;}if(db.addShippingCompany(x)==-1)Toast.makeText(this,"هذه الشركة موجودة مسبقاً",Toast.LENGTH_SHORT).show();refreshShippingSettings[0].run();}).show();
        });
        addAccount.setOnClickListener(v->{
            ArrayList<Store.ShippingCompany> cs=db.shippingCompanies();if(cs.isEmpty()){Toast.makeText(this,"أضف شركة شحن أولاً",Toast.LENGTH_SHORT).show();return;}
            LinearLayout wrap=new LinearLayout(this);wrap.setOrientation(LinearLayout.VERTICAL);wrap.setPadding(dp(8),dp(4),dp(8),dp(4));
            Spinner company=new Spinner(this);ArrayList<String> names=new ArrayList<>();for(Store.ShippingCompany x:cs)names.add(x.name);ArrayAdapter<String> ca=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,names);ca.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);company.setAdapter(ca);
            EditText account=input("اسم الحساب مثل Store MGE02");wrap.addView(company);wrap.addView(account,margin(-1,dp(48),0,0));
            new AlertDialog.Builder(this).setTitle("إضافة حساب Store").setView(wrap).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",(d,w)->{String x=account.getText().toString().trim();if(x.isEmpty()){Toast.makeText(this,"أدخل اسم الحساب",Toast.LENGTH_SHORT).show();return;}int pos=company.getSelectedItemPosition();if(pos>=0&&db.addShippingAccount(cs.get(pos).id,x)==-1)Toast.makeText(this,"هذا الحساب موجود لهذه الشركة",Toast.LENGTH_SHORT).show();refreshShippingSettings[0].run();}).show();
        });
        refreshShippingSettings[0].run();
        body.addView(text("سيظهر اسم الشركة ورقم الهاتف في ملف PDF.",13,MUTED));
    }

    /**
     * Creates the invoice PDF only.
     *
     * The invoice PDF intentionally contains NO product images. This keeps
     * the file small and fast to share with the customer/partner.
     * Product photos are exported separately by makeProductPhotosPdf().
     */
    /**
     * إنشاء PDF الفاتورة مع دعم عدد غير محدود من الصفحات.
     * يحافظ على نفس التصميم، ويكمل منتجات الفاتورة تلقائياً في صفحات إضافية
     * بدل قصّ المنتجات التي تتجاوز الصفحة الأولى.
     */
    void buildInvoiceOnlyPdf(Store.Invoice inv){
        if(inv==null)return;

        final int pageW=595, pageH=842;
        final int left=40, right=555;
        final int firstRowsTop=388;
        final int continuationRowsTop=115;
        final int bottomRows=735;

        PdfDocument doc=new PdfDocument();
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        PdfDocument.Page page=null;
        Canvas c=null;
        int pageNo=0;
        int y=0;
        double total=0;

        try{
            // الصفحة الأولى: نفس رأس الفاتورة الحالي.
            page=doc.startPage(new PdfDocument.PageInfo.Builder(pageW,pageH,++pageNo).create());
            c=page.getCanvas();
            p.setColor(Color.WHITE); c.drawPaint(p);
            drawInvoiceHeader(c,p,inv);
            y=drawInvoiceTableHeader(c,p,firstRowsTop);

            p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT);p.setTextSize(11);

            if(inv.items!=null){
                for(Store.Item it:inv.items){
                    // قبل رسم المنتج، تأكد أن هناك مساحة كافية.
                    // نترك مساحة مناسبة في آخر الصفحة للملخص، لكن الملخص
                    // لا يرسم إلا في الصفحة الأخيرة.
                    if(y>bottomRows){
                        doc.finishPage(page);
                        page=doc.startPage(new PdfDocument.PageInfo.Builder(pageW,pageH,++pageNo).create());
                        c=page.getCanvas();
                        p.setColor(Color.WHITE);c.drawPaint(p);
                        drawInvoiceContinuationHeader(c,p,inv,pageNo);
                        y=drawInvoiceTableHeader(c,p,continuationRowsTop);
                    }

                    double lineTotal=it.salePrice*it.qty;
                    total+=lineTotal;
                    p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT);p.setTextSize(11);
                    c.drawText(trim(it.name,31),48,y,p);
                    c.drawText(""+it.qty,270,y,p);
                    c.drawText(money(it.salePrice),390,y,p);
                    c.drawText(money(lineTotal),490,y,p);
                    y+=31;
                    p.setColor(BORDER);c.drawLine(left,y-15,right,y-15,p);
                    p.setColor(TEXT);
                }
            }

            // إذا كانت الفاتورة طويلة جداً، ضع الملخص في صفحة مستقلة.
            int summaryNeeded=inv.shippingEnabled?245:215;
            if(y+summaryNeeded>805){
                doc.finishPage(page);
                page=doc.startPage(new PdfDocument.PageInfo.Builder(pageW,pageH,++pageNo).create());
                c=page.getCanvas();
                p.setColor(Color.WHITE);c.drawPaint(p);
                drawInvoiceContinuationHeader(c,p,inv,pageNo);
                y=95;
            }

            if(inv.shippingEnabled){
                p.setColor(BLUE);p.setTypeface(Typeface.DEFAULT);p.setTextSize(11);
                c.drawText("Frais de livraison / مصاريف الشحن",300,y+12,p);
                c.drawText(money(inv.shippingCharge)+" DH",490,y+12,p);
                y+=34;
                total+=inv.shippingCharge;
            }

            // ملخص الفاتورة في آخر صفحة: كل عنصر في سطر مستقل لتجنب
            // خروج النص العربي/الفرنسي والأرقام خارج حدود الصفحة.
            p.setTypeface(Typeface.DEFAULT_BOLD);p.setColor(TEXT);p.setTextSize(12);
            double grossTotal=total;
            double advance=Math.max(0,Math.min(inv.advancePayment,grossTotal));
            double amountDue=Math.max(0,grossTotal-advance);
            drawCenteredPdfText(c,p,"TOTAL FACTURE / إجمالي الفاتورة",y+18,12,TEXT);
            drawCenteredPdfText(c,p,money(grossTotal)+" DH",y+40,16,TEXT);
            if(advance>0){
                drawCenteredPdfText(c,p,"Acompte / التسبيق",y+62,11,GREEN);
                drawCenteredPdfText(c,p,"- "+money(advance)+" DH",y+82,13,GREEN);
                drawCenteredPdfText(c,p,"À payer à la livraison / المبلغ عند الاستلام",y+104,11,BLUE);
                drawCenteredPdfText(c,p,money(amountDue)+" DH",y+126,16,BLUE);
                if(inv.advancePaymentDate!=null&&!inv.advancePaymentDate.isEmpty())
                    drawCenteredPdfText(c,p,"Date acompte / تاريخ التسبيق : "+safe(inv.advancePaymentDate),y+145,9,MUTED);
            }else{
                drawCenteredPdfText(c,p,"À payer à la livraison / المبلغ عند الاستلام",y+64,11,BLUE);
                drawCenteredPdfText(c,p,money(amountDue)+" DH",y+86,16,BLUE);
            }

            if(inv.partnerId>0){
                int py=advance>0?y+164:y+104;
                drawCenteredPdfText(c,p,"Partner profit / ربح الشريك : "+money(inv.commission)+" DH",py,10,TEXT);
                if(inv.partnerProfitPaid) drawCenteredPdfText(c,p,"Profit paid / تم دفع الربح : "+safe(inv.partnerProfitPaidDate),py+18,9,MUTED);
            }

            drawCenteredPdfText(c,p,db.get("footer","Merci pour votre confiance"),y+(advance>0?196:126),11,TEXT);

            doc.finishPage(page);page=null;

            ByteArrayOutputStream buffer=new ByteArrayOutputStream();
            doc.writeTo(buffer);doc.close();
            byte[] pdfBytes=buffer.toByteArray();
            String fileName="Facture_"+inv.id+".pdf";
            Uri uri=savePdfToDownloads(pdfBytes,fileName);

            Intent share=new Intent(Intent.ACTION_SEND);
            share.setType("application/pdf");
            share.putExtra(Intent.EXTRA_STREAM,uri);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            share.setClipData(ClipData.newRawUri("PDF",uri));
            startActivity(Intent.createChooser(share,"إرسال الفاتورة PDF"));
            Toast.makeText(this,"تم حفظ الفاتورة كاملة في Download/FactureSimple ("+pageNo+" صفحة)",Toast.LENGTH_LONG).show();
        }catch(Exception e){
            try{if(page!=null)doc.finishPage(page);}catch(Exception ignored){}
            try{doc.close();}catch(Exception ignored){}
            Toast.makeText(this,"خطأ PDF: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    void drawCenteredPdfText(Canvas c,Paint p,String value,float y,float size,int color){
        String s=value==null?"":value;
        p.setTypeface(Typeface.DEFAULT);p.setTextSize(size);p.setColor(color);
        float x=(595f-p.measureText(s))/2f;
        x=Math.max(40f,Math.min(x,555f-p.measureText(s)));
        c.drawText(s,x,y,p);
    }

    /** رأس خفيف للصفحات الإضافية مع الحفاظ على هوية الفاتورة. */
    void drawInvoiceContinuationHeader(Canvas c,Paint p,Store.Invoice inv,int pageNo){
        p.setColor(Color.BLACK);
        c.drawRect(40,25,125,68,p);
        p.setColor(Color.WHITE);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(19);
        c.drawText("MGE",62,53,p);

        p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(15);
        c.drawText("FACTURE / فاتورة #"+invoiceNo(inv),145,52,p);
        p.setTypeface(Typeface.DEFAULT);p.setTextSize(10);p.setColor(MUTED);
        c.drawText("Client : "+safe(inv.client)+"   •   Page "+pageNo,pixelSafeX(410),52,p);
    }

    // يحافظ على موضع النص ضمن عرض الصفحة في رأس الصفحات الإضافية.
    int pixelSafeX(int preferred){
        return Math.min(preferred,420);
    }

    void makePdf(int id){
        final Store.Invoice inv=db.invoice(id);
        if(inv==null)return;
        Toast.makeText(this,"جاري إنشاء فاتورة PDF…",Toast.LENGTH_SHORT).show();
        // For partner invoices, refresh the partner contact from Firebase first.
        // This guarantees that the PDF uses the phone entered in إدارة الشركاء,
        // not a stale local value (such as the partner email).
        if(inv.partnerId>0 && cloud!=null && cloud.isAdmin()){
            cloud.refreshPartnerContactForInvoice(inv.partnerId,
                () -> buildInvoiceOnlyPdf(db.invoice(id)),
                () -> buildInvoiceOnlyPdf(db.invoice(id)));
        }else{
            buildInvoiceOnlyPdf(inv);
        }
    }

    /**
     * PDF الشريك = ألبوم صور المنتجات الخاصة بالشريك فقط.
     * لا يحتوي على أرباح أو بيانات مالية.
     */
    void makePartnerInvoicePdf(int id){
        makeInvoicePhotosPdf(id,true);
    }

    /**
     * PDF صور الزبائن = صور المنتجات الرسمية التي نعرضها نحن.
     * PDF الشريك = صور customer_image التي يضعها الشريك.
     */
    void makeProductPhotosPdf(int id){
        makeInvoicePhotosPdf(id,false);
    }

    void makeInvoicePhotosPdf(int id, boolean partnerImages){
        final Store.Invoice inv=db.invoice(id);
        if(inv==null)return;
        final java.util.ArrayList<Store.Item> items =
                inv.items==null ? new java.util.ArrayList<Store.Item>() : inv.items;
        if(items.isEmpty()){
            Toast.makeText(this,"لا توجد منتجات في هذه الفاتورة",Toast.LENGTH_SHORT).show();
            return;
        }
        if(partnerImages && inv.partnerId<=0){
            Toast.makeText(this,"هذه الفاتورة ليست مرتبطة بشريك",Toast.LENGTH_SHORT).show();
            return;
        }

        final String title=partnerImages ? "صور منتجات الشريك / Partner Photos" : "Photos clients / صور الزبائن";
        Toast.makeText(this,partnerImages?"جاري تجهيز PDF صور الشريك…":"جاري تجهيز PDF صور المنتجات…",Toast.LENGTH_SHORT).show();

        final java.util.HashMap<Integer,Bitmap> images=new java.util.HashMap<Integer,Bitmap>();
        final int[] remaining={items.size()};

        for(int index=0;index<items.size();index++){
            final int itemIndex=index;
            final Store.Item item=items.get(index);
            final Store.Product product=db.product(item.productId);
            String imageRef="";

            if(partnerImages){
                Store.PartnerProductSetting ps=db.partnerProductSetting(inv.partnerId,item.productId);
                if(ps!=null) imageRef=safe(ps.customerImage).trim();
            }else{
                imageRef=product==null?"":safe(product.image).trim();
            }

            if(imageRef.isEmpty()){
                if(--remaining[0]==0)buildInvoicePhotosPdf(inv,items,images,partnerImages,title);
                continue;
            }

            loadPdfBitmap(imageRef,dp(520),dp(360),new PdfBitmapCallback(){
                @Override public void onLoaded(Bitmap bitmap){
                    if(bitmap!=null)images.put(itemIndex,bitmap);
                    if(--remaining[0]==0)buildInvoicePhotosPdf(inv,items,images,partnerImages,title);
                }
            });
        }
    }

    interface PdfBitmapCallback { void onLoaded(Bitmap bitmap); }

    /**
     * تحميل الصورة بطريقة موثوقة للـ PDF.
     * الصور المحلية (file:// و content:// والمسارات المباشرة) تُقرأ مباشرة
     * بدلاً من الاعتماد على Glide، لأن Glide قد لا يعيد Bitmap لبعض URI
     * الخاصة بالتطبيق بعد الاستعادة أو على Android 10.
     */
    void loadPdfBitmap(String imageRef,int maxW,int maxH,PdfBitmapCallback callback){
        final String ref=safe(imageRef).trim();
        if(ref.isEmpty()){callback.onLoaded(null);return;}

        try{
            Uri uri=Uri.parse(ref);
            String scheme=uri.getScheme()==null?"":uri.getScheme().toLowerCase(Locale.US);

            if("file".equals(scheme)){
                String path=uri.getPath();
                Bitmap b=decodeLocalBitmap(path,maxW,maxH);
                if(b!=null){callback.onLoaded(b);return;}
            }else if("content".equals(scheme)){
                Bitmap b=decodeContentBitmap(uri,maxW,maxH);
                if(b!=null){callback.onLoaded(b);return;}
            }else if(scheme.isEmpty()){
                Bitmap b=decodeLocalBitmap(ref,maxW,maxH);
                if(b!=null){callback.onLoaded(b);return;}
            }
        }catch(Exception ignored){}

        // Fallback for remote URLs and any URI that could not be decoded directly.
        try{
            com.bumptech.glide.Glide.with(this).asBitmap().load(ref).override(maxW,maxH).into(new CustomTarget<Bitmap>(){
                boolean delivered=false;
                void done(Bitmap b){if(delivered)return;delivered=true;callback.onLoaded(b);}
                @Override public void onResourceReady(Bitmap bitmap,Transition<? super Bitmap> transition){done(bitmap);}
                @Override public void onLoadCleared(Drawable placeholder){ }
                @Override public void onLoadFailed(Drawable errorDrawable){done(null);}
            });
        }catch(Exception e){callback.onLoaded(null);}
    }

    Bitmap decodeLocalBitmap(String path,int maxW,int maxH){
        if(path==null||path.trim().isEmpty())return null;
        File f=new File(path);
        if(!f.exists()||!f.isFile())return null;
        BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;
        BitmapFactory.decodeFile(f.getAbsolutePath(),bounds);
        if(bounds.outWidth<=0||bounds.outHeight<=0)return null;
        BitmapFactory.Options opts=new BitmapFactory.Options();opts.inSampleSize=sampleFor(bounds.outWidth,bounds.outHeight,maxW,maxH);opts.inPreferredConfig=Bitmap.Config.ARGB_8888;
        return BitmapFactory.decodeFile(f.getAbsolutePath(),opts);
    }

    Bitmap decodeContentBitmap(Uri uri,int maxW,int maxH)throws IOException{
        BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;
        try(InputStream in=getContentResolver().openInputStream(uri)){
            if(in==null)return null;BitmapFactory.decodeStream(in,null,bounds);
        }
        if(bounds.outWidth<=0||bounds.outHeight<=0)return null;
        BitmapFactory.Options opts=new BitmapFactory.Options();opts.inSampleSize=sampleFor(bounds.outWidth,bounds.outHeight,maxW,maxH);opts.inPreferredConfig=Bitmap.Config.ARGB_8888;
        try(InputStream in=getContentResolver().openInputStream(uri)){
            if(in==null)return null;return BitmapFactory.decodeStream(in,null,opts);
        }
    }

    int sampleFor(int w,int h,int maxW,int maxH){
        int sample=1;
        while(w/sample>maxW*2 || h/sample>maxH*2)sample*=2;
        return Math.max(1,sample);
    }

    void buildInvoicePhotosPdf(Store.Invoice inv,java.util.ArrayList<Store.Item> items,
                               java.util.HashMap<Integer,Bitmap> images,boolean partnerImages,String title){
        PdfDocument doc=new PdfDocument();
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        int pageNo=0;PdfDocument.Page page=null;Canvas c=null;int y=0;
        final int pageW=595,pageH=842;
        try{
            page=doc.startPage(new PdfDocument.PageInfo.Builder(pageW,pageH,++pageNo).create());
            c=page.getCanvas();p.setColor(Color.WHITE);c.drawPaint(p);
            y=55;
            p.setColor(partnerImages?GREEN:BLUE);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(18);
            c.drawText(title,40,y,p);
            p.setColor(MUTED);p.setTypeface(Typeface.DEFAULT);p.setTextSize(10);
            c.drawText("Facture N° "+invoiceNo(inv)+"  •  Produit + quantité",40,y+22,p);
            y+=48;

            final int cardW=255,cardH=190,gapX=15,gapY=14;
            for(int i=0;i<items.size();i++){
                if(y+cardH>810){
                    doc.finishPage(page);
                    page=doc.startPage(new PdfDocument.PageInfo.Builder(pageW,pageH,++pageNo).create());
                    c=page.getCanvas();p.setColor(Color.WHITE);c.drawPaint(p);
                    p.setColor(partnerImages?GREEN:BLUE);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(15);
                    c.drawText(title,40,35,p);y=58;
                }

                int col=i%2;
                int x=40+col*(cardW+gapX);
                int rowY=y;
                p.setColor(Color.rgb(250,251,253));c.drawRoundRect(x,rowY,x+cardW,rowY+cardH,10,10,p);
                p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);p.setColor(BORDER);
                c.drawRoundRect(x,rowY,x+cardW,rowY+cardH,10,10,p);p.setStyle(Paint.Style.FILL);

                Bitmap bm=images.get(i);
                int imgLeft=x+10,imgTop=rowY+10,imgRight=x+245,imgBottom=rowY+125;
                p.setColor(Color.WHITE);c.drawRect(imgLeft,imgTop,imgRight,imgBottom,p);
                if(bm!=null&&!bm.isRecycled()){
                    Rect src=new Rect(0,0,bm.getWidth(),bm.getHeight());
                    RectF dst=fitBitmapRect(bm,imgLeft,imgTop,imgRight,imgBottom);
                    c.drawBitmap(bm,src,dst,p);
                }else{
                    p.setColor(MUTED);p.setTypeface(Typeface.DEFAULT);p.setTextSize(9);
                    c.drawText(partnerImages?"Image partenaire indisponible / لا توجد صورة الشريك":"Image non disponible / لا توجد صورة",imgLeft+18,imgTop+58,p);
                }

                Store.Item it=items.get(i);
                p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(10);
                c.drawText(trim(it.name,42),x+12,rowY+147,p);
                p.setTypeface(Typeface.DEFAULT);p.setTextSize(12);
                c.drawText("Qté / الكمية : "+it.qty,x+12,rowY+170,p);

                if(col==1 || i==items.size()-1)y+=cardH+gapY;
            }
            doc.finishPage(page);page=null;
            String fileName=(partnerImages?"Partner_Photos_Facture_":"Photos_Facture_")+inv.id+".pdf";
            saveAndSharePdfDocument(doc,fileName,partnerImages?"إرسال PDF صور الشريك":"إرسال PDF صور الزبائن");
        }catch(Exception e){
            try{if(page!=null)doc.finishPage(page);}catch(Exception ignored){}
            try{doc.close();}catch(Exception ignored){}
            Toast.makeText(this,"خطأ PDF الصور: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    void saveAndSharePdfDocument(PdfDocument doc,String fileName,String chooserTitle)throws Exception{
        ByteArrayOutputStream buffer=new ByteArrayOutputStream();
        doc.writeTo(buffer);doc.close();
        byte[] pdfBytes=buffer.toByteArray();
        Uri uri=savePdfToDownloads(pdfBytes,fileName);
        Intent share=new Intent(Intent.ACTION_SEND);
        share.setType("application/pdf");
        share.putExtra(Intent.EXTRA_STREAM,uri);
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        share.setClipData(ClipData.newRawUri("PDF",uri));
        startActivity(Intent.createChooser(share,chooserTitle));
    }

    void drawInvoiceHeader(Canvas c,Paint p,Store.Invoice inv){
        p.setColor(Color.BLACK);
        c.drawRect(40,35,145,90,p);
        p.setColor(Color.WHITE);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(25);
        c.drawText("MGE",66,71,p);

        p.setColor(TEXT);p.setTextSize(21);
        c.drawText("FACTURE / فاتورة",305,65,p);
        p.setTypeface(Typeface.DEFAULT);p.setTextSize(12);
        c.drawText("Tel : "+db.get("phone","+212666964731"),40,110,p);
        c.drawText("N° : "+invoiceNo(inv),40,132,p);
        c.drawText("Date : "+inv.date,40,154,p);
        c.drawText("Client : "+inv.client,40,176,p);

        String invoicePhone=safe(inv.customerPhone);
        String invoiceCity=safe(inv.customerCity);
        String invoiceAddress=safe(inv.customerAddress);
        if(invoicePhone.isEmpty()&&inv.clientId>0){
            Store.Customer cu=db.customer(inv.clientId);
            if(cu!=null){
                invoicePhone=safe(cu.phone);
                invoiceCity=safe(cu.city);
                invoiceAddress=safe(cu.address);
            }
        }
        c.drawText("Tel : "+invoicePhone,300,176,p);
        c.drawText("Ville : "+invoiceCity,40,196,p);
        c.drawText("Adresse : "+invoiceAddress,300,196,p);

        if(inv.partnerId>0){
            Store.Customer partner=db.partnerAccountCustomer(inv.partnerId);
            if(partner!=null){
                p.setColor(BLUE);p.setTypeface(Typeface.DEFAULT_BOLD);
                c.drawText("Commercial "+safe(partner.name),40,218,p);
                if(!safe(partner.phone).isEmpty()) c.drawText("Tel : "+safe(partner.phone),300,218,p);
            }
        }

        p.setColor(inv.paid?GREEN:RED);p.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText(inv.paid?"Statut : PAYÉE / مدفوعة":"Statut : NON PAYÉE / غير مدفوعة",40,244,p);

        if(inv.paid&&inv.paidDate!=null&&!inv.paidDate.isEmpty()){
            p.setColor(GREEN);p.setTypeface(Typeface.DEFAULT);
            c.drawText("Date de paiement / تاريخ الدفع : "+inv.paidDate,300,244,p);
        }

        if(inv.trackingNumber!=null&&!inv.trackingNumber.isEmpty()){
            p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT);
            c.drawText("Suivi / التتبع : "+inv.trackingNumber+" • "+
                    (inv.deliveryReceived?"REÇU / تم الاستلام":"NON REÇU / لم يتم الاستلام"),300,264,p);
        }

        if(inv.shippingEnabled&&inv.shippingCompany!=null&&!inv.shippingCompany.isEmpty()){
            p.setColor(BLUE);p.setTypeface(Typeface.DEFAULT);
            String carrierLine="Expédition / شركة الشحن : "+safe(inv.shippingCompany);
            if(inv.trackingNumber!=null&&!inv.trackingNumber.trim().isEmpty())
                carrierLine+=" • N° suivi / رقم التتبع : "+safe(inv.trackingNumber);
            c.drawText(carrierLine,40,284,p);
        }

        if(inv.deliveryReceived&&inv.deliveryReceivedDate!=null&&!inv.deliveryReceivedDate.isEmpty()){
            c.drawText("Date réception / تاريخ الاستلام : "+inv.deliveryReceivedDate,40,304,p);
        }
        if(!inv.deliveryReceived&&inv.deliveryFailureReason!=null&&!inv.deliveryFailureReason.isEmpty()){
            p.setColor(RED);
            c.drawText("Cause / سبب عدم الاستلام : "+inv.deliveryFailureReason,40,304,p);
        }
    }

    int drawInvoiceTableHeader(Canvas c,Paint p,int y){
        p.setColor(BLUE);
        c.drawRect(40,y-15,555,y+21,p);
        p.setColor(Color.WHITE);p.setTextSize(11);p.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText("Produit / البيان",48,y+8,p);
        c.drawText("Qté",270,y+8,p);
        c.drawText("Prix",390,y+8,p);
        c.drawText("Total",490,y+8,p);
        p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT);
        return y+48;
    }

    RectF fitBitmapRect(Bitmap bm,int left,int top,int right,int bottom){
        float boxW=right-left,boxH=bottom-top;
        float scale=Math.min(boxW/bm.getWidth(),boxH/bm.getHeight());
        float w=bm.getWidth()*scale,h=bm.getHeight()*scale;
        float x=left+(boxW-w)/2f,y=top+(boxH-h)/2f;
        return new RectF(x,y,x+w,y+h);
    }

    void watch(EditText e,final Runnable r){e.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){r.run();}public void afterTextChanged(Editable e){}});}
    void loadImage(ImageView v,String uri){
        try{
            if(uri==null||uri.isEmpty()){v.setImageResource(R.drawable.ic_product);return;}
            com.bumptech.glide.Glide.with(this).load(uri).placeholder(R.drawable.ic_product).error(R.drawable.ic_product).into(v);
        }catch(Exception e){v.setImageResource(R.drawable.ic_product);}
    }

    boolean isZipFile(File f)throws IOException{
        try(FileInputStream in=new FileInputStream(f)){int a=in.read(),b=in.read();return a==0x50&&b==0x4b;}
    }

    void createBackupZip(File target)throws IOException{
        compressAllLocalProductImages();
        File dbFile=getDatabasePath("facturesimple.db");
        if(!dbFile.exists())throw new IOException("قاعدة البيانات غير موجودة");
        try(ZipOutputStream zos=new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(target)))){
            addFileToZip(zos,dbFile,"facturesimple.db");
            File images=new File(getFilesDir(),"product_images");
            if(images.exists())addDirectoryToZip(zos,images,"product_images");
            ZipEntry manifest=new ZipEntry("backup_info.txt"); zos.putNextEntry(manifest);
            String info="MGE Backup\nVersion: 3.8.6\nDatabase: facturesimple.db\nImages: product_images/\n";
            zos.write(info.getBytes(java.nio.charset.StandardCharsets.UTF_8)); zos.closeEntry();
        }
    }

    void addFileToZip(ZipOutputStream zos,File file,String entryName)throws IOException{
        ZipEntry e=new ZipEntry(entryName); zos.putNextEntry(e);
        try(InputStream in=new BufferedInputStream(new FileInputStream(file))){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)zos.write(b,0,n);} zos.closeEntry();
    }

    void addDirectoryToZip(ZipOutputStream zos,File dir,String prefix)throws IOException{
        File[] files=dir.listFiles(); if(files==null)return;
        for(File f:files){String name=prefix+"/"+f.getName(); if(f.isDirectory())addDirectoryToZip(zos,f,name);else addFileToZip(zos,f,name);}
    }

    void extractBackupZip(File zip,File dbOut,File imagesOut)throws IOException{
        boolean dbFound=false;
        try(ZipInputStream zis=new ZipInputStream(new BufferedInputStream(new FileInputStream(zip)))){
            ZipEntry e;
            byte[] b=new byte[8192];
            while((e=zis.getNextEntry())!=null){
                String name=e.getName().replace('\\','/');
                if(name.startsWith("/")||name.contains("../")||name.contains("..\\"))throw new IOException("ملف ZIP غير آمن");
                if(e.isDirectory()){zis.closeEntry();continue;}
                File out=null;
                if(name.equals("facturesimple.db")) {out=dbOut;dbFound=true;}
                else if(name.startsWith("product_images/") && name.length()>15){out=new File(imagesOut,name.substring("product_images/".length()));}
                else {zis.closeEntry();continue;}
                File parent=out.getParentFile();if(parent!=null&&!parent.exists())parent.mkdirs();
                try(OutputStream os=new BufferedOutputStream(new FileOutputStream(out))){int n;while((n=zis.read(b))!=-1)os.write(b,0,n);}
                zis.closeEntry();
            }
        }
        if(!dbFound)throw new IOException("النسخة ZIP لا تحتوي على facturesimple.db");
    }

    void validateDatabaseFile(File incoming)throws IOException{
        android.database.sqlite.SQLiteDatabase test=null;
        try{
            test=android.database.sqlite.SQLiteDatabase.openDatabase(incoming.getAbsolutePath(),null,android.database.sqlite.SQLiteDatabase.OPEN_READONLY);
            Cursor c=test.rawQuery("SELECT name FROM sqlite_master WHERE type='table'",null);boolean valid=false;
            while(c.moveToNext())if("products".equals(c.getString(0))){valid=true;break;} c.close();
            if(!valid)throw new IOException("هذا الملف ليس نسخة MGE صحيحة");
        }finally{if(test!=null)test.close();}
    }

    void copyDirectory(File source,File target)throws IOException{
        if(!target.exists()&&!target.mkdirs())throw new IOException("تعذر إنشاء مجلد الصور");
        File[] files=source.listFiles();if(files==null)return;
        for(File f:files){File out=new File(target,f.getName());if(f.isDirectory())copyDirectory(f,out);else copyFile(f,out);}
    }

    void deleteRecursively(File f){
        if(f==null||!f.exists())return;File[] files=f.listFiles();if(files!=null)for(File x:files)deleteRecursively(x);f.delete();
    }

    static final int MAX_PRODUCT_IMAGE_BYTES = 200 * 1024;

    String copyImageToApp(Uri uri)throws IOException{
        File dir=new File(getFilesDir(),"product_images");if(!dir.exists()&&!dir.mkdirs())throw new IOException("تعذر إنشاء مجلد الصور");
        BitmapFactory.Options bounds=new BitmapFactory.Options(); bounds.inJustDecodeBounds=true;
        try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new IOException("تعذر قراءة الصورة");BitmapFactory.decodeStream(in,null,bounds);}
        if(bounds.outWidth<=0||bounds.outHeight<=0)throw new IOException("الصورة غير صالحة");
        int sample=1,maxDim=Math.max(bounds.outWidth,bounds.outHeight);while(maxDim/sample>1600)sample*=2;
        BitmapFactory.Options opts=new BitmapFactory.Options();opts.inSampleSize=sample;Bitmap bmp;
        try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new IOException("تعذر قراءة الصورة");bmp=BitmapFactory.decodeStream(in,null,opts);}
        if(bmp==null)throw new IOException("تعذر فك الصورة");
        File out=new File(dir,"img_"+System.currentTimeMillis()+".jpg");
        try{
            int w=bmp.getWidth(),h=bmp.getHeight();
            boolean saved=false;
            for(int pass=0;pass<12&&!saved;pass++){
                int q=Math.max(25,85-(pass%7)*10);ByteArrayOutputStream bos=new ByteArrayOutputStream();bmp.compress(Bitmap.CompressFormat.JPEG,q,bos);byte[] data=bos.toByteArray();
                if(data.length<=MAX_PRODUCT_IMAGE_BYTES){try(FileOutputStream os=new FileOutputStream(out)){os.write(data);}saved=true;break;}
                if(pass==6||pass==11){Bitmap smaller=Bitmap.createScaledBitmap(bmp,Math.max(320,(int)(w*0.8f)),Math.max(320,(int)(h*0.8f)),true);if(smaller!=bmp)bmp.recycle();bmp=smaller;w=bmp.getWidth();h=bmp.getHeight();}
            }
            if(!saved){ByteArrayOutputStream bos=new ByteArrayOutputStream();bmp.compress(Bitmap.CompressFormat.JPEG,25,bos);byte[] data=bos.toByteArray();try(FileOutputStream os=new FileOutputStream(out)){os.write(data);}if(out.length()>MAX_PRODUCT_IMAGE_BYTES){out.delete();throw new IOException("تعذر ضغط الصورة إلى أقل من 200KB");}}
        }finally{bmp.recycle();}
        return Uri.fromFile(out).toString();
    }

    /**
     * Rebind image paths after restoring a ZIP on a different Android device.
     * The SQLite database contains absolute paths from the old installation,
     * so those paths are invalid after reinstall. The image files themselves
     * are restored correctly into this installation's files/product_images/
     * directory; we must point the products table to the new local paths.
     */
    void repairRestoredProductImagePaths(){
        Cursor c=null;
        try{
            File dir=new File(getFilesDir(),"product_images");
            if(!dir.exists())dir.mkdirs();
            c=db.getReadableDatabase().query("products",new String[]{"id","image"},null,null,null,null,null);
            while(c.moveToNext()){
                int id=c.getInt(0);
                String image=c.getString(1);
                if(image==null||image.isEmpty()||image.startsWith("http://")||image.startsWith("https://"))continue;
                String name=null;
                try{
                    Uri u=Uri.parse(image);
                    name=u.getPath();
                    if(name!=null)name=new File(name).getName();
                }catch(Exception ignored){}
                if(name==null||name.isEmpty()){
                    try{name=new File(image).getName();}catch(Exception ignored){}
                }
                if(name==null||name.isEmpty())continue;
                File restored=new File(dir,name);
                if(restored.exists()&&restored.isFile()){
                    ContentValues v=new ContentValues();
                    v.put("image",Uri.fromFile(restored).toString());
                    db.getWritableDatabase().update("products",v,"id=?",new String[]{String.valueOf(id)});
                }else{
                    // Do not leave a broken absolute path from the old phone.
                    // An empty local path allows the cloud image to be restored.
                    ContentValues v=new ContentValues();
                    v.put("image","");
                    db.getWritableDatabase().update("products",v,"id=?",new String[]{String.valueOf(id)});
                }
            }
        }finally{if(c!=null)c.close();}
        Cursor pc=null;
        try{
            pc=db.getReadableDatabase().query("partner_product_settings",new String[]{"partner_id","product_id","customer_image"},"customer_image IS NOT NULL AND customer_image<>''",null,null,null,null);
            File base=new File(getFilesDir(),"product_images");
            while(pc.moveToNext()){
                int partnerId=pc.getInt(0),productId=pc.getInt(1);String image=pc.getString(2);
                if(image==null||image.isEmpty()||image.startsWith("http://")||image.startsWith("https://"))continue;
                File restored=new File(base,"partner_"+partnerId+"/product_"+productId+".jpg");
                ContentValues v=new ContentValues();v.put("customer_image",restored.exists()?Uri.fromFile(restored).toString():"");
                db.getWritableDatabase().update("partner_product_settings",v,"partner_id=? AND product_id=?",new String[]{String.valueOf(partnerId),String.valueOf(productId)});
            }
        }finally{if(pc!=null)pc.close();}
    }

    void markAllProductsDirtyAfterImport(){
        Cursor c=null;try{c=db.getReadableDatabase().query("products",new String[]{"id"},null,null,null,null,null);long now=System.currentTimeMillis();while(c.moveToNext())db.markSync("products",c.getInt(0),now++,"dirty",0,false);}finally{if(c!=null)c.close();}
    }

    void compressAllLocalProductImages(){
        Cursor c=null;try{c=db.getReadableDatabase().query("products",new String[]{"id","image"},null,null,null,null,null);while(c.moveToNext()){int id=c.getInt(0);String path=c.getString(1);if(path==null||path.isEmpty()||path.startsWith("http"))continue;File f=new File(Uri.parse(path).getPath()==null?path:Uri.parse(path).getPath());if(!f.exists()||f.length()<=MAX_PRODUCT_IMAGE_BYTES)continue;try{Uri u=Uri.fromFile(f);String compressed=copyImageToApp(u);ContentValues v=new ContentValues();v.put("image",compressed);db.getWritableDatabase().update("products",v,"id=?",new String[]{String.valueOf(id)});f.delete();}catch(Exception ignored){}}}finally{if(c!=null)c.close();}
    }

    LinearLayout.LayoutParams margin(int w,int h,int l,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(l,0,0,b);return p;}
    double sum(ArrayList<Store.Item> a){double x=0;for(Store.Item i:a)x+=i.price*i.qty;return x;}
    double toD(String s){try{return Double.parseDouble(s.replace(",","."));}catch(Exception e){return 0;}}
    String money(double x){return String.format(Locale.US,"%.2f",x);}
    String safe(String s){return s==null?"":s;}
    String safeFileName(String s){return safe(s).replaceAll("[\\/:*?\"<>|]","_").trim();}
    String trim(String s,int n){s=safe(s);return s.length()>n?s.substring(0,n-1)+"…":s;}

    /**
     * معرض صور داخلي خفيف لنسخ صورة المنتج:
     * على Android 10 وما قبله يعرض جميع الصور الموجودة في الهاتف مباشرة
     * في شبكة واحدة بدل شاشة "فتح من" التي تعرض Images/Drive فقط.
     */
    void openProductGallery(EditText target){
        pendingImageField=target;

        if(Build.VERSION.SDK_INT>=33){
            try{
                Intent picker=new Intent(MediaStore.ACTION_PICK_IMAGES);
                picker.setType("image/*");
                picker.putExtra(Intent.EXTRA_LOCAL_ONLY,true);
                startActivityForResult(picker,9001);
                return;
            }catch(Exception ignored){}
        }

        if(Build.VERSION.SDK_INT>=23 &&
                checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)!=android.content.pm.PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},9002);
            return;
        }
        showAllImagesGallery();
    }

    void showAllImagesGallery(){
        try{
            String[] projection={MediaStore.Images.Media._ID,MediaStore.Images.Media.DISPLAY_NAME};
            imageCursor=getContentResolver().query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    projection,null,null,
                    MediaStore.Images.Media.DATE_ADDED+" DESC");

            if(imageCursor==null||imageCursor.getCount()==0){
                Toast.makeText(this,"لم يتم العثور على صور في الهاتف",Toast.LENGTH_LONG).show();
                if(imageCursor!=null){imageCursor.close();imageCursor=null;}
                return;
            }

            GridView grid=new GridView(this);
            grid.setNumColumns(3);
            grid.setHorizontalSpacing(dp(5));
            grid.setVerticalSpacing(dp(5));
            grid.setPadding(dp(8),dp(8),dp(8),dp(8));
            grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
            grid.setAdapter(new AllImagesAdapter(imageCursor));

            TextView title=text("🖼 معرض الصور — جميع الصور ("+imageCursor.getCount()+")",18,TEXT);
            title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
            title.setGravity(Gravity.CENTER);
            title.setPadding(dp(5),dp(12),dp(5),dp(12));

            LinearLayout wrap=new LinearLayout(this);
            wrap.setOrientation(LinearLayout.VERTICAL);
            wrap.setPadding(dp(5),0,dp(5),0);
            wrap.addView(title);
            wrap.addView(grid,new LinearLayout.LayoutParams(-1,0,1));

            imageGalleryDialog=new AlertDialog.Builder(this)
                    .setView(wrap)
                    .setNegativeButton("إلغاء",null)
                    .create();

            grid.setOnItemClickListener((parent,view,position,id)->{
                Uri u=ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,id);
                try{
                    String saved=copyImageToApp(u);
                    if(pendingImageField!=null)pendingImageField.setText(saved);
                    Toast.makeText(this,"تم اختيار الصورة",Toast.LENGTH_SHORT).show();
                }catch(Exception e){
                    if(pendingImageField!=null)pendingImageField.setText(u.toString());
                    Toast.makeText(this,"تم اختيار الصورة",Toast.LENGTH_SHORT).show();
                }
                if(imageGalleryDialog!=null)imageGalleryDialog.dismiss();
            });

            imageGalleryDialog.setOnDismissListener(d->{
                if(imageCursor!=null){imageCursor.close();imageCursor=null;}
            });
            imageGalleryDialog.show();
            imageGalleryDialog.getWindow().setLayout(-1,(int)(getResources().getDisplayMetrics().heightPixels*0.88f));
        }catch(Exception e){
            if(imageCursor!=null){imageCursor.close();imageCursor=null;}
            Toast.makeText(this,"تعذر فتح معرض الصور: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    class AllImagesAdapter extends BaseAdapter{
        final Cursor cursor;
        final int idCol;
        AllImagesAdapter(Cursor c){
            cursor=c;
            idCol=c.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
        }
        public int getCount(){return cursor==null?0:cursor.getCount();}
        public Object getItem(int position){return position;}
        public long getItemId(int position){
            if(cursor==null)return 0;
            if(cursor.moveToPosition(position))return cursor.getLong(idCol);
            return 0;
        }
        public View getView(int position,View convertView,ViewGroup parent){
            ImageView iv=(convertView instanceof ImageView)?(ImageView)convertView:new ImageView(MainActivity.this);
            iv.setLayoutParams(new AbsListView.LayoutParams(-1,dp(112)));
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackground(round(Color.WHITE,BORDER,8,1));
            long imageId=getItemId(position);
            try{
                Uri u=ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,imageId);
                if(Build.VERSION.SDK_INT>=29){
                    iv.setImageBitmap(getContentResolver().loadThumbnail(u,new android.util.Size(dp(112),dp(112)),null));
                }else{
                    Bitmap b=MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(),imageId,MediaStore.Images.Thumbnails.MINI_KIND,null);
                    iv.setImageBitmap(b);
                }
            }catch(Exception e){
                iv.setImageResource(R.drawable.ic_product);
            }
            return iv;
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==9002){
            if(grantResults.length>0 && grantResults[0]==android.content.pm.PackageManager.PERMISSION_GRANTED){
                showAllImagesGallery();
            }else{
                Toast.makeText(this,"يجب السماح للتطبيق بالوصول إلى الصور لعرض جميع صور الهاتف",Toast.LENGTH_LONG).show();
            }
        }
    }

}