package com.mge.facturesimple;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    Store db;
    LinearLayout root, content;
    TextView title;
    int blue = Color.rgb(25,118,210), green=Color.rgb(22,163,74), red=Color.rgb(220,38,38);

    public void onCreate(Bundle b){
        super.onCreate(b);
        db=new Store(this);
        showHome();
    }

    TextView tv(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.rgb(32,33,36)); t.setPadding(16,12,16,12); return t; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setAllCaps(false); return b; }
    EditText input(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setPadding(14,8,14,8); e.setSingleLine(); return e; }

    void base(String name){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(245,247,250));
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(8,4,8,4); bar.setBackgroundColor(blue);
        Button menu=btn("☰"); menu.setTextColor(Color.WHITE); menu.setBackgroundColor(Color.TRANSPARENT);
        menu.setOnClickListener(v->showHome());
        title=new TextView(this); title.setText(name); title.setTextColor(Color.WHITE); title.setTextSize(20); title.setGravity(Gravity.CENTER);
        bar.addView(menu,new LinearLayout.LayoutParams(54,60)); bar.addView(title,new LinearLayout.LayoutParams(0,60,1));
        root.addView(bar);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(12,12,12,12);
        ScrollView sv=new ScrollView(this); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    void showHome(){
        base("FactureSimple 2.3");
        ImageView logo=new ImageView(this); logo.setImageResource(com.mge.facturesimple.R.drawable.logo_mge); logo.setPadding(12,8,12,8);
        content.addView(logo,new LinearLayout.LayoutParams(-1,90));
        TextView sub=tv("الفواتير + المنتجات + الزبائن",22); sub.setGravity(Gravity.CENTER); content.addView(sub);
        addCard("🧾  الفواتير","حفظ، بحث، تعديل، مدفوعة / غير مدفوعة",v->showInvoices());
        addCard("📦  المنتجات","إضافة، تعديل، حذف، بحث تلقائي وصورة المنتج",v->showProducts());
        addCard("👤  الزبائن","الاسم، الهاتف، المدينة، العنوان، بحث وتعديل",v->showCustomers());
        addCard("⚙  إعدادات الشركة","الشعار ورقم الهاتف الذي يظهران في PDF",v->showSettings());
        Button newInv=btn("＋  إنشاء فاتورة جديدة"); newInv.setOnClickListener(v->showInvoiceEditor(-1)); content.addView(newInv);
    }

    void addCard(String a,String b,View.OnClickListener l){
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(8,8,8,8); c.setBackgroundColor(Color.WHITE);
        TextView x=tv(a,19); TextView y=tv(b,14); c.addView(x); c.addView(y); c.setOnClickListener(l);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,110); p.setMargins(0,6,0,6); content.addView(c,p);
    }

    void showProducts(){
        base("المنتجات");
        EditText search=input("🔎 اكتب اسم المنتج أو الكود للبحث"); content.addView(search);
        Button add=btn("＋ إضافة منتج"); add.setOnClickListener(v->productDialog(-1)); content.addView(add);
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); content.addView(list);
        Runnable refresh=()->{
            list.removeAllViews(); String q=search.getText().toString();
            for(Store.Product p:db.products(q)) productRow(list,p);
        };
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){} public void onTextChanged(CharSequence s,int a,int b,int c){refresh.run();} public void afterTextChanged(android.text.Editable e){}});
        refresh.run();
    }

    void productRow(LinearLayout list,Store.Product p){
        LinearLayout r=new LinearLayout(this); r.setPadding(8,6,8,6); r.setGravity(Gravity.CENTER_VERTICAL); r.setBackgroundColor(Color.WHITE);
        ImageView im=new ImageView(this); im.setImageResource(R.drawable.ic_product); r.addView(im,new LinearLayout.LayoutParams(68,68));
        LinearLayout tx=new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL);
        tx.addView(tv(p.name,17)); tx.addView(tv("Code: "+p.code+"   |   "+p.price+" DH",14));
        r.addView(tx,new LinearLayout.LayoutParams(0,80,1));
        Button edit=btn("✎"); edit.setOnClickListener(v->productDialog(p.id)); r.addView(edit);
        Button del=btn("🗑"); del.setOnClickListener(v->{db.deleteProduct(p.id); showProducts();}); r.addView(del);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,90); lp.setMargins(0,4,0,4); list.addView(r,lp);
    }

    void productDialog(int id){
        Store.Product old=id<0?null:db.product(id);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        EditText n=input("اسم المنتج"); EditText c=input("الكود"); EditText pr=input("السعر DH");
        if(old!=null){n.setText(old.name);c.setText(old.code);pr.setText(""+old.price);}
        box.addView(n);box.addView(c);box.addView(pr);
        new AlertDialog.Builder(this).setTitle(id<0?"إضافة منتج":"تعديل المنتج").setView(box)
          .setPositiveButton("حفظ",(d,w)->{db.saveProduct(id,n.getText().toString(),c.getText().toString(),toD(pr.getText().toString()));showProducts();})
          .setNegativeButton("إلغاء",null).show();
    }

    void showCustomers(){
        base("الزبائن");
        EditText search=input("🔎 البحث عن زبون أو هاتف"); content.addView(search);
        Button add=btn("＋ إضافة زبون"); add.setOnClickListener(v->customerDialog(-1)); content.addView(add);
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); content.addView(list);
        Runnable refresh=()->{list.removeAllViews();for(Store.Customer c:db.customers(search.getText().toString()))customerRow(list,c);};
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){refresh.run();}public void afterTextChanged(android.text.Editable e){}});
        refresh.run();
    }
    void customerRow(LinearLayout list,Store.Customer c){
        LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(12,8,12,8);r.setBackgroundColor(Color.WHITE);
        r.addView(tv("👤  "+c.name,18));r.addView(tv("📞 "+c.phone+"   |   "+c.city,14));r.addView(tv("📍 "+c.address,13));
        Button e=btn("✎ تعديل");e.setOnClickListener(v->customerDialog(c.id));r.addView(e);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,125);lp.setMargins(0,5,0,5);list.addView(r,lp);
    }
    void customerDialog(int id){
        Store.Customer o=id<0?null:db.customer(id);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        EditText n=input("الاسم"),p=input("الهاتف"),city=input("المدينة"),a=input("العنوان");box.addView(n);box.addView(p);box.addView(city);box.addView(a);
        if(o!=null){n.setText(o.name);p.setText(o.phone);city.setText(o.city);a.setText(o.address);}
        new AlertDialog.Builder(this).setTitle(id<0?"إضافة زبون":"تعديل الزبون").setView(box).setPositiveButton("حفظ",(d,w)->{db.saveCustomer(id,n.getText().toString(),p.getText().toString(),city.getText().toString(),a.getText().toString());showCustomers();}).setNegativeButton("إلغاء",null).show();
    }

    void showInvoices(){
        base("الفواتير");
        EditText search=input("🔎 رقم الفاتورة أو اسم الزبون أو الهاتف");content.addView(search);
        Button add=btn("＋ فاتورة جديدة");add.setOnClickListener(v->showInvoiceEditor(-1));content.addView(add);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);
        Runnable refresh=()->{list.removeAllViews();for(Store.Invoice i:db.invoices(search.getText().toString()))invoiceRow(list,i);};
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b){}public void onTextChanged(CharSequence s,int a,int b,int c){refresh.run();}public void afterTextChanged(android.text.Editable e){}});
        refresh.run();
    }
    void invoiceRow(LinearLayout list,Store.Invoice i){
        LinearLayout r=new LinearLayout(this);r.setPadding(8,5,8,5);r.setBackgroundColor(Color.WHITE);r.setOrientation(LinearLayout.VERTICAL);
        TextView x=tv("#"+i.id+"   "+i.client+"   "+i.total+" DH",17);r.addView(x);TextView st=tv(i.paid?"✓ مدفوعة":"✕ غير مدفوعة",14);st.setTextColor(i.paid?green:red);r.addView(st);
        LinearLayout b=new LinearLayout(this);Button e=btn("✎ تعديل");e.setOnClickListener(v->showInvoiceEditor(i.id));Button pdf=btn("PDF");pdf.setOnClickListener(v->makePdf(i.id));b.addView(e);b.addView(pdf);r.addView(b);
        list.addView(r,new LinearLayout.LayoutParams(-1,115));
    }

    void showInvoiceEditor(int id){
        base(id<0?"فاتورة جديدة":"تعديل الفاتورة");
        Store.Invoice old=id<0?null:db.invoice(id);
        EditText client=input("اسم الزبون");content.addView(client); 
        EditText search=input("🔎 البحث عن منتج...");content.addView(search);
        LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);content.addView(results);
        TextView total=tv("المجموع: 0.00 DH",20);content.addView(total);
        CheckBox paid=new CheckBox(this);paid.setText("الفاتورة مدفوعة");content.addView(paid);
        Button save=btn("حفظ الفاتورة");content.addView(save);
        ArrayList<Store.Item> items=new ArrayList<>();
        if(old!=null){client.setText(old.client);paid.setChecked(old.paid);items.addAll(old.items);}
        Runnable render=()->{
            results.removeAllViews();
            for(Store.Product p:db.products(search.getText().toString())){
                LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setBackgroundColor(Color.WHITE);
                ImageView im=new ImageView(this);im.setImageResource(R.drawable.ic_product);r.addView(im,new LinearLayout.LayoutParams(58,58));
                TextView t=tv(p.name+"\n"+p.price+" DH",15);r.addView(t,new LinearLayout.LayoutParams(0,70,1));
                Button plus=btn("＋");plus.setOnClickListener(v->{items.add(new Store.Item(p.name,p.price,1));updateTotal(total,items);});r.addView(plus);
                results.addView(r,new LinearLayout.LayoutParams(-1,75));
            }
            if(!search.getText().toString().isEmpty()) updateTotal(total,items);
        };
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){render.run();}public void afterTextChanged(android.text.Editable e){}});
        save.setOnClickListener(v->{if(client.getText().toString().trim().isEmpty()){client.setError("أدخل اسم الزبون");return;}db.saveInvoice(id,client.getText().toString(),paid.isChecked(),items);Toast.makeText(this,"تم حفظ الفاتورة",Toast.LENGTH_SHORT).show();showInvoices();});
        render.run(); if(old!=null)updateTotal(total,items);
    }

    void updateTotal(TextView t,ArrayList<Store.Item> items){double x=0;for(Store.Item i:items)x+=i.price*i.qty;t.setText(String.format(Locale.US,"المجموع: %.2f DH",x));}
    double toD(String s){try{return Double.parseDouble(s.replace(",","."));}catch(Exception e){return 0;}}

    void showSettings(){
        base("إعدادات الشركة");
        EditText phone=input("هاتف الشركة");phone.setText(db.get("phone","+212666964731"));content.addView(phone);
        Button save=btn("حفظ الإعدادات");save.setOnClickListener(v->{db.put("phone",phone.getText().toString());Toast.makeText(this,"تم الحفظ",Toast.LENGTH_SHORT).show();});content.addView(save);
        content.addView(tv("الشعار الحالي: MGE\nسيظهر أعلى الفاتورة في PDF.",16));
    }

    void makePdf(int id){
        Store.Invoice inv=db.invoice(id);if(inv==null)return;
        PdfDocument doc=new PdfDocument();PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());
        Canvas c=page.getCanvas();Paint p=new Paint();p.setAntiAlias(true);
        p.setColor(Color.BLACK);p.setTextSize(22);p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("MGE",45,55,p);
        p.setTextSize(20);c.drawText("FACTURE / فاتورة",300,55,p);p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(12);c.drawText("Tel : "+db.get("phone","+212666964731"),45,82,p);
        c.drawText("N° : "+inv.id,45,105,p);c.drawText("Date : "+inv.date,45,128,p);c.drawText("Client : "+inv.client,45,151,p);
        p.setColor(inv.paid?green:red);p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText(inv.paid?"Statut : PAYÉE / مدفوعة":"Statut : NON PAYÉE / غير مدفوعة",45,176,p);p.setColor(Color.BLACK);
        p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("Produit / البيان",45,220,p);c.drawText("Qté",365,220,p);c.drawText("Prix",430,220,p);c.drawText("Total",505,220,p);p.setTypeface(Typeface.DEFAULT);
        int y=250;double total=0;for(Store.Item it:inv.items){double z=it.price*it.qty;total+=z;c.drawText(it.name,45,y,p);c.drawText(""+it.qty,365,y,p);c.drawText(String.format(Locale.US,"%.2f",it.price),430,y,p);c.drawText(String.format(Locale.US,"%.2f",z),505,y,p);y+=32;}
        p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(16);c.drawText(String.format(Locale.US,"TOTAL : %.2f DH",total),400,y+25,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(14);c.drawText("Merci pour votre confiance",225,y+75,p);
        doc.finishPage(page);
        File dir=new File(getExternalFilesDir(null),"Factures");dir.mkdirs();File f=new File(dir,"Facture_"+id+".pdf");
        try(FileOutputStream out=new FileOutputStream(f)){doc.writeTo(out);doc.close();Toast.makeText(this,"تم إنشاء PDF: "+f.getName(),Toast.LENGTH_LONG).show();}
        catch(Exception e){Toast.makeText(this,"خطأ PDF: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
}
