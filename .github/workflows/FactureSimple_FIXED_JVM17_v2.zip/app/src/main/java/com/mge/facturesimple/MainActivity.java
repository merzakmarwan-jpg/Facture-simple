package com.mge.facturesimple;

import android.app.*;
import android.os.*;
import android.os.Environment;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.content.ClipData;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import android.text.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {

    Store db;
    LinearLayout root, body;
    TextView screenTitle;
    EditText pendingImageField;

    final int BLUE = Color.rgb(20, 103, 205);
    final int BLUE_DARK = Color.rgb(13, 76, 161);
    final int GREEN = Color.rgb(18, 155, 72);
    final int RED = Color.rgb(220, 50, 50);
    final int BG = Color.rgb(246, 248, 252);
    final int TEXT = Color.rgb(31, 41, 55);
    final int MUTED = Color.rgb(100, 116, 139);
    final int BORDER = Color.rgb(225, 231, 239);

    int dp(float x){ return (int)(x * getResources().getDisplayMetrics().density + .5f); }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        db = new Store(this);
        getWindow().setStatusBarColor(BLUE_DARK);
        showHome();
    }

    TextView text(String s, float size, int color){
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(dp(10),dp(5),dp(10),dp(5));
        return t;
    }

    Button button(String s){
        Button b = new Button(this);
        b.setText(s); b.setTextSize(14); b.setAllCaps(false);
        b.setPadding(dp(10),0,dp(10),0);
        return b;
    }

    EditText input(String hint){
        EditText e = new EditText(this);
        e.setHint(hint); e.setTextSize(14); e.setSingleLine(true);
        e.setTextColor(TEXT); e.setHintTextColor(Color.rgb(150,158,170));
        e.setPadding(dp(12),0,dp(12),0);
        e.setBackground(round(Color.WHITE, BORDER, 12, 1));
        e.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return e;
    }

    GradientDrawable round(int fill, int stroke, int radius, int sw){
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill); g.setCornerRadius(dp(radius));
        if(sw>0) g.setStroke(dp(sw),stroke);
        return g;
    }

    GradientDrawable solid(int fill, int radius){
        return round(fill, fill, radius, 0);
    }

    LinearLayout lp(int w,int h){ return null; }

    void base(String title){
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(7),0,dp(7),0);
        top.setBackgroundColor(BLUE);

        Button menu = button("☰");
        menu.setTextColor(Color.WHITE);
        menu.setTextSize(22);
        menu.setBackgroundColor(Color.TRANSPARENT);
        menu.setOnClickListener(v -> showHome());

        screenTitle = text(title,19,Color.WHITE);
        screenTitle.setGravity(Gravity.CENTER);
        screenTitle.setTypeface(Typeface.DEFAULT,Typeface.BOLD);

        top.addView(menu,new LinearLayout.LayoutParams(dp(54),dp(58)));
        top.addView(screenTitle,new LinearLayout.LayoutParams(0,dp(58),1));

        root.addView(top);

        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(12),dp(10),dp(12),dp(10));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(body);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        root.addView(bottomBar(title));
        setContentView(root);
    }

    View bottomBar(String current){
        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setBackgroundColor(Color.WHITE);
        nav.setPadding(0,dp(3),0,dp(3));

        nav.addView(navItem("⌂","الرئيسية",current.equals("الرئيسية"),v->showHome()));
        nav.addView(navItem("▣","الفواتير",current.equals("الفواتير"),v->showInvoices()));
        nav.addView(navItem("▤","المنتجات",current.equals("المنتجات"),v->showProducts()));
        nav.addView(navItem("♙","الزبائن",current.equals("الزبائن"),v->showCustomers()));
        nav.addView(navItem("⚙","الإعدادات",current.equals("الإعدادات"),v->showSettings()));
        return nav;
    }

    View navItem(String icon,String label,boolean active,View.OnClickListener l){
        LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setGravity(Gravity.CENTER);
        TextView i=text(icon,20,active?BLUE:MUTED);i.setGravity(Gravity.CENTER);
        TextView t=text(label,10,active?BLUE:MUTED);t.setGravity(Gravity.CENTER);
        x.addView(i,new LinearLayout.LayoutParams(-1,dp(26)));
        x.addView(t,new LinearLayout.LayoutParams(-1,dp(24)));
        x.setOnClickListener(l);
        x.setBackground(active?solid(Color.rgb(239,246,255),10):ColorDrawable(Color.TRANSPARENT));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(54),1);p.setMargins(dp(3),0,dp(3),0);
        x.setLayoutParams(p);
        return x;
    }

    Drawable ColorDrawable(int c){ return new android.graphics.drawable.ColorDrawable(c); }

    TextView section(String s){
        TextView t=text(s,16,TEXT);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        t.setPadding(dp(4),dp(12),dp(4),dp(6));return t;
    }

    LinearLayout card(){
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(10),dp(9),dp(10),dp(9));c.setBackground(round(Color.WHITE,BORDER,15,1));
        return c;
    }

    void showHome(){
        base("الرئيسية");

        LinearLayout brand=card();
        brand.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.logo_mge);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        brand.addView(logo,new LinearLayout.LayoutParams(-1,dp(82)));
        TextView sub=text("تطبيق الفواتير + المنتجات + الزبائن",18,TEXT);sub.setGravity(Gravity.CENTER);
        brand.addView(sub);
        TextView ver=text("الإصدار 2.4 • البيانات محفوظة داخل الهاتف",12,MUTED);ver.setGravity(Gravity.CENTER);
        brand.addView(ver);
        body.addView(brand,margin(-1,dp(142),0,dp(8)));

        LinearLayout quick=new LinearLayout(this);
        quick.setOrientation(LinearLayout.HORIZONTAL);
        quick.addView(stat("🧾","الفواتير","إدارة الفواتير",v->showInvoices()),new LinearLayout.LayoutParams(0,dp(112),1));
        quick.addView(stat("📦","المنتجات","إدارة المنتجات",v->showProducts()),new LinearLayout.LayoutParams(0,dp(112),1));
        body.addView(quick);

        LinearLayout quick2=new LinearLayout(this);
        quick2.setOrientation(LinearLayout.HORIZONTAL);
        quick2.addView(stat("👤","الزبائن","إدارة الزبائن",v->showCustomers()),new LinearLayout.LayoutParams(0,dp(112),1));
        quick2.addView(stat("⚙","الإعدادات","إعدادات الشركة",v->showSettings()),new LinearLayout.LayoutParams(0,dp(112),1));
        body.addView(quick2);

        Button create=button("＋   إنشاء فاتورة جديدة");
        create.setTextColor(Color.WHITE);create.setTextSize(16);create.setBackground(solid(GREEN,14));
        create.setOnClickListener(v->showInvoiceEditor(-1));
        body.addView(create,margin(-1,dp(54),0,dp(10)));

        TextView note=text("PDF احترافي • حالة الدفع • بحث مباشر • صور المنتجات",13,MUTED);
        note.setGravity(Gravity.CENTER);body.addView(note);
    }

    View stat(String icon,String title,String desc,View.OnClickListener l){
        LinearLayout c=card();c.setGravity(Gravity.CENTER);
        TextView i=text(icon,27,BLUE);i.setGravity(Gravity.CENTER);
        TextView a=text(title,17,TEXT);a.setTypeface(Typeface.DEFAULT,Typeface.BOLD);a.setGravity(Gravity.CENTER);
        TextView b=text(desc,11,MUTED);b.setGravity(Gravity.CENTER);
        c.addView(i);c.addView(a);c.addView(b);c.setOnClickListener(l);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(106));p.setMargins(dp(4),dp(4),dp(4),dp(4));c.setLayoutParams(p);
        return c;
    }

    void showProducts(){
        base("المنتجات");
        EditText search=input("🔎  ابحث باسم المنتج أو الكود");body.addView(search,margin(-1,dp(48),0,dp(8)));

        Button add=button("＋  إضافة منتج");add.setTextColor(Color.WHITE);add.setBackground(solid(BLUE,12));
        add.setOnClickListener(v->productDialog(-1));body.addView(add,margin(-1,dp(48),0,dp(8)));

        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);body.addView(list);
        Runnable refresh=()->{list.removeAllViews();for(Store.Product p:db.products(search.getText().toString()))productRow(list,p);};
        watch(search,refresh);refresh.run();
    }

    void productRow(LinearLayout list,Store.Product p){
        LinearLayout r=card();r.setOrientation(LinearLayout.HORIZONTAL);r.setGravity(Gravity.CENTER_VERTICAL);
        ImageView im=new ImageView(this);loadImage(im,p.image);im.setScaleType(ImageView.ScaleType.CENTER_CROP);
        r.addView(im,new LinearLayout.LayoutParams(dp(70),dp(70)));

        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(8),0,dp(8),0);
        TextView n=text(p.name,16,TEXT);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        info.addView(n);info.addView(text("Code: "+safe(p.code),12,MUTED));
        TextView price=text(money(p.price)+" DH",14,BLUE);price.setTypeface(Typeface.DEFAULT,Typeface.BOLD);info.addView(price);
        r.addView(info,new LinearLayout.LayoutParams(0,dp(78),1));

        Button edit=button("✎");edit.setTextColor(BLUE);edit.setBackgroundColor(Color.TRANSPARENT);edit.setOnClickListener(v->productDialog(p.id));
        Button del=button("🗑");del.setTextColor(RED);del.setBackgroundColor(Color.TRANSPARENT);del.setOnClickListener(v->{db.deleteProduct(p.id);showProducts();});
        r.addView(edit,new LinearLayout.LayoutParams(dp(48),dp(58)));
        r.addView(del,new LinearLayout.LayoutParams(dp(48),dp(58)));

        list.addView(r,margin(-1,dp(94),0,dp(6)));
    }

    void productDialog(int id){
        Store.Product o=id<0?null:db.product(id);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(5),0,dp(5),0);
        EditText n=input("اسم المنتج"),c=input("الكود"),pr=input("السعر DH"),img=input("مسار صورة المنتج");
        if(o!=null){n.setText(o.name);c.setText(o.code);pr.setText(money(o.price));img.setText(safe(o.image));}
        box.addView(n,margin(-1,dp(48),0,dp(7)));box.addView(c,margin(-1,dp(48),0,dp(7)));
        box.addView(pr,margin(-1,dp(48),0,dp(7)));box.addView(img,margin(-1,dp(48),0,dp(7)));
        Button pick=button("🖼  اختيار صورة من الهاتف");pick.setOnClickListener(v->{pendingImageField=img;Intent in=new Intent(Intent.ACTION_OPEN_DOCUMENT);in.setType("image/*");in.addCategory(Intent.CATEGORY_OPENABLE);in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(in,9001);});
        box.addView(pick);
        AlertDialog d=new AlertDialog.Builder(this).setTitle(id<0?"إضافة منتج":"تعديل المنتج").setView(box)
            .setPositiveButton("حفظ",(x,w)->{db.saveProduct(id,n.getText().toString().trim(),c.getText().toString().trim(),toD(pr.getText().toString()),img.getText().toString());showProducts();})
            .setNegativeButton("إلغاء",null).create();d.show();
    }

    void showCustomers(){
        base("الزبائن والشركاء");
        TextView hint=text("إدارة الزبائن والشركاء وحساب أرباح الشركاء بشكل تلقائي",13,MUTED);hint.setGravity(Gravity.CENTER);body.addView(hint,margin(-1,dp(34),0,dp(3)));
        EditText search=input("🔎  ابحث بالاسم أو الهاتف أو المدينة");body.addView(search,margin(-1,dp(48),0,dp(8)));
        Button add=button("＋  إضافة زبون / شريك");add.setTextColor(Color.WHITE);add.setBackground(solid(BLUE,12));add.setOnClickListener(v->customerDialog(-1));body.addView(add,margin(-1,dp(48),0,dp(8)));
        LinearLayout filters=new LinearLayout(this);filters.setGravity(Gravity.CENTER);final int[] filter={0};
        Button all=button("الكل"),normal=button("الزبائن"),partners=button("🤝 الشركاء");
        filters.addView(all,new LinearLayout.LayoutParams(0,dp(42),1));filters.addView(normal,new LinearLayout.LayoutParams(0,dp(42),1));filters.addView(partners,new LinearLayout.LayoutParams(0,dp(42),1));body.addView(filters,margin(-1,dp(46),0,dp(8)));
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);body.addView(list);
        Runnable refresh=()->{list.removeAllViews();for(Store.Customer c:db.customers(search.getText().toString())){if(filter[0]==1&&c.reseller)continue;if(filter[0]==2&&!c.reseller)continue;customerRow(list,c);}};
        all.setOnClickListener(v->{filter[0]=0;refreshCustomerButtons(all,normal,partners,0);refresh.run();});normal.setOnClickListener(v->{filter[0]=1;refreshCustomerButtons(all,normal,partners,1);refresh.run();});partners.setOnClickListener(v->{filter[0]=2;refreshCustomerButtons(all,normal,partners,2);refresh.run();});refreshCustomerButtons(all,normal,partners,0);
        watch(search,refresh);refresh.run();
    }

    void refreshCustomerButtons(Button all,Button normal,Button partners,int active){Button[] bs={all,normal,partners};for(int i=0;i<bs.length;i++){bs[i].setTextColor(i==active?Color.WHITE:BLUE);bs[i].setBackground(solid(i==active?BLUE:Color.rgb(239,246,255),10));}}

    void customerRow(LinearLayout list,Store.Customer c){
        LinearLayout r=card();r.setOrientation(LinearLayout.VERTICAL);r.setPadding(dp(12),dp(10),dp(12),dp(10));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        TextView avatar=text(c.reseller?"🤝":"👤",24,c.reseller?GREEN:BLUE);avatar.setGravity(Gravity.CENTER);avatar.setBackground(solid(c.reseller?Color.rgb(236,253,245):Color.rgb(239,246,255),40));top.addView(avatar,new LinearLayout.LayoutParams(dp(54),dp(54)));
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(9),0,dp(6),0);
        TextView n=text(c.name,17,TEXT);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);info.addView(n);
        info.addView(text(c.reseller?"شريك إحالة • يرسل لك زبائنه":"زبون عادي"+(c.partnerId>0?" • تابع لشريك":""),11,c.reseller?GREEN:MUTED));
        info.addView(text("📞 "+safe(c.phone)+"   •   📍 "+safe(c.city),12,MUTED));
        if(c.reseller) info.addView(text("🚚 شحن افتراضي: "+money(c.defaultShipping)+" DH",11,BLUE));
        top.addView(info,new LinearLayout.LayoutParams(0,dp(82),1));
        Button edit=button("✎");edit.setTextColor(BLUE);edit.setBackgroundColor(Color.TRANSPARENT);edit.setOnClickListener(v->customerDialog(c.id));
        Button del=button("🗑");del.setTextColor(RED);del.setBackgroundColor(Color.TRANSPARENT);del.setOnClickListener(v->{db.deleteCustomer(c.id);showCustomers();});
        top.addView(edit,new LinearLayout.LayoutParams(dp(42),dp(52)));top.addView(del,new LinearLayout.LayoutParams(dp(42),dp(52)));r.addView(top);
        TextView addr=text("📍 "+safe(c.address),11,MUTED);r.addView(addr);
        if(c.reseller){
            LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER);
            Button clients=button("👥 زبائنه");clients.setTextColor(BLUE);clients.setOnClickListener(v->showPartnerCustomers(c.id));
            Button profits=button("💰 الأرباح");profits.setTextColor(GREEN);profits.setOnClickListener(v->showPartnerProfits(c.id));
            actions.addView(clients,new LinearLayout.LayoutParams(0,dp(44),1));actions.addView(profits,new LinearLayout.LayoutParams(0,dp(44),1));r.addView(actions);
        }
        list.addView(r,margin(-1,c.reseller?dp(178):dp(118),0,dp(7)));
    }

    void customerDialog(int id){
        Store.Customer o=id<0?null:db.customer(id);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(4),0,dp(4),0);
        EditText n=input("الاسم"),p=input("الهاتف"),city=input("المدينة"),a=input("العنوان");
        CheckBox reseller=new CheckBox(this);reseller.setText("🤝 شريك إحالة — يرسل لي زبائنه");reseller.setTextSize(14);
        EditText partnerName=input("الشريك المسؤول عن هذا الزبون (اختياري)");Button pickPartner=button("🤝 اختيار الشريك");
        EditText defaultShip=input("شحن افتراضي للشريك DH");defaultShip.setInputType(2|8192);defaultShip.setText("30");
        final int[] partnerId={0};
        if(o!=null){n.setText(o.name);p.setText(o.phone);city.setText(o.city);a.setText(o.address);reseller.setChecked(o.reseller);partnerId[0]=o.partnerId;if(o.partnerId>0){Store.Customer pc=db.customer(o.partnerId);if(pc!=null)partnerName.setText(pc.name);}if(o.reseller)defaultShip.setText(money(o.defaultShipping));}
        box.addView(n,margin(-1,dp(48),0,dp(5)));box.addView(p,margin(-1,dp(48),0,dp(5)));box.addView(city,margin(-1,dp(48),0,dp(5)));box.addView(a,margin(-1,dp(48),0,dp(5)));box.addView(reseller);
        box.addView(partnerName,margin(-1,dp(48),0,dp(5)));pickPartner.setOnClickListener(v->partnerPicker(partnerName,partnerId));box.addView(pickPartner);box.addView(defaultShip,margin(-1,dp(48),0,dp(5)));
        Runnable state=()->{partnerName.setVisibility(reseller.isChecked()?View.GONE:View.VISIBLE);pickPartner.setVisibility(reseller.isChecked()?View.GONE:View.VISIBLE);defaultShip.setVisibility(reseller.isChecked()?View.VISIBLE:View.GONE);};reseller.setOnCheckedChangeListener((b,checked)->state.run());state.run();
        new AlertDialog.Builder(this).setTitle(id<0?"إضافة زبون / شريك":"تعديل بيانات الزبون").setView(box)
            .setPositiveButton("حفظ",(d,w)->{double ship=toD(defaultShip.getText().toString());if(reseller.isChecked()&&ship<=0)ship=30;db.saveCustomer(id,n.getText().toString().trim(),p.getText().toString().trim(),city.getText().toString().trim(),a.getText().toString().trim(),reseller.isChecked(),reseller.isChecked()?0:partnerId[0],ship);showCustomers();})
            .setNegativeButton("إلغاء",null).show();
    }

    void partnerPicker(EditText target,int[] selected){
        EditText s=input("🔎 ابحث عن شريك");LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);ScrollView sv=new ScrollView(this);sv.addView(list);LinearLayout wrap=new LinearLayout(this);wrap.setOrientation(LinearLayout.VERTICAL);wrap.setPadding(dp(5),dp(5),dp(5),dp(5));wrap.addView(s);wrap.addView(sv,new LinearLayout.LayoutParams(-1,dp(400)));
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("اختيار الشريك").setView(wrap).setNegativeButton("إلغاء",null).create();Runnable r=()->{list.removeAllViews();for(Store.Customer c:db.customers(s.getText().toString()))if(c.reseller){Button b=button("🤝 "+c.name+"\n"+safe(c.phone));b.setOnClickListener(v->{target.setText(c.name);selected[0]=c.id;dlg.dismiss();});list.addView(b);}};watch(s,r);r.run();dlg.show();
    }

    void showPartnerCustomers(int partnerId){
        Store.Customer partner=db.customer(partnerId);if(partner==null)return;
        base("زبائن "+partner.name);
        TextView head=text("👥 جميع زبائن الشريك • "+partner.name,18,TEXT);head.setTypeface(Typeface.DEFAULT,Typeface.BOLD);head.setGravity(Gravity.CENTER);body.addView(head,margin(-1,dp(44),0,dp(6)));
        EditText search=input("🔎 ابحث عن زبون الشريك");body.addView(search,margin(-1,dp(48),0,dp(8)));
        Button add=button("＋ إضافة زبون لهذا الشريك");add.setTextColor(Color.WHITE);add.setBackground(solid(BLUE,12));add.setOnClickListener(v->customerDialogForPartner(partnerId));body.addView(add,margin(-1,dp(48),0,dp(8)));
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);body.addView(list);
        Runnable refresh=()->{list.removeAllViews();for(Store.Customer c:db.partnerCustomers(partnerId,search.getText().toString()))customerRow(list,c);};watch(search,refresh);refresh.run();
    }

    void customerDialogForPartner(int partnerId){
        Store.Customer partner=db.customer(partnerId);if(partner==null)return;
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(4),0,dp(4),0);
        EditText n=input("اسم الزبون"),p=input("الهاتف"),city=input("المدينة"),a=input("العنوان");box.addView(n,margin(-1,dp(48),0,dp(5)));box.addView(p,margin(-1,dp(48),0,dp(5)));box.addView(city,margin(-1,dp(48),0,dp(5)));box.addView(a,margin(-1,dp(48),0,dp(5)));
        new AlertDialog.Builder(this).setTitle("إضافة زبون للشريك: "+partner.name).setView(box).setPositiveButton("حفظ",(d,w)->{db.saveCustomer(-1,n.getText().toString().trim(),p.getText().toString().trim(),city.getText().toString().trim(),a.getText().toString().trim(),false,partnerId,30);showPartnerCustomers(partnerId);}).setNegativeButton("إلغاء",null).show();
    }

    void showPartnerProfits(int partnerId){
        Store.Customer partner=db.customer(partnerId);if(partner==null)return;
        base("أرباح الشريك");
        TextView title=text("💰 أرباح "+partner.name,20,TEXT);title.setGravity(Gravity.CENTER);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);body.addView(title,margin(-1,dp(44),0,dp(6)));
        LinearLayout summary=card();summary.setOrientation(LinearLayout.VERTICAL);summary.addView(text("الشحن الافتراضي: "+money(partner.defaultShipping)+" DH",14,BLUE));
        TextView total=text("",18,TEXT),paid=text("",14,GREEN),pending=text("",14,RED);summary.addView(total);summary.addView(paid);summary.addView(pending);body.addView(summary,margin(-1,-2,0,dp(9)));
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);body.addView(list);
        double[] sums={0,0,0};
        for(Store.Invoice i:db.invoices("")){if(i.partnerId!=partnerId)continue;double productProfit=0;for(Store.Item it:i.items)productProfit+=(it.salePrice-it.price)*it.qty;double net=i.commission;sums[0]+=net;if(i.partnerProfitPaid)sums[1]+=net;else sums[2]+=net;
            LinearLayout r=card();r.setPadding(dp(10),dp(8),dp(10),dp(8));r.addView(text("#"+i.id+" • "+i.client+" • "+i.date,15,TEXT));r.addView(text("ربح المنتجات: "+money(productProfit)+" DH  |  الشحن للزبون: "+money(i.shippingCharge)+" DH  |  التكلفة الفعلية: "+money(i.shippingCost)+" DH",11,MUTED));r.addView(text("صافي ربح الشريك: "+money(net)+" DH",13,net>=0?GREEN:RED));r.addView(text(i.deliveryReceived?"📦 تم الاستلام":"📦 لم يتم الاستلام",11,i.deliveryReceived?GREEN:RED));r.addView(text(i.partnerProfitPaid?"💵 تم دفع أرباح الشريك":"⏳ أرباح الشريك غير مدفوعة",11,i.partnerProfitPaid?GREEN:RED));if(i.deliveryReceived&&!i.partnerProfitPaid){Button pay=button("💵 تم دفع أرباح الشريك");pay.setTextColor(Color.WHITE);pay.setBackground(solid(GREEN,10));pay.setOnClickListener(v->{db.setPartnerProfitPaid(i.id,true);showPartnerProfits(partnerId);});r.addView(pay,new LinearLayout.LayoutParams(-1,dp(44)));}list.addView(r,margin(-1,i.deliveryReceived&&!i.partnerProfitPaid?dp(178):dp(132),0,dp(7)));
        }
        total.setText("إجمالي أرباح الشريك: "+money(sums[0])+" DH");paid.setText("تم دفعه: "+money(sums[1])+" DH");pending.setText("متبقي: "+money(sums[2])+" DH");
    }

    void showInvoices(){
        base("الفواتير");
        EditText search=input("🔎  ابحث برقم الفاتورة أو اسم الزبون");body.addView(search,margin(-1,dp(48),0,dp(8)));
        Button add=button("＋  فاتورة جديدة");add.setTextColor(Color.WHITE);add.setBackground(solid(BLUE,12));add.setOnClickListener(v->showInvoiceEditor(-1));body.addView(add,margin(-1,dp(48),0,dp(8)));
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);body.addView(list);
        Runnable refresh=()->{list.removeAllViews();for(Store.Invoice i:db.invoices(search.getText().toString()))invoiceRow(list,i);};watch(search,refresh);refresh.run();
    }

    void invoiceRow(LinearLayout list,Store.Invoice i){
        double products=0;for(Store.Item it:i.items)products+=it.salePrice*it.qty;double total=products+(i.shippingEnabled?i.shippingCharge:0);
        LinearLayout r=card();r.setPadding(dp(10),dp(8),dp(10),dp(8));LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        TextView no=text("#"+i.id,16,BLUE);no.setTypeface(Typeface.DEFAULT,Typeface.BOLD);top.addView(no,new LinearLayout.LayoutParams(dp(60),dp(36)));TextView cl=text(i.client,16,TEXT);cl.setTypeface(Typeface.DEFAULT,Typeface.BOLD);top.addView(cl,new LinearLayout.LayoutParams(0,dp(36),1));TextView amount=text(money(total)+" DH",15,TEXT);amount.setGravity(Gravity.CENTER);top.addView(amount,new LinearLayout.LayoutParams(dp(105),dp(36)));r.addView(top);
        LinearLayout mid=new LinearLayout(this);mid.setGravity(Gravity.CENTER_VERTICAL);mid.addView(text("📅 "+i.date+(i.partnerId>0?"   • 🤝 شريك":""),11,MUTED),new LinearLayout.LayoutParams(0,dp(28),1));TextView status=text(i.paid?"مدفوعة":"غير مدفوعة",11,i.paid?GREEN:RED);status.setGravity(Gravity.CENTER);status.setBackground(round(i.paid?Color.rgb(232,249,238):Color.rgb(254,239,239),i.paid?Color.rgb(177,230,193):Color.rgb(247,188,188),20,1));mid.addView(status,new LinearLayout.LayoutParams(dp(92),dp(28)));r.addView(mid);
        if(i.shippingEnabled)r.addView(text("🚚 شحن: "+money(i.shippingCharge)+" DH • التكلفة الفعلية: "+money(i.shippingCost)+" DH",11,BLUE));
        if(i.partnerId>0){TextView cm=text("💰 صافي ربح الشريك: "+money(i.commission)+" DH",11,i.commission>=0?GREEN:RED);r.addView(cm);r.addView(text(i.partnerProfitPaid?"💵 تم دفع أرباح الشريك":"⏳ أرباح الشريك غير مدفوعة",11,i.partnerProfitPaid?GREEN:RED));}
        if(i.trackingNumber!=null&&!i.trackingNumber.isEmpty())r.addView(text("🚚 تتبع: "+i.trackingNumber+" • "+(i.deliveryReceived?"تم الاستلام":"لم يتم الاستلام"),11,i.deliveryReceived?GREEN:RED));
        LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER);Button edit=button("✎ تعديل");edit.setTextColor(BLUE);edit.setBackgroundColor(Color.TRANSPARENT);edit.setOnClickListener(v->showInvoiceEditor(i.id));Button pdf=button("PDF");pdf.setTextColor(BLUE);pdf.setBackgroundColor(Color.TRANSPARENT);pdf.setOnClickListener(v->makePdf(i.id));Button del=button("🗑");del.setTextColor(RED);del.setBackgroundColor(Color.TRANSPARENT);del.setOnClickListener(v->{db.deleteInvoice(i.id);showInvoices();});actions.addView(edit);actions.addView(pdf);if(i.partnerId>0&&!i.partnerProfitPaid&&i.deliveryReceived){Button pay=button("💵 دفع الربح");pay.setTextColor(GREEN);pay.setBackgroundColor(Color.TRANSPARENT);pay.setOnClickListener(v->{db.setPartnerProfitPaid(i.id,true);showInvoices();});actions.addView(pay);}actions.addView(del);r.addView(actions);list.addView(r,margin(-1,-2,0,dp(7)));
    }

    void showInvoiceEditor(int id){
        base(id<0?"فاتورة جديدة":"تعديل الفاتورة");Store.Invoice old=id<0?null:db.invoice(id);
        LinearLayout invoiceHead=card();TextView head=text("بيانات الشريك والزبون",16,TEXT);head.setTypeface(Typeface.DEFAULT,Typeface.BOLD);invoiceHead.addView(head);
        EditText partner=input("الشريك (اختياري)");Button choosePartner=button("🤝 اختيار الشريك");final int[] selectedPartner={old==null?0:old.partnerId};if(selectedPartner[0]>0){Store.Customer pc=db.customer(selectedPartner[0]);if(pc!=null)partner.setText(pc.name);}invoiceHead.addView(partner,margin(-1,dp(48),0,dp(6)));invoiceHead.addView(choosePartner);
        EditText client=input("اسم الزبون المستلم");Button choose=button("👤 اختيار زبون من القائمة");final int[] selectedCustomer={old==null?0:old.clientId};if(old!=null)client.setText(old.client);invoiceHead.addView(client,margin(-1,dp(48),0,dp(6)));invoiceHead.addView(choose);body.addView(invoiceHead,margin(-1,-2,0,dp(9)));
        choosePartner.setOnClickListener(v->partnerPicker(partner,selectedPartner));choose.setOnClickListener(v->customerPicker(client,selectedCustomer,selectedPartner));

        LinearLayout productsCard=card();productsCard.addView(section("البحث عن منتج"));EditText search=input("🔎 اكتب اسم المنتج أو الكود");productsCard.addView(search,margin(-1,dp(48),0,dp(7)));LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);productsCard.addView(results);body.addView(productsCard,margin(-1,-2,0,dp(9)));
        LinearLayout selectedCard=card();selectedCard.addView(section("المنتجات داخل الفاتورة"));selectedCard.addView(text("المنتج                 سعرنا       سعر الزبون",11,MUTED));LinearLayout selected=new LinearLayout(this);selected.setOrientation(LinearLayout.VERTICAL);selectedCard.addView(selected);body.addView(selectedCard,margin(-1,-2,0,dp(9)));

        LinearLayout delivery=card();delivery.addView(section("التوصيل والشحن"));CheckBox shipping=new CheckBox(this);shipping.setText("🚚 هذه الفاتورة سيتم شحنها");shipping.setTextSize(15);delivery.addView(shipping);
        EditText shippingCharge=input("مبلغ الشحن الذي يدفعه الزبون DH");EditText shippingCost=input("تكلفة الشحن الفعلية من شركة التوصيل DH");shippingCharge.setInputType(2|8192);shippingCost.setInputType(2|8192);delivery.addView(shippingCharge,margin(-1,dp(48),0,dp(6)));delivery.addView(shippingCost,margin(-1,dp(48),0,dp(6)));
        EditText tracking=input("رقم تتبع الطلبية (اختياري)");delivery.addView(tracking,margin(-1,dp(48),0,dp(6)));CheckBox received=new CheckBox(this);received.setText("📦 تم الاستلام من طرف الزبون");delivery.addView(received);body.addView(delivery,margin(-1,-2,0,dp(9)));
        LinearLayout totalCard=card();TextView total=text("المجموع على الزبون\n0.00 DH",19,TEXT);total.setGravity(Gravity.CENTER);total.setTypeface(Typeface.DEFAULT,Typeface.BOLD);totalCard.addView(total);TextView commission=text("صافي ربح الشريك بعد الشحن: 0.00 DH",15,GREEN);commission.setGravity(Gravity.CENTER);totalCard.addView(commission);CheckBox profitPaid=new CheckBox(this);profitPaid.setText("💵 تم دفع أرباح الشريك");profitPaid.setTextSize(15);totalCard.addView(profitPaid);CheckBox paid=new CheckBox(this);paid.setText("الفاتورة مدفوعة");paid.setTextSize(15);totalCard.addView(paid);LinearLayout actions=new LinearLayout(this);Button save=button("حفظ الفاتورة");save.setTextColor(Color.WHITE);save.setBackground(solid(GREEN,12));Button pdf=button("تصدير PDF");pdf.setTextColor(Color.WHITE);pdf.setBackground(solid(BLUE,12));pdf.setEnabled(id>=0);actions.addView(save,new LinearLayout.LayoutParams(0,dp(52),1));actions.addView(pdf,new LinearLayout.LayoutParams(0,dp(52),1));totalCard.addView(actions);body.addView(totalCard,margin(-1,-2,0,dp(12)));

        ArrayList<Store.Item> items=new ArrayList<>();if(old!=null){items.addAll(old.items);paid.setChecked(old.paid);shipping.setChecked(old.shippingEnabled);shippingCharge.setText(money(old.shippingCharge));shippingCost.setText(money(old.shippingCost));tracking.setText(safe(old.trackingNumber));received.setChecked(old.deliveryReceived);profitPaid.setChecked(old.partnerProfitPaid);}else{shippingCharge.setText(db.get("default_shipping","30"));shippingCost.setText(db.get("default_shipping","30"));}
        Runnable refreshShipping=()->{boolean en=shipping.isChecked();shippingCharge.setEnabled(en);shippingCost.setEnabled(en);if(en&&toD(shippingCharge.getText().toString())<=0){double d=selectedPartner[0]>0?partnerDefaultShipping(selectedPartner[0]):toD(db.get("default_shipping","30"));shippingCharge.setText(money(d));shippingCost.setText(money(d));}if(!en){shippingCharge.setText("0");shippingCost.setText("0");}updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));};shipping.setOnCheckedChangeListener((b,c)->refreshShipping.run());
        TextWatcher financeWatcher=new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));}public void afterTextChanged(Editable e){}};shippingCharge.addTextChangedListener(financeWatcher);shippingCost.addTextChangedListener(financeWatcher);
        Runnable update=()->{results.removeAllViews();String q=search.getText().toString().trim();if(!q.isEmpty())for(Store.Product p:db.products(q))productSearchRow(results,p,items,total,commission,selected,shipping,shippingCharge,shippingCost);renderItems(selected,items,total,commission,shipping,shippingCharge,shippingCost);updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));};watch(search,update);update.run();refreshShipping.run();
        save.setOnClickListener(v->{if(client.getText().toString().trim().isEmpty()){client.setError("أدخل اسم الزبون");return;}if(items.isEmpty()){Toast.makeText(this,"أضف منتجاً واحداً على الأقل",Toast.LENGTH_SHORT).show();return;}if(selectedPartner[0]>0&&profitPaid.isChecked()&&!received.isChecked()){Toast.makeText(this,"لا يمكن دفع ربح الشريك قبل استلام الزبون للطلبية",Toast.LENGTH_LONG).show();return;}double sc=shipping.isChecked()?toD(shippingCharge.getText().toString()):0;double actual=shipping.isChecked()?toD(shippingCost.getText().toString()):0;db.saveInvoice(id,selectedCustomer[0],client.getText().toString().trim(),paid.isChecked(),selectedPartner[0],shipping.isChecked(),sc,actual,tracking.getText().toString().trim(),received.isChecked(),profitPaid.isChecked(),items);Toast.makeText(this,"تم حفظ الفاتورة بنجاح",Toast.LENGTH_SHORT).show();showInvoices();});
        pdf.setOnClickListener(v->{if(id>=0)makePdf(id);});
    }

    double partnerDefaultShipping(int partnerId){Store.Customer p=db.customer(partnerId);return p==null?30:p.defaultShipping;}

    void productSearchRow(LinearLayout box,Store.Product p,ArrayList<Store.Item> items,TextView total,TextView commission,LinearLayout selected,CheckBox shipping,EditText shippingCharge,EditText shippingCost){
        LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(5),dp(4),dp(5),dp(4));r.setBackground(round(Color.rgb(249,251,255),Color.rgb(219,228,240),10,1));ImageView im=new ImageView(this);loadImage(im,p.image);im.setScaleType(ImageView.ScaleType.CENTER_CROP);r.addView(im,new LinearLayout.LayoutParams(dp(55),dp(55)));LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(7),0,dp(7),0);TextView n=text(p.name,14,TEXT);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);info.addView(n);info.addView(text("Code: "+safe(p.code)+" • "+money(p.price)+" DH",11,MUTED));r.addView(info,new LinearLayout.LayoutParams(0,dp(64),1));Button plus=button("＋");plus.setTextColor(Color.WHITE);plus.setBackground(solid(BLUE,10));plus.setOnClickListener(v->{addItem(items,p);renderItems(selected,items,total,commission,shipping,shippingCharge,shippingCost);updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));});r.addView(plus,new LinearLayout.LayoutParams(dp(52),dp(50)));box.addView(r,margin(-1,dp(70),0,dp(5)));
    }

    void renderItems(LinearLayout box,ArrayList<Store.Item> items,TextView total,TextView commission,CheckBox shipping,EditText shippingCharge,EditText shippingCost){
        box.removeAllViews();for(int k=0;k<items.size();k++){final int idx=k;Store.Item it=items.get(k);LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(5),dp(4),dp(5),dp(4));LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);TextView n=text(it.name,13,TEXT);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);info.addView(n);info.addView(text(money(it.price)+" DH × "+it.qty,10,MUTED));r.addView(info,new LinearLayout.LayoutParams(0,dp(70),1));EditText sale=input("سعر الزبون");sale.setText(money(it.salePrice));sale.setInputType(2|8192);r.addView(sale,new LinearLayout.LayoutParams(dp(105),dp(48)));TextView lineTotal=text(money(it.salePrice*it.qty)+" DH",12,TEXT);lineTotal.setGravity(Gravity.CENTER);r.addView(lineTotal,new LinearLayout.LayoutParams(dp(82),dp(48)));Button minus=button("−");Button plus=button("+");Button del=button("×");del.setTextColor(RED);minus.setOnClickListener(v->{if(it.qty>1)it.qty--;else items.remove(idx);renderItems(box,items,total,commission,shipping,shippingCharge,shippingCost);updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));});plus.setOnClickListener(v->{it.qty++;renderItems(box,items,total,commission,shipping,shippingCharge,shippingCost);updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));});del.setOnClickListener(v->{items.remove(idx);renderItems(box,items,total,commission,shipping,shippingCharge,shippingCost);updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));});r.addView(minus,new LinearLayout.LayoutParams(dp(38),dp(44)));r.addView(plus,new LinearLayout.LayoutParams(dp(38),dp(44)));r.addView(del,new LinearLayout.LayoutParams(dp(38),dp(44)));box.addView(r);sale.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){double v=toD(s.toString());it.salePrice=v;lineTotal.setText(money(v*it.qty)+" DH");updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));}public void afterTextChanged(Editable e){}});if(k<items.size()-1){View line=new View(this);line.setBackgroundColor(BORDER);box.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));}}
    }

    void updateFinancials(TextView total,TextView commission,ArrayList<Store.Item> items,boolean shippingEnabled,double shippingCharge,double shippingCost){double sell=0,productProfit=0;for(Store.Item i:items){sell+=i.salePrice*i.qty;productProfit+=(i.salePrice-i.price)*i.qty;}double customerTotal=sell+(shippingEnabled?shippingCharge:0);double net=productProfit+(shippingEnabled?shippingCharge:0)-(shippingEnabled?shippingCost:0);total.setText("المجموع على الزبون\n"+money(customerTotal)+" DH"+(shippingEnabled?"\nشحن: "+money(shippingCharge)+" DH":"\nاستلام من المتجر — بدون شحن"));commission.setText("صافي ربح الشريك بعد الشحن: "+money(net)+" DH");commission.setTextColor(net>=0?GREEN:RED);}
    void addItem(ArrayList<Store.Item> items,Store.Product p){for(Store.Item it:items)if(it.productId==p.id){it.qty++;return;}items.add(new Store.Item(p.id,p.name,p.price,1));}

    void customerPicker(EditText client,int[] selected,int[] partner){
        EditText s=input("🔎 ابحث عن الزبون");LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);ScrollView sv=new ScrollView(this);sv.addView(list);LinearLayout wrap=new LinearLayout(this);wrap.setOrientation(LinearLayout.VERTICAL);wrap.setPadding(dp(5),dp(5),dp(5),dp(5));wrap.addView(s);wrap.addView(sv,new LinearLayout.LayoutParams(-1,dp(400)));
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle(partner[0]>0?"زبائن الشريك":"اختيار الزبون").setView(wrap).setNegativeButton("إلغاء",null).create();Runnable r=()->{list.removeAllViews();ArrayList<Store.Customer> cs=partner[0]>0?db.partnerCustomers(partner[0],s.getText().toString()):db.customers(s.getText().toString());for(Store.Customer c:cs){if(c.reseller)continue;Button b=button(c.name+"\n"+safe(c.phone)+(c.partnerId>0?" • تابع لشريك":""));b.setOnClickListener(v->{client.setText(c.name);selected[0]=c.id;dlg.dismiss();});list.addView(b);}};watch(s,r);r.run();dlg.show();
    }
    void showSettings(){
        base("الإعدادات");
        LinearLayout c=card();
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.logo_mge);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);c.addView(logo,new LinearLayout.LayoutParams(-1,dp(82)));
        EditText name=input("اسم الشركة");name.setText(db.get("company_name","MGE"));
        EditText phone=input("هاتف الشركة");phone.setText(db.get("phone","+212666964731"));
        EditText footer=input("نص أسفل الفاتورة");footer.setText(db.get("footer","Merci pour votre confiance"));
        c.addView(name,margin(-1,dp(48),0,dp(7)));c.addView(phone,margin(-1,dp(48),0,dp(7)));c.addView(footer,margin(-1,dp(48),0,dp(8)));
        Button save=button("حفظ الإعدادات");save.setTextColor(Color.WHITE);save.setBackground(solid(GREEN,12));
        save.setOnClickListener(v->{db.put("company_name",name.getText().toString());db.put("phone",phone.getText().toString());db.put("footer",footer.getText().toString());Toast.makeText(this,"تم حفظ الإعدادات",Toast.LENGTH_SHORT).show();});
        c.addView(save,new LinearLayout.LayoutParams(-1,dp(52)));
        body.addView(c,margin(-1,-2,0,dp(10)));
        body.addView(text("سيظهر اسم الشركة ورقم الهاتف في ملف PDF.",13,MUTED));
    }

    void makePdf(int id){
        Store.Invoice inv=db.invoice(id);if(inv==null)return;
        PdfDocument doc=new PdfDocument();PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());Canvas c=page.getCanvas();Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(Color.WHITE);c.drawPaint(p);
        p.setColor(Color.BLACK);c.drawRect(40,35,145,90,p);p.setColor(Color.WHITE);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(25);c.drawText("MGE",66,71,p);
        p.setColor(TEXT);p.setTextSize(21);c.drawText("FACTURE / فاتورة",305,65,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(12);c.drawText("Tel : "+db.get("phone","+212666964731"),40,110,p);c.drawText("N° : "+inv.id,40,132,p);c.drawText("Date : "+inv.date,40,154,p);c.drawText("Client : "+inv.client,40,176,p);
        if(inv.clientId>0){Store.Customer cu=db.customer(inv.clientId);if(cu!=null){c.drawText("Tel : "+safe(cu.phone),300,176,p);c.drawText("Ville : "+safe(cu.city),40,196,p);c.drawText("Adresse : "+safe(cu.address),300,196,p);}}
        p.setColor(inv.paid?GREEN:RED);p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText(inv.paid?"Statut : PAYÉE / مدفوعة":"Statut : NON PAYÉE / غير مدفوعة",40,222,p);
        if(inv.trackingNumber!=null&&!inv.trackingNumber.isEmpty()){p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT);c.drawText("Suivi / التتبع : "+inv.trackingNumber+" • "+(inv.deliveryReceived?"REÇU / تم الاستلام":"NON REÇU / لم يتم الاستلام"),300,222,p);}
        p.setColor(BLUE);c.drawRect(40,242,555,278,p);p.setColor(Color.WHITE);p.setTextSize(11);p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("Produit / البيان",48,265,p);c.drawText("Qté",270,265,p);c.drawText("Prix",390,265,p);c.drawText("Total",490,265,p);
        p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT);int y=305;double total=0;
        for(Store.Item it:inv.items){double z=it.salePrice*it.qty;total+=z;c.drawText(trim(it.name,31),48,y,p);c.drawText(""+it.qty,270,y,p);c.drawText(money(it.salePrice),390,y,p);c.drawText(money(z),490,y,p);y+=31;p.setColor(BORDER);c.drawLine(40,y-15,555,y-15,p);p.setColor(TEXT);}
        if(inv.shippingEnabled){p.setColor(BLUE);c.drawText("Frais de livraison / مصاريف الشحن",300,y+12,p);c.drawText(money(inv.shippingCharge)+" DH",490,y+12,p);y+=34;total+=inv.shippingCharge;}
        p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(15);c.drawText("TOTAL : "+money(total)+" DH",385,y+25,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(13);c.drawText(db.get("footer","Merci pour votre confiance"),215,y+65,p);
        doc.finishPage(page);
        try{byte[] pdfBytes;ByteArrayOutputStream buffer=new ByteArrayOutputStream();doc.writeTo(buffer);doc.close();pdfBytes=buffer.toByteArray();String fileName="Facture_"+id+".pdf";Uri uri=null;if(Build.VERSION.SDK_INT>=29){ContentValues values=new ContentValues();values.put(MediaStore.Downloads.DISPLAY_NAME,fileName);values.put(MediaStore.Downloads.MIME_TYPE,"application/pdf");values.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/FactureSimple");uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new IOException("تعذر إنشاء ملف PDF في Downloads");try(OutputStream out=getContentResolver().openOutputStream(uri)){out.write(pdfBytes);}}else{File dir=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS+"/FactureSimple");if(!dir.exists()&&!dir.mkdirs())throw new IOException("تعذر إنشاء مجلد Downloads");File f=new File(dir,fileName);try(OutputStream out=new FileOutputStream(f)){out.write(pdfBytes);}uri=Uri.fromFile(f);}Intent share=new Intent(Intent.ACTION_SEND);share.setType("application/pdf");share.putExtra(Intent.EXTRA_STREAM,uri);share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);share.setClipData(ClipData.newRawUri("PDF",uri));startActivity(Intent.createChooser(share,"إرسال الفاتورة PDF"));Toast.makeText(this,"تم حفظ الفاتورة في Download/FactureSimple",Toast.LENGTH_LONG).show();}catch(Exception e){try{doc.close();}catch(Exception ignored){}Toast.makeText(this,"خطأ PDF: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }

    void watch(EditText e,final Runnable r){e.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){r.run();}public void afterTextChanged(Editable e){}});}
    void loadImage(ImageView v,String uri){try{if(uri!=null&&!uri.isEmpty())v.setImageURI(Uri.parse(uri));else v.setImageResource(R.drawable.ic_product);}catch(Exception e){v.setImageResource(R.drawable.ic_product);}}
    LinearLayout.LayoutParams margin(int w,int h,int l,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(l,0,0,b);return p;}
    double sum(ArrayList<Store.Item> a){double x=0;for(Store.Item i:a)x+=i.price*i.qty;return x;}
    double toD(String s){try{return Double.parseDouble(s.replace(",","."));}catch(Exception e){return 0;}}
    String money(double x){return String.format(Locale.US,"%.2f",x);}
    String safe(String s){return s==null?"":s;}
    String trim(String s,int n){s=safe(s);return s.length()>n?s.substring(0,n-1)+"…":s;}

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==9001&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
            Uri u=data.getData();
            try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
            if(pendingImageField!=null)pendingImageField.setText(u.toString());
        }
    }
}
