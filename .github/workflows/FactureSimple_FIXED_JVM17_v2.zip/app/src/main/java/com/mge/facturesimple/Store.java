package com.mge.facturesimple;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class Store extends SQLiteOpenHelper {
    private static final String DB_NAME = "facturesimple.db";
    private static final int DB_VERSION = 4;

    public Store(Context c) { super(c, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT)");
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,code TEXT,price REAL,image TEXT)");
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,city TEXT,address TEXT,reseller INTEGER DEFAULT 0,partner_id INTEGER DEFAULT 0,default_shipping REAL DEFAULT 30)");
        db.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,client_id INTEGER,client TEXT,date TEXT,paid INTEGER DEFAULT 0,reseller INTEGER DEFAULT 0,delivery_received INTEGER DEFAULT 0,tracking_number TEXT,commission REAL DEFAULT 0,partner_id INTEGER DEFAULT 0,shipping_enabled INTEGER DEFAULT 0,shipping_charge REAL DEFAULT 0,shipping_cost REAL DEFAULT 0,partner_profit_paid INTEGER DEFAULT 0)");
        db.execSQL("CREATE TABLE invoice_items(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER,product_id INTEGER,name TEXT,price REAL,qty INTEGER,sale_price REAL)");
        put(db,"company_name","MGE");
        put(db,"phone","+212666964731");
        put(db,"footer","Merci pour votre confiance");
        put(db,"default_shipping","30");
    }

    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion) {
        if(oldVersion < 2){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN reseller INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE customers ADD COLUMN reseller INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN delivery_received INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN tracking_number TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN commission REAL DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoice_items ADD COLUMN sale_price REAL"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE invoice_items SET sale_price=price WHERE sale_price IS NULL OR sale_price=0"); }catch(Exception ignored){}
        }
        if(oldVersion < 3){
            try{ db.execSQL("ALTER TABLE customers ADD COLUMN partner_id INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE customers ADD COLUMN default_shipping REAL DEFAULT 30"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN partner_id INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN shipping_enabled INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN shipping_charge REAL DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN shipping_cost REAL DEFAULT 0"); }catch(Exception ignored){}
        }
        if(oldVersion < 4){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN partner_profit_paid INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE invoices SET partner_profit_paid=0 WHERE partner_profit_paid IS NULL"); }catch(Exception ignored){}
        }
    }

    private void put(SQLiteDatabase db,String k,String v){ ContentValues x=new ContentValues();x.put("k",k);x.put("v",v);db.insertWithOnConflict("settings",null,x,SQLiteDatabase.CONFLICT_REPLACE); }
    public void put(String k,String v){put(getWritableDatabase(),k,v);}
    public String get(String k,String def){Cursor c=getReadableDatabase().query("settings",new String[]{"v"},"k=?",new String[]{k},null,null,null);try{return c.moveToFirst()?c.getString(0):def;}finally{c.close();}}

    public static class Product { public int id;public String name,code,image;public double price; Product(int i,String n,String c,double p,String im){id=i;name=n;code=c;price=p;image=im;} }
    public static class Customer {
        public int id,partnerId;public String name,phone,city,address;public boolean reseller;public double defaultShipping;
        Customer(int i,String n,String p,String c,String a,boolean r,int pi,double ds){id=i;name=n;phone=p;city=c;address=a;reseller=r;partnerId=pi;defaultShipping=ds;}
    }
    public static class Item { public int productId,qty;public String name;public double price,salePrice;public Item(int pid,String n,double p,int q){productId=pid;name=n;price=p;qty=q;salePrice=p;}public Item(int pid,String n,double p,double sp,int q){productId=pid;name=n;price=p;salePrice=sp;qty=q;} }
    public static class Invoice {
        public int id,clientId,partnerId;public String client,date,trackingNumber;public boolean paid,reseller,deliveryReceived,shippingEnabled,partnerProfitPaid;public double commission,shippingCharge,shippingCost;public ArrayList<Item> items=new ArrayList<>();
        Invoice(int i,int ci,String cl,String d,boolean p){id=i;clientId=ci;client=cl;date=d;paid=p;}
    }

    public ArrayList<Product> products(String q){ArrayList<Product>a=new ArrayList<>();q=q==null?"":q.trim();Cursor c=getReadableDatabase().query("products",null,q.isEmpty()?null:"name LIKE ? OR code LIKE ?",q.isEmpty()?null:new String[]{"%"+q+"%","%"+q+"%"},null,null,"name COLLATE NOCASE ASC");try{while(c.moveToNext())a.add(new Product(c.getInt(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("name")),c.getString(c.getColumnIndexOrThrow("code")),c.getDouble(c.getColumnIndexOrThrow("price")),c.getString(c.getColumnIndexOrThrow("image"))));}finally{c.close();}return a;}
    public Product product(int id){Cursor c=getReadableDatabase().query("products",null,"id=?",new String[]{""+id},null,null,null);try{if(!c.moveToFirst())return null;return new Product(c.getInt(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("name")),c.getString(c.getColumnIndexOrThrow("code")),c.getDouble(c.getColumnIndexOrThrow("price")),c.getString(c.getColumnIndexOrThrow("image")));}finally{c.close();}}
    public void saveProduct(int id,String name,String code,double price,String image){ContentValues v=new ContentValues();v.put("name",name);v.put("code",code);v.put("price",price);v.put("image",image);if(id<0)getWritableDatabase().insert("products",null,v);else getWritableDatabase().update("products",v,"id=?",new String[]{""+id});}
    public void deleteProduct(int id){getWritableDatabase().delete("products","id=?",new String[]{""+id});}

    private Customer readCustomer(Cursor c){return new Customer(c.getInt(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("name")),c.getString(c.getColumnIndexOrThrow("phone")),c.getString(c.getColumnIndexOrThrow("city")),c.getString(c.getColumnIndexOrThrow("address")),c.getInt(c.getColumnIndexOrThrow("reseller"))==1,c.getInt(c.getColumnIndexOrThrow("partner_id")),c.getDouble(c.getColumnIndexOrThrow("default_shipping")));}
    public ArrayList<Customer> customers(String q){ArrayList<Customer>a=new ArrayList<>();q=q==null?"":q.trim();Cursor c=getReadableDatabase().query("customers",null,q.isEmpty()?null:"name LIKE ? OR phone LIKE ? OR city LIKE ?",q.isEmpty()?null:new String[]{"%"+q+"%","%"+q+"%","%"+q+"%"},null,null,"name COLLATE NOCASE ASC");try{while(c.moveToNext())a.add(readCustomer(c));}finally{c.close();}return a;}
    public ArrayList<Customer> partnerCustomers(int partnerId,String q){ArrayList<Customer>a=new ArrayList<>();q=q==null?"":q.trim();String where="partner_id=? AND reseller=0";ArrayList<String>args=new ArrayList<>();args.add(""+partnerId);if(!q.isEmpty()){where+=" AND (name LIKE ? OR phone LIKE ? OR city LIKE ?)";args.add("%"+q+"%");args.add("%"+q+"%");args.add("%"+q+"%");}Cursor c=getReadableDatabase().query("customers",null,where,args.toArray(new String[0]),null,null,"name COLLATE NOCASE ASC");try{while(c.moveToNext())a.add(readCustomer(c));}finally{c.close();}return a;}
    public Customer customer(int id){Cursor c=getReadableDatabase().query("customers",null,"id=?",new String[]{""+id},null,null,null);try{if(!c.moveToFirst())return null;return readCustomer(c);}finally{c.close();}}
    public void saveCustomer(int id,String name,String phone,String city,String address,boolean reseller,int partnerId,double defaultShipping){ContentValues v=new ContentValues();v.put("name",name);v.put("phone",phone);v.put("city",city);v.put("address",address);v.put("reseller",reseller?1:0);v.put("partner_id",reseller?0:partnerId);v.put("default_shipping",reseller?defaultShipping:30);if(id<0)getWritableDatabase().insert("customers",null,v);else getWritableDatabase().update("customers",v,"id=?",new String[]{""+id});}
    public void deleteCustomer(int id){getWritableDatabase().delete("customers","id=?",new String[]{""+id});}

    private Invoice readInvoice(Cursor c){Invoice i=new Invoice(c.getInt(c.getColumnIndexOrThrow("id")),c.getInt(c.getColumnIndexOrThrow("client_id")),c.getString(c.getColumnIndexOrThrow("client")),c.getString(c.getColumnIndexOrThrow("date")),c.getInt(c.getColumnIndexOrThrow("paid"))==1);i.reseller=c.getInt(c.getColumnIndexOrThrow("reseller"))==1;i.deliveryReceived=c.getInt(c.getColumnIndexOrThrow("delivery_received"))==1;i.trackingNumber=c.getString(c.getColumnIndexOrThrow("tracking_number"));i.commission=c.getDouble(c.getColumnIndexOrThrow("commission"));i.partnerId=c.getInt(c.getColumnIndexOrThrow("partner_id"));i.shippingEnabled=c.getInt(c.getColumnIndexOrThrow("shipping_enabled"))==1;i.shippingCharge=c.getDouble(c.getColumnIndexOrThrow("shipping_charge"));i.shippingCost=c.getDouble(c.getColumnIndexOrThrow("shipping_cost"));i.partnerProfitPaid=c.getInt(c.getColumnIndexOrThrow("partner_profit_paid"))==1;loadItems(i);return i;}
    public ArrayList<Invoice> invoices(String q){ArrayList<Invoice>a=new ArrayList<>();q=q==null?"":q.trim();Cursor c=getReadableDatabase().query("invoices",null,q.isEmpty()?null:"CAST(id AS TEXT) LIKE ? OR client LIKE ?",q.isEmpty()?null:new String[]{"%"+q+"%","%"+q+"%"},null,null,"id DESC");try{while(c.moveToNext())a.add(readInvoice(c));}finally{c.close();}return a;}
    public Invoice invoice(int id){Cursor c=getReadableDatabase().query("invoices",null,"id=?",new String[]{""+id},null,null,null);try{if(!c.moveToFirst())return null;return readInvoice(c);}finally{c.close();}}
    private void loadItems(Invoice i){Cursor c=getReadableDatabase().query("invoice_items",null,"invoice_id=?",new String[]{""+i.id},null,null,"id ASC");try{while(c.moveToNext())i.items.add(new Item(c.getInt(c.getColumnIndexOrThrow("product_id")),c.getString(c.getColumnIndexOrThrow("name")),c.getDouble(c.getColumnIndexOrThrow("price")),c.getDouble(c.getColumnIndexOrThrow("sale_price")),c.getInt(c.getColumnIndexOrThrow("qty"))));}finally{c.close();}}

    public void saveInvoice(int id,int clientId,String client,boolean paid,int partnerId,boolean shippingEnabled,double shippingCharge,double shippingCost,String trackingNumber,boolean deliveryReceived,boolean partnerProfitPaid,ArrayList<Item> items){
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{
            boolean reseller=partnerId>0;double productProfit=0;for(Item it:items)productProfit+=(it.salePrice-it.price)*it.qty;double netProfit=reseller?(productProfit+(shippingEnabled?shippingCharge:0)-(shippingEnabled?shippingCost:0)):0;
            ContentValues v=new ContentValues();v.put("client_id",clientId);v.put("client",client);v.put("date",new SimpleDateFormat("dd/MM/yyyy",Locale.US).format(new Date()));v.put("paid",paid?1:0);v.put("reseller",reseller?1:0);v.put("partner_id",partnerId);v.put("shipping_enabled",shippingEnabled?1:0);v.put("shipping_charge",shippingEnabled?shippingCharge:0);v.put("shipping_cost",shippingEnabled?shippingCost:0);v.put("tracking_number",trackingNumber);v.put("delivery_received",deliveryReceived?1:0);v.put("commission",netProfit);v.put("partner_profit_paid",partnerProfitPaid?1:0);
            long invoiceId;if(id<0)invoiceId=db.insert("invoices",null,v);else{db.update("invoices",v,"id=?",new String[]{""+id});invoiceId=id;db.delete("invoice_items","invoice_id=?",new String[]{""+id});}
            for(Item it:items){ContentValues x=new ContentValues();x.put("invoice_id",invoiceId);x.put("product_id",it.productId);x.put("name",it.name);x.put("price",it.price);x.put("qty",it.qty);x.put("sale_price",it.salePrice);db.insert("invoice_items",null,x);}db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }
    public void setPartnerProfitPaid(int invoiceId,boolean paid){ContentValues v=new ContentValues();v.put("partner_profit_paid",paid?1:0);getWritableDatabase().update("invoices",v,"id=?",new String[]{""+invoiceId});}
    public void deleteInvoice(int id){SQLiteDatabase db=getWritableDatabase();db.delete("invoice_items","invoice_id=?",new String[]{""+id});db.delete("invoices","id=?",new String[]{""+id});}
}
