package com.mge.facturesimple;
import android.content.*;import android.database.sqlite.*;import java.text.*;import java.util.*;

public class Store {
 SQLiteDatabase d;
 Store(Context c){d=c.openOrCreateDatabase("facturesimple.db",0,null);
  d.execSQL("CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,code TEXT,price REAL)");
  d.execSQL("CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT,city TEXT,address TEXT)");
  d.execSQL("CREATE TABLE IF NOT EXISTS invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,client TEXT,paid INTEGER,date TEXT)");
  d.execSQL("CREATE TABLE IF NOT EXISTS items(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER,name TEXT,price REAL,qty INTEGER)");
  d.execSQL("CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT)");
  if(products("").isEmpty()){saveProduct(-1,"Cable moteur Xiaomi","CM-XIAOMI",50);saveProduct(-1,"BMS 10S 36V 30A","BMS-10S-30A",110);saveProduct(-1,"Chargeur 42V 2A","CH-42V-2A",120);saveProduct(-1,"Poignée Xiaomi M365","PG-M365",30);saveProduct(-1,"Pneu 10x2.50 Tubeless","PN-10X2.50",140);}
 }
 public String get(String k,String def){android.database.Cursor c=d.rawQuery("SELECT v FROM settings WHERE k=?",new String[]{k});try{if(c.moveToFirst())return c.getString(0);return def;}finally{c.close();}}
 public void put(String k,String v){d.execSQL("INSERT OR REPLACE INTO settings(k,v) VALUES(?,?)",new Object[]{k,v});}
 public static class Product{int id;String name,code;double price;Product(int i,String n,String c,double p){id=i;name=n;code=c;price=p;}}
 public ArrayList<Product> products(String q){ArrayList<Product>a=new ArrayList<>();android.database.Cursor c=d.rawQuery("SELECT id,name,code,price FROM products WHERE name LIKE ? OR code LIKE ? ORDER BY name",new String[]{"%"+q+"%","%"+q+"%"});while(c.moveToNext())a.add(new Product(c.getInt(0),c.getString(1),c.getString(2),c.getDouble(3)));c.close();return a;}
 public Product product(int id){for(Product p:products(""))if(p.id==id)return p;return null;}
 public void saveProduct(int id,String n,String code,double price){if(id<0)d.execSQL("INSERT INTO products(name,code,price) VALUES(?,?,?)",new Object[]{n,code,price});else d.execSQL("UPDATE products SET name=?,code=?,price=? WHERE id=?",new Object[]{n,code,price,id});}
 public void deleteProduct(int id){d.execSQL("DELETE FROM products WHERE id=?",new Object[]{id});}
 public static class Customer{int id;String name,phone,city,address;Customer(int i,String n,String p,String c,String a){id=i;name=n;phone=p;city=c;address=a;}}
 public ArrayList<Customer> customers(String q){ArrayList<Customer>a=new ArrayList<>();android.database.Cursor c=d.rawQuery("SELECT id,name,phone,city,address FROM customers WHERE name LIKE ? OR phone LIKE ? ORDER BY name",new String[]{"%"+q+"%","%"+q+"%"});while(c.moveToNext())a.add(new Customer(c.getInt(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4)));c.close();return a;}
 public Customer customer(int id){for(Customer x:customers(""))if(x.id==id)return x;return null;}
 public void saveCustomer(int id,String n,String p,String city,String a){if(id<0)d.execSQL("INSERT INTO customers(name,phone,city,address) VALUES(?,?,?,?)",new Object[]{n,p,city,a});else d.execSQL("UPDATE customers SET name=?,phone=?,city=?,address=? WHERE id=?",new Object[]{n,p,city,a,id});}
 public static class Item{String name;double price;int qty;Item(String n,double p,int q){name=n;price=p;qty=q;}}
 public static class Invoice{int id;String client,date;boolean paid;ArrayList<Item>items=new ArrayList<>();}
 public ArrayList<Invoice> invoices(String q){ArrayList<Invoice>a=new ArrayList<>();android.database.Cursor c=d.rawQuery("SELECT id,client,paid,date FROM invoices WHERE CAST(id AS TEXT) LIKE ? OR client LIKE ? ORDER BY id DESC",new String[]{"%"+q+"%","%"+q+"%"});while(c.moveToNext()){Invoice i=new Invoice();i.id=c.getInt(0);i.client=c.getString(1);i.paid=c.getInt(2)==1;i.date=c.getString(3);loadItems(i);a.add(i);}c.close();return a;}
 public Invoice invoice(int id){for(Invoice i:invoices(""))if(i.id==id)return i;return null;}
 void loadItems(Invoice i){android.database.Cursor c=d.rawQuery("SELECT name,price,qty FROM items WHERE invoice_id=?",new String[]{""+i.id});while(c.moveToNext())i.items.add(new Item(c.getString(0),c.getDouble(1),c.getInt(2)));c.close();}
 public void saveInvoice(int id,String client,boolean paid,ArrayList<Item>items){String date=new SimpleDateFormat("dd/MM/yyyy",Locale.US).format(new Date());if(id<0){d.execSQL("INSERT INTO invoices(client,paid,date) VALUES(?,?,?)",new Object[]{client,paid?1:0,date});android.database.Cursor c=d.rawQuery("SELECT last_insert_rowid()",null);c.moveToFirst();id=c.getInt(0);c.close();}else{d.execSQL("UPDATE invoices SET client=?,paid=?,date=? WHERE id=?",new Object[]{client,paid?1:0,date,id});d.execSQL("DELETE FROM items WHERE invoice_id=?",new Object[]{id});}for(Item x:items)d.execSQL("INSERT INTO items(invoice_id,name,price,qty) VALUES(?,?,?,?)",new Object[]{id,x.name,x.price,x.qty});}
}
