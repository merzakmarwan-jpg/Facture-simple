package com.mge.facturesimple;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class Store extends SQLiteOpenHelper {
    private static final String DB_NAME = "facturesimple.db";
    private static final int DB_VERSION = 1;

    public Store(Context c) { super(c, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT)");
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,code TEXT,price REAL,image TEXT)");
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,city TEXT,address TEXT)");
        db.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,client_id INTEGER,client TEXT,date TEXT,paid INTEGER DEFAULT 0)");
        db.execSQL("CREATE TABLE invoice_items(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER,product_id INTEGER,name TEXT,price REAL,qty INTEGER)");
        put(db,"company_name","MGE");
        put(db,"phone","+212666964731");
        put(db,"footer","Merci pour votre confiance");
    }

    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion) {}

    private void put(SQLiteDatabase db,String k,String v){
        ContentValues x=new ContentValues(); x.put("k",k); x.put("v",v);
        db.insertWithOnConflict("settings",null,x,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public void put(String k,String v){ SQLiteDatabase db=getWritableDatabase(); put(db,k,v); }
    public String get(String k,String def){
        Cursor c=getReadableDatabase().query("settings",new String[]{"v"},"k=?",new String[]{k},null,null,null);
        try { return c.moveToFirst()?c.getString(0):def; } finally { c.close(); }
    }

    public static class Product {
        public int id; public String name,code,image; public double price;
        Product(int i,String n,String c,double p,String im){id=i;name=n;code=c;price=p;image=im;}
    }
    public static class Customer {
        public int id; public String name,phone,city,address;
        Customer(int i,String n,String p,String c,String a){id=i;name=n;phone=p;city=c;address=a;}
    }
    public static class Item {
        public int productId,qty; public String name; public double price;
        public Item(int pid,String n,double p,int q){productId=pid;name=n;price=p;qty=q;}
    }
    public static class Invoice {
        public int id; public String client,date; public boolean paid; public int clientId;
        public ArrayList<Item> items=new ArrayList<>();
        Invoice(int i,int ci,String cl,String d,boolean p){id=i;clientId=ci;client=cl;date=d;paid=p;}
    }

    public ArrayList<Product> products(String q){
        ArrayList<Product> a=new ArrayList<>();
        q=q==null?"":q.trim();
        Cursor c=getReadableDatabase().query("products",null,
                q.isEmpty()?null:"name LIKE ? OR code LIKE ?",
                q.isEmpty()?null:new String[]{"%"+q+"%","%"+q+"%"},
                null,null,"name COLLATE NOCASE ASC");
        try {
            while(c.moveToNext()) a.add(new Product(c.getInt(c.getColumnIndexOrThrow("id")),
                    c.getString(c.getColumnIndexOrThrow("name")),
                    c.getString(c.getColumnIndexOrThrow("code")),
                    c.getDouble(c.getColumnIndexOrThrow("price")),
                    c.getString(c.getColumnIndexOrThrow("image"))));
        } finally { c.close(); }
        return a;
    }

    public Product product(int id){
        Cursor c=getReadableDatabase().query("products",null,"id=?",new String[]{""+id},null,null,null);
        try {
            if(!c.moveToFirst()) return null;
            return new Product(c.getInt(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("name")),
                    c.getString(c.getColumnIndexOrThrow("code")),c.getDouble(c.getColumnIndexOrThrow("price")),
                    c.getString(c.getColumnIndexOrThrow("image")));
        } finally {c.close();}
    }

    public void saveProduct(int id,String name,String code,double price,String image){
        ContentValues v=new ContentValues(); v.put("name",name);v.put("code",code);v.put("price",price);v.put("image",image);
        if(id<0)getWritableDatabase().insert("products",null,v);
        else getWritableDatabase().update("products",v,"id=?",new String[]{""+id});
    }
    public void deleteProduct(int id){getWritableDatabase().delete("products","id=?",new String[]{""+id});}

    public ArrayList<Customer> customers(String q){
        ArrayList<Customer> a=new ArrayList<>(); q=q==null?"":q.trim();
        Cursor c=getReadableDatabase().query("customers",null,
                q.isEmpty()?null:"name LIKE ? OR phone LIKE ? OR city LIKE ?",
                q.isEmpty()?null:new String[]{"%"+q+"%","%"+q+"%","%"+q+"%"},
                null,null,"name COLLATE NOCASE ASC");
        try {
            while(c.moveToNext()) a.add(new Customer(c.getInt(c.getColumnIndexOrThrow("id")),
                    c.getString(c.getColumnIndexOrThrow("name")),c.getString(c.getColumnIndexOrThrow("phone")),
                    c.getString(c.getColumnIndexOrThrow("city")),c.getString(c.getColumnIndexOrThrow("address"))));
        } finally {c.close();}
        return a;
    }
    public Customer customer(int id){
        Cursor c=getReadableDatabase().query("customers",null,"id=?",new String[]{""+id},null,null,null);
        try{
            if(!c.moveToFirst())return null;
            return new Customer(c.getInt(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("name")),
                    c.getString(c.getColumnIndexOrThrow("phone")),c.getString(c.getColumnIndexOrThrow("city")),
                    c.getString(c.getColumnIndexOrThrow("address")));
        }finally{c.close();}
    }
    public void saveCustomer(int id,String name,String phone,String city,String address){
        ContentValues v=new ContentValues();v.put("name",name);v.put("phone",phone);v.put("city",city);v.put("address",address);
        if(id<0)getWritableDatabase().insert("customers",null,v);
        else getWritableDatabase().update("customers",v,"id=?",new String[]{""+id});
    }
    public void deleteCustomer(int id){getWritableDatabase().delete("customers","id=?",new String[]{""+id});}

    public ArrayList<Invoice> invoices(String q){
        ArrayList<Invoice>a=new ArrayList<>();q=q==null?"":q.trim();
        Cursor c=getReadableDatabase().query("invoices",null,
                q.isEmpty()?null:"CAST(id AS TEXT) LIKE ? OR client LIKE ?",
                q.isEmpty()?null:new String[]{"%"+q+"%","%"+q+"%"},
                null,null,"id DESC");
        try{
            while(c.moveToNext()){
                Invoice i=new Invoice(c.getInt(c.getColumnIndexOrThrow("id")),
                        c.getInt(c.getColumnIndexOrThrow("client_id")),
                        c.getString(c.getColumnIndexOrThrow("client")),
                        c.getString(c.getColumnIndexOrThrow("date")),
                        c.getInt(c.getColumnIndexOrThrow("paid"))==1);
                loadItems(i);a.add(i);
            }
        }finally{c.close();}
        return a;
    }

    public Invoice invoice(int id){
        Cursor c=getReadableDatabase().query("invoices",null,"id=?",new String[]{""+id},null,null,null);
        try{
            if(!c.moveToFirst())return null;
            Invoice i=new Invoice(c.getInt(c.getColumnIndexOrThrow("id")),c.getInt(c.getColumnIndexOrThrow("client_id")),
                    c.getString(c.getColumnIndexOrThrow("client")),c.getString(c.getColumnIndexOrThrow("date")),
                    c.getInt(c.getColumnIndexOrThrow("paid"))==1);
            loadItems(i);return i;
        }finally{c.close();}
    }

    private void loadItems(Invoice i){
        Cursor c=getReadableDatabase().query("invoice_items",null,"invoice_id=?",new String[]{""+i.id},null,null,"id ASC");
        try{
            while(c.moveToNext())i.items.add(new Item(c.getInt(c.getColumnIndexOrThrow("product_id")),
                    c.getString(c.getColumnIndexOrThrow("name")),c.getDouble(c.getColumnIndexOrThrow("price")),
                    c.getInt(c.getColumnIndexOrThrow("qty"))));
        }finally{c.close();}
    }

    public void saveInvoice(int id,int clientId,String client,boolean paid,ArrayList<Item> items){
        SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try{
            ContentValues v=new ContentValues();v.put("client_id",clientId);v.put("client",client);
            v.put("date",new SimpleDateFormat("dd/MM/yyyy",Locale.US).format(new Date()));v.put("paid",paid?1:0);
            long invoiceId;
            if(id<0) invoiceId=db.insert("invoices",null,v);
            else {db.update("invoices",v,"id=?",new String[]{""+id});invoiceId=id;db.delete("invoice_items","invoice_id=?",new String[]{""+id});}
            for(Item it:items){
                ContentValues x=new ContentValues();x.put("invoice_id",invoiceId);x.put("product_id",it.productId);
                x.put("name",it.name);x.put("price",it.price);x.put("qty",it.qty);db.insert("invoice_items",null,x);
            }
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }
    public void deleteInvoice(int id){
        SQLiteDatabase db=getWritableDatabase();db.delete("invoice_items","invoice_id=?",new String[]{""+id});
        db.delete("invoices","id=?",new String[]{""+id});
    }
}
