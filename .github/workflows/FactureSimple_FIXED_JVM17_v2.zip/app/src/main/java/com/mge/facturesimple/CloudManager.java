package com.mge.facturesimple;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/** Firebase authentication + cloud synchronization layer for FactureSimple 3.0. */
public class CloudManager {
    private final Context context;
    private final Store db;
    private final FirebaseAuth auth;
    private final FirebaseFirestore fs;
    private final FirebaseStorage storage;

    public String role = "partner";
    public long partnerId = 0;
    public String displayName = "";

    public CloudManager(Context c, Store store) {
        context = c.getApplicationContext();
        db = store;
        auth = FirebaseAuth.getInstance();
        fs = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();
    }

    public boolean isLoggedIn() { return auth.getCurrentUser() != null; }
    public String uid() { return isLoggedIn() ? auth.getCurrentUser().getUid() : null; }
    public String email() { return isLoggedIn() ? auth.getCurrentUser().getEmail() : null; }
    public boolean isAdmin() { return "admin".equalsIgnoreCase(role); }

    public Task<AuthResult> login(String email, String password) {
        return auth.signInWithEmailAndPassword(email.trim(), password);
    }

    public Task<AuthResult> registerPartner(String email, String password) {
        return auth.createUserWithEmailAndPassword(email.trim(), password);
    }

    public void logout() { auth.signOut(); }

    public Task<Void> saveProfile(String name, String role, long partnerId) {
        Map<String,Object> m = new HashMap<>();
        m.put("name", name);
        m.put("role", role);
        m.put("partnerId", partnerId);
        m.put("email", email());
        return fs.collection("users").document(uid()).set(m);
    }

    public Task<QuerySnapshot> loadProfile() {
        return fs.collection("users").whereEqualTo("uid", uid()).get();
    }

    public void loadProfileAndRun(Runnable done, Runnable failed) {
        if (!isLoggedIn()) { if (failed != null) failed.run(); return; }
        fs.collection("users").document(uid()).get().addOnSuccessListener(doc -> {
            if (doc.exists()) {
                role = doc.getString("role") == null ? "partner" : doc.getString("role");
                Long p = doc.getLong("partnerId"); partnerId = p == null ? 0 : p;
                displayName = doc.getString("name") == null ? "" : doc.getString("name");
                if (done != null) done.run();
            } else if (failed != null) failed.run();
        }).addOnFailureListener(e -> { if (failed != null) failed.run(); });
    }

    public void syncLocalToCloud(final Runnable done, final Runnable failed) {
        if (!isLoggedIn() || !isAdmin()) { if (failed != null) failed.run(); return; }
        syncProducts(done, failed);
    }

    private void syncProducts(Runnable done, Runnable failed) {
        android.database.Cursor c = db.getReadableDatabase().query("products", null, null, null, null, null, "id ASC");
        final int[] remaining = {0};
        try {
            while (c.moveToNext()) {
                remaining[0]++;
                int id=c.getInt(c.getColumnIndexOrThrow("id"));
                Map<String,Object> m=new HashMap<>();
                m.put("name",c.getString(c.getColumnIndexOrThrow("name")));
                m.put("code",c.getString(c.getColumnIndexOrThrow("code")));
                m.put("price",c.getDouble(c.getColumnIndexOrThrow("price")));
                m.put("image",c.getString(c.getColumnIndexOrThrow("image")));
                m.put("updatedAt",System.currentTimeMillis());
                fs.collection("products").document(String.valueOf(id)).set(m)
                    .addOnSuccessListener(v -> { if (--remaining[0] == 0) syncCustomers(done,failed); })
                    .addOnFailureListener(e -> { if (failed != null) failed.run(); });
                uploadProductImage(id,c.getString(c.getColumnIndexOrThrow("image")));
            }
        } finally { c.close(); }
        if (remaining[0] == 0) syncCustomers(done,failed);
    }

    private void uploadProductImage(int productId, String image) {
        if (TextUtils.isEmpty(image)) return;
        try {
            Uri uri = image.startsWith("content://") || image.startsWith("file://") ? Uri.parse(image) : Uri.fromFile(new File(image));
            InputStream in = context.getContentResolver().openInputStream(uri);
            if (in == null) return;
            StorageReference ref = storage.getReference().child("products/"+productId+"/main.jpg");
            ref.putStream(in).addOnCompleteListener(t -> { try { in.close(); } catch(Exception ignored){} });
        } catch(Exception ignored) {}
    }

    private void syncCustomers(Runnable done, Runnable failed) {
        android.database.Cursor c=db.getReadableDatabase().query("customers",null,null,null,null,null,"id ASC");
        final int[] remaining={0};
        try { while(c.moveToNext()){
            remaining[0]++;
            int id=c.getInt(c.getColumnIndexOrThrow("id")); Map<String,Object> m=new HashMap<>();
            m.put("name",c.getString(c.getColumnIndexOrThrow("name"))); m.put("phone",c.getString(c.getColumnIndexOrThrow("phone")));
            m.put("city",c.getString(c.getColumnIndexOrThrow("city"))); m.put("address",c.getString(c.getColumnIndexOrThrow("address")));
            m.put("reseller",c.getInt(c.getColumnIndexOrThrow("reseller"))==1); m.put("partnerId",c.getInt(c.getColumnIndexOrThrow("partner_id")));
            m.put("defaultShipping",c.getDouble(c.getColumnIndexOrThrow("default_shipping")));
            fs.collection("customers").document(String.valueOf(id)).set(m).addOnSuccessListener(v->{if(--remaining[0]==0)syncInvoices(done,failed);}).addOnFailureListener(e->{if(failed!=null)failed.run();});
        }} finally {c.close();}
        if(remaining[0]==0)syncInvoices(done,failed);
    }

    private void syncInvoices(Runnable done,Runnable failed){
        android.database.Cursor c=db.getReadableDatabase().query("invoices",null,null,null,null,null,"id ASC");
        final int[] remaining={0};
        try{while(c.moveToNext()){
            remaining[0]++; int id=c.getInt(c.getColumnIndexOrThrow("id")); Map<String,Object> m=new HashMap<>();
            String[] cols={"client_id","client","date","paid","reseller","delivery_received","tracking_number","commission","partner_id","shipping_enabled","shipping_charge","shipping_cost","partner_profit_paid","paid_date","delivery_received_date","delivery_failure_reason","partner_profit_paid_date","shipping_company","shipping_account"};
            for(String col:cols){int idx=c.getColumnIndex(col);if(idx<0)continue;Object val;if(c.isNull(idx))val=null;else if(col.equals("client")||col.contains("date")||col.equals("tracking_number")||col.equals("delivery_failure_reason")||col.equals("shipping_company")||col.equals("shipping_account"))val=c.getString(idx);else if(col.equals("commission")||col.equals("shipping_charge")||col.equals("shipping_cost"))val=c.getDouble(idx);else val=c.getInt(idx);m.put(col,val);}
            fs.collection("invoices").document(String.valueOf(id)).set(m).addOnSuccessListener(v->{syncInvoiceItems(id);if(--remaining[0]==0&&done!=null)done.run();}).addOnFailureListener(e->{if(failed!=null)failed.run();});
        }}finally{c.close();}
        if(remaining[0]==0&&done!=null)done.run();
    }
    private void syncInvoiceItems(int invoiceId){
        android.database.Cursor c=db.getReadableDatabase().query("invoice_items",null,"invoice_id=?",new String[]{String.valueOf(invoiceId)},null,null,"id ASC");
        try{while(c.moveToNext()){Map<String,Object> m=new HashMap<>();m.put("productId",c.getInt(c.getColumnIndexOrThrow("product_id")));m.put("name",c.getString(c.getColumnIndexOrThrow("name")));m.put("price",c.getDouble(c.getColumnIndexOrThrow("price")));m.put("salePrice",c.getDouble(c.getColumnIndexOrThrow("sale_price")));m.put("qty",c.getInt(c.getColumnIndexOrThrow("qty")));fs.collection("invoices").document(String.valueOf(invoiceId)).collection("items").document(String.valueOf(c.getInt(c.getColumnIndexOrThrow("id")))).set(m);}}finally{c.close();}
    }
    /** Pull the cloud catalog and the current partner's customers/invoices into local SQLite. */
    public void syncCloudToLocalForPartner(final Runnable done, final Runnable failed) {
        if (!isLoggedIn() || isAdmin() || partnerId <= 0) { if (failed != null) failed.run(); return; }
        fs.collection("products").get().addOnSuccessListener(products -> {
            for (com.google.firebase.firestore.DocumentSnapshot d : products.getDocuments()) {
                ContentValues v=new ContentValues();
                v.put("id", parseInt(d.getId())); v.put("name", str(d.getString("name"))); v.put("code", str(d.getString("code")));
                Double price=d.getDouble("price"); v.put("price", price==null?0:price); v.put("image", str(d.getString("image")));
                db.getWritableDatabase().insertWithOnConflict("products",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);
                final int pid=parseInt(d.getId());
                storage.getReference().child("products/"+pid+"/main.jpg").getDownloadUrl().addOnSuccessListener(url -> {
                    ContentValues x=new ContentValues();x.put("image",url.toString());db.getWritableDatabase().update("products",x,"id=?",new String[]{String.valueOf(pid)});
                });
            }
        }).addOnFailureListener(e->{if(failed!=null)failed.run();});
        fs.collection("customers").whereEqualTo("partnerId", partnerId).get().addOnSuccessListener(customers -> {
            android.database.sqlite.SQLiteDatabase local=db.getWritableDatabase();
            for(com.google.firebase.firestore.DocumentSnapshot d:customers.getDocuments()){
                ContentValues v=new ContentValues();v.put("id",parseInt(d.getId()));v.put("name",str(d.getString("name")));v.put("phone",str(d.getString("phone")));v.put("city",str(d.getString("city")));v.put("address",str(d.getString("address")));v.put("reseller",d.getBoolean("reseller")!=null&&d.getBoolean("reseller")?1:0);v.put("partner_id",partnerId);Double sh=d.getDouble("defaultShipping");v.put("default_shipping",sh==null?30:sh);local.insertWithOnConflict("customers",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);
            }
        }).addOnFailureListener(e->{if(failed!=null)failed.run();});
        fs.collection("invoices").whereEqualTo("partner_id", partnerId).get().addOnSuccessListener(invoices -> {
            android.database.sqlite.SQLiteDatabase local=db.getWritableDatabase();
            for(com.google.firebase.firestore.DocumentSnapshot d:invoices.getDocuments()){
                ContentValues v=new ContentValues();
                v.put("id",parseInt(d.getId()));
                putS(v,"client_id",d.getLong("client_id"));putS(v,"client",d.getString("client"));putS(v,"date",d.getString("date"));
                putB(v,"paid",d.getLong("paid"));putB(v,"reseller",d.getLong("reseller"));putB(v,"delivery_received",d.getLong("delivery_received"));putS(v,"tracking_number",d.getString("tracking_number"));putD(v,"commission",d.getDouble("commission"));putS(v,"partner_id",d.getLong("partner_id"));putB(v,"shipping_enabled",d.getLong("shipping_enabled"));putD(v,"shipping_charge",d.getDouble("shipping_charge"));putD(v,"shipping_cost",d.getDouble("shipping_cost"));putB(v,"partner_profit_paid",d.getLong("partner_profit_paid"));putS(v,"paid_date",d.getString("paid_date"));putS(v,"delivery_received_date",d.getString("delivery_received_date"));putS(v,"delivery_failure_reason",d.getString("delivery_failure_reason"));putS(v,"partner_profit_paid_date",d.getString("partner_profit_paid_date"));putS(v,"shipping_company",d.getString("shipping_company"));putS(v,"shipping_account",d.getString("shipping_account"));
                local.insertWithOnConflict("invoices",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);
                final int invoiceId=parseInt(d.getId());
                d.getReference().collection("items").get().addOnSuccessListener(items->{local.delete("invoice_items","invoice_id=?",new String[]{String.valueOf(invoiceId)});for(com.google.firebase.firestore.DocumentSnapshot it:items.getDocuments()){ContentValues x=new ContentValues();x.put("id",parseInt(it.getId()));x.put("invoice_id",invoiceId);putS(x,"product_id",it.getLong("productId"));putS(x,"name",it.getString("name"));putD(x,"price",it.getDouble("price"));putD(x,"sale_price",it.getDouble("salePrice"));putS(x,"qty",it.getLong("qty"));local.insertWithOnConflict("invoice_items",null,x,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);}});
            }
            if(done!=null)done.run();
        }).addOnFailureListener(e->{if(failed!=null)failed.run();});
    }
    private int parseInt(String s){try{return Integer.parseInt(s);}catch(Exception e){return 0;}}
    private String str(String s){return s==null?"":s;}
    private void putS(ContentValues v,String k,Object o){if(o==null)v.putNull(k);else if(o instanceof Number)v.put(k,((Number)o).longValue());else v.put(k,String.valueOf(o));}
    private void putD(ContentValues v,String k,Double o){if(o==null)v.put(k,0d);else v.put(k,o);}
    private void putB(ContentValues v,String k,Long o){v.put(k,o!=null&&o!=0?1:0);}

}
