package com.mge.facturesimple;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.firestore.Source;
import com.google.firebase.firestore.WriteBatch;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import android.os.Handler;
import android.os.Looper;

/** Firebase authentication + cloud synchronization layer for FactureSimple 3.0. */
public class CloudManager {
    private static final int MAX_IMAGE_BYTES = 200 * 1024;
    private final Context context;
    private final Store db;
    private final FirebaseAuth auth;
    private final FirebaseFirestore fs;
    private final FirebaseStorage storage;

    public String role = "partner";
    public long partnerId = 0;
    public String displayName = "";
    public boolean active = true;
    private UserProfile profile;
    /** Last synchronization failure/warnings, exposed for the settings UI. */
    public String lastSyncError = "";
    public String lastSyncWarning = "";

    // Realtime Firestore listeners. They keep invoices/customers synchronized
    // without requiring the user to leave and reopen the page.
    private ListenerRegistration realtimeInvoicesListener;
    private ListenerRegistration realtimeCustomersListener;
    private final Handler realtimeHandler = new Handler(Looper.getMainLooper());
    private Runnable realtimePendingRun;
    private boolean realtimeStarted = false;

    // Invoice synchronization is deliberately serialized. Two Firestore snapshots
    // can arrive almost at the same time (for example when the phone and tablet
    // create invoices together). Running two reconciliation passes concurrently
    // can make the same local row switch between clean/dirty states.
    private boolean invoiceSyncRunning = false;
    private boolean invoiceSyncAgain = false;
    private final java.util.ArrayList<Runnable> invoiceSyncDoneWaiters = new java.util.ArrayList<>();
    private final java.util.ArrayList<Runnable> invoiceSyncFailedWaiters = new java.util.ArrayList<>();

    public CloudManager(Context c, Store store) {
        context = c.getApplicationContext();
        db = store;
        auth = FirebaseAuth.getInstance();
        fs = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();
    }

    public boolean isLoggedIn() { return auth.getCurrentUser() != null; }
    public String uid() { return isLoggedIn() ? auth.getCurrentUser().getUid() : null; }
    public String email() { return isLoggedIn() ? auth.getCurrentUser().getEmail() : null; }
    public boolean isAdmin() { return "admin".equalsIgnoreCase(role); }

    /**
     * Admin-side initialization/repair of the global invoice counter. It is
     * deliberately run before normal synchronization so a Partner can never
     * initialize a missing counter from only the Partner's private invoice set.
     */
    public Task<Void> ensureGlobalInvoiceCounter() {
        if(!isAdmin()) return com.google.android.gms.tasks.Tasks.forException(new IllegalStateException("Admin only"));
        return fs.collection("invoices")
                .orderBy("invoice_number", Query.Direction.DESCENDING)
                .limit(1)
                .get(Source.SERVER)
                .continueWithTask(t->{
                    if(!t.isSuccessful()) throw t.getException();
                    int remoteMax=0;
                    if(t.getResult()!=null && !t.getResult().isEmpty()){
                        Long n=t.getResult().getDocuments().get(0).getLong("invoice_number");
                        if(n!=null) remoteMax=n.intValue();
                    }
                    Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(MAX(invoice_number),0) FROM invoices WHERE invoice_number_final=1",null);
                    int localMax=0;
                    try{if(c.moveToFirst())localMax=c.getInt(0);}finally{c.close();}
                    final long target=Math.max(Math.max(0,remoteMax),Math.max(0,localMax));
                    DocumentReference ref=fs.collection("counters").document("invoice_numbers");
                    return fs.<Void>runTransaction(transaction->{
                        DocumentSnapshot snap=transaction.get(ref);
                        long current=0;
                        if(snap.exists()){Long n=snap.getLong("lastInvoiceNumber");if(n!=null)current=n;}
                        if(current>=target) return null;
                        Map<String,Object> m=new HashMap<>();
                        m.put("lastInvoiceNumber",target);
                        m.put("updatedAt",System.currentTimeMillis());
                        m.put("updatedBy",uid());
                        transaction.set(ref,m,SetOptions.merge());
                        return null;
                    });
                });
    }

    /**
     * Reserve the next invoice number from a single Firestore counter shared by
     * Admin and every Partner. The counter update is performed inside a
     * Firestore transaction, so two devices creating an invoice at the same
     * time cannot receive the same number.
     */
    public Task<Integer> allocateInvoiceNumber() {
        if (!isLoggedIn()) {
            return com.google.android.gms.tasks.Tasks.forException(
                    new IllegalStateException("لا يوجد مستخدم مسجل الدخول"));
        }
        return allocateInvoiceNumberAttempt(false);
    }

    private Task<Integer> allocateInvoiceNumberAttempt(boolean counterKnown) {
        return fs.collection("invoices")
                .orderBy("invoice_number", Query.Direction.DESCENDING)
                .limit(1)
                .get(Source.SERVER)
                .continueWithTask(maxTask -> {
                    if (!maxTask.isSuccessful()) throw maxTask.getException();
                    int remoteMax = 0;
                    if (maxTask.getResult() != null && !maxTask.getResult().isEmpty()) {
                        Long n = maxTask.getResult().getDocuments().get(0).getLong("invoice_number");
                        if (n != null) remoteMax = n.intValue();
                    }
                    int localMax = 0;
                    Cursor localCursor = db.getReadableDatabase().rawQuery(
                            "SELECT COALESCE(MAX(invoice_number),0) FROM invoices WHERE invoice_number_final=1", null);
                    try { if(localCursor.moveToFirst()) localMax = localCursor.getInt(0); }
                    finally { localCursor.close(); }
                    final int historicalMax = Math.max(Math.max(0, remoteMax), Math.max(0, localMax));
                    DocumentReference counter = fs.collection("counters").document("invoice_numbers");
                    return fs.runTransaction(transaction -> {
                        DocumentSnapshot snap = transaction.get(counter);
                        if (!snap.exists()) {
                            // Bootstrap only with zero. A second transaction performs
                            // the real allocation and can safely use historicalMax.
                            Map<String,Object> init = new HashMap<>();
                            init.put("lastInvoiceNumber", 0L);
                            init.put("updatedAt", System.currentTimeMillis());
                            init.put("updatedBy", uid());
                            transaction.set(counter, init, SetOptions.merge());
                            return 0;
                        }
                        long current = 0;
                        Long n = snap.getLong("lastInvoiceNumber");
                        if (n != null) current = n;
                        long next = Math.max(current, historicalMax) + 1L;
                        Map<String,Object> data = new HashMap<>();
                        data.put("lastInvoiceNumber", next);
                        data.put("updatedAt", System.currentTimeMillis());
                        data.put("updatedBy", uid());
                        transaction.set(counter, data, SetOptions.merge());
                        return (int)next;
                    }).continueWithTask(t -> {
                        if (!t.isSuccessful()) throw t.getException();
                        Integer result = t.getResult();
                        if (result != null && result == 0 && !counterKnown) {
                            return allocateInvoiceNumberAttempt(true);
                        }
                        return com.google.android.gms.tasks.Tasks.forResult(result);
                    });
                });
    }

    public Task<AuthResult> login(String email, String password) {
        return auth.signInWithEmailAndPassword(email.trim(), password);
    }

    public Task<AuthResult> registerPartner(String email, String password) {
        return auth.createUserWithEmailAndPassword(email.trim(), password);
    }

    public void logout() { auth.signOut(); }

    public Task<QuerySnapshot> listPartners() {
        if (!isAdmin()) throw new IllegalStateException("Admin only");
        return fs.collection("users").whereEqualTo("role", "partner").get();
    }

    /**
     * Creates a Firebase Authentication account without signing out the current admin.
     * A secondary FirebaseApp/Auth instance is used only for account creation, then deleted.
     */
    public Task<DocumentSnapshot> createPartnerAccount(String name, String emailAddress, String password, long newPartnerId, String phone) {
        if (!isAdmin()) throw new IllegalStateException("Admin only");
        if (TextUtils.isEmpty(emailAddress) || TextUtils.isEmpty(password))
            throw new IllegalArgumentException("Email and password are required");
        if (password.length() < 6) throw new IllegalArgumentException("Password must be at least 6 characters");
        if (newPartnerId < 1) throw new IllegalArgumentException("Partner ID must be greater than 0");

        String secondaryName = "partner_auth_" + System.currentTimeMillis();
        FirebaseApp secondary = FirebaseApp.initializeApp(context, FirebaseApp.getInstance().getOptions(), secondaryName);
        if (secondary == null) throw new IllegalStateException("Unable to initialize secondary Firebase app");
        FirebaseAuth secondaryAuth = FirebaseAuth.getInstance(secondary);

        return fs.collection("users").whereEqualTo("partnerId", newPartnerId).limit(1).get().continueWithTask(check -> {
            if (!check.isSuccessful()) throw check.getException();
            if (check.getResult() != null && !check.getResult().isEmpty())
                throw new IllegalStateException("Partner ID already exists");
            return secondaryAuth.createUserWithEmailAndPassword(emailAddress.trim(), password);
        }).continueWithTask(created -> {
            if (!created.isSuccessful()) throw created.getException();
            String newUid = created.getResult().getUser().getUid();
            Map<String,Object> m = new HashMap<>();
            m.put("uid", newUid);
            m.put("name", name == null ? "" : name.trim());
            m.put("email", emailAddress.trim());
            m.put("phone", phone == null ? "" : phone.trim());
            m.put("role", "partner");
            m.put("partnerId", newPartnerId);
            m.put("active", true);
            long now = System.currentTimeMillis();
            m.put("createdAt", now);
            m.put("updatedAt", now);
            return fs.collection("users").document(newUid).set(m).continueWithTask(saved -> {
                if (!saved.isSuccessful()) {
                    try { secondaryAuth.getCurrentUser().delete(); } catch (Exception ignored) {}
                    throw saved.getException();
                }
                return fs.collection("users").document(newUid).get().continueWithTask(profileTask -> {
                    if (!profileTask.isSuccessful()) throw profileTask.getException();
                    int localCustomerId=db.upsertPartnerCustomer(newUid,newPartnerId,name,emailAddress,phone);
                    if(localCustomerId<=0) throw new IllegalStateException("Unable to create linked partner customer");
                    return pushLocalCustomer(localCustomerId).continueWith(x->{
                        if(!x.isSuccessful()) throw x.getException();
                        return profileTask.getResult();
                    });
                });
            });
        }).addOnCompleteListener(t -> {
            try { secondary.delete(); } catch (Exception ignored) {}
        });
    }

    public Task<Void> updatePartnerProfile(String partnerUid, String name, long newPartnerId, boolean enabled, String phone) {
        if (!isAdmin()) throw new IllegalStateException("Admin only");
        if (partnerUid == null || partnerUid.trim().isEmpty()) throw new IllegalArgumentException("Missing UID");
        if (newPartnerId < 1) throw new IllegalArgumentException("Partner ID must be greater than 0");
        Map<String,Object> m = new HashMap<>();
        m.put("name", name == null ? "" : name.trim());
        m.put("phone", phone == null ? "" : phone.trim());
        m.put("partnerId", newPartnerId);
        m.put("active", enabled);
        m.put("updatedAt", System.currentTimeMillis());
        return fs.collection("users").whereEqualTo("partnerId", newPartnerId).get().continueWithTask(t -> {
            if (!t.isSuccessful()) throw t.getException();
            for (DocumentSnapshot d : t.getResult().getDocuments()) {
                if (!partnerUid.equals(d.getId())) throw new IllegalStateException("Partner ID already exists");
            }
            return fs.collection("users").document(partnerUid).set(m, SetOptions.merge()).continueWithTask(saved -> {
                if(!saved.isSuccessful()) throw saved.getException();
                return fs.collection("users").document(partnerUid).get();
            }).continueWithTask(profileTask -> {
                if(!profileTask.isSuccessful()) throw profileTask.getException();
                DocumentSnapshot profileDoc=profileTask.getResult();
                String emailValue=profileDoc==null?"":str(profileDoc.getString("email"));
                String phoneValue=profileDoc==null?"":str(profileDoc.getString("phone"));
                int localCustomerId=db.upsertPartnerCustomer(partnerUid,newPartnerId,name,emailValue,phoneValue);
                if(localCustomerId>0) return pushLocalCustomer(localCustomerId);
                return com.google.android.gms.tasks.Tasks.forResult(null);
            });
        });
    }

    /** Refreshes the canonical partner phone from Firebase before generating an invoice PDF.
     * This prevents the partner email from being displayed as the telephone when an old/local
     * linked customer record contains stale contact data.
     */
    public void refreshPartnerContactForInvoice(long targetPartnerId, final Runnable done, final Runnable failed) {
        if (targetPartnerId <= 0) { if (done != null) done.run(); return; }
        fs.collection("users").whereEqualTo("role", "partner")
            .whereEqualTo("partnerId", targetPartnerId).limit(1).get(Source.SERVER)
            .addOnSuccessListener(q -> {
                if (q.isEmpty()) { if (done != null) done.run(); return; }
                DocumentSnapshot d = q.getDocuments().get(0);
                String phone = str(d.getString("phone"));
                String name = str(d.getString("name"));
                String email = str(d.getString("email"));
                if (!phone.trim().isEmpty()) {
                    db.upsertPartnerCustomer(d.getId(), targetPartnerId, name, email, phone);
                }
                if (done != null) done.run();
            })
            .addOnFailureListener(e -> {
                recordSyncFailure(e);
                // PDF generation can still use the last locally cached contact.
                if (failed != null) failed.run();
                else if (done != null) done.run();
            });
    }

    /** Ensures every Firebase partner has exactly one linked customer record.
     * This also repairs partner accounts created before automatic linking existed. */
    public Task<Void> ensureAllPartnerCustomers(){
        if(!isAdmin()) throw new IllegalStateException("Admin only");
        return listPartners().continueWithTask(t->{
            if(!t.isSuccessful()) throw t.getException();
            java.util.ArrayList<Task<Void>> tasks=new java.util.ArrayList<>();
            for(DocumentSnapshot d:t.getResult().getDocuments()){
                Long p=d.getLong("partnerId");
                if(p==null || p<1) continue;
                tasks.add(ensurePartnerCustomer(d.getId(),p,d.getString("name"),d.getString("email"),d.getString("phone")));
            }
            return tasks.isEmpty()?com.google.android.gms.tasks.Tasks.forResult(null):com.google.android.gms.tasks.Tasks.whenAll(tasks);
        });
    }

    private Task<Void> ensurePartnerCustomer(String partnerUid,long partnerId,String name,String email,String phone){
        return fs.collection("customers").whereEqualTo("partnerId",partnerId).get().continueWithTask(q->{
            if(!q.isSuccessful()) throw q.getException();
            DocumentSnapshot found=null;
            for(DocumentSnapshot d:q.getResult().getDocuments()){
                Boolean r=d.getBoolean("reseller");
                if(Boolean.TRUE.equals(r)){found=d;break;}
            }
            if(found!=null){
                int id=parseInt(found.getId());
                if(id>0){
                    ContentValues v=new ContentValues();v.put("id",id);v.put("name",name==null?str(found.getString("name")):name);v.put("phone",phone==null?str(found.getString("phone")):phone);v.put("city",str(found.getString("city")));v.put("address",str(found.getString("address")));v.put("reseller",1);v.put("partner_id",partnerId);v.put("partner_uid",partnerUid);v.put("partner_email",email==null?str(found.getString("partner_email")):email);Double ds=found.getDouble("defaultShipping");v.put("default_shipping",ds==null?30:ds);
                    db.getWritableDatabase().insertWithOnConflict("customers",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);
                    db.markSyncClean("customers",id,remoteTimestamp(found));
                    return com.google.android.gms.tasks.Tasks.forResult(null);
                }
            }
            int localId=db.upsertPartnerCustomer(partnerUid,partnerId,name,email,phone);
            if(localId<=0) throw new IllegalStateException("Unable to link partner customer");
            return pushLocalCustomer(localId);
        });
    }

    /** Removes the linked customer and the Firebase profile together.
     * Firebase Authentication itself cannot delete another user's Auth account from a client app;
     * removing the canonical users/{uid} profile immediately prevents application access. */
    public Task<Void> deletePartnerAndLinkedCustomer(String partnerUid,long partnerId){
        if(!isAdmin()) throw new IllegalStateException("Admin only");
        if(partnerId < 1) throw new IllegalArgumentException("Missing Partner ID");

        // لا نعتمد على UID المخزن محلياً فقط؛ قد يكون السجل المحلي قديماً.
        // نبحث عن الحساب حسب Partner ID ثم نحذف السجل المرتبط به.
        final String[] canonicalUid={partnerUid==null?"":partnerUid.trim()};
        return fs.collection("users").whereEqualTo("partnerId",partnerId).limit(5).get().continueWithTask(usersTask->{
            if(!usersTask.isSuccessful()) throw usersTask.getException();
            for(DocumentSnapshot d:usersTask.getResult().getDocuments()){
                if("partner".equalsIgnoreCase(str(d.getString("role")))){ canonicalUid[0]=d.getId(); break; }
            }
            return fs.collection("customers").whereEqualTo("partnerId",partnerId).get();
        }).continueWithTask(customersTask->{
            if(!customersTask.isSuccessful()) throw customersTask.getException();
            java.util.ArrayList<Task<Void>> deletes=new java.util.ArrayList<>();
            for(DocumentSnapshot d:customersTask.getResult().getDocuments()){
                if(Boolean.TRUE.equals(d.getBoolean("reseller")))
                    deletes.add(fs.collection("customers").document(d.getId()).delete());
            }
            Task<Void> customerDeletes=deletes.isEmpty()?com.google.android.gms.tasks.Tasks.forResult(null):com.google.android.gms.tasks.Tasks.whenAll(deletes);
            return customerDeletes.continueWithTask(v->{
                if(!v.isSuccessful()) throw v.getException();
                if(canonicalUid[0].isEmpty()) return com.google.android.gms.tasks.Tasks.forResult(null);
                return fs.collection("users").document(canonicalUid[0]).delete().continueWithTask(userDelete->{
                    if(userDelete.isSuccessful()) return com.google.android.gms.tasks.Tasks.forResult(null);
                    // بعض مشاريع Firebase المنشورة قد تكون فيها قاعدة delete قديمة.
                    // في هذه الحالة نعطّل الحساب نهائياً بدلاً من تركه فعالاً.
                    Map<String,Object> fallback=new HashMap<>();
                    fallback.put("active",false); fallback.put("deleted",true); fallback.put("updatedAt",System.currentTimeMillis());
                    return fs.collection("users").document(canonicalUid[0]).set(fallback,SetOptions.merge()).continueWith(f->{
                        if(!f.isSuccessful()) throw userDelete.getException()!=null?userDelete.getException():f.getException();
                        lastSyncWarning="تم حذف الشريك المرتبط وتعطيل حساب Firebase بسبب رفض حذف مستند الحساب.";
                        return null;
                    });
                });
            }).continueWith(v->{
                if(!v.isSuccessful()) throw v.getException();
                int localId=db.linkedPartnerCustomer(partnerId,canonicalUid[0]);
                if(localId<0 && partnerUid!=null) localId=db.linkedPartnerCustomer(partnerId,partnerUid);
                if(localId>0) db.deleteCustomer(localId);
                return null;
            });
        });
    }

    public Task<Void> sendPartnerPasswordReset(String emailAddress) {
        if (!isAdmin()) throw new IllegalStateException("Admin only");
        return auth.sendPasswordResetEmail(emailAddress.trim());
    }

    /**
     * Saves the authenticated user's profile in users/{uid}.
     * This is the canonical user document used by the application.
     */
    public Task<Void> saveProfile(String name, String role, long partnerId) {
        String id = uid();
        if (id == null) throw new IllegalStateException("No authenticated Firebase user");

        long now = System.currentTimeMillis();
        Map<String,Object> m = new HashMap<>();
        m.put("uid", id);
        m.put("name", name == null ? "" : name.trim());
        m.put("role", role == null ? "partner" : role.trim().toLowerCase());
        m.put("partnerId", partnerId);
        m.put("email", email() == null ? "" : email());
        m.put("active", true);
        m.put("updatedAt", now);

        // Keep createdAt when the profile already exists.
        return fs.collection("users").document(id).get().continueWithTask(t -> {
            if (t.isSuccessful() && t.getResult() != null && t.getResult().exists()) {
                return fs.collection("users").document(id).set(m, SetOptions.merge());
            }
            m.put("createdAt", now);
            return fs.collection("users").document(id).set(m);
        });
    }

    /** Reads the canonical users/{uid} document. */
    public Task<DocumentSnapshot> loadProfile() {
        String id = uid();
        if (id == null) throw new IllegalStateException("No authenticated Firebase user");
        return fs.collection("users").document(id).get(Source.SERVER);
    }

    public UserProfile getProfile() { return profile; }

    /** Loads users/{uid} without blocking the UI on a slow network. Cached profile is used first,
     * then a server refresh is attempted in the background. This prevents the white-screen-after-login issue. */
    public void loadProfileAndRun(Runnable done, Runnable failed) {
        if (!isLoggedIn()) { if (failed != null) failed.run(); return; }
        final boolean[] completed = {false};
        fs.collection("users").document(uid()).get(Source.CACHE).addOnSuccessListener(cached -> {
            if (cached != null && cached.exists() && applyProfileDocument(cached, false)) {
                // Admin may use the cached profile immediately. For partners, however,
                // partnerId is the key used by the Firestore invoice query. Never start
                // the first cloud sync from a stale cached partner profile; wait for the
                // authoritative server profile below so a fresh/new device cannot end
                // up with products only and no invoices.
                if (isAdmin()) {
                    completed[0] = true;
                    if (done != null) done.run();
                }
            }
            loadProfile().addOnSuccessListener(server -> {
                if (server == null || !server.exists()) {
                    if (!completed[0] && failed != null) failed.run();
                    return;
                }
                if (applyProfileDocument(server, true) && !completed[0]) { completed[0] = true; if (done != null) done.run(); }
            }).addOnFailureListener(e -> {
                recordSyncFailure(e);
                if (!completed[0] && failed != null) failed.run();
            });
        }).addOnFailureListener(e -> {
            loadProfile().addOnSuccessListener(server -> {
                if (server != null && server.exists() && applyProfileDocument(server, true)) {
                    completed[0] = true; if (done != null) done.run();
                } else if (failed != null) failed.run();
            }).addOnFailureListener(serverErr -> { recordSyncFailure(serverErr); if (failed != null) failed.run(); });
        });
    }

    private boolean applyProfileDocument(DocumentSnapshot doc, boolean strict) {
        if (doc == null || !doc.exists()) {
            lastSyncError="حساب Firebase مسجل الدخول، لكن users/"+uid()+" غير موجود";
            return false;
        }
        UserProfile p = new UserProfile();
        p.uid = uid();
        p.email = doc.getString("email") == null ? email() : doc.getString("email");
        p.name = doc.getString("name") == null ? "" : doc.getString("name");
        p.role = doc.getString("role") == null ? "partner" : doc.getString("role");
        Long partner = doc.getLong("partnerId"); p.partnerId = partner == null ? 0 : partner;
        Boolean enabled = doc.getBoolean("active"); p.active = enabled == null || enabled;
        Long created = doc.getLong("createdAt"); p.createdAt = created == null ? 0 : created;
        Long updated = doc.getLong("updatedAt"); p.updatedAt = updated == null ? 0 : updated;
        if (!p.active) { lastSyncError="حساب الشريك معطل من الأدمن"; return false; }
        if (!p.isAdmin() && !p.isPartner()) { lastSyncError="دور الحساب غير صحيح: "+p.role; return false; }
        profile=p; role=p.role; partnerId=p.partnerId; displayName=p.name; active=p.active;
        return true;
    }

    /** Pushes exactly one invoice immediately. The UI can return to the invoice list without waiting for a full sync. */
    public void pushInvoiceNow(int invoiceId, Runnable done, Runnable failed) {
        if (!isLoggedIn() || invoiceId <= 0) { if (failed != null) failed.run(); return; }
        Store.Invoice local=db.invoice(invoiceId);
        if(local==null){if(failed!=null)failed.run();return;}
        String key=local.cloudKey==null?"":local.cloudKey.trim();
        if(key.isEmpty()){key="inv_"+java.util.UUID.randomUUID().toString();db.setInvoiceCloudKey(invoiceId,key);}
        final String cloudKey=key;
        fs.collection("invoices").document(cloudKey).get()
            .continueWithTask(t -> {
                if (!t.isSuccessful()) throw t.getException();
                return finalizeInvoiceNumberIfNeeded(invoiceId)
                    .continueWithTask(f -> {
                        if (!f.isSuccessful()) throw f.getException();
                        return pushLocalInvoice(invoiceId, t.getResult());
                    });
            })
            .addOnSuccessListener(v -> { if (done != null) done.run(); })
            .addOnFailureListener(e -> {
                recordSyncFailure(e);
                // لا نترك الفاتورة معلقة حتى دورة WorkManager القادمة فقط؛ اطلب إعادة
                // المحاولة فوراً مع احترام قيد الشبكة الموجود في SyncScheduler.
                SyncScheduler.runNow(context);
                if (failed != null) failed.run();
            });
    }

    /** Pushes exactly one customer immediately, instead of running a full customer reconciliation. */
    public void pushCustomerNow(int customerId, Runnable done, Runnable failed) {
        if (!isLoggedIn() || customerId <= 0) { if (failed != null) failed.run(); return; }
        pushLocalCustomer(customerId)
            .addOnSuccessListener(v -> { if (done != null) done.run(); })
            .addOnFailureListener(e -> { recordSyncFailure(e); if (failed != null) failed.run(); });
    }

    /**
     * Phase 3.4: true Admin bidirectional synchronization.
     * Local changes are tracked in Store.sync_meta. For each entity, the newer
     * side wins using millisecond updatedAt timestamps. Dirty local deletions
     * are represented by tombstones in sync_meta so they can also be propagated.
     */
    private Task<Void> refreshAuthToken(){
        if(auth.getCurrentUser()==null) return com.google.android.gms.tasks.Tasks.forException(new IllegalStateException("لا يوجد مستخدم مسجل الدخول"));
        return auth.getCurrentUser().getIdToken(true).continueWith(t->{
            if(!t.isSuccessful()) throw t.getException();
            return null;
        });
    }

    /**
     * Starts lightweight Firestore listeners for the current account. A change
     * in customers or invoices schedules a normal bidirectional reconciliation
     * so the local SQLite database and the cloud converge on the same data.
     */
    public void startRealtimeSync(final Runnable onChanged) {
        stopRealtimeSync();
        if (!isLoggedIn()) return;
        realtimeStarted = true;

        if (isAdmin()) {
            realtimeCustomersListener = fs.collection("customers").addSnapshotListener((snap, err) -> {
                if (err != null || snap == null || !realtimeStarted) return;
                scheduleRealtimeReconcile(onChanged);
            });
            realtimeInvoicesListener = fs.collection("invoices").addSnapshotListener((snap, err) -> {
                if (err != null || snap == null || !realtimeStarted) return;
                // Invoice changes are much more frequent than catalog changes.
                // Sync invoices directly instead of starting the heavy full Admin
                // reconciliation; this makes phone <-> tablet invoice updates
                // effectively realtime and avoids unrelated product/image delays.
                syncInvoicesOnlyForAdmin(onChanged, onChanged);
            });
        } else if (partnerId > 0) {
            realtimeCustomersListener = fs.collection("customers")
                    .whereEqualTo("partnerId", partnerId)
                    .addSnapshotListener((snap, err) -> {
                        if (err != null || snap == null || !realtimeStarted) return;
                        scheduleRealtimeReconcile(onChanged);
                    });
            realtimeInvoicesListener = fs.collection("invoices")
                    .whereEqualTo("partner_id", partnerId)
                    .addSnapshotListener((snap, err) -> {
                        if (err != null || snap == null || !realtimeStarted) return;
                        scheduleRealtimeReconcile(onChanged);
                    });
        }
    }

    private void scheduleRealtimeReconcile(final Runnable onChanged) {
        if (!realtimeStarted) return;
        if (realtimePendingRun != null) realtimeHandler.removeCallbacks(realtimePendingRun);
        realtimePendingRun = () -> {
            if (!realtimeStarted) return;
            Runnable done = () -> { if (onChanged != null) onChanged.run(); };
            if (isAdmin()) {
                syncLocalToCloud(done, () -> { if (onChanged != null) onChanged.run(); });
            } else {
                syncCloudToLocalForPartner(done, () -> { if (onChanged != null) onChanged.run(); });
            }
        };
        // Coalesce the initial snapshot and rapid successive writes into one sync.
        realtimeHandler.postDelayed(realtimePendingRun, 350);
    }

    public void stopRealtimeSync() {
        realtimeStarted = false;
        if (realtimePendingRun != null) { realtimeHandler.removeCallbacks(realtimePendingRun); realtimePendingRun = null; }
        if (realtimeInvoicesListener != null) { realtimeInvoicesListener.remove(); realtimeInvoicesListener = null; }
        if (realtimeCustomersListener != null) { realtimeCustomersListener.remove(); realtimeCustomersListener = null; }
    }

    /** Reconciles all customer records for one partner while logged in as Admin. */
    public void syncPartnerCustomersForAdmin(long targetPartnerId, final Runnable done, final Runnable failed) {
        if (!isAdmin() || targetPartnerId <= 0) {
            if (failed != null) failed.run();
            return;
        }
        // Targeted reconciliation for the selected partner. The relationship
        // key is the canonical Firebase Partner ID, never the local SQLite row ID.
        ensurePartnerCustomerForTarget(targetPartnerId)
            .continueWithTask(v -> fs.collection("customers")
                .whereEqualTo("partnerId", targetPartnerId).get())
            .addOnSuccessListener(remote -> {
                java.util.ArrayList<Task<Void>> tasks = new java.util.ArrayList<>();
                for (DocumentSnapshot d : remote.getDocuments()) {
                    if (Boolean.TRUE.equals(d.getBoolean("reseller"))) continue;
                    if (isCustomerTombstoneForCloudId(d.getId())) continue;
                    tasks.add(applyRemoteCustomer(d));
                }

                android.database.Cursor lc = db.getReadableDatabase().query(
                    "customers", new String[]{"id"},
                    "partner_id=? AND reseller=0",
                    new String[]{String.valueOf(targetPartnerId)}, null,null,null);
                try {
                    while (lc.moveToNext()) {
                        int id = lc.getInt(0);
                        Store.Customer local = db.customer(id);
                        if (local == null || !"dirty".equals(db.syncState("customers", id))) continue;
                        tasks.add(pushLocalCustomer(id));
                    }
                } finally { lc.close(); }

                if (tasks.isEmpty()) {
                    if (done != null) done.run();
                    return;
                }
                com.google.android.gms.tasks.Tasks.whenAll(tasks)
                    .addOnSuccessListener(x -> { if (done != null) done.run(); })
                    .addOnFailureListener(e -> {
                        recordSyncFailure(e);
                        if (failed != null) failed.run();
                    });
            })
            .addOnFailureListener(e -> {
                recordSyncFailure(e);
                if (failed != null) failed.run();
            });
    }

    private Task<Void> ensurePartnerCustomerForTarget(long targetPartnerId) {
        return fs.collection("users").whereEqualTo("role","partner")
            .whereEqualTo("partnerId",targetPartnerId).limit(1).get()
            .continueWithTask(t -> {
                if (!t.isSuccessful()) throw t.getException();
                if (t.getResult().isEmpty()) return com.google.android.gms.tasks.Tasks.forResult(null);
                DocumentSnapshot p = t.getResult().getDocuments().get(0);
                return ensurePartnerCustomer(p.getId(), targetPartnerId, p.getString("name"), p.getString("email"), p.getString("phone"));
            });
    }

    public void syncLocalToCloud(final Runnable done, final Runnable failed) {
        lastSyncError=""; lastSyncWarning="";
        if (!isLoggedIn() || !isAdmin()) { lastSyncError="لا يوجد مستخدم مدير مسجل الدخول"; if (failed != null) failed.run(); return; }
        refreshAuthToken().addOnSuccessListener(v->syncBidirectionalAdmin(done,failed)).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
    }

    public void syncBidirectionalAdmin(final Runnable done, final Runnable failed) {
        if (!isLoggedIn() || !isAdmin()) { if (failed != null) failed.run(); return; }
        // IMPORTANT: image repair is intentionally NOT part of the blocking full sync.
        // The previous version scanned/downloaded/re-uploaded every product image on
        // each manual/automatic sync. With many products this could run for minutes
        // and hit the worker timeout, causing "انتهت مهلة المزامنة السحابية".
        // Images are now normalized when they are uploaded/replaced. Existing oversized
        // cloud images can be repaired separately without blocking invoice/customer sync.
        syncShippingCompaniesToCloud(
            () -> syncProductsBidirectional(
                () -> syncPartnerProductSettingsToCloud(
                    () -> syncCustomersBidirectional(
                        () -> {
                            // Remembered customer prices are optional. They must NEVER block
                            // the critical invoice/customer synchronization. This also keeps
                            // compatibility with Firebase projects whose rules predate the
                            // customer_product_prices collection.
                            syncInvoicesOnlyForAdmin(done, failed);
                            syncRememberedSalePrices(
                                () -> {},
                                () -> recordSyncWarning("تعذر مزامنة أسعار الزبائن المحفوظة؛ تمت مزامنة الفواتير بشكل طبيعي.", null)
                            );
                        }, failed), failed),
                failed),
            failed);
    }

    private void syncProductsBidirectional(final Runnable done, final Runnable failed) {
        fs.collection("products").get().addOnSuccessListener(remote -> {
            java.util.HashMap<Integer,DocumentSnapshot> remoteMap=new java.util.HashMap<>();
            for(DocumentSnapshot d:remote.getDocuments()) remoteMap.put(parseInt(d.getId()),d);

            // IMPORTANT: include BOTH sides. The old implementation only iterated
            // local product IDs. After an uninstall/reinstall the local SQLite
            // database is empty, so the cloud catalog (and its images) was never
            // downloaded back to the Admin device.
            java.util.LinkedHashSet<Integer> ids=new java.util.LinkedHashSet<>();
            ids.addAll(remoteMap.keySet());
            android.database.Cursor c=db.getReadableDatabase().query("sync_meta",null,"entity=?",new String[]{"products"},null,null,null);
            try{while(c.moveToNext())ids.add(c.getInt(c.getColumnIndexOrThrow("local_id")));}finally{c.close();}
            android.database.Cursor pc=db.getReadableDatabase().query("products",new String[]{"id"},null,null,null,null,null);
            try{while(pc.moveToNext())ids.add(pc.getInt(0));}finally{pc.close();}

            java.util.ArrayList<Task<Void>> tasks=new java.util.ArrayList<>();
            for(Integer id:ids){
                final int localId=id; final DocumentSnapshot r=remoteMap.get(id);
                final boolean localExists=localProductExists(localId);
                final boolean tomb="dirty".equals(db.syncState("products",localId)) && !localExists;
                long localTs=db.syncLocalUpdatedAt("products",localId); long remoteTs=remoteTimestamp(r);

                if(tomb){
                    if(r==null || localTs>=remoteTs){
                        tasks.add(fs.collection("products").document(String.valueOf(localId)).delete().continueWith(t->{db.markSyncClean("products",localId,localTs);return null;}));
                    }else{
                        // Cloud is newer than a stale local tombstone: restore it,
                        // including its Storage image.
                        tasks.add(applyRemoteProduct(r));
                    }
                } else if(r==null){
                    // Local-only product: upload it to the cloud.
                    if(localExists) tasks.add(pushLocalProduct(localId));
                } else if(!localExists){
                    // Fresh install / cleared app: cloud is authoritative.
                    tasks.add(applyRemoteProduct(r));
                } else if(localTs>=remoteTs && "dirty".equals(db.syncState("products",localId))){
                    tasks.add(pushLocalProduct(localId));
                } else {
                    // Remote is authoritative and must restore metadata + image.
                    tasks.add(applyRemoteProduct(r));
                }
            }
            if(tasks.isEmpty()){if(done!=null)done.run();return;}
            com.google.android.gms.tasks.Tasks.whenAll(tasks)
                .addOnSuccessListener(v->{if(done!=null)done.run();})
                .addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
        }).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
    }

    private boolean localProductExists(int id){ Cursor c=db.getReadableDatabase().query("products",new String[]{"id"},"id=?",new String[]{String.valueOf(id)},null,null,null);try{return c.moveToFirst();}finally{c.close();} }
    private Task<Void> pushLocalProduct(int id){
        Store.Product p=db.product(id);
        if(p==null)return com.google.android.gms.tasks.Tasks.forResult(null);
        final long ts=Math.max(System.currentTimeMillis(),db.syncLocalUpdatedAt("products",id));
        // Product metadata must not depend on Firebase Storage. If an image cannot
        // be uploaded, keep the previous cloud image and still synchronize the product.
        return fs.collection("products").document(String.valueOf(id)).get().continueWithTask(read->{
            if(!read.isSuccessful()) throw read.getException();
            String existing=read.getResult()!=null?read.getResult().getString("imageUrl"):null;
            return uploadProductImageTask(p).continueWithTask(imageTask->{
                String imageUrl=existing==null?"":existing;
                if(imageTask.isSuccessful() && imageTask.getResult()!=null && !imageTask.getResult().isEmpty()) imageUrl=imageTask.getResult();
                else if(!TextUtils.isEmpty(p.image) && !p.image.startsWith("http://") && !p.image.startsWith("https://")){
                    recordSyncWarning("تعذر رفع صورة المنتج "+p.id+"؛ تمت مزامنة بيانات المنتج مع الإبقاء على الصورة السحابية الحالية.", imageTask.getException());
                }
                Map<String,Object> m=new HashMap<>();
                m.put("name",p.name);m.put("code",p.code);m.put("price",p.price);
                m.put("imageUrl",imageUrl);m.put("available",p.available);m.put("priceTiers",p.priceTiers==null?"":p.priceTiers);m.put("updatedAt",ts);m.put("updatedBy",uid());
                return fs.collection("products").document(String.valueOf(id)).set(m,SetOptions.merge());
            });
        }).continueWith(t->{
            if(!t.isSuccessful()){ recordSyncFailure(t.getException()); throw t.getException(); }
            db.markSyncClean("products",id,ts);
            return null;
        });
    }
    private Task<String> uploadProductImageTask(Store.Product p){
        if(TextUtils.isEmpty(p.image))return com.google.android.gms.tasks.Tasks.forResult("");
        if(p.image.startsWith("http://")||p.image.startsWith("https://"))return com.google.android.gms.tasks.Tasks.forResult(p.image);
        try{
            Uri uri=p.image.startsWith("content://")||p.image.startsWith("file://")?Uri.parse(p.image):Uri.fromFile(new File(p.image));
            File compressed = compressImageUri(uri, p.id);
            StorageReference ref=storage.getReference().child("products/"+p.id+"/main.jpg");
            // The object path is fixed, so putFile() replaces the object in place.
            // IMPORTANT: never delete the existing object before the new upload has
            // completed. If the upload fails (network, auth, timeout, etc.), deleting
            // first would permanently remove the last working image and the product
            // would appear without a picture after the next synchronization.
            return ref.putFile(Uri.fromFile(compressed))
                .continueWithTask(t->{if(!t.isSuccessful())throw t.getException();return ref.getDownloadUrl();})
                .continueWith(t->{
                    try{compressed.delete();}catch(Exception ignored){}
                    if(!t.isSuccessful())throw t.getException();
                    return t.getResult().toString();
                });
        }catch(Exception e){return com.google.android.gms.tasks.Tasks.forException(e);}
    }

    private File compressImageUri(Uri uri, int productId) throws Exception {
        File dir=new File(context.getCacheDir(),"mge_compressed_images");
        if(!dir.exists()&&!dir.mkdirs())throw new IOException("تعذر إنشاء مجلد ضغط الصور");
        File out=new File(dir,"product_"+productId+"_"+System.currentTimeMillis()+".jpg");
        BitmapFactory.Options bounds=new BitmapFactory.Options(); bounds.inJustDecodeBounds=true;
        try(InputStream in=context.getContentResolver().openInputStream(uri)){
            if(in==null)throw new IOException("تعذر قراءة الصورة");
            BitmapFactory.decodeStream(in,null,bounds);
        }
        if(bounds.outWidth<=0||bounds.outHeight<=0)throw new IOException("الصورة غير صالحة");
        int sample=1; int maxDim=Math.max(bounds.outWidth,bounds.outHeight);
        while(maxDim/sample>1600)sample*=2;
        BitmapFactory.Options opts=new BitmapFactory.Options(); opts.inSampleSize=sample;
        Bitmap bitmap;
        try(InputStream in=context.getContentResolver().openInputStream(uri)){
            if(in==null)throw new IOException("تعذر قراءة الصورة");
            bitmap=BitmapFactory.decodeStream(in,null,opts);
        }
        if(bitmap==null)throw new IOException("تعذر فك الصورة");
        try{
            int width=bitmap.getWidth(), height=bitmap.getHeight();
            for(int pass=0; pass<8; pass++){
                int quality=Math.max(25,85-pass*10);
                ByteArrayOutputStream bos=new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG,quality,bos);
                byte[] bytes=bos.toByteArray();
                if(bytes.length<=MAX_IMAGE_BYTES || pass==7){
                    try(FileOutputStream fos=new FileOutputStream(out)){fos.write(bytes);fos.flush();}
                    if(out.length()>MAX_IMAGE_BYTES){
                        float scale=0.85f;
                        Bitmap smaller=Bitmap.createScaledBitmap(bitmap,Math.max(320,(int)(width*scale)),Math.max(320,(int)(height*scale)),true);
                        if(smaller!=bitmap)bitmap.recycle(); bitmap=smaller; width=bitmap.getWidth(); height=bitmap.getHeight(); pass=-1;
                        if(width<=320||height<=320){
                            ByteArrayOutputStream last=new ByteArrayOutputStream(); bitmap.compress(Bitmap.CompressFormat.JPEG,25,last);
                            try(FileOutputStream fos=new FileOutputStream(out)){fos.write(last.toByteArray());}
                            if(out.length()>MAX_IMAGE_BYTES)throw new IOException("تعذر ضغط الصورة إلى أقل من 200KB");
                            break;
                        }
                        continue;
                    }
                    break;
                }
            }
        }finally{bitmap.recycle();}
        return out;
    }

    /** Compress every local product image before cloud upload. */
    private File compressLocalImageIfNeeded(String path,int productId) throws Exception {
        if(TextUtils.isEmpty(path)||path.startsWith("http://")||path.startsWith("https://"))return null;
        Uri uri=path.startsWith("content://")||path.startsWith("file://")?Uri.parse(path):Uri.fromFile(new File(path));
        File f=compressImageUri(uri,productId);
        return f;
    }

    /** Repair cloud images: if an existing Storage object exceeds 200KB, download,
     * compress, delete the old object and upload the normalized image. */
    private Task<String> normalizeCloudImage(int productId,String currentUrl){
        StorageReference ref=storage.getReference().child("products/"+productId+"/main.jpg");
        return ref.getMetadata().continueWithTask(metaTask->{
            if(!metaTask.isSuccessful())throw metaTask.getException();
            long size=metaTask.getResult().getSizeBytes();
            if(size<=MAX_IMAGE_BYTES)return com.google.android.gms.tasks.Tasks.forResult(currentUrl==null?"":currentUrl);
            File tmp=new File(context.getCacheDir(),"mge_cloud_"+productId+".jpg");
            return ref.getFile(tmp).continueWithTask(download->{
                if(!download.isSuccessful())throw download.getException();
                File compressed=compressLocalImageIfNeeded(Uri.fromFile(tmp).toString(),productId);
                // Replace the object in place. Do not delete first: a failed upload
                // must leave the existing cloud image available.
                return ref.putFile(Uri.fromFile(compressed))
                    .continueWithTask(up->{if(!up.isSuccessful())throw up.getException();return ref.getDownloadUrl();})
                    .continueWith(urlTask->{
                        try{tmp.delete();compressed.delete();}catch(Exception ignored){}
                        if(!urlTask.isSuccessful())throw urlTask.getException();
                        return urlTask.getResult().toString();
                    });
            });
        });
    }

    /** Admin repair pass for existing oversized images and images missing from Storage. */
    public void repairProductImagesCloud(final Runnable done, final Runnable failed){
        if(!isLoggedIn()||!isAdmin()){if(failed!=null)failed.run();return;}
        fs.collection("products").get().addOnSuccessListener(snapshot->{
            java.util.ArrayList<Task<?>> tasks=new java.util.ArrayList<>();
            for(DocumentSnapshot d:snapshot.getDocuments()){
                final int id=parseInt(d.getId()); final String url=str(d.getString("imageUrl"));
                Store.Product local=db.product(id);
                if((url==null||url.isEmpty()) && (local==null||TextUtils.isEmpty(local.image)))continue;
                tasks.add(normalizeCloudImage(id,url).continueWithTask(newUrl->{
                    if(newUrl.isSuccessful()){
                        String u=newUrl.getResult();
                        if(u==null)u="";
                        if(!u.equals(url))return fs.collection("products").document(String.valueOf(id)).update("imageUrl",u,"updatedAt",System.currentTimeMillis(),"updatedBy",uid());
                        return com.google.android.gms.tasks.Tasks.forResult(null);
                    }
                    // Storage object missing or inaccessible: if we have a local image,
                    // restore it from the Admin device instead of leaving a broken URL.
                    Store.Product pLocal=db.product(id);
                    if(pLocal!=null&&!TextUtils.isEmpty(pLocal.image)&&!pLocal.image.startsWith("http://")&&!pLocal.image.startsWith("https://")){
                        return uploadProductImageTask(pLocal).continueWithTask(upload->{
                            if(!upload.isSuccessful())throw upload.getException();
                            String u=upload.getResult()==null?"":upload.getResult();
                            return fs.collection("products").document(String.valueOf(id)).update("imageUrl",u,"updatedAt",System.currentTimeMillis(),"updatedBy",uid());
                        });
                    }
                    throw new RuntimeException(newUrl.getException());
                }));
            }
            if(tasks.isEmpty()){if(done!=null)done.run();return;}
            com.google.android.gms.tasks.Tasks.whenAll(tasks).addOnSuccessListener(v->{if(done!=null)done.run();}).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
        }).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
    }

    private void recordSyncFailure(Exception e){
        lastSyncError=syncErrorText(e);
    }
    private void recordSyncWarning(String message, Exception e){
        if(lastSyncWarning==null||lastSyncWarning.isEmpty()) lastSyncWarning=message;
        if(e!=null && (lastSyncError==null||lastSyncError.isEmpty())) lastSyncError=syncErrorText(e);
    }
    private String syncErrorText(Exception e){
        if(e==null)return "خطأ غير معروف";
        String code="";
        if(e instanceof FirebaseFirestoreException){
            FirebaseFirestoreException f=(FirebaseFirestoreException)e;
            code=f.getCode()==null?"":f.getCode().name();
        } else if(e instanceof com.google.firebase.auth.FirebaseAuthException){
            code=((com.google.firebase.auth.FirebaseAuthException)e).getErrorCode();
        }
        String m=e.getMessage();
        if(m==null||m.trim().isEmpty())m=e.getClass().getSimpleName();
        String project="facturesimple-1b613";
        return (code.isEmpty()?"":code+" — ")+m+"\nFirebase: "+project;
    }
    private Task<Void> applyRemoteProduct(DocumentSnapshot d){
        if(d==null)return com.google.android.gms.tasks.Tasks.forResult(null);
        final int id=parseInt(d.getId());
        final String imageUrl=str(d.getString("imageUrl"));
        ContentValues v=new ContentValues();
        v.put("id",id);
        v.put("name",str(d.getString("name")));
        v.put("code",str(d.getString("code")));
        Double price=d.getDouble("price");
        v.put("price",price==null?0:price);
        Boolean av=d.getBoolean("available"); v.put("available",av==null?1:(av?1:0));
        v.put("price_tiers",str(d.getString("priceTiers")));
        // Keep the cloud URL immediately. After the Storage download succeeds,
        // replace it with a local file so the catalog remains usable offline.
        v.put("image",imageUrl);
        db.getWritableDatabase().insertWithOnConflict("products",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);

        if(imageUrl.isEmpty()){
            db.markSyncClean("products",id,remoteTimestamp(d));
            return com.google.android.gms.tasks.Tasks.forResult(null);
        }

        return downloadProductImage(id,imageUrl).continueWith(t->{
            if(t.isSuccessful() && t.getResult()!=null && !t.getResult().isEmpty()){
                ContentValues iv=new ContentValues();
                iv.put("image",t.getResult());
                db.getWritableDatabase().update("products",iv,"id=?",new String[]{String.valueOf(id)});
            } else {
                // Do not fail the whole catalog sync just because one Storage
                // object is temporarily unavailable. The Firebase download URL
                // remains in SQLite and can still be displayed by Glide.
                recordSyncWarning("تعذر تنزيل صورة المنتج "+id+" من Firebase Storage؛ بقي رابط الصورة السحابية محفوظاً.",t.getException());
            }
            db.markSyncClean("products",id,remoteTimestamp(d));
            return null;
        });
    }

    private Store.Customer localCustomerForRemote(DocumentSnapshot d){
        if(d==null||!d.exists())return null;
        Store.Customer c=db.customerByCloudId(d.getId());
        if(c!=null)return c;
        int preferredId=parseInt(d.getId());
        if(preferredId>0){
            Store.Customer byId=db.customer(preferredId);
            Long pi=d.getLong("partnerId");int rp=pi==null?0:pi.intValue();
            boolean rr=Boolean.TRUE.equals(d.getBoolean("reseller"));
            if(byId!=null && (byId.cloudId==null||byId.cloudId.isEmpty()) && byId.partnerId==rp && byId.reseller==rr) return byId;
        }
        return null;
    }

    private boolean isCustomerTombstoneForCloudId(String cloudId){
        if(cloudId==null || cloudId.trim().isEmpty()) return false;
        Cursor c=db.getReadableDatabase().query("sync_meta",new String[]{"local_id"},
                "entity=? AND state=? AND deleted=1 AND cloud_key=?",
                new String[]{"customers","dirty",cloudId},null,null,null,"1");
        try{return c.moveToFirst();}finally{c.close();}
    }

    private void syncCustomersBidirectional(final Runnable done, final Runnable failed) {
        fs.collection("customers").get().addOnSuccessListener(remote->{
            java.util.HashMap<String,DocumentSnapshot> remoteMap=new java.util.HashMap<>();
            for(DocumentSnapshot d:remote.getDocuments()) remoteMap.put(d.getId(),d);
            java.util.ArrayList<Task<Void>> tasks=new java.util.ArrayList<>();
            // Resolve cloud records against local records without allowing a remote pull to overwrite a newer local edit.
            for(DocumentSnapshot r:remote.getDocuments()){
                // A local deletion may race the Firestore listener. Do not recreate
                // the customer from the just-arrived snapshot while its tombstone
                // is still waiting to be uploaded.
                if(isCustomerTombstoneForCloudId(r.getId())) continue;
                Store.Customer local=localCustomerForRemote(r);
                if(local==null){
                    tasks.add(applyRemoteCustomer(r));
                }else{
                    if(local.cloudId==null||local.cloudId.isEmpty()) db.setCustomerCloudId(local.id,r.getId());
                    long lt=db.syncLocalUpdatedAt("customers",local.id), rt=remoteTimestamp(r);
                    if("dirty".equals(db.syncState("customers",local.id)) && lt>=rt) tasks.add(pushLocalCustomer(local.id));
                    else tasks.add(applyRemoteCustomer(r));
                }
            }
            // Push local rows that have no cloud counterpart.
            android.database.Cursor lc=db.getReadableDatabase().query("customers",new String[]{"id"},null,null,null,null,null);
            try{while(lc.moveToNext()){
                int id=lc.getInt(0); Store.Customer c=db.customer(id); if(c==null||!"dirty".equals(db.syncState("customers",id))) continue;
                String key=(c.cloudId==null||c.cloudId.isEmpty())?String.valueOf(id):c.cloudId;
                if(!remoteMap.containsKey(key)) tasks.add(pushLocalCustomer(id));
            }}finally{lc.close();}
            // If a customer was deleted from another device, remove the stale
            // clean local copy instead of making it reappear on the Admin phone.
            android.database.Cursor missing=db.getReadableDatabase().query("customers",new String[]{"id","cloud_id"},null,null,null,null,null);
            try{while(missing.moveToNext()){
                int id=missing.getInt(0);
                String key=missing.isNull(1)?"":missing.getString(1);
                if(key.isEmpty()) key=String.valueOf(id);
                if(remoteMap.containsKey(key)) continue;
                if("dirty".equals(db.syncState("customers",id))) continue;
                db.getWritableDatabase().delete("customers","id=?",new String[]{String.valueOf(id)});
            }}finally{missing.close();}

            // Propagate local customer deletions.
            android.database.Cursor dc=db.getReadableDatabase().query("sync_meta",new String[]{"local_id"},"entity=? AND state=? AND deleted=1",new String[]{"customers","dirty"},null,null,null);
            try{while(dc.moveToNext()){
                int id=dc.getInt(0); String key=db.syncCloudKey("customers",id); if(key==null||key.isEmpty())key=String.valueOf(id); DocumentSnapshot r=remoteMap.get(key);
                if(r!=null) tasks.add(fs.collection("customers").document(key).delete().continueWith(t->{if(!t.isSuccessful())throw t.getException();db.markSyncClean("customers",id,System.currentTimeMillis());return null;}));
            }}finally{dc.close();}
            if(tasks.isEmpty()){if(done!=null)done.run();return;}
            com.google.android.gms.tasks.Tasks.whenAll(tasks).addOnSuccessListener(v->{if(done!=null)done.run();}).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
        }).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
    }
    private boolean localCustomerExists(int id){Cursor c=db.getReadableDatabase().query("customers",new String[]{"id"},"id=?",new String[]{String.valueOf(id)},null,null,null);try{return c.moveToFirst();}finally{c.close();}}
    private Task<Void> pushLocalCustomer(int id){
        Store.Customer x=db.customer(id);
        if(x==null)return com.google.android.gms.tasks.Tasks.forResult(null);
        long ts=Math.max(System.currentTimeMillis(),db.syncLocalUpdatedAt("customers",id));
        String cloudId=(x.cloudId==null?"":x.cloudId.trim());
        if(cloudId.isEmpty()) cloudId=isAdmin()?String.valueOf(id):("p"+partnerId+"_"+java.util.UUID.randomUUID().toString());
        final String finalCloudId=cloudId;
        Map<String,Object> m=new HashMap<>();
        m.put("name",x.name);m.put("phone",x.phone);m.put("city",x.city);m.put("address",x.address);
        if(isAdmin()){
            m.put("reseller",x.reseller);m.put("partnerId",x.partnerId);m.put("partnerUid",x.partnerUid==null?"":x.partnerUid);m.put("partner_email",x.partnerEmail==null?"":x.partnerEmail);m.put("defaultShipping",x.defaultShipping);
        }else{
            // Partner accounts may only own normal customers belonging to their Partner ID.
            if(x.reseller || x.partnerId!=(int)partnerId) return com.google.android.gms.tasks.Tasks.forException(new IllegalStateException("لا يمكن للشريك مزامنة زبون خارج حسابه"));
            m.put("partnerId",partnerId);m.put("reseller",false);m.put("defaultShipping",30);m.put("partnerUid",uid());m.put("partner_email",email()==null?"":email());
        }
        m.put("localId",id);m.put("updatedAt",ts);m.put("updatedBy",uid());
        return fs.collection("customers").document(finalCloudId).get().continueWithTask(read->{
            if(!read.isSuccessful()) throw read.getException();
            boolean exists=read.getResult()!=null&&read.getResult().exists();
            Map<String,Object> payload=new HashMap<>(m);
            if(exists && !isAdmin()){
                // Firestore rules intentionally restrict partner updates to the four customer fields + timestamps.
                payload.clear();payload.put("name",x.name);payload.put("phone",x.phone);payload.put("city",x.city);payload.put("address",x.address);payload.put("updatedAt",ts);payload.put("updatedBy",uid());
            }
            return fs.collection("customers").document(finalCloudId).set(payload,SetOptions.merge());
        }).continueWith(t->{
            if(!t.isSuccessful())throw t.getException();
            db.setCustomerCloudId(id,finalCloudId);db.markSyncClean("customers",id,ts);db.setSyncCloudKey("customers",id,finalCloudId);return null;
        });
    }

    private Task<Void> applyRemoteCustomer(DocumentSnapshot d){
        if(d==null||!d.exists())return com.google.android.gms.tasks.Tasks.forResult(null);
        String cloudId=d.getId();
        int preferredId=parseInt(cloudId);
        Store.Customer existing=db.customerByCloudId(cloudId);
        Long pi=d.getLong("partnerId");int partner=(pi==null?0:pi.intValue());
        boolean reseller=Boolean.TRUE.equals(d.getBoolean("reseller"));
        boolean usePreferredId=false;
        if(existing==null && preferredId>0){
            Store.Customer byId=db.customer(preferredId);
            if(byId==null) usePreferredId=true;
            else if((byId.cloudId==null||byId.cloudId.isEmpty()) && byId.partnerId==partner && byId.reseller==reseller){ existing=byId; }
        }
        ContentValues v=new ContentValues();
        if(existing!=null) v.put("id",existing.id);
        else if(usePreferredId) v.put("id",preferredId);
        v.put("name",str(d.getString("name")));v.put("phone",str(d.getString("phone")));v.put("city",str(d.getString("city")));v.put("address",str(d.getString("address")));v.put("reseller",reseller?1:0);v.put("partner_id",partner);v.put("partner_uid",str(d.getString("partnerUid")));v.put("partner_email",str(d.getString("partner_email")));Double sh=d.getDouble("defaultShipping");v.put("default_shipping",sh==null?30:sh);v.put("cloud_id",cloudId);
        int localId=existing==null? (int)db.getWritableDatabase().insert("customers",null,v) : existing.id;
        if(existing!=null) db.getWritableDatabase().update("customers",v,"id=?",new String[]{String.valueOf(localId)});
        if(localId<=0) throw new IllegalStateException("Unable to store remote customer");
        db.markSyncClean("customers",localId,remoteTimestamp(d));
        return com.google.android.gms.tasks.Tasks.forResult(null);
    }

    /** Sync invoices only for the Admin invoice screen. */
    public void syncInvoicesOnlyForAdmin(final Runnable done, final Runnable failed){
        lastSyncError=""; lastSyncWarning="";
        if(!isLoggedIn() || !isAdmin()){
            lastSyncError="لا يوجد مستخدم مدير مسجل الدخول";
            if(failed!=null)failed.run();
            return;
        }
        if(done!=null) invoiceSyncDoneWaiters.add(done);
        if(failed!=null) invoiceSyncFailedWaiters.add(failed);
        if(invoiceSyncRunning){
            // A second request while a reconciliation is running is not lost.
            // We simply run one more pass after the current pass completes.
            invoiceSyncAgain=true;
            return;
        }
        invoiceSyncRunning=true;
        refreshAuthToken()
            .addOnSuccessListener(v->performInvoiceSyncPass())
            .addOnFailureListener(e->{recordSyncFailure(e);finishInvoiceSync(false);});
    }

    /**
     * Reliable Admin invoice reconciliation.
     *
     * The important difference from the old implementation is that every invoice
     * is processed one after another and an error in one invoice does not abort
     * the remaining invoices. The pass is considered successful only when every
     * invoice and its items have completed successfully.
     */
    private void performInvoiceSyncPass(){
        fs.collection("invoices").get(Source.SERVER).addOnSuccessListener(remote->{
            final java.util.HashSet<String> deletedKeys=new java.util.HashSet<>();
            android.database.Cursor dc=db.getReadableDatabase().query("sync_meta",new String[]{"local_id","cloud_key"},"entity=? AND state=? AND deleted=1",new String[]{"invoices","dirty"},null,null,null);
            try{
                while(dc.moveToNext()){
                    String key=dc.isNull(1)?"":dc.getString(1).trim();
                    if(!key.isEmpty()) deletedKeys.add(key);
                }
            }finally{dc.close();}

            final java.util.HashMap<String,DocumentSnapshot> remoteMap=new java.util.HashMap<>();
            for(DocumentSnapshot r:remote.getDocuments()) if(!deletedKeys.contains(r.getId())) remoteMap.put(r.getId(),r);

            final int[] failures={0};
            final String[] firstFailure={""};

            // Process deletions first so a stale local tombstone can never be
            // resurrected by the same snapshot. A failed deletion is recorded
            // but never blocks the remaining invoices.
            Task<Void> chain=com.google.android.gms.tasks.Tasks.forResult(null);
            for(String key:deletedKeys){
                final String k=key;
                chain=chain.continueWithTask(t->{
                    DocumentSnapshot r=remoteDocById(remote,k);
                    if(r!=null) return deleteCloudInvoiceAndMarkTombstone(k);
                    return markInvoiceTombstoneClean(k);
                }).continueWith(t->{
                    if(!t.isSuccessful()){
                        failures[0]++;
                        if(firstFailure[0].isEmpty()) firstFailure[0]=syncErrorText(t.getException());
                    }
                    return null;
                });
            }

            // Download/update every cloud invoice. A failure is recorded but does
            // not stop the next invoice from being processed.
            for(DocumentSnapshot r:remote.getDocuments()){
                if(deletedKeys.contains(r.getId())) continue;
                final DocumentSnapshot remoteInvoice=r;
                chain=chain.continueWithTask(t->{
                    if(!t.isSuccessful()) return com.google.android.gms.tasks.Tasks.forResult(null);
                    return reconcileRemoteInvoice(remoteInvoice);
                }).continueWith(t->{
                    if(!t.isSuccessful()){
                        failures[0]++;
                        if(firstFailure[0].isEmpty()) firstFailure[0]=syncErrorText(t.getException());
                    }
                    return null;
                });
            }

            // Repair/upload every local invoice that is dirty or missing from the
            // cloud. This pass is what makes a freshly installed tablet converge
            // to the cloud and also guarantees local invoices are not silently lost.
            android.database.Cursor lc=db.getReadableDatabase().query("invoices",new String[]{"id"},null,null,null,null,"id ASC");
            final java.util.ArrayList<Integer> localIds=new java.util.ArrayList<>();
            try{while(lc.moveToNext()) localIds.add(lc.getInt(0));}finally{lc.close();}
            for(Integer id:localIds){
                final int localId=id;
                chain=chain.continueWithTask(t->{
                    Store.Invoice local=db.invoice(localId);
                    if(local==null) return com.google.android.gms.tasks.Tasks.forResult(null);
                    String key=local.cloudKey==null?"":local.cloudKey.trim();
                    if(key.isEmpty()){
                        key="inv_"+java.util.UUID.randomUUID().toString();
                        db.setInvoiceCloudKey(localId,key);
                    }
                    if(deletedKeys.contains(key)) return com.google.android.gms.tasks.Tasks.forResult(null);
                    DocumentSnapshot r=remoteMap.get(key);
                    long lt=db.syncLocalUpdatedAt("invoices",localId);
                    long rt=r==null?0:remoteTimestamp(r);
                    boolean dirty="dirty".equals(db.syncState("invoices",localId));
                    boolean localWins=dirty && lt>=rt;
                    if(r==null || localWins){
                        return finalizeInvoiceNumberIfNeeded(localId).continueWithTask(fin->{
                            if(!fin.isSuccessful()) throw fin.getException();
                            return pushLocalInvoice(localId,r);
                        });
                    }
                    return com.google.android.gms.tasks.Tasks.forResult(null);
                }).continueWith(t->{
                    if(!t.isSuccessful()){
                        failures[0]++;
                        if(firstFailure[0].isEmpty()) firstFailure[0]=syncErrorText(t.getException());
                    }
                    return null;
                });
            }

            chain.continueWith(t->{
                if(failures[0]>0){
                    lastSyncError="تعذر مزامنة "+failures[0]+" فاتورة. "+firstFailure[0];
                    finishInvoiceSync(false);
                }else{
                    lastSyncError="";
                    finishInvoiceSync(true);
                }
                return null;
            });
        }).addOnFailureListener(e->{recordSyncFailure(e);finishInvoiceSync(false);});
    }

    /** Reconcile one remote invoice without allowing one bad invoice to stop the batch. */
    private Task<Void> reconcileRemoteInvoice(DocumentSnapshot r){
        if(r==null||!r.exists()) return com.google.android.gms.tasks.Tasks.forResult(null);
        Store.Invoice local=db.invoiceByCloudKey(r.getId());
        if(local==null){
            int legacyId=parseInt(r.getId());
            if(legacyId>0){
                Store.Invoice candidate=db.invoice(legacyId);
                Long rp=r.getLong("partner_id"); int remotePartner=rp==null?0:rp.intValue();
                if(candidate!=null && candidate.partnerId==remotePartner && (candidate.cloudKey==null||candidate.cloudKey.isEmpty())) local=candidate;
            }
        }
        if(local==null) return applyRemoteInvoice(r);
        long lt=db.syncLocalUpdatedAt("invoices",local.id);
        long rt=remoteTimestamp(r);
        if("dirty".equals(db.syncState("invoices",local.id)) && lt>=rt){
            final int id=local.id;
            return finalizeInvoiceNumberIfNeeded(id).continueWithTask(t->{
                if(!t.isSuccessful()) throw t.getException();
                return pushLocalInvoice(id,r);
            });
        }
        return applyRemoteInvoice(r);
    }

    private void finishInvoiceSync(boolean success){
        if(invoiceSyncAgain){
            invoiceSyncAgain=false;
            // Keep the current waiter queues; all callers receive the result of
            // the final pass, not an intermediate snapshot. If the token refresh
            // itself fails, finish immediately instead of recursively retrying.
            refreshAuthToken()
                .addOnSuccessListener(v->performInvoiceSyncPass())
                .addOnFailureListener(e->{recordSyncFailure(e);invoiceSyncAgain=false;finishInvoiceSync(false);});
            return;
        }
        invoiceSyncRunning=false;
        java.util.ArrayList<Runnable> ok=new java.util.ArrayList<>(invoiceSyncDoneWaiters);
        java.util.ArrayList<Runnable> bad=new java.util.ArrayList<>(invoiceSyncFailedWaiters);
        invoiceSyncDoneWaiters.clear();
        invoiceSyncFailedWaiters.clear();
        java.util.ArrayList<Runnable> list=success?ok:bad;
        for(Runnable r:list) try{if(r!=null)r.run();}catch(Exception ignored){}
    }

    private DocumentSnapshot remoteDocById(QuerySnapshot snap,String id){
        if(snap==null||id==null||id.isEmpty())return null;
        for(DocumentSnapshot d:snap.getDocuments())if(id.equals(d.getId()))return d;
        return null;
    }

    private Task<Void> deleteCloudInvoice(String key){
        return fs.collection("invoices").document(key).collection("items").get().continueWithTask(t->{
            if(!t.isSuccessful())throw t.getException();
            WriteBatch b=fs.batch();
            for(DocumentSnapshot d:t.getResult().getDocuments())b.delete(d.getReference());
            b.delete(fs.collection("invoices").document(key));
            return b.commit();
        });
    }

    private Task<Void> markInvoiceTombstoneClean(String key){
        android.database.Cursor c=db.getReadableDatabase().query("sync_meta",new String[]{"local_id"},"entity=? AND state=? AND deleted=1 AND cloud_key=?",new String[]{"invoices","dirty",key},null,null,null);
        try{while(c.moveToNext())db.markSyncClean("invoices",c.getInt(0),System.currentTimeMillis());}finally{c.close();}
        return com.google.android.gms.tasks.Tasks.forResult(null);
    }

    private Task<Void> deleteCloudInvoiceAndMarkTombstone(String key){
        return deleteCloudInvoice(key).continueWithTask(t->{
            if(!t.isSuccessful())throw t.getException();
            return markInvoiceTombstoneClean(key);
        });
    }

    private void cleanupLocalInvoiceDuplicates(java.util.HashMap<String,DocumentSnapshot> winners){ /* intentionally non-destructive */ }
    private java.util.HashMap<String,DocumentSnapshot> dedupeRemoteInvoices(QuerySnapshot remote,java.util.Set<String> deletedKeys,java.util.ArrayList<Task<Void>> tasks){
        java.util.HashMap<String,DocumentSnapshot> all=new java.util.HashMap<>();
        if(remote==null)return all;
        for(DocumentSnapshot d:remote.getDocuments()){ if(deletedKeys.contains(d.getId()))continue; all.put(d.getId(),d); }
        // Never delete invoices merely because two documents temporarily share a number.
        // The document cloud_key is the immutable identity; number conflicts are resolved
        // by assigning a fresh global number during the next push.
        return all;
    }
    private boolean localInvoiceExists(int id){Cursor c=db.getReadableDatabase().query("invoices",new String[]{"id"},"id=?",new String[]{String.valueOf(id)},null,null,null);try{return c.moveToFirst();}finally{c.close();}}
    private Task<Void> pushLocalInvoice(int id){ return pushLocalInvoice(id,null); }
    /** Finalize an offline/provisional invoice number using the shared Firestore counter.
     * The local provisional number is never used as the identity of the invoice.
     * If another device already consumed that number, this invoice simply receives
     * the next free global number; the invoice document itself is preserved.
     */
    private Task<Void> finalizeInvoiceNumberIfNeeded(int id){
        Store.Invoice inv=db.invoice(id);
        if(inv==null || inv.invoiceNumberFinal) return com.google.android.gms.tasks.Tasks.forResult(null);
        return allocateInvoiceNumber().continueWith(t->{
            if(!t.isSuccessful()) throw t.getException();
            Integer n=t.getResult();
            if(n==null||n<=0) throw new IllegalStateException("تعذر الحصول على رقم فاتورة موحد");
            db.finalizeInvoiceNumber(id,n);
            return null;
        });
    }


    private Task<Void> pushLocalInvoice(int id, DocumentSnapshot remote){
        Store.Invoice x=db.invoice(id);
        if(x==null)return com.google.android.gms.tasks.Tasks.forResult(null);
        long ts=Math.max(System.currentTimeMillis(),db.syncLocalUpdatedAt("invoices",id));
        String cloudKey=x.cloudKey==null?"":x.cloudKey.trim();
        if(cloudKey.isEmpty()){cloudKey="inv_"+java.util.UUID.randomUUID().toString();db.setInvoiceCloudKey(id,cloudKey);}
        final String finalCloudKey=cloudKey;
        Map<String,Object> m=new HashMap<>();
        m.put("invoice_number",x.invoiceNumber>0?x.invoiceNumber:x.id);
        m.put("invoice_number_final",x.invoiceNumberFinal);
        m.put("createdAt",x.createdAt>0?x.createdAt:ts);
        m.put("cloud_key",finalCloudKey);
        m.put("client_id",x.clientId);m.put("client",x.client);m.put("customer_phone",x.customerPhone);m.put("customer_city",x.customerCity);m.put("customer_address",x.customerAddress);m.put("customer_type",x.customerType);m.put("date",x.date);m.put("paid",x.paid);m.put("reseller",x.reseller);m.put("delivery_received",x.deliveryReceived);m.put("tracking_number",x.trackingNumber);m.put("commission",x.commission);m.put("partner_id",x.partnerId);m.put("shipping_enabled",x.shippingEnabled);m.put("shipping_charge",x.shippingCharge);m.put("shipping_cost",x.shippingCost);m.put("partner_profit_paid",x.partnerProfitPaid);m.put("paid_date",x.paidDate);m.put("delivery_received_date",x.deliveryReceivedDate);m.put("delivery_failure_reason",x.deliveryFailureReason);m.put("partner_profit_paid_date",x.partnerProfitPaidDate);m.put("bank_received",x.bankReceived);m.put("bank_received_date",x.bankReceivedDate);m.put("shipping_company",x.shippingCompany);m.put("shipping_account",x.shippingAccount);m.put("shipped_by_admin",x.shippedByAdmin);m.put("company_accounted",x.companyAccounted);m.put("company_accounted_date",x.companyAccountedDate);m.put("company_accounting_store",x.companyAccountingStore);m.put("company_accounting_export_id",x.companyAccountingExportId);m.put("virement_code",x.virementCode);m.put("virement_date",x.virementDate);m.put("virement_total_crbt",x.virementTotalCrbt);m.put("virement_total_fees",x.virementTotalFees);m.put("virement_net",x.virementNet);m.put("advance_payment",x.advancePayment);m.put("advance_payment_date",x.advancePaymentDate);m.put("advance_received_by_partner_id",x.advanceReceivedByPartnerId);m.put("assembly_completed",x.assemblyCompleted);m.put("adhkar",x.adhkar==null?"":x.adhkar);m.put("updatedAt",ts);m.put("updatedBy",uid());
        if(!isAdmin() && remote!=null && remote.exists()){
            Map<String,Object> allowed=new HashMap<>();
            allowed.put("client_id",x.clientId);allowed.put("client",x.client);allowed.put("customer_phone",x.customerPhone);allowed.put("customer_city",x.customerCity);allowed.put("customer_address",x.customerAddress);allowed.put("customer_type",x.customerType);allowed.put("shipping_enabled",x.shippingEnabled);allowed.put("shipping_charge",x.shippingCharge);allowed.put("shipping_company",x.shippingCompany);allowed.put("commission",x.commission);allowed.put("adhkar",x.adhkar==null?"":x.adhkar);allowed.put("updatedAt",ts);allowed.put("updatedBy",uid());
            m=allowed;
        }
        return fs.collection("invoices").document(finalCloudKey).set(m,SetOptions.merge())
                .continueWithTask(t->{if(!t.isSuccessful())throw t.getException();return uploadInvoiceItems(id);})
                .continueWith(t->{if(!t.isSuccessful())throw t.getException();db.setInvoiceCloudKey(id,finalCloudKey);db.markSyncClean("invoices",id,ts);return null;});
    }

    private Task<Void> applyRemoteInvoice(DocumentSnapshot d){
        if(d==null||!d.exists())return com.google.android.gms.tasks.Tasks.forResult(null);
        String cloudKey=d.getId();
        Store.Invoice existing=db.invoiceByCloudKey(cloudKey);
        Long rp=d.getLong("partner_id"); int remotePartner=rp==null?0:rp.intValue();
        Long rn=d.getLong("invoice_number"); int invoiceNumber=rn==null?parseInt(cloudKey):rn.intValue();
        if(existing==null){
            int preferredId=parseInt(cloudKey);
            if(preferredId>0){Store.Invoice byId=db.invoice(preferredId);if(byId!=null && byId.partnerId==remotePartner && (byId.cloudKey==null||byId.cloudKey.isEmpty())) existing=byId;}
        }
        ContentValues v=new ContentValues();
        if(existing!=null) v.put("id",existing.id);
        v.put("invoice_number",invoiceNumber);
        Boolean remoteFinal=d.getBoolean("invoice_number_final");
        v.put("invoice_number_final",remoteFinal==null || remoteFinal ? 1 : 0);
        Long cat=d.getLong("createdAt");v.put("created_at",cat==null?remoteTimestamp(d):cat);v.put("cloud_key",cloudKey);
        v.put("client_id",d.getLong("client_id")==null?0:d.getLong("client_id"));putS(v,"client",d.getString("client"));putS(v,"customer_phone",d.getString("customer_phone"));putS(v,"customer_city",d.getString("customer_city"));putS(v,"customer_address",d.getString("customer_address"));putS(v,"customer_type",d.getString("customer_type"));putS(v,"date",d.getString("date"));putB(v,"paid",d.getBoolean("paid"));putB(v,"reseller",d.getBoolean("reseller"));putB(v,"delivery_received",d.getBoolean("delivery_received"));putS(v,"tracking_number",d.getString("tracking_number"));putD(v,"commission",d.getDouble("commission"));putS(v,"partner_id",d.getLong("partner_id"));putB(v,"shipping_enabled",d.getBoolean("shipping_enabled"));putD(v,"shipping_charge",d.getDouble("shipping_charge"));putD(v,"shipping_cost",d.getDouble("shipping_cost"));putB(v,"partner_profit_paid",d.getBoolean("partner_profit_paid"));putS(v,"paid_date",d.getString("paid_date"));putS(v,"delivery_received_date",d.getString("delivery_received_date"));putS(v,"delivery_failure_reason",d.getString("delivery_failure_reason"));putS(v,"partner_profit_paid_date",d.getString("partner_profit_paid_date"));putB(v,"bank_received",d.getBoolean("bank_received"));putS(v,"bank_received_date",d.getString("bank_received_date"));putS(v,"shipping_company",d.getString("shipping_company"));putS(v,"shipping_account",d.getString("shipping_account"));putB(v,"shipped_by_admin",d.getBoolean("shipped_by_admin"));putB(v,"company_accounted",d.getBoolean("company_accounted"));putS(v,"company_accounted_date",d.getString("company_accounted_date"));putS(v,"company_accounting_store",d.getString("company_accounting_store"));putS(v,"company_accounting_export_id",d.getString("company_accounting_export_id"));putS(v,"virement_code",d.getString("virement_code"));putS(v,"virement_date",d.getString("virement_date"));putD(v,"virement_total_crbt",d.getDouble("virement_total_crbt"));putD(v,"virement_total_fees",d.getDouble("virement_total_fees"));putD(v,"virement_net",d.getDouble("virement_net"));putD(v,"advance_payment",d.getDouble("advance_payment"));putS(v,"advance_payment_date",d.getString("advance_payment_date"));putS(v,"advance_received_by_partner_id",d.getLong("advance_received_by_partner_id"));putB(v,"assembly_completed",d.getBoolean("assembly_completed"));putS(v,"adhkar",d.getString("adhkar"));
        int localId;
        if(existing!=null){localId=existing.id;db.getWritableDatabase().update("invoices",v,"id=?",new String[]{String.valueOf(localId)});}
        else {localId=(int)db.getWritableDatabase().insert("invoices",null,v);}
        if(localId<=0)throw new IllegalStateException("Unable to store remote invoice");
        db.setInvoiceCloudKey(localId,cloudKey);db.markSyncClean("invoices",localId,remoteTimestamp(d));
        final int finalLocalId=localId;
        return fs.collection("invoices").document(cloudKey).collection("items").get().continueWith(t->{if(!t.isSuccessful())throw t.getException();android.database.sqlite.SQLiteDatabase local=db.getWritableDatabase();local.delete("invoice_items","invoice_id=?",new String[]{String.valueOf(finalLocalId)});for(DocumentSnapshot it:t.getResult().getDocuments()){ContentValues x=new ContentValues();x.put("invoice_id",finalLocalId);x.put("product_id",it.getLong("productId")==null?0:it.getLong("productId"));x.put("name",str(it.getString("name")));Double p=it.getDouble("price"),sp=it.getDouble("salePrice"),pp=it.getDouble("partnerPrice");Long q=it.getLong("qty");x.put("price",p==null?0:p);x.put("sale_price",sp==null?0:sp);x.put("partner_price",pp==null?(sp==null?0:sp):pp);x.put("qty",q==null?0:q);local.insert("invoice_items",null,x);}return null;});
    }

    private long remoteTimestamp(DocumentSnapshot d){if(d==null||!d.exists())return 0;Long x=d.getLong("updatedAt");return x==null?0:x;}
    private static class CursorCompat { private final android.database.Cursor c; CursorCompat(android.database.Cursor x){c=x;} boolean moveToNext(){return c.moveToNext();} int id(){return c.getInt(c.getColumnIndexOrThrow("local_id"));} void close(){c.close();} }

    /**
     * Phase 3.2: synchronize the local product catalog and its main images.
     * Firestore keeps product metadata + imageUrl; Firebase Storage keeps the
     * binary image at products/{id}/main.jpg. The local database is never
     * replaced by a remote URL on the Admin device.
     */
    public void syncProductsToCloud(final Runnable done, final Runnable failed) {
        if (!isLoggedIn() || !isAdmin()) { if (failed != null) failed.run(); return; }
        syncProducts(done, failed);
    }

    private void syncProducts(Runnable done, Runnable failed) {
        android.database.Cursor c = db.getReadableDatabase().query("products", new String[]{"id"}, null, null, null, null, "id ASC");
        java.util.ArrayList<Integer> ids = new java.util.ArrayList<>();
        try {
            while (c.moveToNext()) ids.add(c.getInt(0));
        } finally { c.close(); }

        if (ids.isEmpty()) { if (done != null) done.run(); return; }
        java.util.ArrayList<Task<Void>> tasks = new java.util.ArrayList<>();
        for (Integer id : ids) {
            if (id != null && id > 0) tasks.add(pushLocalProduct(id));
        }
        if (tasks.isEmpty()) { if (done != null) done.run(); return; }
        com.google.android.gms.tasks.Tasks.whenAll(tasks)
            .addOnSuccessListener(v -> { if (done != null) done.run(); })
            .addOnFailureListener(e -> { recordSyncFailure(e); if (failed != null) failed.run(); });
    }

    private interface ImageUrlCallback { void onResult(String url); }
    private interface ErrorCallback { void onError(Exception e); }

    private void uploadOrReuseProductImage(Store.Product product, ImageUrlCallback ok, ErrorCallback bad) {
        uploadProductImageTask(product)
            .addOnSuccessListener(ok::onResult)
            .addOnFailureListener(bad::onError);
    }

    /** Upload all local customers. Admin-only because partners must never write customer data. */
    private void syncCustomersToCloud(final Runnable done, final Runnable failed) {
        android.database.Cursor c=db.getReadableDatabase().query("customers",null,null,null,null,null,"id ASC");
        java.util.ArrayList<Map<String,Object>> docs=new java.util.ArrayList<>();
        try {
            while(c.moveToNext()) {
                int id=c.getInt(c.getColumnIndexOrThrow("id"));
                Map<String,Object> m=new HashMap<>();
                m.put("name",c.getString(c.getColumnIndexOrThrow("name")));
                m.put("phone",c.getString(c.getColumnIndexOrThrow("phone")));
                m.put("city",c.getString(c.getColumnIndexOrThrow("city")));
                m.put("address",c.getString(c.getColumnIndexOrThrow("address")));
                m.put("reseller",c.getInt(c.getColumnIndexOrThrow("reseller"))==1);
                m.put("partnerId",c.getInt(c.getColumnIndexOrThrow("partner_id")));
                int puIdx=c.getColumnIndex("partner_uid"), peIdx=c.getColumnIndex("partner_email");
                m.put("partnerUid",puIdx>=0 && !c.isNull(puIdx)?c.getString(puIdx):"");
                m.put("partner_email",peIdx>=0 && !c.isNull(peIdx)?c.getString(peIdx):"");
                m.put("defaultShipping",c.getDouble(c.getColumnIndexOrThrow("default_shipping")));
                m.put("updatedAt",System.currentTimeMillis());
                m.put("updatedBy",uid());
                Map<String,Object> row=new HashMap<>(); row.put("id",id); row.put("data",m); docs.add(row);
            }
        } finally { c.close(); }
        if(docs.isEmpty()){ if(done!=null)done.run(); return; }
        final int[] remaining={docs.size()}; final boolean[] failedOnce={false};
        for(Map<String,Object> row:docs){
            int id=((Number)row.get("id")).intValue();
            fs.collection("customers").document(String.valueOf(id)).set((Map<String,Object>)row.get("data"),SetOptions.merge())
                .addOnSuccessListener(v->{if(--remaining[0]==0&&!failedOnce[0]&&done!=null)done.run();})
                .addOnFailureListener(e->{if(!failedOnce[0]){failedOnce[0]=true;recordSyncFailure(e);if(failed!=null)failed.run();}});
        }
    }

    /** Upload all local invoices and wait for every invoice's item subcollection. */
    private void syncInvoicesToCloud(final Runnable done, final Runnable failed){
        android.database.Cursor c=db.getReadableDatabase().query("invoices",null,null,null,null,null,"id ASC");
        java.util.ArrayList<Integer> ids=new java.util.ArrayList<>();
        java.util.HashMap<Integer,Map<String,Object>> rows=new java.util.HashMap<>();
        String[] cols={"client_id","client","customer_phone","customer_city","customer_address","customer_type","date","paid","reseller","delivery_received","tracking_number","commission","partner_id","shipping_enabled","shipping_charge","shipping_cost","partner_profit_paid","paid_date","delivery_received_date","delivery_failure_reason","partner_profit_paid_date","bank_received","bank_received_date","shipping_company","shipping_account","shipped_by_admin","company_accounted","company_accounted_date","company_accounting_store","company_accounting_export_id","virement_code","virement_date","virement_total_crbt","virement_total_fees","virement_net","advance_payment","advance_payment_date","advance_received_by_partner_id","assembly_completed","adhkar"};
        try{
            while(c.moveToNext()){
                int id=c.getInt(c.getColumnIndexOrThrow("id")); ids.add(id); Map<String,Object> m=new HashMap<>();
                for(String col:cols){int idx=c.getColumnIndex(col);if(idx<0)continue;Object val;if(c.isNull(idx))val=null;else if(col.equals("client")||col.equals("customer_phone")||col.equals("customer_city")||col.equals("customer_address")||col.equals("customer_type")||col.contains("date")||col.equals("tracking_number")||col.equals("delivery_failure_reason")||col.equals("adhkar")||col.equals("shipping_company")||col.equals("shipping_account")||col.equals("company_accounted_date")||col.equals("company_accounting_store")||col.equals("company_accounting_export_id")||col.equals("virement_code")||col.equals("virement_date"))val=c.getString(idx);else if(col.equals("commission")||col.equals("shipping_charge")||col.equals("shipping_cost")||col.equals("virement_total_crbt")||col.equals("virement_total_fees")||col.equals("virement_net")||col.equals("advance_payment"))val=c.getDouble(idx);else val=c.getInt(idx);m.put(col,val);} 
                Store.Invoice inv=db.invoice(id);String ck=inv==null?"":(inv.cloudKey==null?"":inv.cloudKey.trim());if(ck.isEmpty()){ck="inv_"+java.util.UUID.randomUUID().toString();db.setInvoiceCloudKey(id,ck);}m.put("invoice_number",inv!=null&&inv.invoiceNumber>0?inv.invoiceNumber:id);m.put("invoice_number_final",inv==null||inv.invoiceNumberFinal);m.put("createdAt",inv!=null&&inv.createdAt>0?inv.createdAt:System.currentTimeMillis());m.put("cloud_key",ck);m.put("updatedAt",System.currentTimeMillis()); m.put("updatedBy",uid()); rows.put(id,m);
            }
        }finally{c.close();}
        if(ids.isEmpty()){if(done!=null)done.run();return;}
        final int[] remaining={ids.size()}; final boolean[] failedOnce={false};
        for(Integer invoiceId:ids){
            fs.collection("invoices").document(db.invoice(invoiceId).cloudKey).set(rows.get(invoiceId),SetOptions.merge())
                .continueWithTask(t->{if(!t.isSuccessful())throw t.getException();return uploadInvoiceItems(invoiceId);})
                .addOnSuccessListener(v->{if(--remaining[0]==0&&!failedOnce[0]&&done!=null)done.run();})
                .addOnFailureListener(e->{if(!failedOnce[0]){failedOnce[0]=true;recordSyncFailure(e);if(failed!=null)failed.run();}});
        }
    }

    private Task<Void> uploadInvoiceItems(int invoiceId){
        android.database.Cursor c=db.getReadableDatabase().query("invoice_items",null,"invoice_id=?",new String[]{String.valueOf(invoiceId)},null,null,"id ASC");
        final java.util.HashMap<Integer,Map<String,Object>> localItems=new java.util.HashMap<>();
        try{while(c.moveToNext()){
            int itemId=c.getInt(c.getColumnIndexOrThrow("id")); Map<String,Object> m=new HashMap<>();
            m.put("productId",c.getInt(c.getColumnIndexOrThrow("product_id")));
            m.put("name",c.getString(c.getColumnIndexOrThrow("name")));
            m.put("price",c.getDouble(c.getColumnIndexOrThrow("price")));
            m.put("salePrice",c.getDouble(c.getColumnIndexOrThrow("sale_price")));
            int ppc=c.getColumnIndex("partner_price"); m.put("partnerPrice",ppc<0||c.isNull(ppc)?c.getDouble(c.getColumnIndexOrThrow("sale_price")):c.getDouble(ppc));
            m.put("qty",c.getInt(c.getColumnIndexOrThrow("qty")));
            localItems.put(itemId,m);
        }}finally{c.close();}
        return fs.collection("invoices").document(db.invoice(invoiceId).cloudKey).collection("items").get().continueWithTask(t->{
            if(!t.isSuccessful())throw t.getException();
            WriteBatch batch=fs.batch();
            java.util.HashSet<Integer> remoteIds=new java.util.HashSet<>();
            for(DocumentSnapshot d:t.getResult().getDocuments()){int rid=parseInt(d.getId());remoteIds.add(rid);if(!localItems.containsKey(rid))batch.delete(d.getReference());}
            for(Map.Entry<Integer,Map<String,Object>> e:localItems.entrySet()) batch.set(fs.collection("invoices").document(db.invoice(invoiceId).cloudKey).collection("items").document(String.valueOf(e.getKey())),e.getValue(),SetOptions.merge());
            return batch.commit();
        });
    }

    private Task<Void> syncShippingCompaniesToCloud(final Runnable done, final Runnable failed){
        try{
            final java.util.HashMap<Integer,Store.ShippingCompany> localCompanies=new java.util.HashMap<>();
            for(Store.ShippingCompany x:db.shippingCompanies()) localCompanies.put(x.id,x);
            final java.util.HashMap<Integer,Store.ShippingAccount> localAccounts=new java.util.HashMap<>();
            for(Store.ShippingAccount x:db.shippingAccountsAll()) localAccounts.put(x.id,x);
            return fs.collection("shipping_companies").get().continueWithTask(compTask->{
                if(!compTask.isSuccessful())throw compTask.getException();
                return fs.collection("shipping_accounts").get().continueWithTask(accTask->{
                    if(!accTask.isSuccessful())throw accTask.getException();
                    WriteBatch b=fs.batch(); long now=System.currentTimeMillis();
                    java.util.HashSet<Integer> remoteCompanyIds=new java.util.HashSet<>();
                    for(DocumentSnapshot d:compTask.getResult().getDocuments()) remoteCompanyIds.add(parseInt(d.getId()));
                    // Bidirectional/union sync: never delete a shipping company just
                    // because this device has an empty/stale local database.
                    for(Store.ShippingCompany x:localCompanies.values()){
                        Map<String,Object> m=new HashMap<>(); m.put("name",x.name); m.put("updatedAt",now);
                        b.set(fs.collection("shipping_companies").document(String.valueOf(x.id)),m,SetOptions.merge());
                    }
                    for(DocumentSnapshot d:compTask.getResult().getDocuments()){
                        int id=parseInt(d.getId());
                        if(!localCompanies.containsKey(id)){
                            Map<String,Object> m=new HashMap<>(); m.put("name",str(d.getString("name"))); m.put("updatedAt",d.getLong("updatedAt"));
                            b.set(fs.collection("shipping_companies").document(String.valueOf(id)),m,SetOptions.merge());
                        }
                    }
                    java.util.HashSet<Integer> remoteAccountIds=new java.util.HashSet<>();
                    for(DocumentSnapshot d:accTask.getResult().getDocuments()) remoteAccountIds.add(parseInt(d.getId()));
                    for(Store.ShippingAccount x:localAccounts.values()){
                        Map<String,Object> m=new HashMap<>(); m.put("companyId",x.companyId); m.put("name",x.name); m.put("updatedAt",now);
                        b.set(fs.collection("shipping_accounts").document(String.valueOf(x.id)),m,SetOptions.merge());
                    }
                    for(DocumentSnapshot d:accTask.getResult().getDocuments()){
                        int id=parseInt(d.getId());
                        if(!localAccounts.containsKey(id)){
                            Map<String,Object> m=new HashMap<>(); Long ci=d.getLong("companyId"); m.put("companyId",ci==null?0:ci); m.put("name",str(d.getString("name"))); m.put("updatedAt",d.getLong("updatedAt"));
                            b.set(fs.collection("shipping_accounts").document(String.valueOf(id)),m,SetOptions.merge());
                        }
                    }
                    return b.commit();
                });
            }).addOnSuccessListener(v->{if(done!=null)done.run();}).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
        }catch(Exception e){recordSyncFailure(e);if(failed!=null)failed.run();return com.google.android.gms.tasks.Tasks.forResult(null);}
    }

    private void syncShippingCompaniesFromCloud(final Runnable done, final Runnable failed){
        Task<QuerySnapshot> companiesTask=fs.collection("shipping_companies").get();
        Task<QuerySnapshot> accountsTask=fs.collection("shipping_accounts").get();
        com.google.android.gms.tasks.Tasks.whenAllSuccess(companiesTask,accountsTask).addOnSuccessListener(results->{
            QuerySnapshot companies=(QuerySnapshot)results.get(0);
            QuerySnapshot accounts=(QuerySnapshot)results.get(1);
            if(companies.isEmpty() && accounts.isEmpty()){if(done!=null)done.run();return;}
            android.database.sqlite.SQLiteDatabase local=db.getWritableDatabase();
            local.beginTransaction();
            try{
                local.delete("shipping_accounts",null,null);
                local.delete("shipping_companies",null,null);
                for(DocumentSnapshot d:companies.getDocuments()){
                    ContentValues v=new ContentValues(); v.put("id",parseInt(d.getId())); v.put("name",str(d.getString("name")));
                    local.insertWithOnConflict("shipping_companies",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);
                }
                for(DocumentSnapshot d:accounts.getDocuments()){
                    Long ci=d.getLong("companyId"); String name=str(d.getString("name"));
                    if(ci==null||ci<=0||name.trim().isEmpty())continue;
                    ContentValues v=new ContentValues(); v.put("id",parseInt(d.getId())); v.put("company_id",ci); v.put("name",name);
                    local.insertWithOnConflict("shipping_accounts",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);
                }
                local.setTransactionSuccessful();
            }finally{local.endTransaction();}
            if(done!=null)done.run();
        }).addOnFailureListener(e->{
            recordSyncWarning("تعذر تحديث شركات الشحن وحسابات Store، لكن ستستمر مزامنة المنتجات والعملاء والفواتير.",e);
            if(done!=null)done.run();
        });
    }

    /** Pull the cloud catalog and the current partner's customers/invoices into local SQLite. */
    public void syncCloudToLocalForPartner(final Runnable done, final Runnable failed) {
        lastSyncError=""; lastSyncWarning="";
        if (!isLoggedIn() || isAdmin()) {
            lastSyncError="حساب الشريك غير صالح أو غير مسجل الدخول";
            if (failed != null) failed.run();
            return;
        }

        // Always use the authoritative server profile before a partner sync.
        // This prevents a fresh/reinstalled device from starting with a stale
        // cached partnerId and therefore skipping the invoice query.
        loadProfile().addOnSuccessListener(profileDoc -> {
            if (profileDoc == null || !profileDoc.exists() ||
                    !applyProfileDocument(profileDoc, true) || partnerId <= 0) {
                lastSyncError="تعذر تحديد Partner ID للحساب قبل مزامنة الفواتير.";
                if (failed != null) failed.run();
                return;
            }

            refreshAuthToken().addOnSuccessListener(v -> {
                // IMPORTANT: invoices are the critical partner data. Pull them
                // first and independently. A permission/problem in optional
                // shipping, product-settings, or customer sync must never prevent
                // invoices from reaching a newly installed partner device.
                syncPartnerInvoicesBidirectional(done, failed);

                // Optional data continues independently in the background.
                syncShippingCompaniesFromCloud(
                    () -> {},
                    () -> recordSyncWarning("تعذر تحديث شركات الشحن للشريك.", null)
                );
                syncProductsFromCloud(
                    () -> {},
                    () -> recordSyncWarning("تعذر تحديث بعض بيانات المنتجات للشريك.", null)
                );
                syncPartnerProductSettingsFromCloud(
                    () -> {},
                    () -> recordSyncWarning("تعذر تحديث إعدادات منتجات الشريك.", null)
                );
                syncPartnerCustomersBidirectional(
                    () -> syncRememberedSalePrices(
                        () -> {},
                        () -> recordSyncWarning("تعذر تحديث أسعار الزبائن المحفوظة للشريك.", null)
                    ),
                    () -> recordSyncWarning("تعذر تحديث زبائن الشريك.", null)
                );
            }).addOnFailureListener(e -> {
                recordSyncFailure(e);
                if (failed != null) failed.run();
            });
        }).addOnFailureListener(e -> {
            recordSyncFailure(e);
            if (failed != null) failed.run();
        });
    }

    /** Push/pull remembered last sale prices for registered customers. */
    public void syncRememberedSalePrices(final Runnable done, final Runnable failed){
        // Optional feature: a missing/old Firestore rule must not fail the main sync.
        if(!isLoggedIn()){ if(done!=null)done.run(); return; }
        pushRememberedCustomerPrices(() -> {
            if(isAdmin()) syncRememberedCustomerPricesForAdmin(done,failed);
            else syncRememberedCustomerPricesForPartner(done,failed);
        }, failed);
    }

    private void pushRememberedCustomerPrices(final Runnable done, final Runnable failed){
        java.util.ArrayList<ContentValues> rows=db.customerProductPricesForSync();
        java.util.ArrayList<Task<Void>> tasks=new java.util.ArrayList<>();
        for(ContentValues row:rows){
            Integer cid=row.getAsInteger("customer_id"), pid=row.getAsInteger("product_id");
            if(cid==null||pid==null)continue;
            Store.Customer c=db.customer(cid); if(c==null||c.cloudId==null||c.cloudId.trim().isEmpty())continue;
            if(!isAdmin() && c.partnerId!=(int)partnerId)continue;
            String key=c.cloudId.trim()+"_"+pid;
            Map<String,Object> m=new HashMap<>();m.put("customerCloudId",c.cloudId.trim());m.put("customerId",cid);m.put("productId",pid);m.put("lastPrice",row.getAsDouble("last_price"));m.put("partnerId",c.partnerId);m.put("updatedAt",row.getAsLong("updated_at"));m.put("updatedBy",uid());
            tasks.add(fs.collection("customer_product_prices").document(key).set(m,SetOptions.merge()));
        }
        if(tasks.isEmpty()){if(done!=null)done.run();return;}
        com.google.android.gms.tasks.Tasks.whenAll(tasks).addOnSuccessListener(v->{if(done!=null)done.run();}).addOnFailureListener(e->{
            recordSyncWarning("تعذر مزامنة أسعار الزبائن المحفوظة: "+(e==null?"":String.valueOf(e.getMessage())), e);
            if(failed!=null)failed.run();
        });
    }
    private void syncRememberedCustomerPricesForAdmin(final Runnable done, final Runnable failed){
        fs.collection("customer_product_prices").get().addOnSuccessListener(snapshot->{for(DocumentSnapshot d:snapshot.getDocuments())applyRemoteCustomerPrice(d);if(done!=null)done.run();}).addOnFailureListener(e->{
            recordSyncWarning("تعذر قراءة أسعار الزبائن المحفوظة من السحابة.", e);
            if(failed!=null)failed.run();
        });
    }
    private void syncRememberedCustomerPricesForPartner(final Runnable done, final Runnable failed){
        if(partnerId<=0){if(done!=null)done.run();return;}
        fs.collection("customer_product_prices").whereEqualTo("partnerId",partnerId).get().addOnSuccessListener(snapshot->{for(DocumentSnapshot d:snapshot.getDocuments())applyRemoteCustomerPrice(d);if(done!=null)done.run();}).addOnFailureListener(e->{
            recordSyncWarning("تعذر قراءة أسعار الزبائن المحفوظة للشريك من السحابة.", e);
            if(failed!=null)failed.run();
        });
    }
    private void applyRemoteCustomerPrice(DocumentSnapshot d){
        String customerCloudId=str(d.getString("customerCloudId"));Long pid=d.getLong("productId");Double price=d.getDouble("lastPrice");
        if(customerCloudId.isEmpty()||pid==null||pid<=0||price==null||price<=0)return;
        Store.Customer c=db.customerByCloudId(customerCloudId);if(c==null)return;
        db.saveCustomerProductPrice(c.id,pid.intValue(),price);
    }

    /** Sync partner-specific product price + customer-facing image. Admin controls price; partner controls only image. */
    public void syncPartnerProductSettingsToCloud(final Runnable done, final Runnable failed){
        if(!isLoggedIn() || (!isAdmin() && partnerId<=0)){ if(failed!=null)failed.run(); return; }
        android.database.Cursor c=db.getReadableDatabase().query("partner_product_settings",null,isAdmin()?null:"partner_id=?",isAdmin()?null:new String[]{String.valueOf(partnerId)},null,null,null);
        java.util.ArrayList<Store.PartnerProductSetting> rows=new java.util.ArrayList<>();
        try{while(c.moveToNext()) rows.add(new Store.PartnerProductSetting(c.getInt(c.getColumnIndexOrThrow("id")),c.getInt(c.getColumnIndexOrThrow("partner_id")),c.getInt(c.getColumnIndexOrThrow("product_id")),c.getDouble(c.getColumnIndexOrThrow("partner_price")),c.getColumnIndex("price_tiers")<0?"":(c.isNull(c.getColumnIndex("price_tiers"))?"":c.getString(c.getColumnIndex("price_tiers"))),c.getString(c.getColumnIndexOrThrow("customer_image"))));}finally{c.close();}
        if(rows.isEmpty()){if(done!=null)done.run();return;}
        java.util.ArrayList<Task<Void>> tasks=new java.util.ArrayList<>();
        for(Store.PartnerProductSetting row:rows) tasks.add(pushPartnerProductSetting(row));
        com.google.android.gms.tasks.Tasks.whenAll(tasks).addOnSuccessListener(v->{
            if(isAdmin()) syncAllPartnerProductSettingsFromCloud(done,failed); else if(done!=null)done.run();
        }).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
    }

    private Task<Void> pushPartnerProductSetting(final Store.PartnerProductSetting row){
        if(row.partnerId<=0||row.productId<=0)return com.google.android.gms.tasks.Tasks.forResult(null);
        if(!isAdmin() && row.partnerId!=(int)partnerId)return com.google.android.gms.tasks.Tasks.forException(new IllegalStateException("لا يمكن للشريك تعديل إعدادات شريك آخر"));
        final String key=row.partnerId+"_"+row.productId;
        return uploadPartnerProductImageTask(row).continueWithTask(imageTask->{
            String imageUrl=imageTask.isSuccessful()?imageTask.getResult():"";
            Map<String,Object> m=new HashMap<>();m.put("partnerId",row.partnerId);m.put("productId",row.productId);m.put("partnerPrice",row.partnerPrice);m.put("priceTiers",row.priceTiers==null?"":row.priceTiers);m.put("customerImageUrl",imageUrl);m.put("updatedAt",System.currentTimeMillis());m.put("updatedBy",uid());
            return fs.collection("partner_product_settings").document(key).get().continueWithTask(read->{
                DocumentSnapshot old=read.getResult();
                if(!imageUrl.isEmpty() || old==null || !old.exists()) return fs.collection("partner_product_settings").document(key).set(m,SetOptions.merge());
                // If there is no new local image, preserve the already uploaded cloud image.
                m.put("customerImageUrl",str(old.getString("customerImageUrl")));
                return fs.collection("partner_product_settings").document(key).set(m,SetOptions.merge());
            });
        });
    }

    private Task<String> uploadPartnerProductImageTask(Store.PartnerProductSetting row){
        String image=row.customerImage==null?"":row.customerImage.trim();
        if(image.isEmpty() || image.startsWith("http"))return com.google.android.gms.tasks.Tasks.forResult(image);
        try{
            Uri uri=Uri.parse(image); File file=new File(uri.getPath()==null?image:uri.getPath());
            if(!file.exists())return com.google.android.gms.tasks.Tasks.forResult("");
            StorageReference ref=storage.getReference().child("partner_product_images/"+row.partnerId+"/"+row.productId+".jpg");
            return ref.putFile(uri).continueWithTask(t->{if(!t.isSuccessful())throw t.getException();return ref.getDownloadUrl();}).continueWith(t->{if(!t.isSuccessful())throw t.getException();return t.getResult().toString();});
        }catch(Exception e){return com.google.android.gms.tasks.Tasks.forException(e);}
    }

    private void syncAllPartnerProductSettingsFromCloud(final Runnable done, final Runnable failed){
        fs.collection("partner_product_settings").get().addOnSuccessListener(snapshot->{
            java.util.List<DocumentSnapshot> docs=snapshot.getDocuments(); if(docs.isEmpty()){if(done!=null)done.run();return;}
            final int[] remaining={docs.size()};
            for(DocumentSnapshot d:docs){
                Long lp=d.getLong("partnerId"), lprod=d.getLong("productId");int partner=lp==null?0:lp.intValue(),product=lprod==null?0:lprod.intValue();Double pp=d.getDouble("partnerPrice");String pt=str(d.getString("priceTiers"));String imageUrl=str(d.getString("customerImageUrl"));
                if(partner<=0||product<=0){if(--remaining[0]==0&&done!=null)done.run();continue;}
                if(imageUrl.isEmpty()){db.savePartnerProductSetting(partner,product,pp==null?0:pp,pt,"");if(--remaining[0]==0&&done!=null)done.run();continue;}
                downloadPartnerProductImage(partner,product,imageUrl).addOnSuccessListener(path->{db.savePartnerProductSetting(partner,product,pp==null?0:pp,pt,path);if(--remaining[0]==0&&done!=null)done.run();}).addOnFailureListener(e->{recordSyncWarning("تعذر تنزيل صورة الشريك للمنتج "+product,e);if(--remaining[0]==0&&done!=null)done.run();});
            }
        }).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
    }

    private void syncPartnerProductSettingsFromCloud(final Runnable done, final Runnable failed){
        if(!isLoggedIn()||isAdmin()||partnerId<=0){if(done!=null)done.run();return;}
        fs.collection("partner_product_settings").whereEqualTo("partnerId",partnerId).get().addOnSuccessListener(snapshot->{
            java.util.List<DocumentSnapshot> docs=snapshot.getDocuments();
            if(docs.isEmpty()){if(done!=null)done.run();return;}
            final int[] remaining={docs.size()};
            for(DocumentSnapshot d:docs){
                // productId is stored as a Firestore number. Do not call getString() first:
                // on partner accounts this callback runs during the background sync and a
                // type mismatch can throw and terminate the app a few seconds after login.
                Long lp=d.getLong("productId");
                int pid=lp==null?parseInt(str(d.getString("productId"))):lp.intValue();
                if(pid<=0){if(--remaining[0]==0&&done!=null)done.run();continue;}
                Double pp=d.getDouble("partnerPrice");String pt=str(d.getString("priceTiers"));String imageUrl=str(d.getString("customerImageUrl"));
                final int productId=pid; final double price=pp==null?0:pp; final String partnerTiers=pt;
                if(imageUrl.isEmpty()){
                    Store.PartnerProductSetting old=db.partnerProductSetting((int)partnerId,productId);String localImage=old==null?"":old.customerImage;
                    db.savePartnerProductSetting((int)partnerId,productId,price,partnerTiers,localImage);
                    if(--remaining[0]==0&&done!=null)done.run();continue;
                }
                downloadPartnerProductImage((int)partnerId,productId,imageUrl).addOnSuccessListener(path->{db.savePartnerProductSetting((int)partnerId,productId,price,partnerTiers,path);if(--remaining[0]==0&&done!=null)done.run();}).addOnFailureListener(e->{recordSyncWarning("تعذر تنزيل صورة الزبائن للمنتج "+productId,e);Store.PartnerProductSetting old=db.partnerProductSetting((int)partnerId,productId);db.savePartnerProductSetting((int)partnerId,productId,price,partnerTiers,old==null?"":old.customerImage);if(--remaining[0]==0&&done!=null)done.run();});
            }
        }).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
    }

    private Task<String> downloadPartnerProductImage(int partnerId,int productId,String imageUrl){
        try{
            File dir=new File(context.getFilesDir(),"product_images/partner_"+partnerId);if(!dir.exists()&&!dir.mkdirs())return com.google.android.gms.tasks.Tasks.forException(new IllegalStateException("تعذر إنشاء مجلد صور الشريك"));
            File out=new File(dir,"product_"+productId+".jpg");
            return storage.getReference().child("partner_product_images/"+partnerId+"/"+productId+".jpg").getFile(out).continueWith(t->{if(!t.isSuccessful())throw t.getException();return Uri.fromFile(out).toString();});
        }catch(Exception e){return com.google.android.gms.tasks.Tasks.forException(e);}
    }

    /**
     * Partner invoice pull/push.
     *
     * A partner must always be able to pull the invoices belonging to his
     * Partner ID after a fresh install. Older versions mixed the partner pull
     * with local tombstone/deletion reconciliation; a single denied delete or
     * write could therefore make the whole sync report PERMISSION_DENIED even
     * though the invoice query itself was valid.
     *
     * Partners now pull the authoritative invoice set first from SERVER. Local
     * edits/new invoices may then be pushed, but a partner never attempts to
     * delete a Firestore invoice. Admin remains responsible for deletion.
     */
    private void syncPartnerInvoicesBidirectional(final Runnable done, final Runnable failed){
        if(partnerId<=0){
            lastSyncError="تعذر تحديد Partner ID للحساب قبل مزامنة الفواتير.";
            if(failed!=null)failed.run();
            return;
        }
        fs.collection("invoices").whereEqualTo("partner_id",partnerId).get(Source.SERVER).addOnSuccessListener(remote->{
            java.util.ArrayList<Task<Void>> tasks=new java.util.ArrayList<>();
            java.util.HashMap<String,DocumentSnapshot> winners=dedupeRemoteInvoices(remote,java.util.Collections.emptySet(),tasks);
            cleanupLocalInvoiceDuplicates(winners);
            java.util.HashMap<String,DocumentSnapshot> remoteMap=new java.util.HashMap<>(winners);

            // Pull every remote invoice first. This is the critical path for a
            // newly installed partner phone.
            for(DocumentSnapshot r:winners.values()){
                Store.Invoice local=db.invoiceByCloudKey(r.getId());
                if(local==null){
                    int legacyId=parseInt(r.getId());
                    if(legacyId>0){
                        Store.Invoice candidate=db.invoice(legacyId);
                        Long rp=r.getLong("partner_id"); int remotePartner=rp==null?0:rp.intValue();
                        if(candidate!=null && candidate.partnerId==remotePartner && (candidate.cloudKey==null||candidate.cloudKey.isEmpty())) local=candidate;
                    }
                }
                if(local==null){
                    tasks.add(applyRemoteInvoice(r));
                }else{
                    long lt=db.syncLocalUpdatedAt("invoices",local.id), rt=remoteTimestamp(r);
                    boolean remoteShipped=Boolean.TRUE.equals(r.getBoolean("shipped_by_admin"));
                    // Admin-shipped invoices are authoritative from the cloud.
                    if(remoteShipped || !"dirty".equals(db.syncState("invoices",local.id)) || lt<rt){
                        tasks.add(applyRemoteInvoice(r));
                    }else{
                        final int localId=local.id;
                        tasks.add(finalizeInvoiceNumberIfNeeded(localId).continueWithTask(t->{if(!t.isSuccessful())throw t.getException();return pushLocalInvoice(localId,r);}));
                    }
                }
            }

            // Push local partner-created/edited invoices that do not exist in
            // the cloud yet. Never delete a remote invoice from partner code.
            android.database.Cursor c=db.getReadableDatabase().query("invoices",new String[]{"id"},"partner_id=? AND shipped_by_admin=0",new String[]{String.valueOf(partnerId)},null,null,"id ASC");
            try{
                while(c.moveToNext()){
                    int id=c.getInt(0);
                    Store.Invoice local=db.invoice(id);
                    if(local==null)continue;
                    if(!"dirty".equals(db.syncState("invoices",id)))continue;
                    String key=local.cloudKey==null?"":local.cloudKey.trim();
                    if(key.isEmpty()){key="inv_"+java.util.UUID.randomUUID().toString();db.setInvoiceCloudKey(id,key);}
                    if(!remoteMap.containsKey(key)) tasks.add(finalizeInvoiceNumberIfNeeded(id).continueWithTask(t->{if(!t.isSuccessful())throw t.getException();return pushLocalInvoice(id,null);}));
                }
            }finally{c.close();}

            if(tasks.isEmpty()){if(done!=null)done.run();return;}
            com.google.android.gms.tasks.Tasks.whenAll(tasks)
                .addOnSuccessListener(v->{if(done!=null)done.run();})
                .addOnFailureListener(e->{
                    // The remote pull has already been applied. Report the
                    // optional local push problem as a warning so the partner
                    // still sees invoices on a fresh device.
                    recordSyncWarning("تم تنزيل فواتير الشريك، لكن تعذر رفع بعض التعديلات المحلية.",e);
                    if(done!=null)done.run();
                });
        }).addOnFailureListener(e->{
            recordSyncFailure(e);
            if(failed!=null)failed.run();
        });
    }

    /** Refresh all invoices safely for Admin-only financial reports. */
    public void refreshAllInvoicesForAdmin(final Runnable done, final Runnable failed){
        if(!isLoggedIn() || !isAdmin()){
            if(failed!=null)failed.run();
            return;
        }
        // Reuse the timestamp-aware Admin reconciliation so a report refresh
        // cannot overwrite a newer unsynced local edit.
        syncInvoicesOnlyForAdmin(done, failed);
    }

    private void syncProductsFromCloud(final Runnable done, final Runnable failed){
        fs.collection("products").get().addOnSuccessListener(products -> {
            java.util.List<com.google.firebase.firestore.DocumentSnapshot> docs=products.getDocuments();
            if(docs.isEmpty()){if(done!=null)done.run();return;}
            final int[] remaining={docs.size()};
            android.database.sqlite.SQLiteDatabase local=db.getWritableDatabase();
            for(com.google.firebase.firestore.DocumentSnapshot d:docs){
                final int pid=parseInt(d.getId());
                final String imageUrl=str(d.getString("imageUrl"));
                ContentValues v=new ContentValues();
                v.put("id",pid); v.put("name",str(d.getString("name"))); v.put("code",str(d.getString("code")));
                Double price=d.getDouble("price"); v.put("price",price==null?0:price); Boolean av=d.getBoolean("available"); v.put("available",av==null?1:(av?1:0)); v.put("price_tiers",str(d.getString("priceTiers")));
                // Keep the cloud URL immediately; then replace it with a local cached copy when possible.
                v.put("image",imageUrl);
                local.insertWithOnConflict("products",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);
                if(imageUrl.isEmpty()){
                    if(--remaining[0]==0&&done!=null)done.run();
                    continue;
                }
                downloadProductImage(pid,imageUrl).addOnSuccessListener(path->{
                    if(path!=null&&!path.isEmpty()){
                        ContentValues iv=new ContentValues(); iv.put("image",path);
                        db.getWritableDatabase().update("products",iv,"id=?",new String[]{String.valueOf(pid)});
                    }
                    if(--remaining[0]==0&&done!=null)done.run();
                }).addOnFailureListener(e->{
                    // Image download must not make the whole cloud sync fail.
                    recordSyncWarning("تعذر تنزيل صورة المنتج "+pid+"؛ تم تنزيل بيانات المنتج.",e);
                    if(--remaining[0]==0&&done!=null)done.run();
                });
            }
        }).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
    }

    private Task<String> downloadProductImage(int productId,String imageUrl){
        try{
            File dir=new File(context.getFilesDir(),"product_images");
            if(!dir.exists()&&!dir.mkdirs()) return com.google.android.gms.tasks.Tasks.forException(new IllegalStateException("تعذر إنشاء مجلد صور المنتجات"));
            File out=new File(dir,"cloud_"+productId+".jpg");
            return storage.getReference().child("products/"+productId+"/main.jpg").getFile(out).continueWith(t->{
                if(!t.isSuccessful()) throw t.getException();
                return Uri.fromFile(out).toString();
            });
        }catch(Exception e){return com.google.android.gms.tasks.Tasks.forException(e);}
    }

    private void syncCustomersFromCloud(final Runnable done, final Runnable failed){
        fs.collection("customers").whereEqualTo("partnerId",partnerId).get().addOnSuccessListener(customers->{
            android.database.sqlite.SQLiteDatabase local=db.getWritableDatabase();
            for(com.google.firebase.firestore.DocumentSnapshot d:customers.getDocuments()){
                ContentValues v=new ContentValues();v.put("id",parseInt(d.getId()));v.put("name",str(d.getString("name")));v.put("phone",str(d.getString("phone")));v.put("city",str(d.getString("city")));v.put("address",str(d.getString("address")));v.put("reseller",Boolean.TRUE.equals(d.getBoolean("reseller"))?1:0);v.put("partner_id",partnerId);v.put("partner_uid",str(d.getString("partnerUid")));v.put("partner_email",str(d.getString("partner_email")));Double sh=d.getDouble("defaultShipping");v.put("default_shipping",sh==null?30:sh);local.insertWithOnConflict("customers",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);
            }
            if(done!=null)done.run();
        }).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
    }

    private void syncPartnerCustomersBidirectional(final Runnable done, final Runnable failed){
        fs.collection("customers").whereEqualTo("partnerId",partnerId).get().addOnSuccessListener(remote->{
            java.util.HashMap<String,DocumentSnapshot> remoteMap=new java.util.HashMap<>();
            for(DocumentSnapshot d:remote.getDocuments()) if(!Boolean.TRUE.equals(d.getBoolean("reseller"))) remoteMap.put(d.getId(),d);
            java.util.ArrayList<Task<Void>> tasks=new java.util.ArrayList<>();
            for(DocumentSnapshot r:remote.getDocuments()){
                if(Boolean.TRUE.equals(r.getBoolean("reseller"))) continue;
                if(isCustomerTombstoneForCloudId(r.getId())) continue;
                Store.Customer local=localCustomerForRemote(r);
                if(local==null){
                    tasks.add(applyRemoteCustomer(r));
                }else{
                    if(local.cloudId==null||local.cloudId.isEmpty()) db.setCustomerCloudId(local.id,r.getId());
                    long lt=db.syncLocalUpdatedAt("customers",local.id), rt=remoteTimestamp(r);
                    if(local.partnerId==(int)partnerId && "dirty".equals(db.syncState("customers",local.id)) && lt>=rt) tasks.add(pushLocalCustomer(local.id));
                    else tasks.add(applyRemoteCustomer(r));
                }
            }
            android.database.Cursor lc=db.getReadableDatabase().query("customers",new String[]{"id"},"partner_id=? AND reseller=0",new String[]{String.valueOf(partnerId)},null,null,null);
            try{while(lc.moveToNext()){
                int id=lc.getInt(0); Store.Customer c=db.customer(id); if(c==null||!"dirty".equals(db.syncState("customers",id))) continue;
                String key=(c.cloudId==null||c.cloudId.isEmpty())?String.valueOf(id):c.cloudId;
                if(!remoteMap.containsKey(key)) tasks.add(pushLocalCustomer(id));
            }}finally{lc.close();}
            android.database.Cursor dc=db.getReadableDatabase().query("sync_meta",new String[]{"local_id"},"entity=? AND state=? AND deleted=1",new String[]{"customers","dirty"},null,null,null);
            try{while(dc.moveToNext()){int id=dc.getInt(0);String key=db.syncCloudKey("customers",id);if(key==null||key.isEmpty())key=String.valueOf(id);if(remoteMap.containsKey(key))tasks.add(fs.collection("customers").document(key).delete().continueWith(t->{if(!t.isSuccessful())throw t.getException();db.markSyncClean("customers",id,System.currentTimeMillis());return null;}));}}finally{dc.close();}
            if(tasks.isEmpty()){if(done!=null)done.run();return;}
            com.google.android.gms.tasks.Tasks.whenAll(tasks).addOnSuccessListener(v->{if(done!=null)done.run();}).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
        }).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
    }

    private void syncInvoicesFromCloud(final Runnable done, final Runnable failed){
        fs.collection("invoices").whereEqualTo("partner_id",partnerId).get().addOnSuccessListener(invoices->{
            java.util.List<com.google.firebase.firestore.DocumentSnapshot> docs=invoices.getDocuments();
            if(docs.isEmpty()){if(done!=null)done.run();return;}
            final int[] remaining={docs.size()};final boolean[] failedOnce={false};
            for(com.google.firebase.firestore.DocumentSnapshot d:docs){
                applyRemoteInvoice(d).addOnSuccessListener(v->{if(--remaining[0]==0&&!failedOnce[0]&&done!=null)done.run();}).addOnFailureListener(e->{if(!failedOnce[0]){failedOnce[0]=true;recordSyncFailure(e);if(failed!=null)failed.run();}});
            }
        }).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
    }

    private int parseInt(String s){try{return Integer.parseInt(s);}catch(Exception e){return 0;}}
    private String str(String s){return s==null?"":s;}
    private void putS(ContentValues v,String k,Object o){if(o==null)v.putNull(k);else if(o instanceof Number)v.put(k,((Number)o).longValue());else v.put(k,String.valueOf(o));}
    private void putD(ContentValues v,String k,Double o){if(o==null)v.put(k,0d);else v.put(k,o);}
    private void putB(ContentValues v,String k,Long o){v.put(k,o!=null&&o!=0?1:0);}
    private void putB(ContentValues v,String k,Boolean o){v.put(k,Boolean.TRUE.equals(o)?1:0);}

}
