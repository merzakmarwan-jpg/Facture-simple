package ma.mge.facturesimple

import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Item(
    val name: String,
    val qty: Double,
    val price: Double,
    val productId: String = "",
    val imagePath: String = ""
) { fun total(): Double = qty * price }

data class Product(
    val id: String,
    var name: String,
    var code: String,
    var price: Double,
    var imagePath: String = ""
) { override fun toString(): String = "$name $code" }

data class Customer(
    val id: String,
    var name: String,
    var phone: String = "",
    var city: String = "",
    var address: String = ""
)

class MainActivity : AppCompatActivity() {
    private lateinit var invoiceNo: EditText
    private lateinit var customer: AutoCompleteTextView
    private lateinit var customerPhone: EditText
    private lateinit var customerCity: EditText
    private lateinit var customerAddress: EditText
    private lateinit var itemsBox: LinearLayout
    private lateinit var totalView: TextView
    private lateinit var dateView: TextView
    private lateinit var paymentStatus: CheckBox

    private val prefs by lazy { getSharedPreferences("invoices", MODE_PRIVATE) }
    private val products = mutableListOf<Product>()
    private val customers = mutableListOf<Customer>()
    private val productAdapters = mutableListOf<ProductAdapter>()
    private var companyLogoPath = ""
    private var companyPhone = ""
    private var editingInvoiceNumber: String? = null
    private var editingInvoiceDate: String? = null
    private var pendingProductImagePath = ""
    private var pendingProductImageView: ImageView? = null
    private var pendingCompanyLogoPath = ""
    private var pendingCompanyLogoView: ImageView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadProducts(); loadCustomers(); loadCompanySettings(); buildUi(); startNewInvoice()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 12, 18, 18)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "فاتورة بسيطة"; textSize = 24f; setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(Button(this).apply { text = "الشركة"; setOnClickListener { showCompanySettingsDialog() } }, lpWrap())
        header.addView(Button(this).apply { text = "المنتجات"; setOnClickListener { showProductsDialog() } }, lpWrap())
        header.addView(Button(this).apply { text = "الزبائن"; setOnClickListener { showCustomersDialog() } }, lpWrap())
        header.addView(Button(this).apply { text = "الفواتير"; setOnClickListener { showInvoicesDialog() } }, lpWrap())
        root.addView(header, lp())

        invoiceNo = field("رقم الفاتورة").apply { inputType = InputType.TYPE_CLASS_NUMBER }
        root.addView(invoiceNo, lp())

        customer = AutoCompleteTextView(this).apply {
            hint = "اسم الزبون"; textSize = 16f; threshold = 1; setPadding(14,10,14,10)
            background = AppCompatResources.getDrawable(this@MainActivity, android.R.drawable.edit_text)
            setAdapter(CustomerAdapter(customers))
            setOnItemClickListener { _, _, position, _ ->
                val c = adapter.getItem(position) as? Customer ?: return@setOnItemClickListener
                fillCustomer(c)
            }
        }
        root.addView(customer, lp())
        customerPhone = field("هاتف الزبون")
        customerPhone.inputType = InputType.TYPE_CLASS_PHONE
        customerCity = field("مدينة الزبون")
        customerAddress = field("عنوان الزبون")
        root.addView(customerPhone, lp()); root.addView(customerCity, lp()); root.addView(customerAddress, lp())

        paymentStatus = CheckBox(this).apply { text = "الفاتورة مدفوعة"; textSize = 17f }
        root.addView(paymentStatus, lp())
        dateView = TextView(this).apply { textSize = 16f; setPadding(4,4,4,10) }
        root.addView(dateView, lp())
        root.addView(TextView(this).apply { text = "المنتجات في الفاتورة"; textSize = 19f; setTypeface(null,Typeface.BOLD) }, lp())

        val scroll = ScrollView(this)
        itemsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0,4,0,4) }
        scroll.addView(itemsBox); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        root.addView(Button(this).apply { text = "＋ إضافة منتج"; setOnClickListener { addItemRow() } }, lp())
        totalView = TextView(this).apply { textSize=22f; setTypeface(null,Typeface.BOLD); gravity=Gravity.CENTER; setPadding(0,12,0,12) }
        root.addView(totalView, lp())
        val buttons = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
        buttons.addView(Button(this).apply { text="حفظ الفاتورة"; setOnClickListener { saveInvoice() } }, LinearLayout.LayoutParams(0,-2,1f))
        buttons.addView(Button(this).apply { text="PDF"; setOnClickListener { createPdfAndShare() } }, LinearLayout.LayoutParams(0,-2,1f))
        buttons.addView(Button(this).apply { text="فاتورة جديدة"; setOnClickListener { startNewInvoice() } }, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(buttons)
        setContentView(root)
    }

    private fun addItemRow(item: Item? = null) {
        val row = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,8,0,8); background=ColorDrawable(Color.rgb(245,247,250)) }
        val adapter = ProductAdapter(products); productAdapters.add(adapter)
        val productInput = AutoCompleteTextView(this).apply {
            hint="اكتب اسم المنتج أو المرجع"; textSize=16f; threshold=1; setPadding(14,10,14,10)
            background=AppCompatResources.getDrawable(this@MainActivity,android.R.drawable.edit_text); setAdapter(adapter)
        }
        val preview=ImageView(this).apply { layoutParams=LinearLayout.LayoutParams(90,90).apply{gravity=Gravity.CENTER_HORIZONTAL;bottomMargin=6};scaleType=ImageView.ScaleType.CENTER_CROP;visibility=View.GONE }
        val qty=field("الكمية").apply{inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL}
        val price=field("الثمن DH").apply{inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL}
        val selected=item?.let{findProduct(it.productId)}
        if(item!=null){ productInput.setText(item.name,false);qty.setText(fmt(item.qty));price.setText(fmt(item.price));row.tag=item.productId; if(item.imagePath.isNotEmpty())showImage(preview,item.imagePath) else if(selected?.imagePath?.isNotEmpty()==true)showImage(preview,selected.imagePath) }
        productInput.setOnItemClickListener { _,_,position,_ ->
            val p=productInput.adapter.getItem(position) as? Product ?: return@setOnItemClickListener
            productInput.setText(p.name,false);price.setText(fmt(p.price));row.tag=p.id
            if(p.imagePath.isNotEmpty())showImage(preview,p.imagePath) else preview.visibility=View.GONE; updateTotal()
        }
        val watcher=object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){updateTotal()};override fun afterTextChanged(s:Editable?) {}}
        qty.addTextChangedListener(watcher);price.addTextChangedListener(watcher)
        row.addView(productInput,lp());row.addView(preview)
        val numbers=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};numbers.addView(qty,LinearLayout.LayoutParams(0,-2,1f));numbers.addView(price,LinearLayout.LayoutParams(0,-2,1f));row.addView(numbers)
        row.addView(Button(this).apply{text="حذف هذا المنتج";setOnClickListener{itemsBox.removeView(row);updateTotal()}},lp())
        itemsBox.addView(row)
    }

    private fun readItems():List<Item>{
        val result=mutableListOf<Item>()
        for(i in 0 until itemsBox.childCount){
            val row=itemsBox.getChildAt(i) as? LinearLayout ?: continue
            if(row.childCount<3)continue
            val name=(row.getChildAt(0) as AutoCompleteTextView).text.toString().trim(); val numbers=row.getChildAt(2) as? LinearLayout ?: continue
            val qty=(numbers.getChildAt(0) as EditText).text.toString().toDoubleOrNull()?:0.0;val price=(numbers.getChildAt(1) as EditText).text.toString().toDoubleOrNull()?:0.0
            val id=row.tag?.toString() ?: ""; val image=findProduct(id)?.imagePath?:""; if(name.isNotEmpty())result.add(Item(name,qty,price,id,image))
        };return result
    }
    private fun updateTotal(){totalView.text=String.format(Locale.US,"المجموع : %.2f DH",readItems().sumOf{it.total()})}

    private fun saveInvoice(){
        val no=invoiceNo.text.toString().trim(); if(no.isEmpty()){toast("أدخل رقم الفاتورة");return};val data=readItems();if(data.isEmpty()){toast("أضف منتجًا واحدًا على الأقل");return}
        val date=editingInvoiceDate?:today(); val obj=JSONObject().apply{
            put("number",no);put("date",date);put("customer",customer.text.toString().trim());put("customerPhone",customerPhone.text.toString().trim());put("customerCity",customerCity.text.toString().trim());put("customerAddress",customerAddress.text.toString().trim());put("paid",paymentStatus.isChecked)
            put("items",JSONArray().apply{data.forEach{put(JSONObject().apply{put("name",it.name);put("qty",it.qty);put("price",it.price);put("productId",it.productId);put("imagePath",it.imagePath)})}})
        }
        val array=JSONArray(prefs.getString("invoices","[]"));var found=false
        for(i in 0 until array.length())if(array.getJSONObject(i).optString("number")==no){array.put(i,obj);found=true;break};if(!found)array.put(obj)
        prefs.edit().putString("invoices",array.toString()).putInt("last_number",maxOf(prefs.getInt("last_number",0),no.toIntOrNull()?:0)).apply()
        saveOrUpdateCustomerFromInvoice();editingInvoiceNumber=no;editingInvoiceDate=date;toast("تم حفظ الفاتورة رقم $no")
    }

    private fun showInvoicesDialog(){
        var dialog:AlertDialog?=null
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,8,18,8);layoutDirection=View.LAYOUT_DIRECTION_RTL}
        val search=field("بحث برقم الفاتورة أو اسم/هاتف الزبون");box.addView(search,lp())
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};val scroll=ScrollView(this);scroll.addView(list);box.addView(scroll,LinearLayout.LayoutParams(-1,560))
        fun render(){
            list.removeAllViews();val q=search.text.toString().trim().lowercase(Locale.getDefault());val array=JSONArray(prefs.getString("invoices","[]"));var count=0
            for(i in array.length()-1 downTo 0){val o=array.getJSONObject(i);val text=(o.optString("number")+" "+o.optString("customer")+" "+o.optString("customerPhone")).lowercase(Locale.getDefault());if(q.isNotEmpty()&&!text.contains(q))continue;count++
                val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,10,12,10);setBackgroundColor(Color.rgb(245,247,250))}
                row.addView(TextView(this).apply{text="فاتورة #${o.optString("number")}  •  ${o.optString("date")}";textSize=17f;setTypeface(null,Typeface.BOLD)})
                row.addView(TextView(this).apply{val status=if(o.optBoolean("paid"))"✓ مدفوعة" else "✗ غير مدفوعة";text="${o.optString("customer","بدون اسم")}  •  ${o.optString("customerPhone")}  •  ${fmt(invoiceTotal(o))} DH  •  $status";textSize=14f})
                val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
                actions.addView(Button(this).apply{text="تعديل";setOnClickListener{loadInvoice(o);dialog?.dismiss() }},LinearLayout.LayoutParams(0,-2,1f))
                actions.addView(Button(this).apply{text="PDF";setOnClickListener{loadInvoice(o);dialog?.dismiss();createPdfAndShare()}},LinearLayout.LayoutParams(0,-2,1f))
                actions.addView(Button(this).apply{text="حذف";setOnClickListener{confirmDeleteInvoice(o,optDialog={dialog?.dismiss();showInvoicesDialog()})}},LinearLayout.LayoutParams(0,-2,1f))
                row.addView(actions);list.addView(row,lp())
            }
            if(count==0)list.addView(TextView(this).apply{text="لا توجد نتائج";textSize=17f;setPadding(0,30,0,30)})
        }
        search.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){render()};override fun afterTextChanged(s:Editable?){}})
        box.addView(Button(this).apply{text="إغلاق";setOnClickListener{dialog?.dismiss()}},lp());dialog=AlertDialog.Builder(this).setTitle("البحث وتعديل الفواتير").setView(box).create();dialog.show();render()
    }

    private fun confirmDeleteInvoice(o:JSONObject,optDialog:()->Unit){AlertDialog.Builder(this).setTitle("حذف الفاتورة").setMessage("هل تريد حذف الفاتورة رقم ${o.optString("number")}؟").setPositiveButton("حذف"){_,_->val a=JSONArray(prefs.getString("invoices","[]"));val out=JSONArray();for(i in 0 until a.length())if(a.getJSONObject(i).optString("number")!=o.optString("number"))out.put(a.getJSONObject(i));prefs.edit().putString("invoices",out.toString()).apply();toast("تم حذف الفاتورة");optDialog()}.setNegativeButton("إلغاء",null).show()}

    private fun loadInvoice(o:JSONObject){
        editingInvoiceNumber=o.optString("number");editingInvoiceDate=o.optString("date",today());invoiceNo.setText(editingInvoiceNumber);customer.setText(o.optString("customer"),false);customerPhone.setText(o.optString("customerPhone"));customerCity.setText(o.optString("customerCity"));customerAddress.setText(o.optString("customerAddress"));paymentStatus.isChecked=o.optBoolean("paid",false)
        itemsBox.removeAllViews();val arr=o.optJSONArray("items")?:JSONArray();for(i in 0 until arr.length()){val x=arr.getJSONObject(i);addItemRow(Item(x.optString("name"),x.optDouble("qty",1.0),x.optDouble("price",0.0),x.optString("productId"),x.optString("imagePath")))};if(arr.length()==0)addItemRow();updateDateText();updateTotal();toast("تم فتح الفاتورة رقم ${editingInvoiceNumber}")
    }

    private fun showProductsDialog(){
        var dialog:AlertDialog?=null;val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,8,18,8);layoutDirection=View.LAYOUT_DIRECTION_RTL}
        box.addView(Button(this).apply{text="＋ إضافة منتج جديد";setOnClickListener{showAddProductDialog()}},lp());val search=field("بحث باسم المنتج أو المرجع");box.addView(search,lp())
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};val scroll=ScrollView(this);scroll.addView(list);box.addView(scroll,LinearLayout.LayoutParams(-1,560))
        fun render(){list.removeAllViews();val q=search.text.toString().trim().lowercase(Locale.getDefault());val filtered=products.filter{q.isEmpty()||it.name.lowercase(Locale.getDefault()).contains(q)||it.code.lowercase(Locale.getDefault()).contains(q)};if(filtered.isEmpty())list.addView(TextView(this).apply{text="لا توجد منتجات";textSize=17f;setPadding(0,25,0,25)}) else filtered.forEach{p->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(8,8,8,8)};val image=ImageView(this).apply{layoutParams=LinearLayout.LayoutParams(65,65);scaleType=ImageView.ScaleType.CENTER_CROP};if(p.imagePath.isNotEmpty())showImage(image,p.imagePath) else image.setImageResource(android.R.drawable.ic_menu_gallery);row.addView(image)
            row.addView(TextView(this).apply{text="${p.name}\n${p.code}  •  ${fmt(p.price)} DH";textSize=15f;setPadding(10,0,10,0)},LinearLayout.LayoutParams(0,-2,1f))
            row.addView(Button(this).apply{text="تعديل";setOnClickListener{showAddProductDialog(p)} });row.addView(Button(this).apply{text="حذف";setOnClickListener{confirmDeleteProduct(p)}});list.addView(row,lp())
        }}
        search.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){render()};override fun afterTextChanged(s:Editable?){}})
        box.addView(Button(this).apply{text="إغلاق";setOnClickListener{dialog?.dismiss()}},lp());dialog=AlertDialog.Builder(this).setTitle("البحث وتعديل المنتجات").setView(box).create();dialog.show();render()
    }

    private fun confirmDeleteProduct(p:Product){AlertDialog.Builder(this).setTitle("حذف المنتج").setMessage("هل تريد حذف ${p.name}؟").setPositiveButton("حذف"){_,_->products.removeAll{it.id==p.id};saveProducts();showProductsDialog();toast("تم حذف المنتج")}.setNegativeButton("إلغاء",null).show()}

    private fun showAddProductDialog(existing:Product?=null){
        pendingProductImagePath=existing?.imagePath?:"";val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,8,24,8);layoutDirection=View.LAYOUT_DIRECTION_RTL}
        val image=ImageView(this).apply{layoutParams=LinearLayout.LayoutParams(150,150).apply{gravity=Gravity.CENTER_HORIZONTAL;bottomMargin=8};scaleType=ImageView.ScaleType.CENTER_CROP};if(pendingProductImagePath.isNotEmpty())showImage(image,pendingProductImagePath)else image.setImageResource(android.R.drawable.ic_menu_gallery);pendingProductImageView=image;box.addView(image)
        box.addView(Button(this).apply{text="اختيار صورة المنتج";setOnClickListener{val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";addCategory(Intent.CATEGORY_OPENABLE)};startActivityForResult(i,REQUEST_PRODUCT_IMAGE)}},lp())
        val name=field("اسم المنتج");val code=field("المرجع / Code");val price=field("السعر DH").apply{inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL};if(existing!=null){name.setText(existing.name);code.setText(existing.code);price.setText(fmt(existing.price))};box.addView(name,lp());box.addView(code,lp());box.addView(price,lp())
        val dialog=AlertDialog.Builder(this).setTitle(if(existing==null)"إضافة منتج" else "تعديل المنتج").setView(box).setPositiveButton("حفظ",null).setNegativeButton("إلغاء",null).create();dialog.setOnShowListener{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{val n=name.text.toString().trim();val c=code.text.toString().trim();val pr=price.text.toString().toDoubleOrNull();if(n.isEmpty()||pr==null){toast("أدخل اسم المنتج والسعر");return@setOnClickListener};if(existing==null)products.add(Product(System.currentTimeMillis().toString(),n,c,pr,pendingProductImagePath))else{existing.name=n;existing.code=c;existing.price=pr;existing.imagePath=pendingProductImagePath};saveProducts();dialog.dismiss();showProductsDialog()}};dialog.show()
    }

    private fun showCustomersDialog(){
        var dialog:AlertDialog?=null;val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,8,18,8);layoutDirection=View.LAYOUT_DIRECTION_RTL}
        box.addView(Button(this).apply{text="＋ إضافة زبون جديد";setOnClickListener{showCustomerEditDialog()}},lp());val search=field("بحث بالاسم أو الهاتف أو المدينة");box.addView(search,lp());val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};val scroll=ScrollView(this);scroll.addView(list);box.addView(scroll,LinearLayout.LayoutParams(-1,560))
        fun render(){list.removeAllViews();val q=search.text.toString().trim().lowercase(Locale.getDefault());val filtered=customers.filter{q.isEmpty()||it.name.lowercase(Locale.getDefault()).contains(q)||it.phone.lowercase(Locale.getDefault()).contains(q)||it.city.lowercase(Locale.getDefault()).contains(q)||it.address.lowercase(Locale.getDefault()).contains(q)};if(filtered.isEmpty())list.addView(TextView(this).apply{text="لا يوجد زبائن";textSize=17f;setPadding(0,25,0,25)}) else filtered.forEach{c->
            val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,10,12,10);setBackgroundColor(Color.rgb(245,247,250))};row.addView(TextView(this).apply{text=c.name;if(c.name.isEmpty())text="بدون اسم";textSize=17f;setTypeface(null,Typeface.BOLD)});row.addView(TextView(this).apply{text="هاتف: ${c.phone}\nمدينة: ${c.city}\nعنوان: ${c.address}";textSize=14f});val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};actions.addView(Button(this).apply{text="تعديل";setOnClickListener{showCustomerEditDialog(c)}},LinearLayout.LayoutParams(0,-2,1f));actions.addView(Button(this).apply{text="حذف";setOnClickListener{confirmDeleteCustomer(c)}},LinearLayout.LayoutParams(0,-2,1f));row.addView(actions);list.addView(row,lp())
        }}
        search.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){render()};override fun afterTextChanged(s:Editable?){}});box.addView(Button(this).apply{text="إغلاق";setOnClickListener{dialog?.dismiss()}},lp());dialog=AlertDialog.Builder(this).setTitle("البحث وتعديل الزبائن").setView(box).create();dialog.show();render()
    }

    private fun showCustomerEditDialog(existing:Customer?=null){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,8,24,8);layoutDirection=View.LAYOUT_DIRECTION_RTL};val name=field("اسم الزبون");val phone=field("هاتف الزبون").apply{inputType=InputType.TYPE_CLASS_PHONE};val city=field("المدينة");val address=field("العنوان");if(existing!=null){name.setText(existing.name);phone.setText(existing.phone);city.setText(existing.city);address.setText(existing.address)};box.addView(name,lp());box.addView(phone,lp());box.addView(city,lp());box.addView(address,lp())
        val dialog=AlertDialog.Builder(this).setTitle(if(existing==null)"إضافة زبون" else "تعديل الزبون").setView(box).setPositiveButton("حفظ",null).setNegativeButton("إلغاء",null).create();dialog.setOnShowListener{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{val n=name.text.toString().trim();if(n.isEmpty()){toast("أدخل اسم الزبون");return@setOnClickListener};if(existing==null)customers.add(Customer(System.currentTimeMillis().toString(),n,phone.text.toString().trim(),city.text.toString().trim(),address.text.toString().trim()))else{existing.name=n;existing.phone=phone.text.toString().trim();existing.city=city.text.toString().trim();existing.address=address.text.toString().trim()};saveCustomers();dialog.dismiss();showCustomersDialog()}};dialog.show()
    }
    private fun confirmDeleteCustomer(c:Customer){AlertDialog.Builder(this).setTitle("حذف الزبون").setMessage("هل تريد حذف ${c.name}؟").setPositiveButton("حذف"){_,_->customers.removeAll{it.id==c.id};saveCustomers();showCustomersDialog();toast("تم حذف الزبون")}.setNegativeButton("إلغاء",null).show()}

    private fun fillCustomer(c:Customer){customer.setText(c.name,false);customerPhone.setText(c.phone);customerCity.setText(c.city);customerAddress.setText(c.address)}
    private fun saveOrUpdateCustomerFromInvoice(){val n=customer.text.toString().trim();if(n.isEmpty())return;val ph=customerPhone.text.toString().trim();val city=customerCity.text.toString().trim();val addr=customerAddress.text.toString().trim();val c=customers.firstOrNull{it.name.equals(n,true)&&it.phone==ph};if(c!=null){c.name=n;c.phone=ph;c.city=city;c.address=addr}else customers.add(Customer(System.currentTimeMillis().toString(),n,ph,city,addr));saveCustomers()}

    private fun loadProducts(){products.clear();val a=JSONArray(prefs.getString("products","[]"));for(i in 0 until a.length()){val x=a.getJSONObject(i);products.add(Product(x.optString("id"),x.optString("name"),x.optString("code"),x.optDouble("price"),x.optString("imagePath")))}}
    private fun saveProducts(){val a=JSONArray();products.forEach{p->a.put(JSONObject().apply{put("id",p.id);put("name",p.name);put("code",p.code);put("price",p.price);put("imagePath",p.imagePath)})};prefs.edit().putString("products",a.toString()).apply();productAdapters.forEach{it.notifyDataSetChanged()}}
    private fun findProduct(id:String)=products.firstOrNull{it.id==id}

    private fun loadCustomers(){customers.clear();val a=JSONArray(prefs.getString("customers","[]"));for(i in 0 until a.length()){val x=a.getJSONObject(i);customers.add(Customer(x.optString("id"),x.optString("name"),x.optString("phone"),x.optString("city"),x.optString("address")))}}
    private fun saveCustomers(){val a=JSONArray();customers.forEach{c->a.put(JSONObject().apply{put("id",c.id);put("name",c.name);put("phone",c.phone);put("city",c.city);put("address",c.address)})};prefs.edit().putString("customers",a.toString()).apply();(customer.adapter as? BaseAdapter)?.notifyDataSetChanged()}

    private fun loadCompanySettings(){companyLogoPath=prefs.getString("company_logo","")?:"";companyPhone=prefs.getString("company_phone","")?:""}
    private fun saveCompanySettings(){prefs.edit().putString("company_logo",companyLogoPath).putString("company_phone",companyPhone).apply()}
    private fun showCompanySettingsDialog(){
        pendingCompanyLogoPath=companyLogoPath;val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,8,24,8);layoutDirection=View.LAYOUT_DIRECTION_RTL};val logo=ImageView(this).apply{layoutParams=LinearLayout.LayoutParams(150,100).apply{gravity=Gravity.CENTER_HORIZONTAL;bottomMargin=8};scaleType=ImageView.ScaleType.CENTER_INSIDE};if(pendingCompanyLogoPath.isNotEmpty())showImage(logo,pendingCompanyLogoPath)else logo.setImageResource(android.R.drawable.ic_menu_gallery);pendingCompanyLogoView=logo;box.addView(logo)
        box.addView(Button(this).apply{text="اختيار لوجو الشركة";setOnClickListener{val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";addCategory(Intent.CATEGORY_OPENABLE)};startActivityForResult(i,REQUEST_COMPANY_LOGO)}},lp());val phone=field("هاتف الشركة").apply{inputType=InputType.TYPE_CLASS_PHONE;setText(companyPhone)};box.addView(phone,lp());box.addView(TextView(this).apply{text="سيظهر اللوجو في أعلى اليسار والهاتف تحته بدون تداخل.";textSize=14f},lp())
        val dialog=AlertDialog.Builder(this).setTitle("بيانات الشركة").setView(box).setPositiveButton("حفظ",null).setNegativeButton("إلغاء",null).create();dialog.setOnShowListener{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{companyLogoPath=pendingCompanyLogoPath;companyPhone=phone.text.toString().trim();saveCompanySettings();dialog.dismiss();toast("تم حفظ بيانات الشركة")}};dialog.show()
    }

    private fun startNewInvoice(){editingInvoiceNumber=null;editingInvoiceDate=today();itemsBox.removeAllViews();invoiceNo.setText((prefs.getInt("last_number",0)+1).toString());customer.setText("",false);customerPhone.setText("");customerCity.setText("");customerAddress.setText("");paymentStatus.isChecked=false;addItemRow();updateDateText();updateTotal()}
    private fun updateDateText(){dateView.text="التاريخ: ${editingInvoiceDate?:today()}"}

    private fun createPdfAndShare(){
        val no=invoiceNo.text.toString().trim();val data=readItems();if(data.isEmpty()){toast("أضف منتجًا واحدًا على الأقل");return}
        val doc=android.graphics.pdf.PdfDocument();val page=doc.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(595,842,1).create());val canvas=page.canvas;val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;textSize=16f};val bold=Paint(paint).apply{typeface=Typeface.DEFAULT_BOLD}
        // Reserve a clean header area so the logo never overlaps the company phone.
        if(companyLogoPath.isNotEmpty())try{BitmapFactory.decodeFile(companyLogoPath)?.let{b->val maxW=105f;val maxH=55f;val scale=minOf(maxW/b.width,maxH/b.height);val w=b.width*scale;val h=b.height*scale;canvas.drawBitmap(b,null,RectF(45f,22f,45f+w,22f+h),paint)}}catch(_:Exception){}
        canvas.drawText("FACTURE / فاتورة",250f,52f,bold)
        var y=105f
        if(companyPhone.isNotEmpty()){canvas.drawText("Tél : $companyPhone",45f,y,paint);y+=24f}
        canvas.drawText("N° : $no",45f,y,paint);y+=24f;canvas.drawText("Date : ${editingInvoiceDate?:today()}",45f,y,paint);y+=24f
        val cust=customer.text.toString().trim();if(cust.isNotEmpty()){canvas.drawText("Client : $cust",45f,y,paint);y+=23f}
        val ph=customerPhone.text.toString().trim();if(ph.isNotEmpty()){canvas.drawText("Tél client : $ph",45f,y,paint);y+=23f}
        val city=customerCity.text.toString().trim();if(city.isNotEmpty()){canvas.drawText("Ville : $city",45f,y,paint);y+=23f}
        val addr=customerAddress.text.toString().trim();if(addr.isNotEmpty()){canvas.drawText("Adresse : ${addr.take(55)}",45f,y,paint);y+=23f}
        val status=if(paymentStatus.isChecked)"PAYÉE / مدفوعة" else "NON PAYÉE / غير مدفوعة";val statusPaint=Paint(paint).apply{typeface=Typeface.DEFAULT_BOLD;color=if(paymentStatus.isChecked)Color.rgb(20,120,60)else Color.rgb(190,40,40)};canvas.drawText("Statut : $status",45f,y,statusPaint)
        y+=45f;canvas.drawText("Produit / البيان",45f,y,bold);canvas.drawText("Qté",360f,y,bold);canvas.drawText("Prix",420f,y,bold);canvas.drawText("Total",500f,y,bold);canvas.drawLine(40f,y+10f,555f,y+10f,paint);y+=38f
        var grand=0.0;data.forEach{val t=it.total();grand+=t;canvas.drawText(it.name.take(34),45f,y,paint);canvas.drawText(fmt(it.qty),360f,y,paint);canvas.drawText(fmt(it.price),420f,y,paint);canvas.drawText(fmt(t),500f,y,paint);y+=28f};canvas.drawLine(40f,y,555f,y,paint);y+=35f;canvas.drawText("TOTAL : ${fmt(grand)} DH",370f,y,bold);y+=55f;canvas.drawText("Merci pour votre confiance",200f,y,paint);doc.finishPage(page)
        val filename="Facture_$no.pdf";val values=ContentValues().apply{put(MediaStore.Downloads.DISPLAY_NAME,filename);put(MediaStore.Downloads.MIME_TYPE,"application/pdf");put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS)};val uri=contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);if(uri==null){doc.close();toast("تعذر إنشاء ملف PDF");return};contentResolver.openOutputStream(uri)?.use{doc.writeTo(it)};doc.close();startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"مشاركة الفاتورة"))
    }

    private fun invoiceTotal(o:JSONObject):Double{val a=o.optJSONArray("items")?:return 0.0;var total=0.0;for(i in 0 until a.length()){val x=a.getJSONObject(i);total+=x.optDouble("qty")*x.optDouble("price")};return total}
    private fun showImage(v:ImageView,path:String){try{BitmapFactory.decodeFile(path)?.let{v.setImageBitmap(it);v.visibility=View.VISIBLE}}catch(_:Exception){}}
    private fun copyImageToInternalStorage(uri:Uri):String{val dir=File(filesDir,"product_images");if(!dir.exists())dir.mkdirs();val file=File(dir,"img_${System.currentTimeMillis()}.jpg");contentResolver.openInputStream(uri).use{input->FileOutputStream(file).use{output->input?.copyTo(output)}};return file.absolutePath}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK)return;val uri=data?.data?:return;try{val path=copyImageToInternalStorage(uri);if(requestCode==REQUEST_PRODUCT_IMAGE){pendingProductImagePath=path;pendingProductImageView?.let{showImage(it,path)}}else if(requestCode==REQUEST_COMPANY_LOGO){pendingCompanyLogoPath=path;pendingCompanyLogoView?.let{showImage(it,path)}}}catch(_:Exception){toast("تعذر حفظ الصورة")}}
    private fun field(hint:String)=EditText(this).apply{this.hint=hint;textSize=16f;setPadding(14,10,14,10);background=AppCompatResources.getDrawable(this@MainActivity,android.R.drawable.edit_text)}
    private fun lp()=LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=6};private fun lpWrap()=LinearLayout.LayoutParams(-2,-2).apply{leftMargin=2;rightMargin=2};private fun today()=SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(Date());private fun fmt(v:Double)=String.format(Locale.US,"%.2f",v);private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()

    inner class ProductAdapter(list:List<Product>):ArrayAdapter<Product>(this@MainActivity,android.R.layout.simple_dropdown_item_1line,list){override fun getView(position:Int,convertView:View?,parent:ViewGroup):View{val row=LinearLayout(this@MainActivity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(10,8,10,8)};val image=ImageView(this@MainActivity).apply{layoutParams=LinearLayout.LayoutParams(55,55);scaleType=ImageView.ScaleType.CENTER_CROP};val p=getItem(position);if(p?.imagePath?.isNotEmpty()==true)showImage(image,p.imagePath)else image.setImageResource(android.R.drawable.ic_menu_gallery);row.addView(image);row.addView(TextView(this@MainActivity).apply{text=if(p==null)"" else "${p.name}\n${p.code}  •  ${fmt(p.price)} DH";textSize=16f;setPadding(12,0,0,0)});return row}}
    inner class CustomerAdapter(list:List<Customer>):ArrayAdapter<Customer>(this@MainActivity,android.R.layout.simple_dropdown_item_1line,list){override fun getView(position:Int,convertView:View?,parent:ViewGroup):View{val c=getItem(position);return TextView(this@MainActivity).apply{text=if(c==null)"" else "${c.name}  •  ${c.phone}  •  ${c.city}";textSize=16f;setPadding(14,14,14,14)}}}

    companion object{private const val REQUEST_PRODUCT_IMAGE=7001;private const val REQUEST_COMPANY_LOGO=7002}
}
