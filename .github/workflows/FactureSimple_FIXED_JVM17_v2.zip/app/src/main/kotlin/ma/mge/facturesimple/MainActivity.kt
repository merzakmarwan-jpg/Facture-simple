package ma.mge.facturesimple

import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Item(
    val name: String,
    val qty: Double,
    val price: Double,
    val productId: String = "",
    val imagePath: String = ""
) {
    fun total(): Double = qty * price
}

data class Product(
    val id: String,
    var name: String,
    var code: String,
    var price: Double,
    var imagePath: String = ""
) {
    override fun toString(): String = "$name $code"
}

class MainActivity : AppCompatActivity() {

    private lateinit var invoiceNo: EditText
    private lateinit var customer: EditText
    private lateinit var itemsBox: LinearLayout
    private lateinit var totalView: TextView

    private val prefs by lazy { getSharedPreferences("invoices", MODE_PRIVATE) }
    private val products = mutableListOf<Product>()
    private var companyLogoPath: String = ""
    private var companyPhone: String = ""
    private val productAdapters = mutableListOf<ProductAdapter>()
    private var editingInvoiceNumber: String? = null
    private var editingInvoiceDate: String? = null
    private lateinit var dateView: TextView

    private var pendingProductImagePath: String = ""
    private var pendingProductImageView: ImageView? = null
    private var pendingCompanyLogoPath: String = ""
    private var pendingCompanyLogoView: ImageView? = null
    private lateinit var paymentStatus: CheckBox
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadProducts()
        loadCompanySettings()
        buildUi()
        startNewInvoice()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 12, 18, 18)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "فاتورة بسيطة"
            textSize = 25f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(Button(this).apply {
            text = "الشركة"
            setOnClickListener { showCompanySettingsDialog() }
        }, LinearLayout.LayoutParams(-2, -2))
        header.addView(Button(this).apply {
            text = "المنتجات"
            setOnClickListener { showProductsDialog() }
        }, LinearLayout.LayoutParams(-2, -2))
        header.addView(Button(this).apply {
            text = "الفواتير"
            setOnClickListener { showInvoicesDialog() }
        }, LinearLayout.LayoutParams(-2, -2))
        root.addView(header, lp())

        invoiceNo = field("رقم الفاتورة")
        invoiceNo.inputType = InputType.TYPE_CLASS_NUMBER
        customer = field("اسم الزبون (اختياري)")
        root.addView(invoiceNo, lp())
        root.addView(customer, lp())

        paymentStatus = CheckBox(this).apply {
            text = "الفاتورة مدفوعة"
            textSize = 17f
            isChecked = false
            buttonTintList = null
        }
        root.addView(paymentStatus, lp())

        dateView = TextView(this).apply {
            textSize = 16f
            setPadding(4, 4, 4, 10)
        }
        root.addView(dateView, lp())

        root.addView(TextView(this).apply {
            text = "المنتجات في الفاتورة"
            textSize = 19f
            setTypeface(null, Typeface.BOLD)
        }, lp())

        val scroll = ScrollView(this)
        itemsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 4, 0, 4)
        }
        scroll.addView(itemsBox)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(Button(this).apply {
            text = "＋ إضافة منتج"
            setOnClickListener { addItemRow() }
        }, lp())

        totalView = TextView(this).apply {
            textSize = 22f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 12)
        }
        root.addView(totalView, lp())

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        buttons.addView(Button(this).apply {
            text = "حفظ الفاتورة"
            setOnClickListener { saveInvoice() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(Button(this).apply {
            text = "PDF"
            setOnClickListener { createPdfAndShare() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(Button(this).apply {
            text = "فاتورة جديدة"
            setOnClickListener { startNewInvoice() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(buttons)

        setContentView(root)
    }

    private fun addItemRow(item: Item? = null) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 8, 0, 8)
            background = ColorDrawable(Color.rgb(245, 247, 250))
        }

        val adapter = ProductAdapter(products)
        productAdapters.add(adapter)

        val productInput = AutoCompleteTextView(this).apply {
            hint = "اكتب اسم المنتج أو المرجع"
            textSize = 16f
            threshold = 1
            setPadding(14, 10, 14, 10)
            background = AppCompatResources.getDrawable(this@MainActivity, android.R.drawable.edit_text)
            setAdapter(adapter)
        }

        val preview = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(90, 90).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = 6
            }
            scaleType = ImageView.ScaleType.CENTER_CROP
            visibility = View.GONE
        }

        val qty = field("الكمية").apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        val price = field("الثمن DH").apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }

        val selected = item?.let { findProduct(it.productId) }
        if (item != null) {
            productInput.setText(item.name, false)
            qty.setText(fmt(item.qty))
            price.setText(fmt(item.price))
            if (item.imagePath.isNotEmpty()) {
                showImage(preview, item.imagePath)
            } else if (selected != null && selected.imagePath.isNotEmpty()) {
                showImage(preview, selected.imagePath)
            }
            row.tag = item.productId
        }

        productInput.setOnItemClickListener { _, _, position, _ ->
            val p = productInput.adapter.getItem(position) as? Product ?: return@setOnItemClickListener
            productInput.setText(p.name, false)
            price.setText(fmt(p.price))
            row.tag = p.id
            if (p.imagePath.isNotEmpty()) showImage(preview, p.imagePath)
            else preview.visibility = View.GONE
            updateTotal()
        }

        val watcher = object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { updateTotal() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        }
        qty.addTextChangedListener(watcher)
        price.addTextChangedListener(watcher)

        row.addView(productInput, lp())
        row.addView(preview)
        val numbers = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        numbers.addView(qty, LinearLayout.LayoutParams(0, -2, 1f))
        numbers.addView(price, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(numbers)
        row.addView(Button(this).apply {
            text = "حذف هذا المنتج"
            setOnClickListener {
                itemsBox.removeView(row)
                updateTotal()
            }
        }, lp())

        itemsBox.addView(row)
    }

    private fun readItems(): List<Item> {
        val result = mutableListOf<Item>()
        for (i in 0 until itemsBox.childCount) {
            val row = itemsBox.getChildAt(i) as? LinearLayout ?: continue
            if (row.childCount < 3) continue
            val name = (row.getChildAt(0) as AutoCompleteTextView).text.toString().trim()
            val preview = row.getChildAt(1) as? ImageView
            val numbers = row.getChildAt(2) as? LinearLayout ?: continue
            val qty = (numbers.getChildAt(0) as EditText).text.toString().toDoubleOrNull() ?: 0.0
            val price = (numbers.getChildAt(1) as EditText).text.toString().toDoubleOrNull() ?: 0.0
            val productId = row.tag?.toString() ?: ""
            val imagePath = findProduct(productId)?.imagePath ?: ""
            if (name.isNotEmpty()) {
                result.add(Item(name, qty, price, productId, imagePath))
            }
        }
        return result
    }

    private fun updateTotal() {
        val total = readItems().sumOf { it.total() }
        totalView.text = String.format(Locale.US, "المجموع : %.2f DH", total)
    }

    private fun saveInvoice() {
        val no = invoiceNo.text.toString().trim()
        if (no.isEmpty()) {
            Toast.makeText(this, "أدخل رقم الفاتورة", Toast.LENGTH_SHORT).show()
            return
        }
        val data = readItems()
        if (data.isEmpty()) {
            Toast.makeText(this, "أضف منتجًا واحدًا على الأقل", Toast.LENGTH_SHORT).show()
            return
        }

        val date = editingInvoiceDate ?: today()
        val obj = JSONObject().apply {
            put("number", no)
            put("date", date)
            put("customer", customer.text.toString().trim())
            put("paid", paymentStatus.isChecked)
            put("items", JSONArray().apply {
                data.forEach {
                    put(JSONObject().apply {
                        put("name", it.name)
                        put("qty", it.qty)
                        put("price", it.price)
                        put("productId", it.productId)
                        put("imagePath", it.imagePath)
                    })
                }
            })
        }

        val array = JSONArray(prefs.getString("invoices", "[]"))
        var found = false
        for (i in 0 until array.length()) {
            if (array.getJSONObject(i).optString("number") == no) {
                array.put(i, obj)
                found = true
                break
            }
        }
        if (!found) array.put(obj)

        prefs.edit()
            .putString("invoices", array.toString())
            .putInt("last_number", maxOf(prefs.getInt("last_number", 0), no.toIntOrNull() ?: 0))
            .apply()

        editingInvoiceNumber = no
        editingInvoiceDate = date
        Toast.makeText(this, "تم حفظ الفاتورة رقم $no", Toast.LENGTH_SHORT).show()
    }

    private fun showInvoicesDialog() {
        var dialog: AlertDialog? = null
        val array = JSONArray(prefs.getString("invoices", "[]"))
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 8, 18, 8)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val title = TextView(this).apply {
            text = "الفواتير المحفوظة (${array.length()})"
            textSize = 21f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 0, 0, 12)
        }
        container.addView(title)

        if (array.length() == 0) {
            container.addView(TextView(this).apply {
                text = "لا توجد فواتير محفوظة بعد."
                textSize = 17f
                setPadding(0, 20, 0, 20)
            })
        } else {
            val scroll = ScrollView(this)
            val list = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
            }
            for (i in array.length() - 1 downTo 0) {
                val obj = array.getJSONObject(i)
                val number = obj.optString("number")
                val date = obj.optString("date")
                val customerName = obj.optString("customer")
                val paid = obj.optBoolean("paid", false)
                val total = invoiceTotal(obj)
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(12, 10, 12, 10)
                    setBackgroundColor(Color.rgb(245, 247, 250))
                    isClickable = true
                }
                row.addView(TextView(this).apply {
                    text = "فاتورة #$number  •  $date"
                    textSize = 17f
                    setTypeface(null, Typeface.BOLD)
                })
                row.addView(TextView(this).apply {
                    val status = if (paid) "✓ مدفوعة" else "✗ غير مدفوعة"
                    text = if (customerName.isEmpty()) "بدون اسم زبون  •  ${fmt(total)} DH  •  $status"
                    else "$customerName  •  ${fmt(total)} DH  •  $status"
                    textSize = 15f
                })
                row.setOnClickListener {
                    loadInvoice(obj)
                    dialog?.dismiss()
                }
                list.addView(row, lp())
            }
            scroll.addView(list)
            container.addView(scroll, LinearLayout.LayoutParams(-1, 520))
        }

        container.addView(Button(this).apply {
            text = "إغلاق"
            setOnClickListener { dialog?.dismiss() }
        }, lp())

        dialog = AlertDialog.Builder(this)
            .setView(container)
            .create()
        dialog?.show()
    }

    private fun loadInvoice(obj: JSONObject) {
        editingInvoiceNumber = obj.optString("number")
        editingInvoiceDate = obj.optString("date", today())
        invoiceNo.setText(editingInvoiceNumber)
        customer.setText(obj.optString("customer"))
        paymentStatus.isChecked = obj.optBoolean("paid", false)

        itemsBox.removeAllViews()
        val arr = obj.optJSONArray("items") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val x = arr.getJSONObject(i)
            addItemRow(
                Item(
                    x.optString("name"),
                    x.optDouble("qty", 1.0),
                    x.optDouble("price", 0.0),
                    x.optString("productId"),
                    x.optString("imagePath")
                )
            )
        }
        if (arr.length() == 0) addItemRow()
        updateDateText()
        updateTotal()
        Toast.makeText(this, "تم فتح الفاتورة رقم ${editingInvoiceNumber}", Toast.LENGTH_SHORT).show()
    }


    private fun loadCompanySettings() {
        companyLogoPath = prefs.getString("company_logo", "") ?: ""
        companyPhone = prefs.getString("company_phone", "") ?: ""
    }

    private fun saveCompanySettings() {
        prefs.edit()
            .putString("company_logo", companyLogoPath)
            .putString("company_phone", companyPhone)
            .apply()
    }

    private fun showCompanySettingsDialog() {
        pendingCompanyLogoPath = companyLogoPath
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 8)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val logo = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(150, 150).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = 8
            }
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        if (pendingCompanyLogoPath.isNotEmpty()) {
            showImage(logo, pendingCompanyLogoPath)
        } else {
            logo.setImageResource(android.R.drawable.ic_menu_gallery)
        }
        pendingCompanyLogoView = logo
        box.addView(logo)

        box.addView(Button(this).apply {
            text = "اختيار لوجو الشركة"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "image/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                startActivityForResult(intent, REQUEST_COMPANY_LOGO)
            }
        }, lp())

        val phone = field("هاتف الشركة")
        phone.inputType = InputType.TYPE_CLASS_PHONE
        phone.setText(companyPhone)
        box.addView(phone, lp())

        box.addView(TextView(this).apply {
            text = "سيظهر اللوجو ورقم الهاتف أعلى كل فاتورة PDF."
            textSize = 14f
            setPadding(4, 6, 4, 8)
        }, lp())

        val dialog = AlertDialog.Builder(this)
            .setTitle("بيانات الشركة")
            .setView(box)
            .setPositiveButton("حفظ", null)
            .setNegativeButton("إلغاء", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                companyLogoPath = pendingCompanyLogoPath
                companyPhone = phone.text.toString().trim()
                saveCompanySettings()
                dialog.dismiss()
                Toast.makeText(this, "تم حفظ بيانات الشركة", Toast.LENGTH_SHORT).show()
            }
        }
        dialog.show()
    }

    private fun showProductsDialog() {
        var dialog: AlertDialog? = null
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 8, 18, 8)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        container.addView(Button(this).apply {
            text = "＋ إضافة منتج جديد"
            setOnClickListener { showAddProductDialog() }
        }, lp())

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        if (products.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "لا توجد منتجات. أضف أول منتج مع صورته وسعره."
                textSize = 17f
                setPadding(0, 20, 0, 20)
            })
        } else {
            products.forEach { p ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(8, 8, 8, 8)
                }
                val image = ImageView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(70, 70)
                    scaleType = ImageView.ScaleType.CENTER_CROP
                }
                if (p.imagePath.isNotEmpty()) showImage(image, p.imagePath)
                row.addView(image)
                row.addView(TextView(this).apply {
                    text = "${p.name}\n${p.code}   •   ${fmt(p.price)} DH"
                    textSize = 16f
                    setPadding(12, 0, 12, 0)
                }, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(Button(this).apply {
                    text = "تعديل"
                    setOnClickListener { showAddProductDialog(p) }
                })
                row.addView(Button(this).apply {
                    text = "حذف"
                    setOnClickListener {
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle("حذف المنتج")
                            .setMessage("هل تريد حذف ${p.name}؟")
                            .setPositiveButton("حذف") { _, _ ->
                                products.removeAll { it.id == p.id }
                                saveProducts()
                                showProductsDialog()
                                Toast.makeText(this@MainActivity, "تم حذف المنتج", Toast.LENGTH_SHORT).show()
                            }
                            .setNegativeButton("إلغاء", null)
                            .show()
                    }
                })
                list.addView(row, lp())
            }
        }

        scroll.addView(list)
        container.addView(scroll, LinearLayout.LayoutParams(-1, 520))
        container.addView(Button(this).apply {
            text = "إغلاق"
            setOnClickListener { dialog?.dismiss() }
        }, lp())

        dialog = AlertDialog.Builder(this)
            .setTitle("إدارة المنتجات")
            .setView(container)
            .create()
        dialog?.show()
    }

    private fun showAddProductDialog(existing: Product? = null) {
        pendingProductImagePath = existing?.imagePath ?: ""
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 8)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val image = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(150, 150).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = 8
            }
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        if (pendingProductImagePath.isNotEmpty()) showImage(image, pendingProductImagePath)
        else image.setImageResource(android.R.drawable.ic_menu_gallery)
        pendingProductImageView = image
        box.addView(image)

        box.addView(Button(this).apply {
            text = "اختيار صورة المنتج"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "image/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                startActivityForResult(intent, REQUEST_PRODUCT_IMAGE)
            }
        }, lp())

        val name = field("اسم المنتج")
        val code = field("المرجع / Code")
        val price = field("السعر DH").apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        if (existing != null) {
            name.setText(existing.name)
            code.setText(existing.code)
            price.setText(fmt(existing.price))
        }
        box.addView(name, lp())
        box.addView(code, lp())
        box.addView(price, lp())

        val dialog = AlertDialog.Builder(this)
            .setTitle(if (existing == null) "إضافة منتج" else "تعديل المنتج")
            .setView(box)
            .setPositiveButton("حفظ", null)
            .setNegativeButton("إلغاء", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val n = name.text.toString().trim()
                val c = code.text.toString().trim()
                val pr = price.text.toString().toDoubleOrNull()
                if (n.isEmpty() || pr == null) {
                    Toast.makeText(this, "أدخل اسم المنتج والسعر", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                if (existing == null) {
                    products.add(Product(
                        System.currentTimeMillis().toString(),
                        n, c, pr, pendingProductImagePath
                    ))
                } else {
                    existing.name = n
                    existing.code = c
                    existing.price = pr
                    existing.imagePath = pendingProductImagePath
                }
                saveProducts()
                dialog.dismiss()
                showProductsDialog()
            }
        }
        dialog.show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val path = copyImageToInternalStorage(uri)
            if (requestCode == REQUEST_PRODUCT_IMAGE) {
                pendingProductImagePath = path
                pendingProductImageView?.let { showImage(it, path) }
            } else if (requestCode == REQUEST_COMPANY_LOGO) {
                pendingCompanyLogoPath = path
                pendingCompanyLogoView?.let { showImage(it, path) }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر حفظ الصورة", Toast.LENGTH_SHORT).show()
        }
    }

    private fun copyImageToInternalStorage(uri: Uri): String {
        val dir = File(filesDir, "product_images")
        if (!dir.exists()) dir.mkdirs()
        val file = File(dir, "product_${System.currentTimeMillis()}.jpg")
        contentResolver.openInputStream(uri).use { input ->
            FileOutputStream(file).use { output ->
                input?.copyTo(output)
            }
        }
        return file.absolutePath
    }

    private fun loadProducts() {
        products.clear()
        val array = JSONArray(prefs.getString("products", "[]"))
        for (i in 0 until array.length()) {
            val x = array.getJSONObject(i)
            products.add(
                Product(
                    x.optString("id"),
                    x.optString("name"),
                    x.optString("code"),
                    x.optDouble("price", 0.0),
                    x.optString("imagePath")
                )
            )
        }
    }

    private fun saveProducts() {
        val array = JSONArray()
        products.forEach { p ->
            array.put(JSONObject().apply {
                put("id", p.id)
                put("name", p.name)
                put("code", p.code)
                put("price", p.price)
                put("imagePath", p.imagePath)
            })
        }
        prefs.edit().putString("products", array.toString()).apply()
        productAdapters.forEach { it.notifyDataSetChanged() }
    }

    private fun findProduct(id: String): Product? =
        products.firstOrNull { it.id == id }

    private fun invoiceTotal(obj: JSONObject): Double {
        val arr = obj.optJSONArray("items") ?: return 0.0
        var total = 0.0
        for (i in 0 until arr.length()) {
            val x = arr.getJSONObject(i)
            total += x.optDouble("qty", 0.0) * x.optDouble("price", 0.0)
        }
        return total
    }

    private fun startNewInvoice() {
        editingInvoiceNumber = null
        editingInvoiceDate = today()
        itemsBox.removeAllViews()
        invoiceNo.setText((prefs.getInt("last_number", 0) + 1).toString())
        customer.setText("")
        paymentStatus.isChecked = false
        addItemRow()
        updateDateText()
        updateTotal()
    }

    private fun updateDateText() {
        if (::dateView.isInitialized) dateView.text = "التاريخ: ${editingInvoiceDate ?: today()}"
    }

    private fun createPdfAndShare() {
        val no = invoiceNo.text.toString().trim()
        val data = readItems()
        if (data.isEmpty()) {
            Toast.makeText(this, "أضف منتجًا واحدًا على الأقل", Toast.LENGTH_SHORT).show()
            return
        }

        val doc = android.graphics.pdf.PdfDocument()
        val page = doc.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val canvas = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 16f
        }
        val bold = Paint(paint).apply { typeface = Typeface.DEFAULT_BOLD }

        // Company header
        if (companyLogoPath.isNotEmpty()) {
            try {
                val logoBitmap = BitmapFactory.decodeFile(companyLogoPath)
                if (logoBitmap != null) {
                    val maxW = 105f
                    val maxH = 70f
                    val scale = minOf(maxW / logoBitmap.width, maxH / logoBitmap.height)
                    val w = logoBitmap.width * scale
                    val h = logoBitmap.height * scale
                    val dst = RectF(45f, 25f, 45f + w, 25f + h)
                    canvas.drawBitmap(logoBitmap, null, dst, paint)
                }
            } catch (_: Exception) {}
        }

        val titleX = if (companyLogoPath.isNotEmpty()) 220f else 210f
        canvas.drawText("FACTURE / فاتورة", titleX, 55f, bold)

        var headerY = 85f
        if (companyPhone.isNotEmpty()) {
            canvas.drawText("Tél : $companyPhone", 45f, headerY, paint)
            headerY += 23f
        }

        canvas.drawText("N° : $no", 45f, headerY, paint)
        headerY += 25f
        canvas.drawText("Date : ${editingInvoiceDate ?: today()}", 45f, headerY, paint)
        headerY += 25f

        val cust = customer.text.toString().trim()
        if (cust.isNotEmpty()) {
            canvas.drawText("Client : $cust", 45f, headerY, paint)
            headerY += 25f
        }

        val status = if (paymentStatus.isChecked) "PAYÉE / مدفوعة" else "NON PAYÉE / غير مدفوعة"
        val statusPaint = Paint(paint).apply {
            typeface = Typeface.DEFAULT_BOLD
            color = if (paymentStatus.isChecked) Color.rgb(20, 120, 60) else Color.rgb(190, 40, 40)
        }
        canvas.drawText("Statut : $status", 45f, headerY, statusPaint)

        var y = headerY + 45f
        canvas.drawText("Produit / البيان", 45f, y, bold)
        canvas.drawText("Qté", 360f, y, bold)
        canvas.drawText("Prix", 420f, y, bold)
        canvas.drawText("Total", 500f, y, bold)
        canvas.drawLine(40f, y + 10f, 555f, y + 10f, paint)
        y += 38f

        var grand = 0.0
        data.forEach {
            val t = it.total()
            grand += t
            canvas.drawText(it.name.take(34), 45f, y, paint)
            canvas.drawText(fmt(it.qty), 360f, y, paint)
            canvas.drawText(fmt(it.price), 420f, y, paint)
            canvas.drawText(fmt(t), 500f, y, paint)
            y += 28f
        }

        canvas.drawLine(40f, y, 555f, y, paint)
        y += 35f
        canvas.drawText("TOTAL : ${fmt(grand)} DH", 370f, y, bold)
        y += 55f
        canvas.drawText("Merci pour votre confiance", 200f, y, paint)
        doc.finishPage(page)

        val filename = "Facture_$no.pdf"
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, filename)
            put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            doc.close()
            Toast.makeText(this, "تعذر إنشاء ملف PDF", Toast.LENGTH_SHORT).show()
            return
        }
        contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) }
        doc.close()

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "مشاركة الفاتورة"))
    }

    private fun showImage(view: ImageView, path: String) {
        try {
            val bitmap = BitmapFactory.decodeFile(path)
            if (bitmap != null) {
                view.setImageBitmap(bitmap)
                view.visibility = View.VISIBLE
            }
        } catch (_: Exception) {
        }
    }

    private fun field(hint: String) = EditText(this).apply {
        this.hint = hint
        textSize = 16f
        setPadding(14, 10, 14, 10)
        background = AppCompatResources.getDrawable(this@MainActivity, android.R.drawable.edit_text)
    }

    private fun lp() = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 6 }

    private fun today() = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())

    private fun fmt(value: Double) = String.format(Locale.US, "%.2f", value)

    inner class ProductAdapter(list: List<Product>) :
        ArrayAdapter<Product>(this@MainActivity, android.R.layout.simple_dropdown_item_1line, list) {

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(10, 8, 10, 8)
            }
            val image = ImageView(this@MainActivity).apply {
                layoutParams = LinearLayout.LayoutParams(55, 55)
                scaleType = ImageView.ScaleType.CENTER_CROP
            }
            val p = getItem(position)
            if (p != null && p.imagePath.isNotEmpty()) showImage(image, p.imagePath)
            else image.setImageResource(android.R.drawable.ic_menu_gallery)
            row.addView(image)
            row.addView(TextView(this@MainActivity).apply {
                text = if (p == null) "" else "${p.name}\n${p.code}  •  ${fmt(p.price)} DH"
                textSize = 16f
                setPadding(12, 0, 0, 0)
            })
            return row
        }
    }

    companion object {
        private const val REQUEST_PRODUCT_IMAGE = 7001
        private const val REQUEST_COMPANY_LOGO = 7002
    }
}
