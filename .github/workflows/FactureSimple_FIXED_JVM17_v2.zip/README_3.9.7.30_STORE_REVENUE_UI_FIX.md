# MGE 3.9.7.30 — Store Revenue UI / Firebase Error Fix

- Removed the automatic full Admin invoice Firebase reconciliation from the Store Revenue page.
- A partial Firebase sync failure can no longer blank/block the Store Revenue display or show the misleading "تعذر تحديث فواتير التقارير" toast when opening this page.
- Store Revenue continues to use the local SQLite invoice data already maintained by invoice creation/import/sync operations.
- Moved the Store account PDF action controls to the top of the Store account invoice page so they remain visible on small phone screens.
- Kept the invoice selection checkboxes and professional PDF/WhatsApp export behavior unchanged.
- Added explicit wrap-content layout for the invoice list to avoid a collapsed/very thin container at the bottom of the page.
