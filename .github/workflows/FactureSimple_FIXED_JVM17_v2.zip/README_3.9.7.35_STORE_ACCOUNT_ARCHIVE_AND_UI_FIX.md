# MGE 3.9.7.35 — Store Accounting Archive + UI Fix

## Store archive
- Adds persistent Store accounting archive batches.
- Each accounting export gets a permanent archive number per Store: Archive #1, #2, ...
- Each archive stores its archive date/time, export reference, and invoice count.
- Archive screen now lists the archive batches instead of showing invoices immediately.
- Opening an archive shows only invoices belonging to that archive.
- Selected invoices can be restored without deleting the archive history.
- PDF can be generated from a complete archive or a selected subset.

## UI fixes
- Removes the thin/hidden archive toolbar effect by using WRAP_CONTENT and explicit visible rows.
- Store revenue cards no longer use tiny fixed heights for multiline monetary lines, preventing partial clipping.
- Filter card receives proper vertical padding.

Version: 3.9.7.35 / versionCode 97.
