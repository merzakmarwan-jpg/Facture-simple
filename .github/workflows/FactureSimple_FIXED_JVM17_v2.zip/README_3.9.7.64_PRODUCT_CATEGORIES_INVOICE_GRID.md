# MGE 3.9.7.64 — Product Categories + Invoice Product Grid

Base: confirmed stable MGE 3.9.7.63.

Changes only:
- Added a product category field to the local product database; existing products keep an empty category until assigned.
- Product page has category filters, with `عام • الكل` showing all products.
- Product editor allows assigning/creating a category by typing its name; existing categories are shown in the category list.
- Product category is synchronized with Firebase as product metadata.
- Invoice add/edit screen now shows product images in a grid. Tapping the product image/card adds the product to the invoice.
- Invoice product categories appear at the top; selecting a category filters the grid.
- Search by product name/code remains available and works together with the selected category.
- Invoice grid is paginated to keep the editor responsive with large catalogs.
- Settings now allow configuring invoice product grid columns and rows (examples: 3×3, 4×4, 5×6).
- No existing invoice, invoice numbering, offline behavior, Firebase invoice sync, local image cache, shipping/accounting fields, or previous product features are intentionally removed.
