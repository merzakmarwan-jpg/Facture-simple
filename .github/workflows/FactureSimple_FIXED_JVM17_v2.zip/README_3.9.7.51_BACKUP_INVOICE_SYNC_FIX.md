# MGE 3.9.7.51 — Backup invoice cloud synchronization fix

- After importing a backup, all restored invoices are marked dirty with fresh timestamps.
- Invoice-only synchronization is triggered instead of the heavy full synchronization.
- This prevents products/customers/shipping synchronization from blocking restored invoices.
- Existing cloud invoices are updated from the restored backup, while missing cloud invoices are created.
- VersionCode: 113
