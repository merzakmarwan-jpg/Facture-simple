# MGE 3.9.7.65

Based on 3.9.7.64.

- Restores invoice details removed by the compact invoice card: assembly status, partner accounting status, customer phone/city/address, payment/advance information, shipping charge and actual cost, shipping company, partner profit, tracking/delivery status, Store account, and bank receipt status.
- Keeps Share PDF, Share product-photo PDF, delete, partner profit payment, and per-invoice sync inside the `⋮ خيارات` menu to keep the list lighter.
- Keeps Edit visible with the same admin/partner permissions as before.
- Realtime Firebase invoice synchronization continues in the background without rebuilding the visible invoice list, preventing automatic jumps to the top and interrupted scrolling.
- Manual refresh/pull-to-refresh keeps the current scroll position.
- Product-photo PDF already includes customer name, phone, and address.
