package com.mge.facturesimple;

import android.app.*;
import android.Manifest;
import android.os.*;
import android.os.Environment;
import android.content.*;
import android.database.Cursor;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.content.ContentUris;
import android.content.ClipData;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import android.text.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {

    Store db;
    LinearLayout root, body;
    TextView screenTitle;
    EditText pendingImageField;
    Cursor imageCursor;
    AlertDialog imageGalleryDialog;
    Runnable invoicePartnerModeRefresh;
    boolean invoicePartnerMode=false;

    final int BLUE = Color.rgb(20, 103, 205);
    final int BLUE_DARK = Color.rgb(13, 76, 161);
    final int GREEN = Color.rgb(18, 155, 72);
    final int RED = Color.rgb(220, 50, 50);
    final int BG = Color.rgb(246, 248, 252);
    final int TEXT = Color.rgb(31, 41, 55);
    final int MUTED = Color.rgb(100, 116, 139);
    final int BORDER = Color.rgb(225, 231, 239);

    int dp(float x){ return (int)(x * getResources().getDisplayMetrics().density + .5f); }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        db = new Store(this);
        getWindow().setStatusBarColor(BLUE_DARK);
        showHome();
    }

    TextView text(String s, float size, int color){
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(dp(10),dp(5),dp(10),dp(5));
        return t;
    }

    Button button(String s){
        Button b = new Button(this);
        b.setText(s); b.setTextSize(14); b.setAllCaps(false);
        b.setPadding(dp(10),0,dp(10),0);
        return b;
    }

    EditText input(String hint){
        EditText e = new EditText(this);
        e.setHint(hint); e.setTextSize(14); e.setSingleLine(true);
        e.setTextColor(TEXT); e.setHintTextColor(Color.rgb(150,158,170));
        e.setPadding(dp(12),0,dp(12),0);
        e.setBackground(round(Color.WHITE, BORDER, 12, 1));
        e.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return e;
    }

    GradientDrawable round(int fill, int stroke, int radius, int sw){
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill); g.setCornerRadius(dp(radius));
        if(sw>0) g.setStroke(dp(sw),stroke);
        return g;
    }

    GradientDrawable solid(int fill, int radius){
        return round(fill, fill, radius, 0);
    }

    void base(String title){
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(7),0,dp(7),0);
        top.setBackgroundColor(BLUE);

        Button menu = button("☰");
        menu.setTextColor(Color.WHITE);
        menu.setTextSize(22);
        menu.setBackgroundColor(Color.TRANSPARENT);
        menu.setOnClickListener(v -> showHome());

        screenTitle = text(title,19,Color.WHITE);
        screenTitle.setGravity(Gravity.CENTER);
        screenTitle.setTypeface(Typeface.DEFAULT,Typeface.BOLD);

        top.addView(menu,new LinearLayout.LayoutParams(dp(54),dp(58)));
        top.addView(screenTitle,new LinearLayout.LayoutParams(0,dp(58),1));

        root.addView(top);

        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(12),dp(10),dp(12),dp(10));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(body);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        root.addView(bottomBar(title));
        setContentView(root);
    }

    View bottomBar(String current){
        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setBackgroundColor(Color.WHITE);
        nav.setPadding(0,dp(3),0,dp(3));

        nav.addView(navItem("⌂","الرئيسية",current.equals("الرئيسية"),v->showHome()));
        nav.addView(navItem("▣","الفواتير",current.equals("الفواتير"),v->showInvoices()));
        nav.addView(navItem("▤","المنتجات",current.equals("المنتجات"),v->showProducts()));
        nav.addView(navItem("♙","الزبائن",current.equals("الزبائن"),v->showCustomers()));
        nav.addView(navItem("⚙","الإعدادات",current.equals("الإعدادات"),v->showSettings()));
        return nav;
    }

    View navItem(String icon,String label,boolean active,View.OnClickListener l){
        LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setGravity(Gravity.CENTER);
        TextView i=text(icon,20,active?BLUE:MUTED);i.setGravity(Gravity.CENTER);
        TextView t=text(label,10,active?BLUE:MUTED);t.setGravity(Gravity.CENTER);
        x.addView(i,new LinearLayout.LayoutParams(-1,dp(26)));
        x.addView(t,new LinearLayout.LayoutParams(-1,dp(24)));
        x.setOnClickListener(l);
        x.setBackground(active?solid(Color.rgb(239,246,255),10):ColorDrawable(Color.TRANSPARENT));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(54),1);p.setMargins(dp(3),0,dp(3),0);
        x.setLayoutParams(p);
        return x;
    }

    Drawable ColorDrawable(int c){ return new android.graphics.drawable.ColorDrawable(c); }

    TextView section(String s){
        TextView t=text(s,16,TEXT);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        t.setPadding(dp(4),dp(12),dp(4),dp(6));return t;
    }

    LinearLayout card(){
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(10),dp(9),dp(10),dp(9));c.setBackground(round(Color.WHITE,BORDER,15,1));
        return c;
    }

    void showHome(){
        base("الرئيسية");

        LinearLayout brand=card();
        brand.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.logo_mge);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        brand.addView(logo,new LinearLayout.LayoutParams(-1,dp(82)));
        TextView sub=text("تطبيق الفواتير + المنتجات + الزبائن",18,TEXT);sub.setGravity(Gravity.CENTER);
        brand.addView(sub);
        TextView ver=text("الإصدار 2.4 • البيانات محفوظة داخل الهاتف",12,MUTED);ver.setGravity(Gravity.CENTER);
        brand.addView(ver);
        body.addView(brand,margin(-1,dp(142),0,dp(8)));

        LinearLayout quick=new LinearLayout(this);
        quick.setOrientation(LinearLayout.HORIZONTAL);
        quick.addView(stat("🧾","الفواتير","إدارة الفواتير",v->showInvoices()),new LinearLayout.LayoutParams(0,dp(112),1));
        quick.addView(stat("📦","المنتجات","إدارة المنتجات",v->showProducts()),new LinearLayout.LayoutParams(0,dp(112),1));
        body.addView(quick);

        LinearLayout quick2=new LinearLayout(this);
        quick2.setOrientation(LinearLayout.HORIZONTAL);
        quick2.addView(stat("👤","الزبائن","إدارة الزبائن",v->showCustomers()),new LinearLayout.LayoutParams(0,dp(112),1));
        quick2.addView(stat("⚙","الإعدادات","إعدادات الشركة",v->showSettings()),new LinearLayout.LayoutParams(0,dp(112),1));
        body.addView(quick2);

        Button create=button("＋   إنشاء فاتورة جديدة");
        create.setTextColor(Color.WHITE);create.setTextSize(16);create.setBackground(solid(GREEN,14));
        create.setOnClickListener(v->showInvoiceEditor(-1));
        body.addView(create,margin(-1,dp(54),0,dp(10)));

        TextView note=text("PDF احترافي • حالة الدفع • بحث مباشر • صور المنتجات",13,MUTED);
        note.setGravity(Gravity.CENTER);body.addView(note);
    }

    View stat(String icon,String title,String desc,View.OnClickListener l){
        LinearLayout c=card();c.setGravity(Gravity.CENTER);
        TextView i=text(icon,27,BLUE);i.setGravity(Gravity.CENTER);
        TextView a=text(title,17,TEXT);a.setTypeface(Typeface.DEFAULT,Typeface.BOLD);a.setGravity(Gravity.CENTER);
        TextView b=text(desc,11,MUTED);b.setGravity(Gravity.CENTER);
        c.addView(i);c.addView(a);c.addView(b);c.setOnClickListener(l);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(106));p.setMargins(dp(4),dp(4),dp(4),dp(4));c.setLayoutParams(p);
        return c;
    }

    void showProducts(){
        base("المنتجات");
        EditText search=input("🔎  ابحث باسم المنتج أو الكود");body.addView(search,margin(-1,dp(48),0,dp(8)));

        Button add=button("＋  إضافة منتج");add.setTextColor(Color.WHITE);add.setBackground(solid(BLUE,12));
        add.setOnClickListener(v->productDialog(-1));body.addView(add,margin(-1,dp(48),0,dp(8)));

        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);body.addView(list);
        Runnable refresh=()->{list.removeAllViews();for(Store.Product p:db.products(search.getText().toString()))productRow(list,p);};
        watch(search,refresh);refresh.run();
    }

    void productRow(LinearLayout list,Store.Product p){
        LinearLayout r=card();r.setOrientation(LinearLayout.HORIZONTAL);r.setGravity(Gravity.CENTER_VERTICAL);
        ImageView im=new ImageView(this);loadImage(im,p.image);im.setScaleType(ImageView.ScaleType.CENTER_CROP);
        r.addView(im,new LinearLayout.LayoutParams(dp(70),dp(70)));

        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(8),0,dp(8),0);
        TextView n=text(p.name,16,TEXT);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        info.addView(n);info.addView(text("Code: "+safe(p.code),12,MUTED));
        TextView price=text(money(p.price)+" DH",14,BLUE);price.setTypeface(Typeface.DEFAULT,Typeface.BOLD);info.addView(price);
        r.addView(info,new LinearLayout.LayoutParams(0,dp(78),1));

        Button edit=button("✎");edit.setTextColor(BLUE);edit.setBackgroundColor(Color.TRANSPARENT);edit.setOnClickListener(v->productDialog(p.id));
        Button del=button("🗑");del.setTextColor(RED);del.setBackgroundColor(Color.TRANSPARENT);del.setOnClickListener(v->{db.deleteProduct(p.id);showProducts();});
        r.addView(edit,new LinearLayout.LayoutParams(dp(48),dp(58)));
        r.addView(del,new LinearLayout.LayoutParams(dp(48),dp(58)));

        list.addView(r,margin(-1,dp(94),0,dp(6)));
    }

    void productDialog(int id){
        Store.Product o=id<0?null:db.product(id);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(5),0,dp(5),0);
        EditText n=input("اسم المنتج"),c=input("الكود"),pr=input("السعر DH"),img=input("الصورة (يتم اختيارها من الهاتف)");
        if(o!=null){n.setText(o.name);c.setText(o.code);pr.setText(money(o.price));img.setText(safe(o.image));}
        box.addView(n,margin(-1,dp(48),0,dp(7)));box.addView(c,margin(-1,dp(48),0,dp(7)));
        box.addView(pr,margin(-1,dp(48),0,dp(7)));box.addView(img,margin(-1,dp(48),0,dp(7)));
        Button pick=button("🖼  اختيار صورة من معرض الهاتف");
        pick.setOnClickListener(v->openProductGallery(img));
        box.addView(pick);
        AlertDialog d=new AlertDialog.Builder(this).setTitle(id<0?"إضافة منتج":"تعديل المنتج").setView(box)
            .setPositiveButton("حفظ",(x,w)->{db.saveProduct(id,n.getText().toString().trim(),c.getText().toString().trim(),toD(pr.getText().toString()),img.getText().toString());showProducts();})
            .setNegativeButton("إلغاء",null).create();d.show();
    }

    void showCustomers(){
        base("الزبائن والشركاء");
        TextView hint=text("إدارة الزبائن والشركاء وحساب أرباح الشركاء بشكل تلقائي",13,MUTED);hint.setGravity(Gravity.CENTER);body.addView(hint,margin(-1,dp(34),0,dp(3)));
        EditText search=input("🔎  ابحث بالاسم أو الهاتف أو المدينة");body.addView(search,margin(-1,dp(48),0,dp(8)));
        Button add=button("＋  إضافة زبون / شريك");add.setTextColor(Color.WHITE);add.setBackground(solid(BLUE,12));add.setOnClickListener(v->customerDialog(-1));body.addView(add,margin(-1,dp(48),0,dp(8)));
        LinearLayout filters=new LinearLayout(this);filters.setGravity(Gravity.CENTER);final int[] filter={0};
        Button all=button("الكل"),normal=button("الزبائن"),partners=button("🤝 الشركاء");
        filters.addView(all,new LinearLayout.LayoutParams(0,dp(42),1));filters.addView(normal,new LinearLayout.LayoutParams(0,dp(42),1));filters.addView(partners,new LinearLayout.LayoutParams(0,dp(42),1));body.addView(filters,margin(-1,dp(46),0,dp(8)));
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);body.addView(list);
        Runnable refresh=()->{list.removeAllViews();for(Store.Customer c:db.customers(search.getText().toString())){if(filter[0]==1&&c.reseller)continue;if(filter[0]==2&&!c.reseller)continue;customerRow(list,c);}};
        all.setOnClickListener(v->{filter[0]=0;refreshCustomerButtons(all,normal,partners,0);refresh.run();});normal.setOnClickListener(v->{filter[0]=1;refreshCustomerButtons(all,normal,partners,1);refresh.run();});partners.setOnClickListener(v->{filter[0]=2;refreshCustomerButtons(all,normal,partners,2);refresh.run();});refreshCustomerButtons(all,normal,partners,0);
        watch(search,refresh);refresh.run();
    }

    void refreshCustomerButtons(Button all,Button normal,Button partners,int active){Button[] bs={all,normal,partners};for(int i=0;i<bs.length;i++){bs[i].setTextColor(i==active?Color.WHITE:BLUE);bs[i].setBackground(solid(i==active?BLUE:Color.rgb(239,246,255),10));}}

    void customerRow(LinearLayout list,Store.Customer c){
        LinearLayout r=card();r.setOrientation(LinearLayout.VERTICAL);r.setPadding(dp(12),dp(10),dp(12),dp(10));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        TextView avatar=text(c.reseller?"🤝":"👤",24,c.reseller?GREEN:BLUE);avatar.setGravity(Gravity.CENTER);avatar.setBackground(solid(c.reseller?Color.rgb(236,253,245):Color.rgb(239,246,255),40));top.addView(avatar,new LinearLayout.LayoutParams(dp(54),dp(54)));
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(9),0,dp(6),0);
        TextView n=text(c.name,17,TEXT);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);info.addView(n);
        info.addView(text(c.reseller?"شريك إحالة • يرسل لك زبائنه":"زبون عادي"+(c.partnerId>0?" • تابع لشريك":""),11,c.reseller?GREEN:MUTED));
        info.addView(text("📞 "+safe(c.phone)+"   •   📍 "+safe(c.city),12,MUTED));
        if(c.reseller) info.addView(text("🚚 شحن افتراضي: "+money(c.defaultShipping)+" DH",11,BLUE));
        top.addView(info,new LinearLayout.LayoutParams(0,dp(82),1));
        Button edit=button("✎");edit.setTextColor(BLUE);edit.setBackgroundColor(Color.TRANSPARENT);edit.setOnClickListener(v->customerDialog(c.id));
        Button del=button("🗑");del.setTextColor(RED);del.setBackgroundColor(Color.TRANSPARENT);del.setOnClickListener(v->{db.deleteCustomer(c.id);showCustomers();});
        top.addView(edit,new LinearLayout.LayoutParams(dp(42),dp(52)));top.addView(del,new LinearLayout.LayoutParams(dp(42),dp(52)));r.addView(top);
        TextView addr=text("📍 "+safe(c.address),11,MUTED);r.addView(addr);
        if(c.reseller){
            LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER);
            Button clients=button("👥 زبائنه");clients.setTextColor(BLUE);clients.setOnClickListener(v->showPartnerCustomers(c.id));
            Button profits=button("💰 الأرباح");profits.setTextColor(GREEN);profits.setOnClickListener(v->showPartnerProfits(c.id));
            actions.addView(clients,new LinearLayout.LayoutParams(0,dp(44),1));actions.addView(profits,new LinearLayout.LayoutParams(0,dp(44),1));r.addView(actions);
        }
        list.addView(r,margin(-1,-2,0,dp(7)));
    }

    void customerDialog(int id){
        Store.Customer o=id<0?null:db.customer(id);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(4),0,dp(4),0);
        EditText n=input("الاسم"),p=input("الهاتف"),city=input("المدينة"),a=input("العنوان");
        CheckBox reseller=new CheckBox(this);reseller.setText("🤝 شريك إحالة — يرسل لي زبائنه");reseller.setTextSize(14);
        EditText partnerName=input("الشريك المسؤول عن هذا الزبون (اختياري)");Button pickPartner=button("🤝 اختيار الشريك");
        EditText defaultShip=input("شحن افتراضي للشريك DH");defaultShip.setInputType(2|8192);defaultShip.setText("30");
        final int[] partnerId={0};
        if(o!=null){n.setText(o.name);p.setText(o.phone);city.setText(o.city);a.setText(o.address);reseller.setChecked(o.reseller);partnerId[0]=o.partnerId;if(o.partnerId>0){Store.Customer pc=db.customer(o.partnerId);if(pc!=null)partnerName.setText(pc.name);}if(o.reseller)defaultShip.setText(money(o.defaultShipping));}
        box.addView(n,margin(-1,dp(48),0,dp(5)));box.addView(p,margin(-1,dp(48),0,dp(5)));box.addView(city,margin(-1,dp(48),0,dp(5)));box.addView(a,margin(-1,dp(48),0,dp(5)));box.addView(reseller);
        box.addView(partnerName,margin(-1,dp(48),0,dp(5)));pickPartner.setOnClickListener(v->partnerPicker(partnerName,partnerId));box.addView(pickPartner);box.addView(defaultShip,margin(-1,dp(48),0,dp(5)));
        Runnable state=()->{partnerName.setVisibility(reseller.isChecked()?View.GONE:View.VISIBLE);pickPartner.setVisibility(reseller.isChecked()?View.GONE:View.VISIBLE);defaultShip.setVisibility(reseller.isChecked()?View.VISIBLE:View.GONE);};reseller.setOnCheckedChangeListener((b,checked)->state.run());state.run();
        new AlertDialog.Builder(this).setTitle(id<0?"إضافة زبون / شريك":"تعديل بيانات الزبون").setView(box)
            .setPositiveButton("حفظ",(d,w)->{double ship=toD(defaultShip.getText().toString());if(reseller.isChecked()&&ship<=0)ship=30;db.saveCustomer(id,n.getText().toString().trim(),p.getText().toString().trim(),city.getText().toString().trim(),a.getText().toString().trim(),reseller.isChecked(),reseller.isChecked()?0:partnerId[0],ship);showCustomers();})
            .setNegativeButton("إلغاء",null).show();
    }

    void partnerPicker(EditText target,int[] selected){partnerPicker(target,selected,null);}
    void partnerPicker(EditText target,int[] selected,Runnable onSelected){
        EditText s=input("🔎 ابحث عن شريك");LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);ScrollView sv=new ScrollView(this);sv.addView(list);LinearLayout wrap=new LinearLayout(this);wrap.setOrientation(LinearLayout.VERTICAL);wrap.setPadding(dp(5),dp(5),dp(5),dp(5));wrap.addView(s);wrap.addView(sv,new LinearLayout.LayoutParams(-1,dp(400)));
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("اختيار الشريك").setView(wrap).setNegativeButton("إلغاء",null).create();Runnable r=()->{list.removeAllViews();for(Store.Customer c:db.customers(s.getText().toString()))if(c.reseller){Button b=button("🤝 "+c.name+"\n"+safe(c.phone));b.setOnClickListener(v->{target.setText(c.name);selected[0]=c.id;dlg.dismiss();if(onSelected!=null)onSelected.run();});list.addView(b);}};watch(s,r);r.run();dlg.show();
    }

    void showPartnerCustomers(int partnerId){
        Store.Customer partner=db.customer(partnerId);if(partner==null)return;
        base("زبائن "+partner.name);
        TextView head=text("👥 جميع زبائن الشريك • "+partner.name,18,TEXT);head.setTypeface(Typeface.DEFAULT,Typeface.BOLD);head.setGravity(Gravity.CENTER);body.addView(head,margin(-1,dp(44),0,dp(6)));
        EditText search=input("🔎 ابحث عن زبون الشريك");body.addView(search,margin(-1,dp(48),0,dp(8)));
        Button add=button("＋ إضافة زبون لهذا الشريك");add.setTextColor(Color.WHITE);add.setBackground(solid(BLUE,12));add.setOnClickListener(v->customerDialogForPartner(partnerId));body.addView(add,margin(-1,dp(48),0,dp(8)));
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);body.addView(list);
        Runnable refresh=()->{list.removeAllViews();for(Store.Customer c:db.partnerCustomers(partnerId,search.getText().toString()))customerRow(list,c);};watch(search,refresh);refresh.run();
    }

    void customerDialogForPartner(int partnerId){
        Store.Customer partner=db.customer(partnerId);if(partner==null)return;
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(4),0,dp(4),0);
        EditText n=input("اسم الزبون"),p=input("الهاتف"),city=input("المدينة"),a=input("العنوان");box.addView(n,margin(-1,dp(48),0,dp(5)));box.addView(p,margin(-1,dp(48),0,dp(5)));box.addView(city,margin(-1,dp(48),0,dp(5)));box.addView(a,margin(-1,dp(48),0,dp(5)));
        new AlertDialog.Builder(this).setTitle("إضافة زبون للشريك: "+partner.name).setView(box).setPositiveButton("حفظ",(d,w)->{db.saveCustomer(-1,n.getText().toString().trim(),p.getText().toString().trim(),city.getText().toString().trim(),a.getText().toString().trim(),false,partnerId,30);showPartnerCustomers(partnerId);}).setNegativeButton("إلغاء",null).show();
    }

    void showPartnerProfits(int partnerId){
        Store.Customer partner=db.customer(partnerId);if(partner==null)return;
        base("أرباح الشريك");

        TextView title=text("💰 أرباح "+partner.name,20,TEXT);
        title.setGravity(Gravity.CENTER);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        body.addView(title,margin(-1,dp(44),0,dp(6)));

        LinearLayout summary=card();summary.setOrientation(LinearLayout.VERTICAL);
        summary.addView(text("🚚 الشحن الافتراضي للشريك: "+money(partner.defaultShipping)+" DH",14,BLUE));
        TextView total=text("",18,TEXT),paid=text("",14,GREEN),pending=text("",14,RED);
        summary.addView(total);summary.addView(paid);summary.addView(pending);
        body.addView(summary,margin(-1,-2,0,dp(9)));

        LinearLayout tools=new LinearLayout(this);tools.setOrientation(LinearLayout.VERTICAL);
        Button settle=button("☑  تحديد الطلبات المستلمة ودفع الأرباح");
        settle.setTextColor(Color.WHITE);settle.setBackground(solid(GREEN,12));
        settle.setOnClickListener(v->showPartnerSettlement(partnerId));
        Button pdfReceived=button("📄 PDF أرباح الطلبات المستلمة");
        pdfReceived.setTextColor(Color.WHITE);pdfReceived.setBackground(solid(BLUE,12));
        pdfReceived.setOnClickListener(v->makePartnerProfitPdf(partnerId,true));
        Button pdfFailed=button("📄 PDF الطلبات غير المستلمة");
        pdfFailed.setTextColor(Color.WHITE);pdfFailed.setBackground(solid(Color.rgb(180,60,60),12));
        pdfFailed.setOnClickListener(v->makePartnerProfitPdf(partnerId,false));
        tools.addView(settle,new LinearLayout.LayoutParams(-1,dp(50)));
        LinearLayout pdfs=new LinearLayout(this);
        pdfs.addView(pdfReceived,new LinearLayout.LayoutParams(0,dp(48),1));
        pdfs.addView(pdfFailed,new LinearLayout.LayoutParams(0,dp(48),1));
        tools.addView(pdfs);
        body.addView(tools,margin(-1,-2,0,dp(10)));

        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);body.addView(list);
        double[] sums={0,0,0}; int receivedCount=0,failedCount=0;
        for(Store.Invoice i:db.invoices("")){
            if(i.partnerId!=partnerId)continue;
            double net=i.commission;sums[0]+=net;
            if(i.partnerProfitPaid)sums[1]+=net;else sums[2]+=net;
            if(i.deliveryReceived)receivedCount++;else failedCount++;

            LinearLayout r=card();r.setPadding(dp(10),dp(8),dp(10),dp(8));
            Store.Customer cu=i.clientId>0?db.customer(i.clientId):null;
            String clientLine=i.client+(cu!=null?" • "+safe(cu.city):"");
            r.addView(text("#"+i.id+"  •  "+clientLine+"  •  "+i.date,15,TEXT));
            if(cu!=null)r.addView(text("📞 "+safe(cu.phone)+"  •  📍 "+safe(cu.address),11,MUTED));
            r.addView(text("ربح المنتجات: "+money(productProfit(i))+" DH  |  شحن الزبون: "+money(i.shippingCharge)+" DH  |  التكلفة الفعلية: "+money(i.shippingCost)+" DH",11,MUTED));
            r.addView(text("💰 صافي ربح الشريك: "+money(net)+" DH",13,net>=0?GREEN:RED));
            r.addView(text(i.deliveryReceived?"📦 تم الاستلام":"📦 لم يتم الاستلام",11,i.deliveryReceived?GREEN:RED));
            if(!i.deliveryReceived && i.deliveryFailureReason!=null && !i.deliveryFailureReason.isEmpty())
                r.addView(text("سبب عدم الاستلام: "+i.deliveryFailureReason,11,RED));
            if(i.partnerProfitPaid)
                r.addView(text("💵 تم دفع أرباح الشريك • "+safe(i.partnerProfitPaidDate),11,GREEN));
            else if(i.deliveryReceived)
                r.addView(text("⏳ أرباح الشريك مستحقة وغير مدفوعة",11,RED));
            list.addView(r,margin(-1,-2,0,dp(7)));
        }
        total.setText("إجمالي أرباح الشريك: "+money(sums[0])+" DH");
        paid.setText("💵 تم دفعه: "+money(sums[1])+" DH");
        pending.setText("⏳ متبقي: "+money(sums[2])+" DH");
        body.addView(text("📦 مستلمة: "+receivedCount+"   •   ❌ غير مستلمة: "+failedCount,12,MUTED),margin(-1,dp(28),0,dp(8)));
    }

    double productProfit(Store.Invoice i){
        double x=0;for(Store.Item it:i.items)x+=(it.salePrice-it.price)*it.qty;return x;
    }

    void showPartnerSettlement(int partnerId){
        Store.Customer partner=db.customer(partnerId);if(partner==null)return;
        base("تسوية أرباح "+partner.name);

        TextView head=text("☑ اختر الطلبات التي تم استلامها ليتم جمع أرباحها ودفعها معاً",15,TEXT);
        head.setGravity(Gravity.CENTER);body.addView(head,margin(-1,dp(44),0,dp(6)));

        LinearLayout list= new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv=new ScrollView(this);sv.addView(list);
        body.addView(sv,new LinearLayout.LayoutParams(-1,0,1));

        ArrayList<Integer> selectedIds=new ArrayList<>();
        ArrayList<CheckBox> boxes=new ArrayList<>();
        ArrayList<Store.Invoice> eligible=new ArrayList<>();
        double[] selectedTotal={0};
        final TextView[] sumHolder={null};

        for(Store.Invoice i:db.invoices("")){
            if(i.partnerId!=partnerId || !i.deliveryReceived || i.partnerProfitPaid)continue;
            eligible.add(i);
            LinearLayout r=card();r.setPadding(dp(8),dp(7),dp(8),dp(7));
            CheckBox cb=new CheckBox(this);cb.setText("☑  #"+i.id+"  "+i.client);cb.setTextSize(15);cb.setTextColor(TEXT);
            r.addView(cb);
            Store.Customer cu=i.clientId>0?db.customer(i.clientId):null;
            r.addView(text("📞 "+(cu==null?"":safe(cu.phone))+"   •   📍 "+(cu==null?"":safe(cu.city)),11,MUTED));
            r.addView(text("💰 ربح الشريك: "+money(i.commission)+" DH"+(i.shippingCost>i.shippingCharge?"   •   اقتطاع فرق الشحن: "+money(i.shippingCost-i.shippingCharge)+" DH":""),12,i.commission>=0?GREEN:RED));
            cb.setOnCheckedChangeListener((b,checked)->{
                if(checked){if(!selectedIds.contains(i.id)){selectedIds.add(i.id);selectedTotal[0]+=i.commission;}}
                else{selectedIds.remove((Integer)i.id);selectedTotal[0]-=i.commission;}
            });
            boxes.add(cb);list.addView(r,margin(-1,-2,0,dp(6)));
        }

        if(eligible.isEmpty()){
            list.addView(text("لا توجد طلبات مستلمة غير مسددة للشريك.",15,MUTED),margin(-1,dp(60),0,dp(10)));
        }

        LinearLayout bottom=card();
        TextView sum=text("إجمالي المحدد: 0.00 DH",18,TEXT);sum.setGravity(Gravity.CENTER);sumHolder[0]=sum;bottom.addView(sum);
        Button all=button("☑ تحديد الكل");all.setTextColor(BLUE);
        all.setOnClickListener(v->{for(CheckBox cb:boxes)if(!cb.isChecked())cb.setChecked(true);sum.setText("إجمالي المحدد: "+money(selectedTotal[0])+" DH");});
        bottom.addView(all);
        Button confirm=button("💵 تأكيد دفع الأرباح المحددة");confirm.setTextColor(Color.WHITE);confirm.setBackground(solid(GREEN,12));
        confirm.setOnClickListener(v->{
            if(selectedIds.isEmpty()){Toast.makeText(this,"حدد طلبية واحدة على الأقل",Toast.LENGTH_SHORT).show();return;}
            db.setPartnerProfitPaidBulk(selectedIds,true);
            Toast.makeText(this,"تم تسجيل دفع "+money(selectedTotal[0])+" DH للشريك",Toast.LENGTH_LONG).show();
            showPartnerProfits(partnerId);
        });
        bottom.addView(confirm,new LinearLayout.LayoutParams(-1,dp(50)));
        body.addView(bottom,margin(-1,-2,0,dp(8)));

        TextView failedTitle=text("❌ الطلبات التي لم يتم استلامها",17,RED);
        failedTitle.setTypeface(Typeface.DEFAULT,Typeface.BOLD);body.addView(failedTitle,margin(-1,dp(42),0,dp(4)));
        for(Store.Invoice i:db.invoices("")){
            if(i.partnerId!=partnerId||i.deliveryReceived)continue;
            Store.Customer cu=i.clientId>0?db.customer(i.clientId):null;
            LinearLayout r=card();
            r.addView(text("#"+i.id+" • "+i.client,14,TEXT));
            r.addView(text("📞 "+(cu==null?"":safe(cu.phone))+" • 📍 "+(cu==null?"":safe(cu.city)),11,MUTED));
            r.addView(text("🚚 التتبع: "+safe(i.trackingNumber),11,MUTED));
            r.addView(text("سبب عدم الاستلام: "+(i.deliveryFailureReason==null||i.deliveryFailureReason.isEmpty()?"غير محدد":i.deliveryFailureReason),12,RED));
            body.addView(r,margin(-1,-2,0,dp(6)));
        }
    }

    void makePartnerProfitPdf(int partnerId,boolean receivedOnly){
        Store.Customer partner=db.customer(partnerId);if(partner==null)return;
        ArrayList<Store.Invoice> rows=new ArrayList<>();
        for(Store.Invoice i:db.invoices("")){
            if(i.partnerId!=partnerId)continue;
            if(receivedOnly && !i.deliveryReceived)continue;
            if(!receivedOnly && i.deliveryReceived)continue;
            rows.add(i);
        }
        String title=receivedOnly?"أرباح_الشريك_"+safeFileName(partner.name):"طلبات_غير_مستلمة_"+safeFileName(partner.name);
        PdfDocument doc=new PdfDocument();
        int pageNo=0;PdfDocument.Page page=null;Canvas canvas=null;Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);int y=0;
        for(int index=0;index<rows.size();index++){
            if(page==null||y>770){
                if(page!=null)doc.finishPage(page);
                page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,++pageNo).create());
                canvas=page.getCanvas();p.setColor(Color.WHITE);canvas.drawPaint(p);
                p.setColor(BLUE);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(20);canvas.drawText("MGE",40,45,p);
                p.setColor(TEXT);p.setTextSize(18);canvas.drawText(receivedOnly?"PARTNER PROFIT REPORT / أرباح الشريك":"UNDELIVERED ORDERS / الطلبات غير المستلمة",160,45,p);
                p.setTypeface(Typeface.DEFAULT);p.setTextSize(12);
                canvas.drawText("Partenaire / الشريك : "+safe(partner.name),40,70,p);
                canvas.drawText("Date : "+new java.text.SimpleDateFormat("dd/MM/yyyy",Locale.US).format(new java.util.Date()),40,88,p);
                y=120;
            }
            Store.Invoice i=rows.get(index);Store.Customer cu=i.clientId>0?db.customer(i.clientId):null;
            p.setColor(Color.rgb(245,247,250));canvas.drawRect(35,y-17,560,y+60,p);
            p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(12);
            canvas.drawText("#"+i.id+"  "+trim(i.client,30),45,y,p);
            p.setTypeface(Typeface.DEFAULT);p.setTextSize(10);
            canvas.drawText("Phone: "+(cu==null?"":safe(cu.phone)),45,y+18,p);
            canvas.drawText("City: "+(cu==null?"":safe(cu.city)),205,y+18,p);
            canvas.drawText("Address: "+(cu==null?"":trim(cu.address,35)),350,y+18,p);
            if(receivedOnly){
                canvas.drawText("Net partner profit: "+money(i.commission)+" DH",45,y+38,p);
                canvas.drawText("Shipping: "+money(i.shippingCharge)+" DH / Actual: "+money(i.shippingCost)+" DH",270,y+38,p);
                canvas.drawText("Delivery: RECEIVED / تم الاستلام",45,y+55,p);
            }else{
                canvas.drawText("Tracking: "+safe(i.trackingNumber),45,y+38,p);
                canvas.drawText("Reason: "+trim(i.deliveryFailureReason==null?"غير محدد":i.deliveryFailureReason,55),270,y+38,p);
                canvas.drawText("Delivery: NOT RECEIVED / لم يتم الاستلام",45,y+55,p);
            }
            y+=86;
        }
        if(page==null){
            page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());canvas=page.getCanvas();p.setColor(Color.WHITE);canvas.drawPaint(p);p.setColor(TEXT);p.setTextSize(16);
            canvas.drawText(receivedOnly?"لا توجد أرباح مستحقة في هذه القائمة":"لا توجد طلبات غير مستلمة",60,100,p);
        }
        if(page!=null)doc.finishPage(page);
        if(receivedOnly){
            // Add a final summary page with totals.
            PdfDocument.Page sumPage=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,++pageNo).create());
            Canvas sc=sumPage.getCanvas();p.setColor(Color.WHITE);sc.drawPaint(p);p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(20);sc.drawText("SUMMARY / ملخص الأرباح",45,60,p);
            double total=0,paidTotal=0,pendingTotal=0;int count=0;
            for(Store.Invoice i:rows){total+=i.commission;count++;if(i.partnerProfitPaid)paidTotal+=i.commission;else pendingTotal+=i.commission;}
            p.setTypeface(Typeface.DEFAULT);p.setTextSize(15);sc.drawText("Partner: "+safe(partner.name),45,105,p);sc.drawText("Orders received: "+count,45,135,p);sc.drawText("Total profit: "+money(total)+" DH",45,165,p);sc.drawText("Paid: "+money(paidTotal)+" DH",45,195,p);sc.drawText("Remaining: "+money(pendingTotal)+" DH",45,225,p);
            doc.finishPage(sumPage);
        }
        sharePdfDocument(doc,title+".pdf");
    }

    void sharePdfDocument(PdfDocument doc,String fileName){
        try{
            ByteArrayOutputStream buffer=new ByteArrayOutputStream();doc.writeTo(buffer);doc.close();byte[] bytes=buffer.toByteArray();
            Uri uri=savePdfToDownloads(bytes,fileName);
            Intent share=new Intent(Intent.ACTION_SEND);share.setType("application/pdf");share.putExtra(Intent.EXTRA_STREAM,uri);share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);share.setClipData(ClipData.newRawUri("PDF",uri));
            startActivity(Intent.createChooser(share,"إرسال PDF عبر واتساب أو أي تطبيق"));
            Toast.makeText(this,"تم حفظ الملف في Download/FactureSimple",Toast.LENGTH_LONG).show();
        }catch(Exception e){try{doc.close();}catch(Exception ignored){}Toast.makeText(this,"خطأ PDF: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }

    Uri savePdfToDownloads(byte[] bytes,String fileName)throws Exception{
        if(Build.VERSION.SDK_INT>=29){
            ContentValues values=new ContentValues();values.put(MediaStore.Downloads.DISPLAY_NAME,fileName);values.put(MediaStore.Downloads.MIME_TYPE,"application/pdf");values.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/FactureSimple");values.put(MediaStore.Downloads.IS_PENDING,1);
            Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new IOException("تعذر إنشاء الملف");
            try(OutputStream out=getContentResolver().openOutputStream(uri)){out.write(bytes);}
            ContentValues done=new ContentValues();done.put(MediaStore.Downloads.IS_PENDING,0);getContentResolver().update(uri,done,null,null);return uri;
        }
        File dir=new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),"FactureSimple");if(!dir.exists()&&!dir.mkdirs())throw new IOException("تعذر إنشاء المجلد");
        File f=new File(dir,fileName);try(OutputStream out=new FileOutputStream(f)){out.write(bytes);}return Uri.fromFile(f);
    }

    void showInvoices(){
        base("الفواتير");
        EditText search=input("🔎  ابحث برقم الفاتورة أو اسم الزبون");
        body.addView(search,margin(-1,dp(48),0,dp(8)));
        Button add=button("＋  فاتورة جديدة");
        add.setTextColor(Color.WHITE);
        add.setBackground(solid(BLUE,12));
        add.setOnClickListener(v->showInvoiceEditor(-1));
        body.addView(add,margin(-1,dp(48),0,dp(8)));

        LinearLayout accountPanel=new LinearLayout(this);
        accountPanel.setOrientation(LinearLayout.VERTICAL);
        body.addView(accountPanel);

        LinearLayout list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        body.addView(list);

        Runnable refresh=()->{
            accountPanel.removeAllViews();
            list.removeAllViews();

            String q=search.getText().toString().trim();

            // عند البحث باسم زبون، أظهر له مباشرة كشف الفواتير غير المدفوعة
            // حتى يستطيع تحديد عدة فواتير ودفعها دفعة واحدة في نهاية الشهر.
            if(!q.isEmpty()){
                int shown=0;
                for(Store.Customer c:db.customers(q)){
                    if(c.reseller)continue;
                    ArrayList<Store.Invoice> unpaid=db.customerInvoices(c.id,c.name,true);
                    if(unpaid.isEmpty())continue;
                    addCustomerPaymentCard(accountPanel,c,unpaid);
                    shown++;
                    if(shown>=3)break;
                }
            }

            for(Store.Invoice i:db.invoices(q))invoiceRow(list,i);
        };
        watch(search,refresh);
        refresh.run();
    }

    void addCustomerPaymentCard(LinearLayout host,Store.Customer customer,ArrayList<Store.Invoice> unpaid){
        LinearLayout card=card();
        TextView title=text("💳 حساب الزبون: "+customer.name,18,TEXT);
        title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        card.addView(title);

        double outstanding=0;
        for(Store.Invoice i:unpaid)outstanding+=invoiceTotal(i);

        TextView summary=text("الفواتير غير المدفوعة: "+unpaid.size()+"   •   المبلغ المتبقي: "+money(outstanding)+" DH",13,RED);
        summary.setGravity(Gravity.CENTER);
        card.addView(summary);

        TextView instruction=text("حدد الفواتير التي يريد الزبون دفعها الآن",13,MUTED);
        instruction.setGravity(Gravity.CENTER);
        card.addView(instruction);

        LinearLayout rows=new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        ArrayList<Integer> selected=new ArrayList<>();
        double[] selectedTotal={0};

        for(Store.Invoice inv:unpaid){
            LinearLayout row=new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(4),dp(3),dp(4),dp(3));
            row.setBackground(round(Color.rgb(249,251,255),BORDER,10,1));

            CheckBox cb=new CheckBox(this);
            cb.setText("#"+inv.id+"  •  "+inv.date);
            cb.setTextSize(14);
            cb.setTextColor(TEXT);

            TextView amount=text(money(invoiceTotal(inv))+" DH",14,TEXT);
            amount.setGravity(Gravity.CENTER);
            amount.setTypeface(Typeface.DEFAULT,Typeface.BOLD);

            row.addView(cb,new LinearLayout.LayoutParams(0,dp(48),1));
            row.addView(amount,new LinearLayout.LayoutParams(dp(115),dp(48)));

            cb.setOnCheckedChangeListener((buttonView,isChecked)->{
                if(isChecked){
                    if(!selected.contains(inv.id)){
                        selected.add(inv.id);
                        selectedTotal[0]+=invoiceTotal(inv);
                    }
                }else{
                    selected.remove((Integer)inv.id);
                    selectedTotal[0]-=invoiceTotal(inv);
                }
            });
            rows.addView(row,margin(-1,dp(50),0,dp(5)));
        }
        card.addView(rows);

        TextView chosen=text("المحدد: 0 فاتورة • 0.00 DH",16,TEXT);
        chosen.setGravity(Gravity.CENTER);
        card.addView(chosen);

        Button all=button("☑ تحديد كل الفواتير");
        all.setTextColor(BLUE);
        all.setOnClickListener(v->{
            for(int k=0;k<rows.getChildCount();k++){
                View rv=rows.getChildAt(k);
                if(rv instanceof LinearLayout){
                    View first=((LinearLayout)rv).getChildAt(0);
                    if(first instanceof CheckBox){
                        CheckBox cb=(CheckBox)first;
                        if(!cb.isChecked())cb.setChecked(true);
                    }
                }
            }
            chosen.setText("المحدد: "+selected.size()+" فاتورة • "+money(selectedTotal[0])+" DH");
        });
        card.addView(all);

        // تحديث المجموع مباشرة عند كل تحديد.
        for(int k=0;k<rows.getChildCount();k++){
            View rv=rows.getChildAt(k);
            if(rv instanceof LinearLayout){
                View first=((LinearLayout)rv).getChildAt(0);
                if(first instanceof CheckBox){
                    ((CheckBox)first).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
                        @Override public void onCheckedChanged(CompoundButton buttonView,boolean isChecked){
                            // يتم حسابه من الحالة الحالية لتفادي أي خطأ في التحديد.
                            selected.clear();
                            selectedTotal[0]=0;
                            for(int j=0;j<rows.getChildCount();j++){
                                View rr=rows.getChildAt(j);
                                if(rr instanceof LinearLayout){
                                    View f=((LinearLayout)rr).getChildAt(0);
                                    if(f instanceof CheckBox && ((CheckBox)f).isChecked()){
                                        int invoiceId=unpaid.get(j).id;
                                        selected.add(invoiceId);
                                        selectedTotal[0]+=invoiceTotal(unpaid.get(j));
                                    }
                                }
                            }
                            chosen.setText("المحدد: "+selected.size()+" فاتورة • "+money(selectedTotal[0])+" DH");
                        }
                    });
                }
            }
        }

        Button pay=button("💵 تسديد الفواتير المحددة");
        pay.setTextColor(Color.WHITE);
        pay.setBackground(solid(GREEN,12));
        pay.setOnClickListener(v->{
            if(selected.isEmpty()){
                Toast.makeText(this,"حدد فاتورة واحدة على الأقل",Toast.LENGTH_SHORT).show();
                return;
            }
            new AlertDialog.Builder(this)
                    .setTitle("تأكيد التسديد")
                    .setMessage("سيتم تسجيل دفع "+selected.size()+" فاتورة بمجموع "+money(selectedTotal[0])+" DH بتاريخ اليوم.")
                    .setNegativeButton("إلغاء",null)
                    .setPositiveButton("تأكيد الدفع",(d,w)->{
                        ArrayList<Integer> paidIds=new ArrayList<>(selected);
                        db.setInvoicesPaidBulk(paidIds);
                        Toast.makeText(this,"تم تسديد الفواتير المحددة وتسجيل تاريخ الدفع",Toast.LENGTH_LONG).show();
                        makeBulkPaymentPdf(paidIds,customer);
                        showInvoices();
                    }).show();
        });
        card.addView(pay,new LinearLayout.LayoutParams(-1,dp(50)));
        host.addView(card,margin(-1,-2,0,dp(8)));
    }

    double invoiceTotal(Store.Invoice i){
        double total=0;
        for(Store.Item it:i.items)total+=it.salePrice*it.qty;
        if(i.shippingEnabled)total+=i.shippingCharge;
        return total;
    }

    void invoiceRow(LinearLayout list,Store.Invoice i){
        double products=0;for(Store.Item it:i.items)products+=it.salePrice*it.qty;double total=products+(i.shippingEnabled?i.shippingCharge:0);
        LinearLayout r=card();r.setPadding(dp(10),dp(8),dp(10),dp(8));LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        TextView no=text("#"+i.id,16,BLUE);no.setTypeface(Typeface.DEFAULT,Typeface.BOLD);top.addView(no,new LinearLayout.LayoutParams(dp(60),dp(36)));TextView cl=text(i.client,16,TEXT);cl.setTypeface(Typeface.DEFAULT,Typeface.BOLD);top.addView(cl,new LinearLayout.LayoutParams(0,dp(36),1));TextView amount=text(money(total)+" DH",15,TEXT);amount.setGravity(Gravity.CENTER);top.addView(amount,new LinearLayout.LayoutParams(dp(105),dp(36)));r.addView(top);
        LinearLayout mid=new LinearLayout(this);mid.setGravity(Gravity.CENTER_VERTICAL);mid.addView(text("📅 "+i.date+(i.partnerId>0?"   • 🤝 شريك":""),11,MUTED),new LinearLayout.LayoutParams(0,dp(28),1));TextView status=text(i.paid?"مدفوعة":"غير مدفوعة",11,i.paid?GREEN:RED);
        status.setGravity(Gravity.CENTER);
        status.setBackground(round(i.paid?Color.rgb(232,249,238):Color.rgb(254,239,239),i.paid?Color.rgb(177,230,193):Color.rgb(247,188,188),20,1));
        status.setOnClickListener(v->showPaymentDate(i));
        mid.addView(status,new LinearLayout.LayoutParams(dp(92),dp(28)));r.addView(mid);
        if(i.paid&&i.paidDate!=null&&!i.paidDate.isEmpty())
            r.addView(text("💳 تاريخ دفع الفاتورة: "+i.paidDate,11,GREEN));
        if(i.shippingEnabled){
            r.addView(text("🚚 شحن: "+money(i.shippingCharge)+" DH • التكلفة الفعلية: "+money(i.shippingCost)+" DH",11,BLUE));
            if(i.shippingCompany!=null&&!i.shippingCompany.isEmpty())
                r.addView(text("🏢 شركة الشحن: "+safe(i.shippingCompany)+" • الحساب: "+safe(i.shippingAccount),11,BLUE));
        }
        if(i.partnerId>0){TextView cm=text("💰 صافي ربح الشريك: "+money(i.commission)+" DH",11,i.commission>=0?GREEN:RED);r.addView(cm);r.addView(text(i.partnerProfitPaid?"💵 تم دفع أرباح الشريك"+(i.partnerProfitPaidDate!=null&&!i.partnerProfitPaidDate.isEmpty()?" • "+i.partnerProfitPaidDate:""):"⏳ أرباح الشريك غير مدفوعة",11,i.partnerProfitPaid?GREEN:RED));}
        if(i.trackingNumber!=null&&!i.trackingNumber.isEmpty())r.addView(text("🚚 تتبع: "+i.trackingNumber+" • "+(i.deliveryReceived?"تم الاستلام":"لم يتم الاستلام"),11,i.deliveryReceived?GREEN:RED));
        if(i.deliveryReceived&&i.deliveryReceivedDate!=null&&!i.deliveryReceivedDate.isEmpty())r.addView(text("📦 تاريخ الاستلام: "+i.deliveryReceivedDate,11,GREEN));
        if(!i.deliveryReceived&&i.deliveryFailureReason!=null&&!i.deliveryFailureReason.isEmpty())r.addView(text("❌ سبب عدم الاستلام: "+i.deliveryFailureReason,11,RED));
        LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER);Button edit=button("✎ تعديل");edit.setTextColor(BLUE);edit.setBackgroundColor(Color.TRANSPARENT);edit.setOnClickListener(v->showInvoiceEditor(i.id));Button pdf=button("PDF");pdf.setTextColor(BLUE);pdf.setBackgroundColor(Color.TRANSPARENT);pdf.setOnClickListener(v->makePdf(i.id));Button del=button("🗑");del.setTextColor(RED);del.setBackgroundColor(Color.TRANSPARENT);del.setOnClickListener(v->{db.deleteInvoice(i.id);showInvoices();});actions.addView(edit);actions.addView(pdf);if(i.partnerId>0&&!i.partnerProfitPaid&&i.deliveryReceived){Button pay=button("💵 دفع الربح");pay.setTextColor(GREEN);pay.setBackgroundColor(Color.TRANSPARENT);pay.setOnClickListener(v->{db.setPartnerProfitPaid(i.id,true);showInvoices();});actions.addView(pay);}actions.addView(del);r.addView(actions);list.addView(r,margin(-1,-2,0,dp(7)));
    }

    void makeBulkPaymentPdf(ArrayList<Integer> invoiceIds,Store.Customer customer){
        if(invoiceIds==null||invoiceIds.isEmpty())return;
        ArrayList<Store.Invoice> paidInvoices=new ArrayList<>();
        for(Integer id:invoiceIds){if(id!=null){Store.Invoice inv=db.invoice(id);if(inv!=null)paidInvoices.add(inv);}}
        if(paidInvoices.isEmpty())return;

        PdfDocument doc=new PdfDocument();
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        PdfDocument.Page page=null;Canvas c=null;int pageNo=0,y=0;
        double grandTotal=0;
        String paymentTime=new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.US).format(new java.util.Date());

        for(Store.Invoice inv:paidInvoices){
            int blockHeight=115+(inv.items.size()*16)+(inv.shippingEnabled?16:0);
            if(page==null||y+blockHeight>770){
                if(page!=null)doc.finishPage(page);
                page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,++pageNo).create());
                c=page.getCanvas();p.setColor(Color.WHITE);c.drawPaint(p);
                p.setColor(BLUE);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(21);c.drawText("MGE",40,45,p);
                p.setColor(TEXT);p.setTextSize(18);c.drawText("REÇU DE PAIEMENT / وصل الأداء",145,45,p);
                p.setTypeface(Typeface.DEFAULT);p.setTextSize(11);
                c.drawText("Client / الزبون : "+safe(customer==null?inv.client:customer.name),40,70,p);
                c.drawText("Date et heure / تاريخ ووقت الدفع : "+safe(inv.paidDate==null||inv.paidDate.isEmpty()?paymentTime:inv.paidDate),40,88,p);
                y=125;
            }
            p.setColor(Color.rgb(245,247,250));c.drawRoundRect(35,y-20,560,y+blockHeight,10,10,p);
            p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(13);
            c.drawText("FACTURE #"+inv.id,48,y,p);
            p.setTypeface(Typeface.DEFAULT);p.setTextSize(10);
            c.drawText("Date facture : "+safe(inv.date),48,y+18,p);
            c.drawText("Paiement : "+safe(inv.paidDate==null?paymentTime:inv.paidDate),300,y+18,p);
            int iy=y+42;double invTotal=0;
            p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(9);
            c.drawText("Produit",48,iy,p);c.drawText("Qté",315,iy,p);c.drawText("Prix",380,iy,p);c.drawText("Total",475,iy,p);
            p.setTypeface(Typeface.DEFAULT);
            iy+=18;
            for(Store.Item it:inv.items){
                double line=it.salePrice*it.qty;invTotal+=line;
                c.drawText(trim(it.name,34),48,iy,p);c.drawText(""+it.qty,315,iy,p);c.drawText(money(it.salePrice),380,iy,p);c.drawText(money(line),475,iy,p);iy+=16;
            }
            if(inv.shippingEnabled){invTotal+=inv.shippingCharge;c.drawText("الشحن",48,iy,p);c.drawText(money(inv.shippingCharge),475,iy,p);iy+=16;}
            p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("مجموع الفاتورة: "+money(invTotal)+" DH",340,iy+8,p);
            grandTotal+=invTotal;y=iy+45;
        }
        if(page==null){page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());c=page.getCanvas();p.setColor(Color.WHITE);c.drawPaint(p);pageNo=1;}
        if(y>700){doc.finishPage(page);page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,++pageNo).create());c=page.getCanvas();p.setColor(Color.WHITE);c.drawPaint(p);y=90;}
        p.setColor(GREEN);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(17);c.drawText("TOTAL PAYÉ / مجموع المدفوعات : "+money(grandTotal)+" DH",55,y+20,p);
        p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT);p.setTextSize(11);c.drawText("Nombre de factures / عدد الفواتير : "+paidInvoices.size(),55,y+45,p);c.drawText("Merci pour votre confiance",225,y+75,p);
        doc.finishPage(page);
        sharePdfDocument(doc,"Paiement_"+safeFileName(customer==null?paidInvoices.get(0).client:customer.name)+"_"+new java.text.SimpleDateFormat("yyyyMMdd_HHmm",Locale.US).format(new java.util.Date())+".pdf");
    }

    void showPaymentDate(Store.Invoice i){
        String d=(i.paidDate==null||i.paidDate.isEmpty())?"غير مسجل":i.paidDate;
        new AlertDialog.Builder(this)
                .setTitle("💳 تاريخ دفع الفاتورة")
                .setMessage("الفاتورة رقم #"+i.id+"\n\nحالة الدفع: مدفوعة\nتاريخ الدفع: "+d)
                .setPositiveButton("حسناً",null)
                .show();
    }

    void showInvoiceEditor(int id){
        base(id<0?"فاتورة جديدة":"تعديل الفاتورة");Store.Invoice old=id<0?null:db.invoice(id);
        LinearLayout invoiceHead=card();TextView head=text("بيانات الشريك والزبون",16,TEXT);head.setTypeface(Typeface.DEFAULT,Typeface.BOLD);invoiceHead.addView(head);
        EditText partner=input("الشريك (اختياري)");Button choosePartner=button("🤝 اختيار الشريك");final int[] selectedPartner={old==null?0:old.partnerId};if(selectedPartner[0]>0){Store.Customer pc=db.customer(selectedPartner[0]);if(pc!=null)partner.setText(pc.name);}invoiceHead.addView(partner,margin(-1,dp(48),0,dp(6)));invoiceHead.addView(choosePartner);
        EditText client=input("اسم الزبون المستلم");Button choose=button("👤 اختيار زبون من القائمة");final int[] selectedCustomer={old==null?0:old.clientId};if(old!=null)client.setText(old.client);invoiceHead.addView(client,margin(-1,dp(48),0,dp(6)));invoiceHead.addView(choose);body.addView(invoiceHead,margin(-1,-2,0,dp(9)));
        choosePartner.setOnClickListener(v->partnerPicker(partner,selectedPartner,()->{if(invoicePartnerModeRefresh!=null)invoicePartnerModeRefresh.run();}));choose.setOnClickListener(v->customerPicker(client,selectedCustomer,selectedPartner));

        LinearLayout productsCard=card();productsCard.addView(section("البحث عن منتج"));EditText search=input("🔎 اكتب اسم المنتج أو الكود");productsCard.addView(search,margin(-1,dp(48),0,dp(7)));LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);productsCard.addView(results);body.addView(productsCard,margin(-1,-2,0,dp(9)));
        LinearLayout selectedCard=card();selectedCard.addView(section("المنتجات داخل الفاتورة"));TextView selectedHint=text(selectedPartner[0]>0?"المنتج                         السعر":"المنتج                         سعرنا        سعر الزبون",11,MUTED);
        selectedHint.setGravity(Gravity.CENTER);
        selectedCard.addView(selectedHint);LinearLayout selected=new LinearLayout(this);selected.setOrientation(LinearLayout.VERTICAL);selectedCard.addView(selected);body.addView(selectedCard,margin(-1,-2,0,dp(9)));

        LinearLayout delivery=card();
        delivery.addView(section("التوصيل والشحن"));
        CheckBox shipping=new CheckBox(this);
        shipping.setText("🚚 هذه الفاتورة سيتم شحنها");
        shipping.setTextSize(15);
        delivery.addView(shipping);

        // شركة الشحن والحساب: يتم تحميلهما من الإعدادات ويمكن إضافة شركات وحسابات جديدة لاحقاً.
        LinearLayout carrierBox=new LinearLayout(this);
        carrierBox.setOrientation(LinearLayout.VERTICAL);
        carrierBox.addView(section("شركة الشحن والحساب"));
        TextView companyLabel=text("شركة الشحن",13,MUTED);
        companyLabel.setGravity(Gravity.RIGHT);
        carrierBox.addView(companyLabel,margin(-1,dp(28),0,dp(2)));
        Spinner shippingCompany=new Spinner(this);
        TextView accountLabel=text("حساب Store",13,MUTED);
        accountLabel.setGravity(Gravity.RIGHT);
        Spinner shippingAccount=new Spinner(this);
        ArrayList<Store.ShippingCompany> carrierCompanies=db.shippingCompanies();
        ArrayList<String> carrierNames=new ArrayList<>();
        for(Store.ShippingCompany c:carrierCompanies)carrierNames.add(c.name);
        ArrayAdapter<String> companyAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,carrierNames);
        companyAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        shippingCompany.setAdapter(companyAdapter);
        ArrayList<String> accountNames=new ArrayList<>();
        ArrayAdapter<String> accountAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,accountNames);
        accountAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        shippingAccount.setAdapter(accountAdapter);
        Runnable refreshCarrierAccounts=()->{
            accountAdapter.clear();
            int pos=shippingCompany.getSelectedItemPosition();
            if(pos>=0&&pos<carrierCompanies.size()){
                for(Store.ShippingAccount a:db.shippingAccounts(carrierCompanies.get(pos).id))accountAdapter.add(a.name);
            }
            accountAdapter.notifyDataSetChanged();
        };
        Runnable refreshCarrierCompanies=()->{
            carrierCompanies.clear();
            carrierCompanies.addAll(db.shippingCompanies());
            carrierNames.clear();
            for(Store.ShippingCompany c:carrierCompanies)carrierNames.add(c.name);
            companyAdapter.notifyDataSetChanged();
            if(carrierCompanies.isEmpty()){
                accountAdapter.clear();
                accountAdapter.notifyDataSetChanged();
            }else{
                if(shippingCompany.getSelectedItemPosition()<0||shippingCompany.getSelectedItemPosition()>=carrierCompanies.size())shippingCompany.setSelection(0);
                refreshCarrierAccounts.run();
            }
        };
        shippingCompany.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(AdapterView<?> p){}
            public void onItemSelected(AdapterView<?> p,View v,int position,long id){refreshCarrierAccounts.run();}
        });
        carrierBox.addView(shippingCompany,margin(-1,dp(50),0,dp(7)));
        carrierBox.addView(accountLabel,margin(-1,dp(28),0,dp(2)));
        carrierBox.addView(shippingAccount,margin(-1,dp(50),0,dp(9)));

        // إدارة الشحن داخل الفاتورة: أزرار منفصلة بعرض كامل حتى لا تتداخل الكتابة على الشاشات الصغيرة.
        LinearLayout shippingManage=new LinearLayout(this);
        shippingManage.setOrientation(LinearLayout.VERTICAL);
        shippingManage.setPadding(0,dp(2),0,dp(2));

        Button quickAddCompany=button("＋  إضافة شركة شحن");
        quickAddCompany.setTextSize(13);
        quickAddCompany.setGravity(Gravity.CENTER);
        quickAddCompany.setTextColor(Color.WHITE);
        quickAddCompany.setBackground(solid(BLUE,12));
        quickAddCompany.setMinHeight(0);
        quickAddCompany.setMinimumHeight(0);

        Button quickAddAccount=button("＋  إضافة حساب Store");
        quickAddAccount.setTextSize(13);
        quickAddAccount.setGravity(Gravity.CENTER);
        quickAddAccount.setTextColor(Color.WHITE);
        quickAddAccount.setBackground(solid(GREEN,12));
        quickAddAccount.setMinHeight(0);
        quickAddAccount.setMinimumHeight(0);

        shippingManage.addView(quickAddCompany,margin(-1,dp(48),0,dp(7)));
        shippingManage.addView(quickAddAccount,new LinearLayout.LayoutParams(-1,dp(48)));
        carrierBox.addView(shippingManage,margin(-1,dp(3),0,dp(6)));
        delivery.addView(carrierBox);

        quickAddCompany.setOnClickListener(v->{
            EditText n=input("اسم شركة الشحن الجديدة");
            new AlertDialog.Builder(this)
                .setTitle("إضافة شركة شحن")
                .setView(n)
                .setNegativeButton("إلغاء",null)
                .setPositiveButton("حفظ",(d,w)->{
                    String x=n.getText().toString().trim();
                    if(x.isEmpty()){Toast.makeText(this,"أدخل اسم الشركة",Toast.LENGTH_SHORT).show();return;}
                    if(db.addShippingCompany(x)==-1){
                        Toast.makeText(this,"هذه الشركة موجودة مسبقاً",Toast.LENGTH_SHORT).show();
                    }else{
                        refreshCarrierCompanies.run();
                        if(shippingCompany.getCount()>0)shippingCompany.setSelection(shippingCompany.getCount()-1);
                        Toast.makeText(this,"تمت إضافة شركة الشحن",Toast.LENGTH_SHORT).show();
                    }
                }).show();
        });
        quickAddAccount.setOnClickListener(v->{
            ArrayList<Store.ShippingCompany> companies=db.shippingCompanies();
            if(companies.isEmpty()){
                Toast.makeText(this,"أضف شركة شحن أولاً",Toast.LENGTH_SHORT).show();
                return;
            }
            LinearLayout wrap=new LinearLayout(this);
            wrap.setOrientation(LinearLayout.VERTICAL);
            wrap.setPadding(dp(8),dp(4),dp(8),dp(4));
            Spinner company=new Spinner(this);
            ArrayList<String> names=new ArrayList<>();
            for(Store.ShippingCompany x:companies)names.add(x.name);
            ArrayAdapter<String> ca=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,names);
            ca.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            company.setAdapter(ca);
            EditText account=input("اسم الحساب مثل Store MGE02");
            wrap.addView(company);
            wrap.addView(account,margin(-1,dp(48),0,0));
            new AlertDialog.Builder(this)
                .setTitle("إضافة حساب Store")
                .setView(wrap)
                .setNegativeButton("إلغاء",null)
                .setPositiveButton("حفظ",(d,w)->{
                    String x=account.getText().toString().trim();
                    if(x.isEmpty()){Toast.makeText(this,"أدخل اسم الحساب",Toast.LENGTH_SHORT).show();return;}
                    int pos=company.getSelectedItemPosition();
                    if(pos>=0&&db.addShippingAccount(companies.get(pos).id,x)==-1){
                        Toast.makeText(this,"هذا الحساب موجود لهذه الشركة",Toast.LENGTH_SHORT).show();
                    }else{
                        refreshCarrierAccounts.run();
                        Toast.makeText(this,"تمت إضافة حساب Store",Toast.LENGTH_SHORT).show();
                    }
                }).show();
        });

        LinearLayout shippingOptions=new LinearLayout(this);
        shippingOptions.setOrientation(LinearLayout.VERTICAL);

        EditText shippingCharge=input("مبلغ الشحن الذي يدفعه الزبون DH");
        EditText shippingCost=input("تكلفة الشحن الفعلية من شركة التوصيل DH");
        shippingCharge.setInputType(2|8192);
        shippingCost.setInputType(2|8192);
        shippingOptions.addView(shippingCharge,margin(-1,dp(48),0,dp(6)));
        shippingOptions.addView(shippingCost,margin(-1,dp(48),0,dp(6)));

        EditText tracking=input("رقم تتبع الطلبية (اختياري)");
        shippingOptions.addView(tracking,margin(-1,dp(48),0,dp(6)));

        CheckBox received=new CheckBox(this);
        received.setText("📦 تم الاستلام من طرف الزبون");
        shippingOptions.addView(received);

        CheckBox notReceived=new CheckBox(this);
        notReceived.setText("❌ لم يتم الاستلام من طرف الزبون");
        shippingOptions.addView(notReceived);

        LinearLayout failureBox=new LinearLayout(this);
        failureBox.setOrientation(LinearLayout.VERTICAL);
        TextView reasonLabel=section("سبب عدم الاستلام");
        Spinner failureReason=new Spinner(this);
        String[] reasons={"رقم الهاتف خاطئ","الزبون غير مهتم","العنوان خاطئ","المنتوج ليس الذي طلبه","رفض الدفع عند الاستلام","لم يتوصل بالطلب","طلب إرجاع","سبب آخر"};
        ArrayAdapter<String> reasonAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,reasons);
        reasonAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        failureReason.setAdapter(reasonAdapter);
        failureBox.addView(reasonLabel);
        failureBox.addView(failureReason,new LinearLayout.LayoutParams(-1,dp(48)));
        shippingOptions.addView(failureBox);

        delivery.addView(shippingOptions);
        body.addView(delivery,margin(-1,-2,0,dp(9)));
        LinearLayout totalCard=card();TextView total=text("المجموع على الزبون\n0.00 DH",19,TEXT);total.setGravity(Gravity.CENTER);total.setTypeface(Typeface.DEFAULT,Typeface.BOLD);totalCard.addView(total);TextView commission=text("صافي ربح الشريك بعد الشحن: 0.00 DH",15,GREEN);commission.setGravity(Gravity.CENTER);totalCard.addView(commission);CheckBox profitPaid=new CheckBox(this);profitPaid.setText("💵 تم دفع أرباح الشريك");profitPaid.setTextSize(15);profitPaid.setEnabled(false);totalCard.addView(profitPaid);
        CompoundButton.OnCheckedChangeListener deliveryStateListener=(button,checked)->{
            if(button==received && checked){
                if(notReceived.isChecked())notReceived.setChecked(false);
            }else if(button==notReceived && checked){
                if(received.isChecked())received.setChecked(false);
            }
            boolean showReason=notReceived.isChecked();
            failureBox.setVisibility(showReason?View.VISIBLE:View.GONE);
            profitPaid.setEnabled(received.isChecked());
            if(!received.isChecked())profitPaid.setChecked(false);
        };
        received.setOnCheckedChangeListener(deliveryStateListener);
        notReceived.setOnCheckedChangeListener(deliveryStateListener);
        failureBox.setVisibility(View.GONE);
        CheckBox paid=new CheckBox(this);paid.setText("الفاتورة مدفوعة");paid.setTextSize(15);totalCard.addView(paid);LinearLayout actions=new LinearLayout(this);Button save=button("حفظ الفاتورة");save.setTextColor(Color.WHITE);save.setBackground(solid(GREEN,12));Button pdf=button("تصدير PDF");pdf.setTextColor(Color.WHITE);pdf.setBackground(solid(BLUE,12));pdf.setEnabled(id>=0);actions.addView(save,new LinearLayout.LayoutParams(0,dp(52),1));actions.addView(pdf,new LinearLayout.LayoutParams(0,dp(52),1));totalCard.addView(actions);body.addView(totalCard,margin(-1,-2,0,dp(12)));

        ArrayList<Store.Item> items=new ArrayList<>();
        invoicePartnerModeRefresh=null;
        invoicePartnerMode=selectedPartner[0]>0;
        if(old!=null){items.addAll(old.items);paid.setChecked(old.paid);shipping.setChecked(old.shippingEnabled);shippingCharge.setText(money(old.shippingCharge));shippingCost.setText(money(old.shippingCost));tracking.setText(safe(old.trackingNumber));received.setChecked(old.deliveryReceived);notReceived.setChecked(old.shippingEnabled&&!old.deliveryReceived&&old.deliveryFailureReason!=null&&!old.deliveryFailureReason.isEmpty());profitPaid.setChecked(old.partnerProfitPaid);selectFailureReason(failureReason,old.deliveryFailureReason,reasons);failureBox.setVisibility(notReceived.isChecked()?View.VISIBLE:View.GONE);selectSpinnerValue(shippingCompany,old.shippingCompany);selectSpinnerValue(shippingAccount,old.shippingAccount);}else{shippingCharge.setText(db.get("default_shipping","30"));shippingCost.setText(db.get("default_shipping","30"));failureBox.setVisibility(View.GONE);shippingCompany.setSelection(0);shippingAccount.setSelection(0);}
        Runnable refreshShipping=()->{
            boolean en=shipping.isChecked();
            shippingOptions.setVisibility(en?View.VISIBLE:View.GONE);
            carrierBox.setVisibility(en?View.VISIBLE:View.GONE);
            shippingCharge.setEnabled(en);
            shippingCost.setEnabled(en);
            if(en&&toD(shippingCharge.getText().toString())<=0){
                double d=selectedPartner[0]>0?partnerDefaultShipping(selectedPartner[0]):toD(db.get("default_shipping","30"));
                shippingCharge.setText(money(d));
                shippingCost.setText(money(d));
            }
            if(!en){
                shippingCharge.setText("0");
                shippingCost.setText("0");
                received.setChecked(false);
                notReceived.setChecked(false);
                failureBox.setVisibility(View.GONE);
                profitPaid.setChecked(false);
            }
            updateFinancials(total,commission,items,en,toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));
        };
        shipping.setOnCheckedChangeListener((b,c)->refreshShipping.run());
        TextWatcher financeWatcher=new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));}public void afterTextChanged(Editable e){}};shippingCharge.addTextChangedListener(financeWatcher);shippingCost.addTextChangedListener(financeWatcher);
        invoicePartnerModeRefresh=()->{invoicePartnerMode=selectedPartner[0]>0;selectedHint.setText(invoicePartnerMode?"المنتج                         السعر":"المنتج                         سعرنا        سعر الزبون");renderItems(selected,items,total,commission,shipping,shippingCharge,shippingCost,invoicePartnerMode);updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));};
        Runnable update=()->{results.removeAllViews();String q=search.getText().toString().trim();if(!q.isEmpty())for(Store.Product p:db.products(q))productSearchRow(results,p,items,total,commission,selected,shipping,shippingCharge,shippingCost,selectedPartner[0]>0);renderItems(selected,items,total,commission,shipping,shippingCharge,shippingCost,selectedPartner[0]>0);updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));};watch(search,update);update.run();refreshShipping.run();
        save.setOnClickListener(v->{
            if(client.getText().toString().trim().isEmpty()){client.setError("أدخل اسم الزبون");return;}
            if(items.isEmpty()){Toast.makeText(this,"أضف منتجاً واحداً على الأقل",Toast.LENGTH_SHORT).show();return;}
            boolean ship=shipping.isChecked();
            boolean rec=ship&&received.isChecked();
            boolean notRec=ship&&notReceived.isChecked();
            boolean pp=ship&&profitPaid.isChecked();
            if(selectedPartner[0]>0&&pp&&!rec){
                Toast.makeText(this,"لا يمكن دفع ربح الشريك قبل استلام الزبون للطلبية",Toast.LENGTH_LONG).show();
                return;
            }
            double sc=ship?toD(shippingCharge.getText().toString()):0;
            double actual=ship?toD(shippingCost.getText().toString()):0;
            String tr=ship?tracking.getText().toString().trim():"";
            String reason=(notRec&&failureReason.getSelectedItem()!=null)?failureReason.getSelectedItem().toString():"";
            db.saveInvoice(id,selectedCustomer[0],client.getText().toString().trim(),paid.isChecked(),selectedPartner[0],ship,sc,actual,tr,ship?shippingCompany.getSelectedItem().toString():"",ship?shippingAccount.getSelectedItem().toString():"",rec,reason,pp,items);
            Toast.makeText(this,"تم حفظ الفاتورة بنجاح",Toast.LENGTH_SHORT).show();
            showInvoices();
        });
        pdf.setOnClickListener(v->{if(id>=0)makePdf(id);});
    }

    void selectFailureReason(Spinner spinner,String value,String[] reasons){
        if(value==null||value.isEmpty())return;
        for(int i=0;i<reasons.length;i++)if(reasons[i].equals(value)){spinner.setSelection(i);return;}
    }

    void selectSpinnerValue(Spinner spinner,String value){
        if(spinner==null||value==null||value.isEmpty())return;
        for(int i=0;i<spinner.getCount();i++){
            Object item=spinner.getItemAtPosition(i);
            if(item!=null&&value.equals(item.toString())){spinner.setSelection(i);return;}
        }
    }

    double partnerDefaultShipping(int partnerId){Store.Customer p=db.customer(partnerId);return p==null?30:p.defaultShipping;}

    void productSearchRow(LinearLayout box,Store.Product p,ArrayList<Store.Item> items,TextView total,TextView commission,LinearLayout selected,CheckBox shipping,EditText shippingCharge,EditText shippingCost){productSearchRow(box,p,items,total,commission,selected,shipping,shippingCharge,shippingCost,invoicePartnerMode);}
    void productSearchRow(LinearLayout box,Store.Product p,ArrayList<Store.Item> items,TextView total,TextView commission,LinearLayout selected,CheckBox shipping,EditText shippingCharge,EditText shippingCost,boolean partnerMode){
        LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(5),dp(4),dp(5),dp(4));r.setBackground(round(Color.rgb(249,251,255),Color.rgb(219,228,240),10,1));ImageView im=new ImageView(this);loadImage(im,p.image);im.setScaleType(ImageView.ScaleType.CENTER_CROP);r.addView(im,new LinearLayout.LayoutParams(dp(55),dp(55)));LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(7),0,dp(7),0);TextView n=text(p.name,14,TEXT);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);info.addView(n);info.addView(text("Code: "+safe(p.code)+" • "+money(p.price)+" DH",11,MUTED));r.addView(info,new LinearLayout.LayoutParams(0,dp(64),1));Button plus=button("＋");plus.setTextColor(Color.WHITE);plus.setBackground(solid(BLUE,10));plus.setOnClickListener(v->{addItem(items,p);renderItems(selected,items,total,commission,shipping,shippingCharge,shippingCost);updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));});r.addView(plus,new LinearLayout.LayoutParams(dp(52),dp(50)));box.addView(r,margin(-1,dp(70),0,dp(5)));
    }

    void renderItems(LinearLayout box,ArrayList<Store.Item> items,TextView total,TextView commission,CheckBox shipping,EditText shippingCharge,EditText shippingCost){renderItems(box,items,total,commission,shipping,shippingCharge,shippingCost,invoicePartnerMode);}
    void renderItems(LinearLayout box,ArrayList<Store.Item> items,TextView total,TextView commission,CheckBox shipping,EditText shippingCharge,EditText shippingCost,boolean partnerMode){
        box.removeAllViews();
        for(int k=0;k<items.size();k++){
            final int idx=k;
            Store.Item it=items.get(k);

            LinearLayout r=card();
            r.setPadding(dp(10),dp(8),dp(10),dp(8));
            r.setOrientation(LinearLayout.VERTICAL);

            TextView n=text("📦 "+safe(it.name),15,TEXT);
            n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
            n.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
            r.addView(n,new LinearLayout.LayoutParams(-1,dp(38)));

            TextView original=text(partnerMode?"الكمية: "+it.qty:"سعرنا: "+money(it.price)+" DH   •   الكمية: "+it.qty,11,MUTED);
            original.setGravity(Gravity.RIGHT);
            r.addView(original,new LinearLayout.LayoutParams(-1,dp(28)));

            LinearLayout controls=new LinearLayout(this);
            controls.setGravity(Gravity.CENTER_VERTICAL);

            Button minus=button("−");
            Button plus=button("+");
            Button del=button("×");
            minus.setTextSize(16);plus.setTextSize(16);del.setTextColor(RED);
            controls.addView(minus,new LinearLayout.LayoutParams(dp(42),dp(44)));
            controls.addView(plus,new LinearLayout.LayoutParams(dp(42),dp(44)));
            controls.addView(del,new LinearLayout.LayoutParams(dp(42),dp(44)));

            // عند وجود شريك: سعر واحد فقط قابل للتعديل. سعر التكلفة محفوظ داخلياً ولا يظهر بجانب سعر الشريك.
            TextView lineTotal=partnerMode?null:text(money(it.salePrice*it.qty)+" DH",12,TEXT);
            if(lineTotal!=null){
                lineTotal.setGravity(Gravity.CENTER);
                controls.addView(lineTotal,new LinearLayout.LayoutParams(dp(88),dp(44)));
            }

            EditText sale=input(partnerMode?"سعر الشريك للزبون":"سعر الزبون");
            sale.setText(money(it.salePrice));
            sale.setInputType(2|8192);
            controls.addView(sale,new LinearLayout.LayoutParams(0,dp(48),1));

            // في فاتورة الشريك لا نعرض أي خانة سعر ثانية؛ هذا هو السعر الوحيد القابل للتعديل.
            if(!partnerMode){
                TextView saleLabel=text("سعر الزبون:",11,MUTED);
                saleLabel.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
                controls.addView(saleLabel,new LinearLayout.LayoutParams(dp(75),dp(44)));
            }

            r.addView(controls,new LinearLayout.LayoutParams(-1,dp(54)));
            box.addView(r,margin(-1,-2,0,dp(7)));

            minus.setOnClickListener(v->{
                if(it.qty>1)it.qty--;else items.remove(idx);
                renderItems(box,items,total,commission,shipping,shippingCharge,shippingCost);
                updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));
            });
            plus.setOnClickListener(v->{
                it.qty++;
                renderItems(box,items,total,commission,shipping,shippingCharge,shippingCost);
                updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));
            });
            del.setOnClickListener(v->{
                items.remove(idx);
                renderItems(box,items,total,commission,shipping,shippingCharge,shippingCost);
                updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));
            });
            sale.addTextChangedListener(new TextWatcher(){
                public void beforeTextChanged(CharSequence s,int a,int b,int c){}
                public void onTextChanged(CharSequence s,int a,int b,int c){
                    double v=toD(s.toString());it.salePrice=v;
                    if(lineTotal!=null)lineTotal.setText(money(v*it.qty)+" DH");
                    original.setText(partnerMode?"الكمية: "+it.qty:"سعرنا: "+money(it.price)+" DH   •   الكمية: "+it.qty);
                    updateFinancials(total,commission,items,shipping.isChecked(),toD(shippingCharge.getText().toString()),toD(shippingCost.getText().toString()));
                }
                public void afterTextChanged(Editable e){}
            });
        }
    }

    void updateFinancials(TextView total,TextView commission,ArrayList<Store.Item> items,boolean shippingEnabled,double shippingCharge,double shippingCost){double sell=0,productProfit=0;for(Store.Item i:items){sell+=i.salePrice*i.qty;productProfit+=(i.salePrice-i.price)*i.qty;}double customerTotal=sell+(shippingEnabled?shippingCharge:0);double net=productProfit+(shippingEnabled?shippingCharge:0)-(shippingEnabled?shippingCost:0);total.setText("المجموع على الزبون\n"+money(customerTotal)+" DH"+(shippingEnabled?"\nشحن: "+money(shippingCharge)+" DH":"\nاستلام من المتجر — بدون شحن"));commission.setText("صافي ربح الشريك بعد الشحن: "+money(net)+" DH");commission.setTextColor(net>=0?GREEN:RED);}
    void addItem(ArrayList<Store.Item> items,Store.Product p){for(Store.Item it:items)if(it.productId==p.id){it.qty++;return;}items.add(new Store.Item(p.id,p.name,p.price,1));}

    void customerPicker(EditText client,int[] selected,int[] partner){
        EditText s=input("🔎 ابحث عن الزبون");LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);ScrollView sv=new ScrollView(this);sv.addView(list);LinearLayout wrap=new LinearLayout(this);wrap.setOrientation(LinearLayout.VERTICAL);wrap.setPadding(dp(5),dp(5),dp(5),dp(5));wrap.addView(s);wrap.addView(sv,new LinearLayout.LayoutParams(-1,dp(400)));
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle(partner[0]>0?"زبائن الشريك":"اختيار الزبون").setView(wrap).setNegativeButton("إلغاء",null).create();Runnable r=()->{list.removeAllViews();ArrayList<Store.Customer> cs=partner[0]>0?db.partnerCustomers(partner[0],s.getText().toString()):db.customers(s.getText().toString());for(Store.Customer c:cs){if(c.reseller)continue;Button b=button(c.name+"\n"+safe(c.phone)+(c.partnerId>0?" • تابع لشريك":""));b.setOnClickListener(v->{client.setText(c.name);selected[0]=c.id;dlg.dismiss();});list.addView(b);}};watch(s,r);r.run();dlg.show();
    }
    void showSettings(){
        base("الإعدادات");
        LinearLayout c=card();
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.logo_mge);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);c.addView(logo,new LinearLayout.LayoutParams(-1,dp(82)));
        EditText name=input("اسم الشركة");name.setText(db.get("company_name","MGE"));
        EditText phone=input("هاتف الشركة");phone.setText(db.get("phone","+212666964731"));
        EditText footer=input("نص أسفل الفاتورة");footer.setText(db.get("footer","Merci pour votre confiance"));
        c.addView(name,margin(-1,dp(48),0,dp(7)));c.addView(phone,margin(-1,dp(48),0,dp(7)));c.addView(footer,margin(-1,dp(48),0,dp(8)));
        Button save=button("حفظ الإعدادات");save.setTextColor(Color.WHITE);save.setBackground(solid(GREEN,12));
        save.setOnClickListener(v->{db.put("company_name",name.getText().toString());db.put("phone",phone.getText().toString());db.put("footer",footer.getText().toString());Toast.makeText(this,"تم حفظ الإعدادات",Toast.LENGTH_SHORT).show();});
        c.addView(save,new LinearLayout.LayoutParams(-1,dp(52)));
        body.addView(c,margin(-1,-2,0,dp(10)));

        LinearLayout ship=card();
        TextView shipTitle=text("🚚 شركات الشحن وحسابات Store",17,TEXT);shipTitle.setTypeface(Typeface.DEFAULT,Typeface.BOLD);shipTitle.setGravity(Gravity.CENTER);ship.addView(shipTitle);
        ship.addView(text("يمكنك إضافة أي شركة شحن جديدة، ثم إضافة حسابات Store الخاصة بها. ستظهر تلقائياً داخل الفاتورة عند تفعيل الشحن.",12,MUTED));
        // أزرار إدارة شركات الشحن وحسابات Store: كل زر في سطر مستقل لمنع التداخل على الشاشات الصغيرة.
        LinearLayout actions=new LinearLayout(this);
        actions.setOrientation(LinearLayout.VERTICAL);
        actions.setGravity(Gravity.CENTER_HORIZONTAL);
        actions.setPadding(dp(2),dp(8),dp(2),dp(4));

        Button addCompany=button("🚚  إضافة شركة شحن");
        addCompany.setTextColor(Color.WHITE);
        addCompany.setTextSize(15);
        addCompany.setGravity(Gravity.CENTER);
        addCompany.setMinHeight(0);
        addCompany.setMinimumHeight(0);
        addCompany.setPadding(dp(12),0,dp(12),0);
        addCompany.setBackground(solid(BLUE,12));

        Button addAccount=button("🏪  إضافة حساب Store");
        addAccount.setTextColor(Color.WHITE);
        addAccount.setTextSize(15);
        addAccount.setGravity(Gravity.CENTER);
        addAccount.setMinHeight(0);
        addAccount.setMinimumHeight(0);
        addAccount.setPadding(dp(12),0,dp(12),0);
        addAccount.setBackground(solid(GREEN,12));

        LinearLayout.LayoutParams addButtonLp=new LinearLayout.LayoutParams(-1,dp(52));
        addButtonLp.setMargins(0,0,0,dp(8));
        actions.addView(addCompany,addButtonLp);

        LinearLayout.LayoutParams addAccountLp=new LinearLayout.LayoutParams(-1,dp(52));
        actions.addView(addAccount,addAccountLp);

        ship.addView(actions,margin(-1,dp(6),0,dp(8)));
        LinearLayout shipList=new LinearLayout(this);shipList.setOrientation(LinearLayout.VERTICAL);ship.addView(shipList);
        body.addView(ship,margin(-1,-2,0,dp(10)));

        final Runnable[] refreshShippingSettings = new Runnable[1];
        refreshShippingSettings[0]=()->{
            shipList.removeAllViews();
            for(Store.ShippingCompany co:db.shippingCompanies()){
                LinearLayout companyRow=new LinearLayout(this);companyRow.setOrientation(LinearLayout.VERTICAL);companyRow.setPadding(dp(10),dp(8),dp(10),dp(8));companyRow.setBackground(round(Color.rgb(249,251,255),BORDER,10,1));
                LinearLayout topRow=new LinearLayout(this);topRow.setGravity(Gravity.CENTER_VERTICAL);
                TextView ct=text("🏢 "+co.name,15,TEXT);ct.setTypeface(Typeface.DEFAULT,Typeface.BOLD);topRow.addView(ct,new LinearLayout.LayoutParams(0,dp(42),1));
                Button delCompany=button("حذف");delCompany.setTextColor(RED);topRow.addView(delCompany,new LinearLayout.LayoutParams(dp(70),dp(42)));companyRow.addView(topRow);
                for(Store.ShippingAccount ac:db.shippingAccounts(co.id)){
                    LinearLayout ar=new LinearLayout(this);ar.setGravity(Gravity.CENTER_VERTICAL);ar.setPadding(dp(5),dp(2),dp(5),dp(2));
                    TextView at=text("🏪 "+ac.name,13,MUTED);ar.addView(at,new LinearLayout.LayoutParams(0,dp(38),1));
                    Button da=button("×");da.setTextColor(RED);ar.addView(da,new LinearLayout.LayoutParams(dp(50),dp(38)));
                    da.setOnClickListener(v->{db.deleteShippingAccount(ac.id);refreshShippingSettings[0].run();});companyRow.addView(ar);
                }
                delCompany.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف شركة الشحن").setMessage("سيتم حذف الشركة وحساباتها من قائمة الاختيار. الفواتير القديمة ستحتفظ بالمعلومات المسجلة فيها.\n\nهل تريد المتابعة؟").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(d,w)->{db.deleteShippingCompany(co.id);refreshShippingSettings[0].run();}).show());
                shipList.addView(companyRow,margin(-1,dp(6),0,dp(4)));
            }
        };
        addCompany.setOnClickListener(v->{
            EditText n=input("اسم شركة الشحن الجديدة");
            new AlertDialog.Builder(this).setTitle("إضافة شركة شحن").setView(n).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",(d,w)->{String x=n.getText().toString().trim();if(x.isEmpty()){Toast.makeText(this,"أدخل اسم الشركة",Toast.LENGTH_SHORT).show();return;}if(db.addShippingCompany(x)==-1)Toast.makeText(this,"هذه الشركة موجودة مسبقاً",Toast.LENGTH_SHORT).show();refreshShippingSettings[0].run();}).show();
        });
        addAccount.setOnClickListener(v->{
            ArrayList<Store.ShippingCompany> cs=db.shippingCompanies();if(cs.isEmpty()){Toast.makeText(this,"أضف شركة شحن أولاً",Toast.LENGTH_SHORT).show();return;}
            LinearLayout wrap=new LinearLayout(this);wrap.setOrientation(LinearLayout.VERTICAL);wrap.setPadding(dp(8),dp(4),dp(8),dp(4));
            Spinner company=new Spinner(this);ArrayList<String> names=new ArrayList<>();for(Store.ShippingCompany x:cs)names.add(x.name);ArrayAdapter<String> ca=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,names);ca.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);company.setAdapter(ca);
            EditText account=input("اسم الحساب مثل Store MGE02");wrap.addView(company);wrap.addView(account,margin(-1,dp(48),0,0));
            new AlertDialog.Builder(this).setTitle("إضافة حساب Store").setView(wrap).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",(d,w)->{String x=account.getText().toString().trim();if(x.isEmpty()){Toast.makeText(this,"أدخل اسم الحساب",Toast.LENGTH_SHORT).show();return;}int pos=company.getSelectedItemPosition();if(pos>=0&&db.addShippingAccount(cs.get(pos).id,x)==-1)Toast.makeText(this,"هذا الحساب موجود لهذه الشركة",Toast.LENGTH_SHORT).show();refreshShippingSettings[0].run();}).show();
        });
        refreshShippingSettings[0].run();
        body.addView(text("سيظهر اسم الشركة ورقم الهاتف في ملف PDF.",13,MUTED));
    }

    void makePdf(int id){
        Store.Invoice inv=db.invoice(id);if(inv==null)return;
        PdfDocument doc=new PdfDocument();PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());Canvas c=page.getCanvas();Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(Color.WHITE);c.drawPaint(p);
        p.setColor(Color.BLACK);c.drawRect(40,35,145,90,p);p.setColor(Color.WHITE);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(25);c.drawText("MGE",66,71,p);
        p.setColor(TEXT);p.setTextSize(21);c.drawText("FACTURE / فاتورة",305,65,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(12);c.drawText("Tel : "+db.get("phone","+212666964731"),40,110,p);c.drawText("N° : "+inv.id,40,132,p);c.drawText("Date : "+inv.date,40,154,p);c.drawText("Client : "+inv.client,40,176,p);
        if(inv.clientId>0){Store.Customer cu=db.customer(inv.clientId);if(cu!=null){c.drawText("Tel : "+safe(cu.phone),300,176,p);c.drawText("Ville : "+safe(cu.city),40,196,p);c.drawText("Adresse : "+safe(cu.address),300,196,p);}}
        if(inv.partnerId>0){Store.Customer partner=db.customer(inv.partnerId);if(partner!=null){p.setColor(BLUE);p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("Partenaire / الشريك : "+safe(partner.name),40,218,p);}}
        p.setColor(inv.paid?GREEN:RED);p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText(inv.paid?"Statut : PAYÉE / مدفوعة":"Statut : NON PAYÉE / غير مدفوعة",40,244,p);
        if(inv.paid&&inv.paidDate!=null&&!inv.paidDate.isEmpty()){p.setColor(GREEN);p.setTypeface(Typeface.DEFAULT);c.drawText("Date de paiement / تاريخ الدفع : "+inv.paidDate,300,244,p);}
        if(inv.trackingNumber!=null&&!inv.trackingNumber.isEmpty()){p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT);c.drawText("Suivi / التتبع : "+inv.trackingNumber+" • "+(inv.deliveryReceived?"REÇU / تم الاستلام":"NON REÇU / لم يتم الاستلام"),300,264,p);}
        if(inv.shippingEnabled&&inv.shippingCompany!=null&&!inv.shippingCompany.isEmpty()){p.setColor(BLUE);p.setTypeface(Typeface.DEFAULT);c.drawText("Expédition / شركة الشحن : "+safe(inv.shippingCompany)+" • "+safe(inv.shippingAccount),40,284,p);}
        if(inv.deliveryReceived&&inv.deliveryReceivedDate!=null&&!inv.deliveryReceivedDate.isEmpty()){c.drawText("Date réception / تاريخ الاستلام : "+inv.deliveryReceivedDate,40,304,p);}
        if(!inv.deliveryReceived&&inv.deliveryFailureReason!=null&&!inv.deliveryFailureReason.isEmpty()){p.setColor(RED);c.drawText("Cause / سبب عدم الاستلام : "+inv.deliveryFailureReason,40,304,p);}
        p.setColor(BLUE);c.drawRect(40,325,555,361,p);p.setColor(Color.WHITE);p.setTextSize(11);p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("Produit / البيان",48,348,p);c.drawText("Qté",270,348,p);c.drawText("Prix",390,348,p);c.drawText("Total",490,348,p);
        p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT);int y=388;double total=0;
        for(Store.Item it:inv.items){double z=it.salePrice*it.qty;total+=z;c.drawText(trim(it.name,31),48,y,p);c.drawText(""+it.qty,270,y,p);c.drawText(money(it.salePrice),390,y,p);c.drawText(money(z),490,y,p);y+=31;p.setColor(BORDER);c.drawLine(40,y-15,555,y-15,p);p.setColor(TEXT);}
        if(inv.shippingEnabled){p.setColor(BLUE);c.drawText("Frais de livraison / مصاريف الشحن",300,y+12,p);c.drawText(money(inv.shippingCharge)+" DH",490,y+12,p);y+=34;total+=inv.shippingCharge;}
        p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(15);c.drawText("TOTAL : "+money(total)+" DH",385,y+25,p);
        if(inv.partnerId>0){p.setTypeface(Typeface.DEFAULT);p.setTextSize(11);c.drawText("Partner profit / ربح الشريك : "+money(inv.commission)+" DH",40,y+25,p);if(inv.partnerProfitPaid)c.drawText("Profit paid / تم دفع الربح : "+safe(inv.partnerProfitPaidDate),40,y+43,p);}
        p.setTypeface(Typeface.DEFAULT);p.setTextSize(13);c.drawText(db.get("footer","Merci pour votre confiance"),215,y+75,p);
        doc.finishPage(page);
        try{byte[] pdfBytes;ByteArrayOutputStream buffer=new ByteArrayOutputStream();doc.writeTo(buffer);doc.close();pdfBytes=buffer.toByteArray();String fileName="Facture_"+id+".pdf";Uri uri=null;if(Build.VERSION.SDK_INT>=29){ContentValues values=new ContentValues();values.put(MediaStore.Downloads.DISPLAY_NAME,fileName);values.put(MediaStore.Downloads.MIME_TYPE,"application/pdf");values.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/FactureSimple");uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new IOException("تعذر إنشاء ملف PDF في Downloads");try(OutputStream out=getContentResolver().openOutputStream(uri)){out.write(pdfBytes);}}else{File dir=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS+"/FactureSimple");if(!dir.exists()&&!dir.mkdirs())throw new IOException("تعذر إنشاء مجلد Downloads");File f=new File(dir,fileName);try(OutputStream out=new FileOutputStream(f)){out.write(pdfBytes);}uri=Uri.fromFile(f);}Intent share=new Intent(Intent.ACTION_SEND);share.setType("application/pdf");share.putExtra(Intent.EXTRA_STREAM,uri);share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);share.setClipData(ClipData.newRawUri("PDF",uri));startActivity(Intent.createChooser(share,"إرسال الفاتورة PDF"));Toast.makeText(this,"تم حفظ الفاتورة في Download/FactureSimple",Toast.LENGTH_LONG).show();}catch(Exception e){try{doc.close();}catch(Exception ignored){}Toast.makeText(this,"خطأ PDF: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }

    void watch(EditText e,final Runnable r){e.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){r.run();}public void afterTextChanged(Editable e){}});}
    void loadImage(ImageView v,String uri){
        try{
            if(uri==null||uri.isEmpty()){v.setImageResource(R.drawable.ic_product);return;}
            if(uri.startsWith("content://"))v.setImageURI(Uri.parse(uri));
            else v.setImageURI(Uri.parse(uri));
        }catch(Exception e){v.setImageResource(R.drawable.ic_product);}
    }

    String copyImageToApp(Uri uri)throws IOException{
        File dir=new File(getFilesDir(),"product_images");if(!dir.exists()&&!dir.mkdirs())throw new IOException("تعذر إنشاء مجلد الصور");
        String ext=".jpg";String type=getContentResolver().getType(uri);if(type!=null){if(type.contains("png"))ext=".png";else if(type.contains("webp"))ext=".webp";else if(type.contains("jpeg"))ext=".jpg";}
        File out=new File(dir,"img_"+System.currentTimeMillis()+ext);
        try(InputStream in=getContentResolver().openInputStream(uri);OutputStream os=new FileOutputStream(out)){
            if(in==null)throw new IOException("تعذر قراءة الصورة");
            byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)os.write(buf,0,n);
        }
        return Uri.fromFile(out).toString();
    }
    LinearLayout.LayoutParams margin(int w,int h,int l,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(l,0,0,b);return p;}
    double sum(ArrayList<Store.Item> a){double x=0;for(Store.Item i:a)x+=i.price*i.qty;return x;}
    double toD(String s){try{return Double.parseDouble(s.replace(",","."));}catch(Exception e){return 0;}}
    String money(double x){return String.format(Locale.US,"%.2f",x);}
    String safe(String s){return s==null?"":s;}
    String safeFileName(String s){return safe(s).replaceAll("[\\/:*?\"<>|]","_").trim();}
    String trim(String s,int n){s=safe(s);return s.length()>n?s.substring(0,n-1)+"…":s;}

    /**
     * معرض صور داخلي خفيف لنسخ صورة المنتج:
     * على Android 10 وما قبله يعرض جميع الصور الموجودة في الهاتف مباشرة
     * في شبكة واحدة بدل شاشة "فتح من" التي تعرض Images/Drive فقط.
     */
    void openProductGallery(EditText target){
        pendingImageField=target;

        if(Build.VERSION.SDK_INT>=33){
            try{
                Intent picker=new Intent(MediaStore.ACTION_PICK_IMAGES);
                picker.setType("image/*");
                picker.putExtra(Intent.EXTRA_LOCAL_ONLY,true);
                startActivityForResult(picker,9001);
                return;
            }catch(Exception ignored){}
        }

        if(Build.VERSION.SDK_INT>=23 &&
                checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)!=android.content.pm.PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},9002);
            return;
        }
        showAllImagesGallery();
    }

    void showAllImagesGallery(){
        try{
            String[] projection={MediaStore.Images.Media._ID,MediaStore.Images.Media.DISPLAY_NAME};
            imageCursor=getContentResolver().query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    projection,null,null,
                    MediaStore.Images.Media.DATE_ADDED+" DESC");

            if(imageCursor==null||imageCursor.getCount()==0){
                Toast.makeText(this,"لم يتم العثور على صور في الهاتف",Toast.LENGTH_LONG).show();
                if(imageCursor!=null){imageCursor.close();imageCursor=null;}
                return;
            }

            GridView grid=new GridView(this);
            grid.setNumColumns(3);
            grid.setHorizontalSpacing(dp(5));
            grid.setVerticalSpacing(dp(5));
            grid.setPadding(dp(8),dp(8),dp(8),dp(8));
            grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
            grid.setAdapter(new AllImagesAdapter(imageCursor));

            TextView title=text("🖼 معرض الصور — جميع الصور ("+imageCursor.getCount()+")",18,TEXT);
            title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
            title.setGravity(Gravity.CENTER);
            title.setPadding(dp(5),dp(12),dp(5),dp(12));

            LinearLayout wrap=new LinearLayout(this);
            wrap.setOrientation(LinearLayout.VERTICAL);
            wrap.setPadding(dp(5),0,dp(5),0);
            wrap.addView(title);
            wrap.addView(grid,new LinearLayout.LayoutParams(-1,0,1));

            imageGalleryDialog=new AlertDialog.Builder(this)
                    .setView(wrap)
                    .setNegativeButton("إلغاء",null)
                    .create();

            grid.setOnItemClickListener((parent,view,position,id)->{
                Uri u=ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,id);
                try{
                    String saved=copyImageToApp(u);
                    if(pendingImageField!=null)pendingImageField.setText(saved);
                    Toast.makeText(this,"تم اختيار الصورة",Toast.LENGTH_SHORT).show();
                }catch(Exception e){
                    if(pendingImageField!=null)pendingImageField.setText(u.toString());
                    Toast.makeText(this,"تم اختيار الصورة",Toast.LENGTH_SHORT).show();
                }
                if(imageGalleryDialog!=null)imageGalleryDialog.dismiss();
            });

            imageGalleryDialog.setOnDismissListener(d->{
                if(imageCursor!=null){imageCursor.close();imageCursor=null;}
            });
            imageGalleryDialog.show();
            imageGalleryDialog.getWindow().setLayout(-1,(int)(getResources().getDisplayMetrics().heightPixels*0.88f));
        }catch(Exception e){
            if(imageCursor!=null){imageCursor.close();imageCursor=null;}
            Toast.makeText(this,"تعذر فتح معرض الصور: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    class AllImagesAdapter extends BaseAdapter{
        final Cursor cursor;
        final int idCol;
        AllImagesAdapter(Cursor c){
            cursor=c;
            idCol=c.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
        }
        public int getCount(){return cursor==null?0:cursor.getCount();}
        public Object getItem(int position){return position;}
        public long getItemId(int position){
            if(cursor==null)return 0;
            if(cursor.moveToPosition(position))return cursor.getLong(idCol);
            return 0;
        }
        public View getView(int position,View convertView,ViewGroup parent){
            ImageView iv=(convertView instanceof ImageView)?(ImageView)convertView:new ImageView(MainActivity.this);
            iv.setLayoutParams(new AbsListView.LayoutParams(-1,dp(112)));
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackground(round(Color.WHITE,BORDER,8,1));
            long imageId=getItemId(position);
            try{
                Uri u=ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,imageId);
                if(Build.VERSION.SDK_INT>=29){
                    iv.setImageBitmap(getContentResolver().loadThumbnail(u,new android.util.Size(dp(112),dp(112)),null));
                }else{
                    Bitmap b=MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(),imageId,MediaStore.Images.Thumbnails.MINI_KIND,null);
                    iv.setImageBitmap(b);
                }
            }catch(Exception e){
                iv.setImageResource(R.drawable.ic_product);
            }
            return iv;
        }
    }

    @Override public void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==9001 && resultCode==RESULT_OK && data!=null && data.getData()!=null){
            Uri u=data.getData();
            try{
                String saved=copyImageToApp(u);
                if(pendingImageField!=null)pendingImageField.setText(saved);
                Toast.makeText(this,"تم اختيار الصورة",Toast.LENGTH_SHORT).show();
            }catch(Exception e){
                if(pendingImageField!=null)pendingImageField.setText(u.toString());
                Toast.makeText(this,"تم اختيار الصورة",Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==9002){
            if(grantResults.length>0 && grantResults[0]==android.content.pm.PackageManager.PERMISSION_GRANTED){
                showAllImagesGallery();
            }else{
                Toast.makeText(this,"يجب السماح للتطبيق بالوصول إلى الصور لعرض جميع صور الهاتف",Toast.LENGTH_LONG).show();
            }
        }
    }

}
