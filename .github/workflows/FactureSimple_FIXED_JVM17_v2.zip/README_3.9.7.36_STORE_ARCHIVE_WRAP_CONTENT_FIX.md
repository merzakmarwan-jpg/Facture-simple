# MGE 3.9.7.36 — Store Archive + Revenue Layout Fix

## Root cause fixed
Several dynamic Store archive/revenue TextViews and cards were added with `height = 0` (`margin(-1,0,...)`) without a weight. Android therefore measured them at zero height, leaving only a thin horizontal line or clipped text.

## Fix
- Changed the affected dynamic elements to `WRAP_CONTENT` (`-2`).
- Store Archive now displays the archive list, archive number, date/time, invoice count and actions normally.
- Store revenue filter/warning text is no longer clipped.
- Store account details subtitle and other affected multiline text are no longer collapsed.

Version: 3.9.7.36 / versionCode 98.
