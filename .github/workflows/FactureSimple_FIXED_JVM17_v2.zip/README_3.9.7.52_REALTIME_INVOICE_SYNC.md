# MGE 3.9.7.52 — Real-time multi-device invoice synchronization

Based directly on MGE 3.9.7.51.

- Serializes Admin invoice reconciliation so simultaneous phone/tablet sync passes cannot overlap.
- Processes all remote invoices even when one invoice fails; the sync reports failure only after the full pass if any invoice failed.
- Fresh/reinstalled Admin devices independently download the complete cloud invoice set.
- Local invoices missing from Firestore are uploaded automatically.
- Existing dirty local invoices use timestamp-based conflict resolution.
- Keeps each invoice identity on its immutable `cloud_key`; invoice number is not used as document identity.
- Uses the shared Firestore counter for final invoice numbers, preventing two online Admin devices from receiving the same number.
- Admin invoice Firestore listener now triggers invoice-only synchronization for near-real-time phone ↔ tablet updates.
- Remote `adhkar` and `invoice_number_final` are imported correctly.
- GitHub Actions updated to `android-actions/setup-android@v4` with SDK license acceptance.

Important: to guarantee that the phone and tablet never display the same final invoice number, a NEW invoice is not saved unless the shared Firestore counter successfully reserves its final number. Existing invoices remain usable offline, but creating a new invoice requires a working cloud connection. Online phone/tablet creation uses the Firestore transaction counter and cannot allocate the same final number to both devices.
