# MGE 3.9.7.74 — Product/category deletion + multi-category sync fix

Based strictly on 3.9.7.73.

Fixes:
- Product deletion is now synchronized to Firestore. A deleted product is kept as a local tombstone until the cloud deletion succeeds, so the next sync cannot restore it.
- Category deletion updates every affected product locally and uploads those metadata changes to Firestore; deleted categories therefore do not return after sync.
- The bidirectional product reconciler now recognizes deleted-product tombstones even after a successful sync and preserves the deleted state.
- Multi-category selections such as `Category A || Category B` are stored only as a product's category list; they are never inserted as one combined category definition.
- Existing combined category definitions are repaired during database upgrade: individual categories are retained and the combined definition is removed.

No invoice, customer, shipping-account, numbering, or invoice-sync logic was intentionally changed.
