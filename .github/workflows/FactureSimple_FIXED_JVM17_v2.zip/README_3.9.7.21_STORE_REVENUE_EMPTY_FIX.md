# MGE 3.9.7.21 — Store Revenue Empty Screen Fix

## Fix
The Store Revenue page had a zero-height container for its dynamically rendered content. The `holder` was added with height `0dp`, so the filter card, Store account groups, invoice list, totals and PDF selection controls were rendered but not visible.

The container now uses `wrap_content` height (`-2`) so all Store Revenue content is displayed.

## Preserved features
- All-period / 7-day / 14-day filters
- Shipping company filter
- Store account filter
- Bank received / pending filter
- All invoices, including invoices without a Store account (shown under an explicit unspecified group)
- Virement matching and green bank-received status
- Selecting received invoices
- Professional PDF generation and Android/WhatsApp sharing
