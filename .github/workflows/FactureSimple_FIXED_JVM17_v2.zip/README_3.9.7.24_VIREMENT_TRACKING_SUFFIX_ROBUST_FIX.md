# 3.9.7.24 — Robust Virement tracking suffix parsing

Fixes OzonExpress Virement imports where PDFBox returns the shipment suffix separately or in a different column position.

Examples now reconstructed as full tracking codes:
- `BML082631029228` + `GK` → `BML082631029228GK`
- `KNVI082631036347` + `EX` → `KNVI082631036347EX`
- `Tingi082631077860` + `GF` → `Tingi082631077860GF`

The parser no longer depends on the suffix appearing before the two date fields. It identifies the tracking base (letters + digits) and an immediately following short alphabetic suffix, while excluding known route tokens.
