# MGE 3.9.7.73 — Category Delete Root Fix

Based directly on MGE 3.9.7.72.

Only the category-management row layout was corrected.

- The category delete button now has an explicit width (76dp) and height (46dp).
- The previous invisible-layout bug came from assigning the delete button a 5dp width and 0dp height through the generic margin helper.
- Delete remains confirmation-protected.
- Deleting a category removes only that category from products and preserves other categories on the same product.
- No invoice, synchronization, product image, numbering, or other feature was intentionally changed.
