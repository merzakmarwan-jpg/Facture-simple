# MGE 3.4.0 — Offline/Online Bidirectional Sync

## 3.4
- Added local `sync_meta` tracking for products, customers and invoices.
- Admin sync is bidirectional: local and Firebase changes are reconciled using `updatedAt`; the newer side wins.
- Local deletes are represented as tombstones and propagated to Firebase when the local change is newer.
- Remote invoice items are pulled into SQLite without marking them dirty.
- Partner remains cloud-read-only and continues to pull only its partner-scoped customers/invoices.
- Existing Firebase project/package remain unchanged: `facturesimple-1b613`, `com.mge.facturesimple`.

## Sync behavior
- `clean`: local and remote agree.
- `dirty`: local change waiting for sync.
- Conflict: compare local `sync_meta.local_updated_at` with remote `updatedAt`; the newer timestamp wins.
- Offline: local SQLite remains usable; changes are queued as dirty until the next successful sync.


## MGE 3.6.1.0 — Sync Center
- Added a dedicated MGE Cloud sync center in Settings.
- Shows connectivity, pending changes, last sync time, and per-entity status.
- Manual sync is disabled while offline.
- Keeps Admin bidirectional sync and Partner cloud-to-local sync.


## MGE 3.6.0 — Automatic cloud sync
- WorkManager schedules automatic sync every 15 minutes when network is available.
- A one-time sync is queued when the main app starts.
- Admin syncs local SQLite bidirectionally with Firebase; Partner pulls cloud data into local SQLite.
- Sync failures can show a notification when Android notification permission is granted.
- Manual “Sync now” also queues the same background worker.


## MGE 3.7.0 — Professional Home UI
- تم تطبيق تصميم رئيسية احترافي RTL مستوحى من نموذج MGE المعتمد.
- إصلاح اختفاء/قص النصوص تحت بطاقات الفواتير والمنتجات والزبائن والحساب.
- بطاقات الخدمات أصبحت بارتفاع ثابت مناسب مع وصف من سطرين وزر واضح.
- تغيير هوية الصفحة الرئيسية إلى MGE بشكل كامل.
- استخدام شعار MGE نفسه كأيقونة للتطبيق.
- الحفاظ على صلاحيات Admin/Partner والمزامنة وFirebase والوظائف السابقة.
