package com.mge.facturesimple;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.work.Constraints;
import androidx.work.NetworkType;
import androidx.work.WorkerParameters;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Background cloud synchronization. Runs only when the device has a network connection. */
public class CloudSyncWorker extends androidx.work.Worker {
    private static final long TIMEOUT_SECONDS = 8 * 60;

    public CloudSyncWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Store db = new Store(getApplicationContext());
        CloudManager cloud = new CloudManager(getApplicationContext(), db);
        if (!cloud.isLoggedIn()) return Result.success();
        if (!isOnline()) return Result.retry();

        final CountDownLatch latch = new CountDownLatch(1);
        final boolean[] ok = {false};
        final boolean[] ran = {false};
        Runnable done = () -> { ok[0] = true; ran[0] = true; latch.countDown(); };
        Runnable failed = () -> { ran[0] = true; latch.countDown(); };

        try {
            cloud.loadProfileAndRun(() -> {
                if (cloud.isAdmin()) cloud.syncLocalToCloud(done, failed);
                else cloud.syncCloudToLocalForPartner(done, failed);
            }, failed);
            if (!latch.await(TIMEOUT_SECONDS, TimeUnit.SECONDS)) {
                notifyStatus("فشلت المزامنة", "انتهت مهلة المزامنة السحابية.");
                return Result.retry();
            }
        } catch (Exception e) {
            notifyStatus("فشلت المزامنة", "تعذر تنفيذ المزامنة السحابية.");
            return Result.retry();
        }

        if (ok[0]) {
            db.put("cloud_sync_last_status", "success");
            db.put("cloud_sync_last_auto", String.valueOf(System.currentTimeMillis()));
            return Result.success();
        }
        db.put("cloud_sync_last_status", "error");
        String reason = cloud.lastSyncError == null || cloud.lastSyncError.trim().isEmpty()
                ? "تحقق من الإنترنت وصلاحيات Firebase." : cloud.lastSyncError;
        notifyStatus("فشلت المزامنة", reason);
        return Result.retry();
    }

    private boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager)getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        if (Build.VERSION.SDK_INT >= 23) {
            Network n = cm.getActiveNetwork();
            return n != null && cm.getNetworkCapabilities(n) != null;
        }
        android.net.NetworkInfo info = cm.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }

    private void notifyStatus(String title, String body) {
        SyncScheduler.notify(getApplicationContext(), title, body);
    }
}
