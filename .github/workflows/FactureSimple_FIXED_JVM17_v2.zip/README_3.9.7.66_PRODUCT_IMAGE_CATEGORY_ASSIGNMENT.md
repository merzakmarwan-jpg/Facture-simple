# MGE 3.9.7.66

Based on 3.9.7.65 Persistent Product Categories.

Changes:
- Invoice product grid images use FIT_CENTER so the full product image is visible instead of cropped.
- Editing a product and saving restores the previous scroll position in the Products screen.
- Product selection + Manage Categories now applies the chosen saved category to all selected products, including General / no category.
- Category assignment marks affected products dirty for cloud sync.
- Existing invoice grid, persistent categories, local image cache, offline and sync features are preserved.
