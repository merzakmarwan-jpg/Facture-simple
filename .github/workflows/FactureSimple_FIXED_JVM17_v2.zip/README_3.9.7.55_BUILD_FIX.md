# MGE 3.9.7.55 — GitHub Actions Build Fix

- Keeps all invoice bidirectional-sync changes from 3.9.7.54.
- Replaces the failing `android-actions/setup-android@v3` step with a direct use of the Android SDK preinstalled on the GitHub Ubuntu runner.
- Accepts Android SDK licenses without trying to install the obsolete `tools` package.
- Installs only the required `platform-tools`, Android 35 platform, and Build Tools 35.0.0.
- Updates app version to 3.9.7.55 / versionCode 117.
- Fixes the artifact name so the generated APK is clearly labeled 3.9.7.55.
