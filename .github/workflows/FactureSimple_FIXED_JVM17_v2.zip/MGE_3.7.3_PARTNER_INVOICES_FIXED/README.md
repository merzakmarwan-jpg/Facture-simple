# MGE 3.4.0 — Offline/Online Bidirectional Sync

## 3.4
- Added local `sync_meta` tracking for products, customers and invoices.
- Admin sync is bidirectional: local and Firebase changes are reconciled using `updatedAt`; the newer side wins.
- Local deletes are represented as tombstones and propagated to Firebase when the local change is newer.
- Remote invoice items are pulled into SQLite without marking them dirty.
- Partner remains cloud-read-only and continues to pull only its partner-scoped customers/invoices.
- Existing Firebase project/package remain unchanged: `facturesimple-1b613`, `com.mge.facturesimple`.

## Sync behavior
- `clean`: local and remote agree.
- `dirty`: local change waiting for sync.
- Conflict: compare local `sync_meta.local_updated_at` with remote `updatedAt`; the newer timestamp wins.
- Offline: local SQLite remains usable; changes are queued as dirty until the next successful sync.


## MGE 3.6.1.0 — Sync Center
- Added a dedicated MGE Cloud sync center in Settings.
- Shows connectivity, pending changes, last sync time, and per-entity status.
- Manual sync is disabled while offline.
- Keeps Admin bidirectional sync and Partner cloud-to-local sync.


## MGE 3.6.0 — Automatic cloud sync
- WorkManager schedules automatic sync every 15 minutes when network is available.
- A one-time sync is queued when the main app starts.
- Admin syncs local SQLite bidirectionally with Firebase; Partner pulls cloud data into local SQLite.
- Sync failures can show a notification when Android notification permission is granted.
- Manual “Sync now” also queues the same background worker.


## MGE 3.7.1 — Professional Products UI
- تحسين قائمة المنتجات ببطاقات مرنة تمنع قص أسماء المنتجات والأسعار أثناء البحث.
- عرض السعر بشكل واضح داخل كل بطاقة.
- الضغط على صورة المنتج يفتح عارض صور كامل الشاشة مع التكبير باللمس والتحريك.
- تحسين أزرار التعديل والحذف مع تأكيد قبل الحذف.
- الحفاظ على Firebase والمزامنة وصلاحيات Admin/Partner والوظائف السابقة.
- استخدام شعار MGE نفسه كأيقونة للتطبيق.


## MGE 3.7.3 — Partner Invoices
- الشريك يرى جميع الفواتير المرتبطة بـ Partner ID الخاصة به، بما فيها الفواتير التي أنشأها المدير.
- الشريك يستطيع إنشاء فاتورة جديدة من صفحة الفواتير.
- Partner ID للشريك يُفرض تلقائياً ولا يمكن تغييره من واجهة الفاتورة.
- الفواتير الجديدة للشريك تُرفع إلى Firestore أثناء المزامنة.
- إصلاح قراءة حقول paid / reseller / delivery_received / shipping_enabled / partner_profit_paid من Firestore كقيم Boolean.
- قواعد Firestore تسمح للشريك بإنشاء فواتير وعناصر فواتيره فقط، مع منع التعديل والحذف.
- المزامنة لا تعيد رفع فاتورة موجودة مسبقاً في السحابة من جهاز الشريك.


## 3.7.4 — Partner/Customer unified link
- Every partner account created by Admin automatically gets one linked customer/partner record.
- Existing partner accounts are repaired automatically when Partner Management or Customers is opened.
- The link uses Partner ID + Firebase UID and is synchronized to Firestore.
- Renaming/changing Partner ID keeps the linked customer record attached.
- Deleting a partner from either linked admin view removes the Firestore user profile and linked customer record together.
- Partner accounts continue to receive only their own customers in the Customers page.
- Added `partner_uid` and `partner_email` to the local customer schema (DB version 12).
