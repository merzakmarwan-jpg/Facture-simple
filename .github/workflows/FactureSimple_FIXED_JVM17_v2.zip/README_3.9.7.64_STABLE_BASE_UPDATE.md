# MGE 3.9.7.64 — stable 3.9.7.63 base update

This build is based directly on the user's stable `3.9.7.63` project.

Changes only requested:
- Keep product images local and refresh them only with the explicit product-image sync button already present in 3.9.7.63.
- Add customer name, phone, city and address to the product-photo PDF generated from an invoice.
- Keep all invoice information and existing features from 3.9.7.63.
- Reduce invoice-list UI weight by moving sharing / partner-profit-payment / deletion actions into a compact `⋮ خيارات` dialog while keeping the existing `✎ تعديل الفاتورة` button.
- The options dialog preserves PDF invoice sharing, product/customer-photo PDF sharing, partner PDF sharing, partner-profit payment where applicable, and admin invoice deletion.
- Preserve the current invoice sync/realtime system. Manual/periodic invoice refresh now restores the previous scroll position instead of returning to the top.
- No Firebase rules, invoice identity, numbering, local database schema, or sync logic was replaced.
