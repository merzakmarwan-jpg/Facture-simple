# MGE 3.9.7.66

Based on 3.9.7.65.

Fixes:
- Restored the missing `showInvoiceOptionsDialog(Invoice)` method so GitHub Actions can compile the app.
- Restored invoice actions inside `⋮ خيارات`: invoice PDF, product/customer photos PDF, partner PDF when applicable, partner-profit payment when applicable, and admin delete.
- Kept the detailed invoice status fields (assembly, shipping cost/company, Store account, bank receipt, etc.) visible in each invoice card.
- Preserved invoice scroll position when the invoice screen is rebuilt by a refresh/sync callback, unless an edited invoice has an explicit target position.
- Version code 126 / version name 3.9.7.66.
