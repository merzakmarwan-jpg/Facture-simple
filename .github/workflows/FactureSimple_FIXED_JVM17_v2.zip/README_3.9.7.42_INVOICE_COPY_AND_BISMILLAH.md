# MGE 3.9.7.42 — Invoice customer-data copy + Bismillah in customer PDFs

## Changes

### 1. Copy customer shipping data from invoice phone
- In the invoice list, tapping the customer phone copies a ready-to-paste block to the Android clipboard.
- Includes: customer name, phone, address, city, and tracking number.
- For older invoices with missing phone/city/address, the app completes missing values from the linked customer record when available.

### 2. Bismillah on shared customer PDFs
- Adds `بسم الله الرحمن الرحيم` at the top of the invoice PDF.
- Adds the same styled heading to the product-photo PDF.
- The heading is also repeated on continuation pages so every PDF page has the same top treatment.

Version: 3.9.7.42
VersionCode: 104
