# MGE 3.9.7.39 — Virement tracking match fix

Fixes the case where an OzonExpress Virement PDF wraps a tracking suffix onto the next line, for example:

- `Gouna08263107890`
- `0OM`

The parser now reads the short continuation token directly after the tracking token, producing `Gouna082631078900OM` instead of losing the wrapped suffix.

The invoice lookup also compares safe tracking variants, including the stable code when a numeric-leading suffix such as `0OM` is present. This allows an invoice to match whether its stored tracking number contains the full suffix or only the stable tracking part.

Version: 3.9.7.39
VersionCode: 101
