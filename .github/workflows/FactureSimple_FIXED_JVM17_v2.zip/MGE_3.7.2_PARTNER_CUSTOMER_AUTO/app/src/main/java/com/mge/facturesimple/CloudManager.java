package com.mge.facturesimple;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/** Firebase authentication + cloud synchronization layer for FactureSimple 3.0. */
public class CloudManager {
    private final Context context;
    private final Store db;
    private final FirebaseAuth auth;
    private final FirebaseFirestore fs;
    private final FirebaseStorage storage;

    public String role = "partner";
    public long partnerId = 0;
    public String displayName = "";
    public boolean active = true;
    private UserProfile profile;

    public CloudManager(Context c, Store store) {
        context = c.getApplicationContext();
        db = store;
        auth = FirebaseAuth.getInstance();
        fs = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();
    }

    public boolean isLoggedIn() { return auth.getCurrentUser() != null; }
    public String uid() { return isLoggedIn() ? auth.getCurrentUser().getUid() : null; }
    public String email() { return isLoggedIn() ? auth.getCurrentUser().getEmail() : null; }
    public boolean isAdmin() { return "admin".equalsIgnoreCase(role); }

    public Task<AuthResult> login(String email, String password) {
        return auth.signInWithEmailAndPassword(email.trim(), password);
    }

    public Task<AuthResult> registerPartner(String email, String password) {
        return auth.createUserWithEmailAndPassword(email.trim(), password);
    }

    public void logout() { auth.signOut(); }

    public Task<QuerySnapshot> listPartners() {
        if (!isAdmin()) throw new IllegalStateException("Admin only");
        return fs.collection("users").whereEqualTo("role", "partner").get();
    }

    /**
     * Creates a Firebase Authentication account without signing out the current admin.
     * A secondary FirebaseApp/Auth instance is used only for account creation, then deleted.
     */
    public Task<DocumentSnapshot> createPartnerAccount(String name, String emailAddress, String password, long newPartnerId) {
        if (!isAdmin()) throw new IllegalStateException("Admin only");
        if (TextUtils.isEmpty(emailAddress) || TextUtils.isEmpty(password))
            throw new IllegalArgumentException("Email and password are required");
        if (password.length() < 6) throw new IllegalArgumentException("Password must be at least 6 characters");
        if (newPartnerId < 1) throw new IllegalArgumentException("Partner ID must be greater than 0");

        String secondaryName = "partner_auth_" + System.currentTimeMillis();
        FirebaseApp secondary = FirebaseApp.initializeApp(context, FirebaseApp.getInstance().getOptions(), secondaryName);
        if (secondary == null) throw new IllegalStateException("Unable to initialize secondary Firebase app");
        FirebaseAuth secondaryAuth = FirebaseAuth.getInstance(secondary);

        return fs.collection("users").whereEqualTo("partnerId", newPartnerId).limit(1).get().continueWithTask(check -> {
            if (!check.isSuccessful()) throw check.getException();
            if (check.getResult() != null && !check.getResult().isEmpty())
                throw new IllegalStateException("Partner ID already exists");
            return secondaryAuth.createUserWithEmailAndPassword(emailAddress.trim(), password);
        }).continueWithTask(created -> {
            if (!created.isSuccessful()) throw created.getException();
            String newUid = created.getResult().getUser().getUid();
            Map<String,Object> m = new HashMap<>();
            m.put("uid", newUid);
            m.put("name", name == null ? "" : name.trim());
            m.put("email", emailAddress.trim());
            m.put("role", "partner");
            m.put("partnerId", newPartnerId);
            m.put("active", true);
            long now = System.currentTimeMillis();
            m.put("createdAt", now);
            m.put("updatedAt", now);
            return fs.collection("users").document(newUid).set(m).continueWithTask(saved -> {
                if (!saved.isSuccessful()) {
                    try { secondaryAuth.getCurrentUser().delete(); } catch (Exception ignored) {}
                    throw saved.getException();
                }
                return fs.collection("users").document(newUid).get();
            });
        }).addOnCompleteListener(t -> {
            try { secondary.delete(); } catch (Exception ignored) {}
        });
    }

    public Task<Void> updatePartnerProfile(String partnerUid, String name, long newPartnerId, boolean enabled) {
        if (!isAdmin()) throw new IllegalStateException("Admin only");
        if (partnerUid == null || partnerUid.trim().isEmpty()) throw new IllegalArgumentException("Missing UID");
        if (newPartnerId < 1) throw new IllegalArgumentException("Partner ID must be greater than 0");
        Map<String,Object> m = new HashMap<>();
        m.put("name", name == null ? "" : name.trim());
        m.put("partnerId", newPartnerId);
        m.put("active", enabled);
        m.put("updatedAt", System.currentTimeMillis());
        return fs.collection("users").whereEqualTo("partnerId", newPartnerId).get().continueWithTask(t -> {
            if (!t.isSuccessful()) throw t.getException();
            for (DocumentSnapshot d : t.getResult().getDocuments()) {
                if (!partnerUid.equals(d.getId())) throw new IllegalStateException("Partner ID already exists");
            }
            return fs.collection("users").document(partnerUid).set(m, SetOptions.merge());
        });
    }

    public Task<Void> sendPartnerPasswordReset(String emailAddress) {
        if (!isAdmin()) throw new IllegalStateException("Admin only");
        return auth.sendPasswordResetEmail(emailAddress.trim());
    }

    /**
     * Saves the authenticated user's profile in users/{uid}.
     * This is the canonical user document used by the application.
     */
    public Task<Void> saveProfile(String name, String role, long partnerId) {
        String id = uid();
        if (id == null) throw new IllegalStateException("No authenticated Firebase user");

        long now = System.currentTimeMillis();
        Map<String,Object> m = new HashMap<>();
        m.put("uid", id);
        m.put("name", name == null ? "" : name.trim());
        m.put("role", role == null ? "partner" : role.trim().toLowerCase());
        m.put("partnerId", partnerId);
        m.put("email", email() == null ? "" : email());
        m.put("active", true);
        m.put("updatedAt", now);

        // Keep createdAt when the profile already exists.
        return fs.collection("users").document(id).get().continueWithTask(t -> {
            if (t.isSuccessful() && t.getResult() != null && t.getResult().exists()) {
                return fs.collection("users").document(id).set(m, SetOptions.merge());
            }
            m.put("createdAt", now);
            return fs.collection("users").document(id).set(m);
        });
    }

    /** Reads the canonical users/{uid} document. */
    public Task<DocumentSnapshot> loadProfile() {
        String id = uid();
        if (id == null) throw new IllegalStateException("No authenticated Firebase user");
        return fs.collection("users").document(id).get();
    }

    public UserProfile getProfile() { return profile; }

    /** Loads users/{uid} and applies its role/partnerId to the current session. */
    public void loadProfileAndRun(Runnable done, Runnable failed) {
        if (!isLoggedIn()) { if (failed != null) failed.run(); return; }
        loadProfile().addOnSuccessListener(doc -> {
            if (!doc.exists()) { if (failed != null) failed.run(); return; }

            UserProfile p = new UserProfile();
            p.uid = uid();
            p.email = doc.getString("email") == null ? email() : doc.getString("email");
            p.name = doc.getString("name") == null ? "" : doc.getString("name");
            p.role = doc.getString("role") == null ? "partner" : doc.getString("role");
            Long partner = doc.getLong("partnerId");
            p.partnerId = partner == null ? 0 : partner;
            Boolean enabled = doc.getBoolean("active");
            p.active = enabled == null || enabled;
            Long created = doc.getLong("createdAt"); p.createdAt = created == null ? 0 : created;
            Long updated = doc.getLong("updatedAt"); p.updatedAt = updated == null ? 0 : updated;

            if (!p.active) { if (failed != null) failed.run(); return; }
            if (!p.isAdmin() && !p.isPartner()) { if (failed != null) failed.run(); return; }

            profile = p;
            role = p.role;
            partnerId = p.partnerId;
            displayName = p.name;
            active = p.active;
            if (done != null) done.run();
        }).addOnFailureListener(e -> { if (failed != null) failed.run(); });
    }

    /**
     * Phase 3.4: true Admin bidirectional synchronization.
     * Local changes are tracked in Store.sync_meta. For each entity, the newer
     * side wins using millisecond updatedAt timestamps. Dirty local deletions
     * are represented by tombstones in sync_meta so they can also be propagated.
     */
    public void syncLocalToCloud(final Runnable done, final Runnable failed) {
        if (!isLoggedIn() || !isAdmin()) { if (failed != null) failed.run(); return; }
        syncBidirectionalAdmin(done, failed);
    }

    public void syncBidirectionalAdmin(final Runnable done, final Runnable failed) {
        if (!isLoggedIn() || !isAdmin()) { if (failed != null) failed.run(); return; }
        syncProductsBidirectional(() ->
            syncCustomersBidirectional(() ->
                syncInvoicesBidirectional(done, failed), failed), failed);
    }

    private void syncProductsBidirectional(final Runnable done, final Runnable failed) {
        fs.collection("products").get().addOnSuccessListener(remote -> {
            java.util.HashMap<Integer,DocumentSnapshot> remoteMap=new java.util.HashMap<>();
            for(DocumentSnapshot d:remote.getDocuments()) remoteMap.put(parseInt(d.getId()),d);
            android.database.Cursor c=db.getReadableDatabase().query("sync_meta",null,"entity=?",new String[]{"products"},null,null,null);
            java.util.ArrayList<Integer> ids=new java.util.ArrayList<>();
            try{while(c.moveToNext())ids.add(c.getInt(c.getColumnIndexOrThrow("local_id")));}finally{c.close();}
            // Include local rows that predate sync_meta (for databases upgraded in-place).
            android.database.Cursor pc=db.getReadableDatabase().query("products",new String[]{"id"},null,null,null,null,null);
            try{while(pc.moveToNext())if(!ids.contains(pc.getInt(0)))ids.add(pc.getInt(0));}finally{pc.close();}
            java.util.ArrayList<Task<Void>> tasks=new java.util.ArrayList<>();
            for(Integer id:ids){
                final int localId=id; final DocumentSnapshot r=remoteMap.get(id); final boolean tomb="dirty".equals(db.syncState("products",id)) && !localProductExists(id);
                long localTs=db.syncLocalUpdatedAt("products",id); long remoteTs=remoteTimestamp(r);
                if(tomb){
                    if(r==null || localTs>=remoteTs) tasks.add(fs.collection("products").document(String.valueOf(id)).delete().continueWith(t->{db.markSyncClean("products",id,localTs);return null;}));
                    else tasks.add(applyRemoteProduct(r));
                } else if(r==null || localTs>=remoteTs){ tasks.add(pushLocalProduct(localId)); }
                else tasks.add(applyRemoteProduct(r));
            }
            if(tasks.isEmpty()){if(done!=null)done.run();return;}
            com.google.android.gms.tasks.Tasks.whenAll(tasks).addOnSuccessListener(v->{if(done!=null)done.run();}).addOnFailureListener(e->{if(failed!=null)failed.run();});
        }).addOnFailureListener(e->{if(failed!=null)failed.run();});
    }

    private boolean localProductExists(int id){ Cursor c=db.getReadableDatabase().query("products",new String[]{"id"},"id=?",new String[]{String.valueOf(id)},null,null,null);try{return c.moveToFirst();}finally{c.close();} }
    private Task<Void> pushLocalProduct(int id){
        Store.Product p=db.product(id); if(p==null)return com.google.android.gms.tasks.Tasks.forResult(null);
        final long ts=Math.max(System.currentTimeMillis(),db.syncLocalUpdatedAt("products",id));
        return uploadProductImageTask(p).continueWithTask(t->{ if(!t.isSuccessful())throw t.getException(); Map<String,Object> m=new HashMap<>();m.put("name",p.name);m.put("code",p.code);m.put("price",p.price);m.put("imageUrl",t.getResult()==null?"":t.getResult());m.put("updatedAt",ts);m.put("updatedBy",uid());return fs.collection("products").document(String.valueOf(id)).set(m,SetOptions.merge()); }).continueWith(t->{if(!t.isSuccessful())throw t.getException();db.markSyncClean("products",id,ts);return null;});
    }
    private Task<String> uploadProductImageTask(Store.Product p){
        if(TextUtils.isEmpty(p.image))return com.google.android.gms.tasks.Tasks.forResult("");
        if(p.image.startsWith("http://")||p.image.startsWith("https://"))return com.google.android.gms.tasks.Tasks.forResult(p.image);
        try{Uri uri=p.image.startsWith("content://")||p.image.startsWith("file://")?Uri.parse(p.image):Uri.fromFile(new File(p.image));StorageReference ref=storage.getReference().child("products/"+p.id+"/main.jpg");return ref.putFile(uri).continueWithTask(t->{if(!t.isSuccessful())throw t.getException();return ref.getDownloadUrl();}).continueWith(t->{if(!t.isSuccessful())throw t.getException();return t.getResult().toString();});}catch(Exception e){return com.google.android.gms.tasks.Tasks.forException(e);}
    }
    private Task<Void> applyRemoteProduct(DocumentSnapshot d){
        if(d==null)return com.google.android.gms.tasks.Tasks.forResult(null); int id=parseInt(d.getId());ContentValues v=new ContentValues();v.put("id",id);v.put("name",str(d.getString("name")));v.put("code",str(d.getString("code")));Double price=d.getDouble("price");v.put("price",price==null?0:price);v.put("image",str(d.getString("imageUrl")));db.getWritableDatabase().insertWithOnConflict("products",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);db.markSyncClean("products",id,remoteTimestamp(d));return com.google.android.gms.tasks.Tasks.forResult(null);
    }

    private void syncCustomersBidirectional(final Runnable done, final Runnable failed) {
        fs.collection("customers").get().addOnSuccessListener(remote->{
            java.util.HashMap<Integer,DocumentSnapshot> map=new java.util.HashMap<>();for(DocumentSnapshot d:remote.getDocuments())map.put(parseInt(d.getId()),d);
            java.util.ArrayList<Integer> ids=new java.util.ArrayList<>();CursorCompat cc=new CursorCompat(db.getReadableDatabase().query("sync_meta",null,"entity=?",new String[]{"customers"},null,null,null));try{while(cc.moveToNext())ids.add(cc.id());}finally{cc.close();}
            android.database.Cursor lc=db.getReadableDatabase().query("customers",new String[]{"id"},null,null,null,null,null);try{while(lc.moveToNext())if(!ids.contains(lc.getInt(0)))ids.add(lc.getInt(0));}finally{lc.close();}
            java.util.ArrayList<Task<Void>> tasks=new java.util.ArrayList<>();
            for(Integer id:ids){DocumentSnapshot r=map.get(id);long lt=db.syncLocalUpdatedAt("customers",id),rt=remoteTimestamp(r);boolean tomb="dirty".equals(db.syncState("customers",id))&&!localCustomerExists(id);
                if(tomb){if(r==null||lt>=rt)tasks.add(fs.collection("customers").document(String.valueOf(id)).delete().continueWith(t->{db.markSyncClean("customers",id,lt);return null;}));else tasks.add(applyRemoteCustomer(r));}
                else if(r==null||lt>=rt)tasks.add(pushLocalCustomer(id)); else tasks.add(applyRemoteCustomer(r));}
            if(tasks.isEmpty()){if(done!=null)done.run();return;}com.google.android.gms.tasks.Tasks.whenAll(tasks).addOnSuccessListener(v->{if(done!=null)done.run();}).addOnFailureListener(e->{if(failed!=null)failed.run();});
        }).addOnFailureListener(e->{if(failed!=null)failed.run();});
    }
    private boolean localCustomerExists(int id){Cursor c=db.getReadableDatabase().query("customers",new String[]{"id"},"id=?",new String[]{String.valueOf(id)},null,null,null);try{return c.moveToFirst();}finally{c.close();}}
    private Task<Void> pushLocalCustomer(int id){
        Store.Customer x=db.customer(id);if(x==null)return com.google.android.gms.tasks.Tasks.forResult(null);long ts=Math.max(System.currentTimeMillis(),db.syncLocalUpdatedAt("customers",id));Map<String,Object>m=new HashMap<>();m.put("name",x.name);m.put("phone",x.phone);m.put("city",x.city);m.put("address",x.address);m.put("reseller",x.reseller);m.put("partnerId",x.partnerId);m.put("defaultShipping",x.defaultShipping);m.put("accountUid",x.accountUid==null?"":x.accountUid);m.put("updatedAt",ts);m.put("updatedBy",uid());return fs.collection("customers").document(String.valueOf(id)).set(m,SetOptions.merge()).continueWith(t->{if(!t.isSuccessful())throw t.getException();db.markSyncClean("customers",id,ts);return null;});
    }
    private Task<Void> applyRemoteCustomer(DocumentSnapshot d){int id=parseInt(d.getId());ContentValues v=new ContentValues();v.put("id",id);v.put("name",str(d.getString("name")));v.put("phone",str(d.getString("phone")));v.put("city",str(d.getString("city")));v.put("address",str(d.getString("address")));v.put("reseller",Boolean.TRUE.equals(d.getBoolean("reseller"))?1:0);Long pi=d.getLong("partnerId");v.put("partner_id",pi==null?0:pi);Double sh=d.getDouble("defaultShipping");v.put("default_shipping",sh==null?30:sh);v.put("account_uid",str(d.getString("accountUid")));db.getWritableDatabase().insertWithOnConflict("customers",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);db.markSyncClean("customers",id,remoteTimestamp(d));return com.google.android.gms.tasks.Tasks.forResult(null);}

    private void syncInvoicesBidirectional(final Runnable done, final Runnable failed) {
        fs.collection("invoices").get().addOnSuccessListener(remote->{
            java.util.HashMap<Integer,DocumentSnapshot> map=new java.util.HashMap<>();for(DocumentSnapshot d:remote.getDocuments())map.put(parseInt(d.getId()),d);
            java.util.ArrayList<Integer> ids=new java.util.ArrayList<>();android.database.Cursor mc=db.getReadableDatabase().query("sync_meta",null,"entity=?",new String[]{"invoices"},null,null,null);try{while(mc.moveToNext())ids.add(mc.getInt(mc.getColumnIndexOrThrow("local_id")));}finally{mc.close();}
            android.database.Cursor lc=db.getReadableDatabase().query("invoices",new String[]{"id"},null,null,null,null,null);try{while(lc.moveToNext())if(!ids.contains(lc.getInt(0)))ids.add(lc.getInt(0));}finally{lc.close();}
            java.util.ArrayList<Task<Void>> tasks=new java.util.ArrayList<>();
            for(Integer id:ids){DocumentSnapshot r=map.get(id);long lt=db.syncLocalUpdatedAt("invoices",id),rt=remoteTimestamp(r);boolean tomb="dirty".equals(db.syncState("invoices",id))&&!localInvoiceExists(id);
                if(tomb){if(r==null||lt>=rt)tasks.add(fs.collection("invoices").document(String.valueOf(id)).delete().continueWith(t->{db.markSyncClean("invoices",id,lt);return null;}));else tasks.add(applyRemoteInvoice(r));}
                else if(r==null||lt>=rt)tasks.add(pushLocalInvoice(id)); else tasks.add(applyRemoteInvoice(r));}
            if(tasks.isEmpty()){if(done!=null)done.run();return;}com.google.android.gms.tasks.Tasks.whenAll(tasks).addOnSuccessListener(v->{if(done!=null)done.run();}).addOnFailureListener(e->{if(failed!=null)failed.run();});
        }).addOnFailureListener(e->{if(failed!=null)failed.run();});
    }
    private boolean localInvoiceExists(int id){Cursor c=db.getReadableDatabase().query("invoices",new String[]{"id"},"id=?",new String[]{String.valueOf(id)},null,null,null);try{return c.moveToFirst();}finally{c.close();}}
    private Task<Void> pushLocalInvoice(int id){
        Store.Invoice x=db.invoice(id);if(x==null)return com.google.android.gms.tasks.Tasks.forResult(null);long ts=Math.max(System.currentTimeMillis(),db.syncLocalUpdatedAt("invoices",id));Map<String,Object>m=new HashMap<>();m.put("client_id",x.clientId);m.put("client",x.client);m.put("date",x.date);m.put("paid",x.paid);m.put("reseller",x.reseller);m.put("delivery_received",x.deliveryReceived);m.put("tracking_number",x.trackingNumber);m.put("commission",x.commission);m.put("partner_id",x.partnerId);m.put("shipping_enabled",x.shippingEnabled);m.put("shipping_charge",x.shippingCharge);m.put("shipping_cost",x.shippingCost);m.put("partner_profit_paid",x.partnerProfitPaid);m.put("paid_date",x.paidDate);m.put("delivery_received_date",x.deliveryReceivedDate);m.put("delivery_failure_reason",x.deliveryFailureReason);m.put("partner_profit_paid_date",x.partnerProfitPaidDate);m.put("shipping_company",x.shippingCompany);m.put("shipping_account",x.shippingAccount);m.put("updatedAt",ts);m.put("updatedBy",uid());
        return fs.collection("invoices").document(String.valueOf(id)).set(m,SetOptions.merge()).continueWithTask(t->{if(!t.isSuccessful())throw t.getException();return uploadInvoiceItems(id);}).continueWith(t->{if(!t.isSuccessful())throw t.getException();db.markSyncClean("invoices",id,ts);return null;});
    }
    private Task<Void> applyRemoteInvoice(DocumentSnapshot d){
        int id=parseInt(d.getId());ContentValues v=new ContentValues();v.put("id",id);putS(v,"client_id",d.getLong("client_id"));putS(v,"client",d.getString("client"));putS(v,"date",d.getString("date"));putB(v,"paid",d.getBoolean("paid"));putB(v,"reseller",d.getBoolean("reseller"));putB(v,"delivery_received",d.getBoolean("delivery_received"));putS(v,"tracking_number",d.getString("tracking_number"));putD(v,"commission",d.getDouble("commission"));putS(v,"partner_id",d.getLong("partner_id"));putB(v,"shipping_enabled",d.getBoolean("shipping_enabled"));putD(v,"shipping_charge",d.getDouble("shipping_charge"));putD(v,"shipping_cost",d.getDouble("shipping_cost"));putB(v,"partner_profit_paid",d.getBoolean("partner_profit_paid"));putS(v,"paid_date",d.getString("paid_date"));putS(v,"delivery_received_date",d.getString("delivery_received_date"));putS(v,"delivery_failure_reason",d.getString("delivery_failure_reason"));putS(v,"partner_profit_paid_date",d.getString("partner_profit_paid_date"));putS(v,"shipping_company",d.getString("shipping_company"));putS(v,"shipping_account",d.getString("shipping_account"));db.getWritableDatabase().insertWithOnConflict("invoices",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);db.markSyncClean("invoices",id,remoteTimestamp(d));return fs.collection("invoices").document(String.valueOf(id)).collection("items").get().continueWith(t->{if(!t.isSuccessful())throw t.getException();android.database.sqlite.SQLiteDatabase local=db.getWritableDatabase();local.delete("invoice_items","invoice_id=?",new String[]{String.valueOf(id)});for(DocumentSnapshot it:t.getResult().getDocuments()){ContentValues x=new ContentValues();x.put("id",parseInt(it.getId()));x.put("invoice_id",id);x.put("product_id",it.getLong("productId")==null?0:it.getLong("productId"));x.put("name",str(it.getString("name")));Double p=it.getDouble("price"),sp=it.getDouble("salePrice");Long q=it.getLong("qty");x.put("price",p==null?0:p);x.put("sale_price",sp==null?0:sp);x.put("qty",q==null?0:q);local.insertWithOnConflict("invoice_items",null,x,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);}return null;});
    }

    private long remoteTimestamp(DocumentSnapshot d){if(d==null||!d.exists())return 0;Long x=d.getLong("updatedAt");return x==null?0:x;}
    private static class CursorCompat { private final android.database.Cursor c; CursorCompat(android.database.Cursor x){c=x;} boolean moveToNext(){return c.moveToNext();} int id(){return c.getInt(c.getColumnIndexOrThrow("local_id"));} void close(){c.close();} }

    /**
     * Phase 3.2: synchronize the local product catalog and its main images.
     * Firestore keeps product metadata + imageUrl; Firebase Storage keeps the
     * binary image at products/{id}/main.jpg. The local database is never
     * replaced by a remote URL on the Admin device.
     */
    public void syncProductsToCloud(final Runnable done, final Runnable failed) {
        if (!isLoggedIn() || !isAdmin()) { if (failed != null) failed.run(); return; }
        syncProducts(done, failed);
    }

    private void syncProducts(Runnable done, Runnable failed) {
        android.database.Cursor c = db.getReadableDatabase().query("products", null, null, null, null, null, "id ASC");
        java.util.ArrayList<Store.Product> products = new java.util.ArrayList<>();
        try {
            while (c.moveToNext()) {
                int id=c.getInt(c.getColumnIndexOrThrow("id"));
                String name=c.getString(c.getColumnIndexOrThrow("name"));
                String code=c.getString(c.getColumnIndexOrThrow("code"));
                double price=c.getDouble(c.getColumnIndexOrThrow("price"));
                String image=c.getString(c.getColumnIndexOrThrow("image"));
                products.add(new Store.Product(id,name,code,price,image));
            }
        } finally { c.close(); }

        if (products.isEmpty()) { if (done != null) done.run(); return; }
        final int[] remaining={products.size()};
        final boolean[] failedOnce={false};
        for (Store.Product product: products) {
            uploadOrReuseProductImage(product, imageUrl -> {
                Map<String,Object> m=new HashMap<>();
                m.put("name", product.name);
                m.put("code", product.code);
                m.put("price", product.price);
                m.put("imageUrl", imageUrl == null ? "" : imageUrl);
                m.put("updatedAt", System.currentTimeMillis());
                m.put("updatedBy", uid());
                fs.collection("products").document(String.valueOf(product.id)).set(m, SetOptions.merge())
                    .addOnSuccessListener(v -> {
                        if (--remaining[0]==0 && !failedOnce[0] && done!=null) done.run();
                    })
                    .addOnFailureListener(e -> {
                        if (!failedOnce[0]) { failedOnce[0]=true; if(failed!=null)failed.run(); }
                    });
            }, e -> {
                if (!failedOnce[0]) { failedOnce[0]=true; if(failed!=null)failed.run(); }
            });
        }
    }

    private interface ImageUrlCallback { void onResult(String url); }
    private interface ErrorCallback { void onError(Exception e); }

    private void uploadOrReuseProductImage(Store.Product product, ImageUrlCallback ok, ErrorCallback bad) {
        String image=product.image;
        if (TextUtils.isEmpty(image)) { ok.onResult(""); return; }
        if (image.startsWith("http://") || image.startsWith("https://")) {
            ok.onResult(image); return;
        }
        try {
            Uri uri = image.startsWith("content://") || image.startsWith("file://")
                    ? Uri.parse(image) : Uri.fromFile(new File(image));
            StorageReference ref = storage.getReference().child("products/"+product.id+"/main.jpg");
            ref.putFile(uri)
                .continueWithTask(t -> {
                    if (!t.isSuccessful()) throw t.getException();
                    return ref.getDownloadUrl();
                })
                .addOnSuccessListener(url -> ok.onResult(url.toString()))
                .addOnFailureListener(e -> bad.onError(e));
        } catch (Exception e) { bad.onError(e); }
    }

    /** Pushes one local customer row without running the full synchronization. */
    public Task<Void> syncCustomerToCloud(int customerId) {
        if (!isLoggedIn() || !isAdmin()) return com.google.android.gms.tasks.Tasks.forException(new IllegalStateException("Admin only"));
        return pushLocalCustomer(customerId);
    }

    /** Upload all local customers. Admin-only because partners must never write customer data. */
    private void syncCustomersToCloud(final Runnable done, final Runnable failed) {
        android.database.Cursor c=db.getReadableDatabase().query("customers",null,null,null,null,null,"id ASC");
        java.util.ArrayList<Map<String,Object>> docs=new java.util.ArrayList<>();
        try {
            while(c.moveToNext()) {
                int id=c.getInt(c.getColumnIndexOrThrow("id"));
                Map<String,Object> m=new HashMap<>();
                m.put("name",c.getString(c.getColumnIndexOrThrow("name")));
                m.put("phone",c.getString(c.getColumnIndexOrThrow("phone")));
                m.put("city",c.getString(c.getColumnIndexOrThrow("city")));
                m.put("address",c.getString(c.getColumnIndexOrThrow("address")));
                m.put("reseller",c.getInt(c.getColumnIndexOrThrow("reseller"))==1);
                m.put("partnerId",c.getInt(c.getColumnIndexOrThrow("partner_id")));
                m.put("defaultShipping",c.getDouble(c.getColumnIndexOrThrow("default_shipping")));
                m.put("accountUid",c.getString(c.getColumnIndexOrThrow("account_uid")));
                m.put("updatedAt",System.currentTimeMillis());
                m.put("updatedBy",uid());
                Map<String,Object> row=new HashMap<>(); row.put("id",id); row.put("data",m); docs.add(row);
            }
        } finally { c.close(); }
        if(docs.isEmpty()){ if(done!=null)done.run(); return; }
        final int[] remaining={docs.size()}; final boolean[] failedOnce={false};
        for(Map<String,Object> row:docs){
            int id=((Number)row.get("id")).intValue();
            fs.collection("customers").document(String.valueOf(id)).set((Map<String,Object>)row.get("data"),SetOptions.merge())
                .addOnSuccessListener(v->{if(--remaining[0]==0&&!failedOnce[0]&&done!=null)done.run();})
                .addOnFailureListener(e->{if(!failedOnce[0]){failedOnce[0]=true;if(failed!=null)failed.run();}});
        }
    }

    /** Upload all local invoices and wait for every invoice's item subcollection. */
    private void syncInvoicesToCloud(final Runnable done, final Runnable failed){
        android.database.Cursor c=db.getReadableDatabase().query("invoices",null,null,null,null,null,"id ASC");
        java.util.ArrayList<Integer> ids=new java.util.ArrayList<>();
        java.util.HashMap<Integer,Map<String,Object>> rows=new java.util.HashMap<>();
        String[] cols={"client_id","client","date","paid","reseller","delivery_received","tracking_number","commission","partner_id","shipping_enabled","shipping_charge","shipping_cost","partner_profit_paid","paid_date","delivery_received_date","delivery_failure_reason","partner_profit_paid_date","shipping_company","shipping_account"};
        try{
            while(c.moveToNext()){
                int id=c.getInt(c.getColumnIndexOrThrow("id")); ids.add(id); Map<String,Object> m=new HashMap<>();
                for(String col:cols){int idx=c.getColumnIndex(col);if(idx<0)continue;Object val;if(c.isNull(idx))val=null;else if(col.equals("client")||col.contains("date")||col.equals("tracking_number")||col.equals("delivery_failure_reason")||col.equals("shipping_company")||col.equals("shipping_account"))val=c.getString(idx);else if(col.equals("commission")||col.equals("shipping_charge")||col.equals("shipping_cost"))val=c.getDouble(idx);else val=c.getInt(idx);m.put(col,val);} 
                m.put("updatedAt",System.currentTimeMillis()); m.put("updatedBy",uid()); rows.put(id,m);
            }
        }finally{c.close();}
        if(ids.isEmpty()){if(done!=null)done.run();return;}
        final int[] remaining={ids.size()}; final boolean[] failedOnce={false};
        for(Integer invoiceId:ids){
            fs.collection("invoices").document(String.valueOf(invoiceId)).set(rows.get(invoiceId),SetOptions.merge())
                .continueWithTask(t->{if(!t.isSuccessful())throw t.getException();return uploadInvoiceItems(invoiceId);})
                .addOnSuccessListener(v->{if(--remaining[0]==0&&!failedOnce[0]&&done!=null)done.run();})
                .addOnFailureListener(e->{if(!failedOnce[0]){failedOnce[0]=true;if(failed!=null)failed.run();}});
        }
    }

    private Task<Void> uploadInvoiceItems(int invoiceId){
        android.database.Cursor c=db.getReadableDatabase().query("invoice_items",null,"invoice_id=?",new String[]{String.valueOf(invoiceId)},null,null,"id ASC");
        java.util.ArrayList<com.google.android.gms.tasks.Task<Void>> tasks=new java.util.ArrayList<>();
        try{while(c.moveToNext()){
            int itemId=c.getInt(c.getColumnIndexOrThrow("id")); Map<String,Object> m=new HashMap<>();
            m.put("productId",c.getInt(c.getColumnIndexOrThrow("product_id")));
            m.put("name",c.getString(c.getColumnIndexOrThrow("name")));
            m.put("price",c.getDouble(c.getColumnIndexOrThrow("price")));
            m.put("salePrice",c.getDouble(c.getColumnIndexOrThrow("sale_price")));
            m.put("qty",c.getInt(c.getColumnIndexOrThrow("qty")));
            tasks.add(fs.collection("invoices").document(String.valueOf(invoiceId)).collection("items").document(String.valueOf(itemId)).set(m,SetOptions.merge()));
        }}finally{c.close();}
        if(tasks.isEmpty()) return com.google.android.gms.tasks.Tasks.forResult(null);
        return com.google.android.gms.tasks.Tasks.whenAll(tasks);
    }

    /** Pull the cloud catalog and the current partner's customers/invoices into local SQLite. */
    public void syncCloudToLocalForPartner(final Runnable done, final Runnable failed) {
        if (!isLoggedIn() || isAdmin() || partnerId <= 0) { if (failed != null) failed.run(); return; }
        syncProductsFromCloud(() -> syncCustomersFromCloud(() -> syncInvoicesFromCloud(done, failed), failed), failed);
    }

    private void syncProductsFromCloud(final Runnable done, final Runnable failed){
        fs.collection("products").get().addOnSuccessListener(products -> {
            java.util.List<com.google.firebase.firestore.DocumentSnapshot> docs=products.getDocuments();
            if(docs.isEmpty()){if(done!=null)done.run();return;}
            android.database.sqlite.SQLiteDatabase local=db.getWritableDatabase();
            for(com.google.firebase.firestore.DocumentSnapshot d:docs){
                ContentValues v=new ContentValues(); int pid=parseInt(d.getId()); v.put("id",pid); v.put("name",str(d.getString("name"))); v.put("code",str(d.getString("code"))); Double price=d.getDouble("price");v.put("price",price==null?0:price);String imageUrl=d.getString("imageUrl");v.put("image",str(imageUrl));local.insertWithOnConflict("products",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);
            }
            if(done!=null)done.run();
        }).addOnFailureListener(e->{if(failed!=null)failed.run();});
    }

    private void syncCustomersFromCloud(final Runnable done, final Runnable failed){
        fs.collection("customers").whereEqualTo("partnerId",partnerId).get().addOnSuccessListener(customers->{
            android.database.sqlite.SQLiteDatabase local=db.getWritableDatabase();
            for(com.google.firebase.firestore.DocumentSnapshot d:customers.getDocuments()){
                ContentValues v=new ContentValues();v.put("id",parseInt(d.getId()));v.put("name",str(d.getString("name")));v.put("phone",str(d.getString("phone")));v.put("city",str(d.getString("city")));v.put("address",str(d.getString("address")));v.put("reseller",Boolean.TRUE.equals(d.getBoolean("reseller"))?1:0);v.put("partner_id",partnerId);Double sh=d.getDouble("defaultShipping");v.put("default_shipping",sh==null?30:sh);local.insertWithOnConflict("customers",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);
            }
            if(done!=null)done.run();
        }).addOnFailureListener(e->{if(failed!=null)failed.run();});
    }

    private void syncInvoicesFromCloud(final Runnable done, final Runnable failed){
        fs.collection("invoices").whereEqualTo("partner_id",partnerId).get().addOnSuccessListener(invoices->{
            java.util.List<com.google.firebase.firestore.DocumentSnapshot> docs=invoices.getDocuments();
            if(docs.isEmpty()){if(done!=null)done.run();return;}
            final int[] remaining={docs.size()}; final boolean[] failedOnce={false};
            android.database.sqlite.SQLiteDatabase local=db.getWritableDatabase();
            for(com.google.firebase.firestore.DocumentSnapshot d:docs){
                ContentValues v=new ContentValues();v.put("id",parseInt(d.getId()));putS(v,"client_id",d.getLong("client_id"));putS(v,"client",d.getString("client"));putS(v,"date",d.getString("date"));putB(v,"paid",d.getLong("paid"));putB(v,"reseller",d.getLong("reseller"));putB(v,"delivery_received",d.getLong("delivery_received"));putS(v,"tracking_number",d.getString("tracking_number"));putD(v,"commission",d.getDouble("commission"));putS(v,"partner_id",d.getLong("partner_id"));putB(v,"shipping_enabled",d.getLong("shipping_enabled"));putD(v,"shipping_charge",d.getDouble("shipping_charge"));putD(v,"shipping_cost",d.getDouble("shipping_cost"));putB(v,"partner_profit_paid",d.getLong("partner_profit_paid"));putS(v,"paid_date",d.getString("paid_date"));putS(v,"delivery_received_date",d.getString("delivery_received_date"));putS(v,"delivery_failure_reason",d.getString("delivery_failure_reason"));putS(v,"partner_profit_paid_date",d.getString("partner_profit_paid_date"));putS(v,"shipping_company",d.getString("shipping_company"));putS(v,"shipping_account",d.getString("shipping_account"));local.insertWithOnConflict("invoices",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);
                final int invoiceId=parseInt(d.getId());
                d.getReference().collection("items").get().addOnSuccessListener(items->{
                    local.delete("invoice_items","invoice_id=?",new String[]{String.valueOf(invoiceId)});
                    for(com.google.firebase.firestore.DocumentSnapshot it:items.getDocuments()){ContentValues x=new ContentValues();x.put("id",parseInt(it.getId()));x.put("invoice_id",invoiceId);putS(x,"product_id",it.getLong("productId"));putS(x,"name",it.getString("name"));putD(x,"price",it.getDouble("price"));putD(x,"sale_price",it.getDouble("salePrice"));putS(x,"qty",it.getLong("qty"));local.insertWithOnConflict("invoice_items",null,x,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);}
                    if(--remaining[0]==0&&!failedOnce[0]&&done!=null)done.run();
                }).addOnFailureListener(e->{if(!failedOnce[0]){failedOnce[0]=true;if(failed!=null)failed.run();}});
            }
        }).addOnFailureListener(e->{if(failed!=null)failed.run();});
    }

    private int parseInt(String s){try{return Integer.parseInt(s);}catch(Exception e){return 0;}}
    private String str(String s){return s==null?"":s;}
    private void putS(ContentValues v,String k,Object o){if(o==null)v.putNull(k);else if(o instanceof Number)v.put(k,((Number)o).longValue());else v.put(k,String.valueOf(o));}
    private void putD(ContentValues v,String k,Double o){if(o==null)v.put(k,0d);else v.put(k,o);}
    private void putB(ContentValues v,String k,Long o){v.put(k,o!=null&&o!=0?1:0);}
    private void putB(ContentValues v,String k,Boolean o){v.put(k,Boolean.TRUE.equals(o)?1:0);}

}
