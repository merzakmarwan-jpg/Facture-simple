# MGE 3.9.7.34 — Store Account Toolbar Height Fix

Fixes the remaining Store account invoice toolbar visibility issue.

## Root cause
The Store accounting toolbar was given an exact parent height of 4dp through `margin(-1, dp(4), ...)`. Its blue outline therefore appeared as a thin horizontal line while its controls were clipped.

## Fix
The toolbar now uses `WRAP_CONTENT` height while retaining its internal fixed-height rows, so the following controls are visible:
- Select received invoices
- Clear selection
- PDF selected + WhatsApp
- Store accounting archive
- Selected invoice counter

Version: 3.9.7.34 / versionCode 96.
