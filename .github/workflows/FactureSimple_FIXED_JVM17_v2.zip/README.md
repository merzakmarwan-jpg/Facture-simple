FactureSimple 2.9.6

# FactureSimple 3.0 Cloud PRO

نسخة محسنة من تطبيق FactureSimple مع الحفاظ على التصميم الأخير.

## الإضافات في 2.9
- تسوية أرباح الشريك دفعة واحدة: اختيار عدة طلبات مستلمة بعلامة ✓ وحساب الإجمالي تلقائياً.
- تسجيل تاريخ دفع أرباح الشريك.
- تسجيل تاريخ استلام الطلبية.
- أسباب عدم الاستلام: هاتف خاطئ، غير مهتم، عنوان خاطئ، منتوج خاطئ، رفض الدفع، لم يتوصل، إرجاع، سبب آخر.
- PDF لأرباح الشريك يتضمن اسم الزبون، الهاتف، المدينة، العنوان، الربح، وتكاليف الشحن.
- PDF مستقل للطلبات غير المستلمة مع رقم التتبع وسبب عدم الاستلام.
- حفظ PDF داخل Downloads/FactureSimple مع فتح قائمة المشاركة لإرساله عبر WhatsApp أو أي تطبيق.
- اختيار الصور من معرض الهاتف ونسخها إلى ذاكرة التطبيق حتى لا تختفي بعد تغيير مصدر الصورة.
- إصلاح قص بطاقات أرباح الشركاء والفواتير باستخدام ارتفاع تلقائي.
- تاريخ دفع الفاتورة يظهر عند الضغط على حالة «مدفوعة».
- يظهر الشريك في الفاتورة وPDF عندما تكون الفاتورة تابعة لشريك.
- الشحن لا يضاف عند اختيار استلام الزبون من المتجر.

## البناء
GitHub Actions يستخدم JDK 17 وGradle 8.9 وAndroid SDK 35.


## الإصدار 2.9.1 — إصلاح Build
- إصلاح خطأ Java في `Store.java`: استبدال `ContentValues.put(..., null)` بـ `putNull(...)` لتجنب تعارض overload.
- تحسين اختيار صور المنتجات باستخدام Android Storage Access Framework (`ACTION_OPEN_DOCUMENT`) لعرض مصادر الصور بشكل أوسع على الهاتف، مع نسخ الصورة داخل التطبيق.
- رفع رقم الإصدار إلى 2.9.1.


## الإصدار 2.9.2 — تحديث حسابات الزبائن والشحن ومعرض الصور
- إخفاء خيارات التوصيل والشحن بالكامل في الفاتورة بشكل افتراضي.
- لا تظهر خيارات الشحن والتتبع والاستلام وسبب عدم الاستلام إلا بعد تفعيل «هذه الفاتورة سيتم شحنها».
- فواتير زبائن المتجر يمكن أن تبقى غير مدفوعة حتى نهاية الشهر بدون إضافة الشحن.
- عند البحث عن اسم الزبون في صفحة الفواتير يظهر كشف الفواتير غير المدفوعة مع إمكانية تحديد عدة فواتير.
- حساب مجموع الفواتير المحددة تلقائياً وتسديدها دفعة واحدة.
- تسجيل تاريخ دفع مستقل لكل فاتورة عند التسديد الجماعي.
- إنشاء معرض صور داخلي يعرض جميع صور الهاتف من MediaStore بدلاً من الاعتماد على نافذة Documents/Drive، مع طلب صلاحية الصور ونسخ الصورة إلى ذاكرة التطبيق.
- رفع الإصدار إلى 2.9.2.


## 2.9.12 — OCR product title
- When selecting a product image, the app automatically runs on-device OCR and proposes a product name from visible text.
- Added a manual "Read title from image" action.
- The proposed title remains editable before saving.
- OCR uses Google ML Kit Text Recognition (Latin script).

## FactureSimple 3.0 Cloud
- Firebase project: `facturesimple-1b613`.
- Firebase Authentication is used for account login.
- Cloud Firestore stores users, products, customers, invoices and invoice items.
- Firebase Storage stores product images under `products/{productId}/`.
- Admin accounts have full access; partner accounts are restricted to their partnerId.
- Partner UI hides administration, shipping-company/account management and edit/delete controls; tracking and delivery status are read-only.
- `firestore.rules` and `storage.rules` are included in the project.
- The local SQLite database remains available for offline/cache and Export/Import backup.

### First Firebase setup
1. Enable Authentication > Email/Password.
2. Create the first admin account in Authentication.
3. Create its `users/{uid}` Firestore document with `role: "admin"`, `partnerId: 0`, and a name.
4. Create partner user accounts with `role: "partner"` and the matching `partnerId`.
5. Deploy the included Firestore and Storage rules.


## 3.0 Cloud Beta v4 — Login UI fix
- Login screen converted to a ScrollView so the note is never clipped on smaller screens.
- Login and partner-registration controls use fixed 58dp rows with centered text and proper padding.
- No default admin email/password is embedded in the application. The administrator account must be created in Firebase Authentication and assigned role `admin` in Firestore.
