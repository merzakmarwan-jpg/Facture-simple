# FactureSimple 2.1 — corrected build

Cette version corrige l'erreur Kotlin de compilation dans les fenêtres « Factures » et « Produits » : la variable de dialogue est maintenant déclarée avant son utilisation dans les listeners.

Fonctions incluses :
- sauvegarde et modification des factures
- liste des factures enregistrées
- statut payée / non payée
- gestion des produits
- recherche automatique du produit pendant la saisie
- affichage de l'image du produit dans les suggestions et la facture
- logo de l'entreprise
- téléphone de l'entreprise
- PDF avec logo, téléphone et statut de paiement

## GitHub Actions
Le workflow peut utiliser JDK 17 et Gradle 8.9 comme dans la configuration qui a déjà réussi l'environnement de build.

Le projet Android est à la racine de cette archive (`settings.gradle.kts`, `build.gradle.kts`, `app/`).
