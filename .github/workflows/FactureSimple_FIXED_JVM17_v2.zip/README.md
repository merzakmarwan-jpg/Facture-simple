# MGE 3.9.1 — Virement PDF + Store Accounting

- Added PDF Virement import from the Store Revenue page.
- Reads Virement code/date, CRBT, shipping fees and net totals from structured OzonExpress PDFs.
- Matches each `Code d'envoi` to the invoice `tracking_number` automatically.
- Replaces the invoice's estimated shipping cost with the actual `Frais` from the Virement after a review/confirmation step.
- Adds independent Store-company accounting status; it is not related to user/commission partners and requires no Store partner login.
- Invoice status uses the exact Store wording, e.g. `تمت المحاسبة مع حساب Store Karamatech`.
- Selected unaccounted invoices can be exported as a multi-page accounting PDF. After successful export, the invoices are permanently marked as accounted for that Store with date and export ID, preventing accidental re-accounting.
- Bank receipt remains a separate status: `تم الاستلام من شركة الشحن إلى البنك` with the receipt date.
- Store revenue now uses actual shipping cost when imported from Virement.
- Home quick cards have more vertical space and wrapped descriptions to prevent text clipping on small phones.
- Database version increased to 25; existing invoices are preserved during upgrade.

# MGE 3.8.21 — Partner Invoice Sync + Store Revenue

- Partner invoice synchronization now pulls the authoritative `invoices` query from Firestore using `partner_id` and `Source.SERVER` after login.
- Partner sync no longer attempts cloud invoice deletion; a denied optional write cannot prevent existing invoices from appearing on a fresh phone.
- Admin Store-revenue reports refresh invoices through the timestamp-aware Admin reconciliation before calculating results.
- Store revenue is grouped by shipping company + Store account and shows gross customer collection, actual shipping deduction, net amount due to bank, amount received by bank, and remaining amount.
- Revenue reports no longer discard partner invoices when an Admin has assigned a Store account to them.
- The Store-revenue page now shows a diagnostic message when invoices have no Store account instead of appearing empty.
- Home-page quick cards were given enough height and wrapped description text so the labels under invoices/products/customers/settings are fully visible on smaller screens.
- `bank_received` and `bank_received_date` remain synchronized through the existing Admin cloud sync.

# MGE 3.8.7 — Invoice Cloud Identity Fix

This revision separates the internal SQLite invoice ID from the human invoice number and gives every invoice an immutable unique cloud key. This prevents Admin invoice #1 and Partner invoice #1 (or #2) from overwriting each other in Firestore. Existing invoice data is preserved locally during database upgrade; previously overwritten cloud documents cannot be reconstructed by the code if the original document was already replaced.

Key changes:
- `invoices.invoice_number` keeps the visible invoice number.
- `invoices.cloud_key` is a UUID-based immutable Firestore document ID.
- Invoice realtime/bidirectional sync resolves records by cloud key, not by local SQLite ID.
- Remote invoice items are inserted with local auto-increment IDs to avoid item-ID collisions between invoices.
- Partner/admin invoice creation can therefore use the same visible number without overwriting another account's invoice.

Build with GitHub Actions or Android Gradle tooling.

# MGE 3.4.0 — Offline/Online Bidirectional Sync

## 3.4
- Added local `sync_meta` tracking for products, customers and invoices.
- Admin sync is bidirectional: local and Firebase changes are reconciled using `updatedAt`; the newer side wins.
- Local deletes are represented as tombstones and propagated to Firebase when the local change is newer.
- Remote invoice items are pulled into SQLite without marking them dirty.
- Partner remains cloud-read-only and continues to pull only its partner-scoped customers/invoices.
- Existing Firebase project/package remain unchanged: `facturesimple-1b613`, `com.mge.facturesimple`.

## Sync behavior
- `clean`: local and remote agree.
- `dirty`: local change waiting for sync.
- Conflict: compare local `sync_meta.local_updated_at` with remote `updatedAt`; the newer timestamp wins.
- Offline: local SQLite remains usable; changes are queued as dirty until the next successful sync.


## MGE 3.6.1.0 — Sync Center
- Added a dedicated MGE Cloud sync center in Settings.
- Shows connectivity, pending changes, last sync time, and per-entity status.
- Manual sync is disabled while offline.
- Keeps Admin bidirectional sync and Partner cloud-to-local sync.


## MGE 3.6.0 — Automatic cloud sync
- WorkManager schedules automatic sync every 15 minutes when network is available.
- A one-time sync is queued when the main app starts.
- Admin syncs local SQLite bidirectionally with Firebase; Partner pulls cloud data into local SQLite.
- Sync failures can show a notification when Android notification permission is granted.
- Manual “Sync now” also queues the same background worker.


## MGE 3.7.1 — Professional Products UI
- تحسين قائمة المنتجات ببطاقات مرنة تمنع قص أسماء المنتجات والأسعار أثناء البحث.
- عرض السعر بشكل واضح داخل كل بطاقة.
- الضغط على صورة المنتج يفتح عارض صور كامل الشاشة مع التكبير باللمس والتحريك.
- تحسين أزرار التعديل والحذف مع تأكيد قبل الحذف.
- الحفاظ على Firebase والمزامنة وصلاحيات Admin/Partner والوظائف السابقة.
- استخدام شعار MGE نفسه كأيقونة للتطبيق.


## MGE 3.7.3 — Partner Invoices
- الشريك يرى جميع الفواتير المرتبطة بـ Partner ID الخاصة به، بما فيها الفواتير التي أنشأها المدير.
- الشريك يستطيع إنشاء فاتورة جديدة من صفحة الفواتير.
- Partner ID للشريك يُفرض تلقائياً ولا يمكن تغييره من واجهة الفاتورة.
- الفواتير الجديدة للشريك تُرفع إلى Firestore أثناء المزامنة.
- إصلاح قراءة حقول paid / reseller / delivery_received / shipping_enabled / partner_profit_paid من Firestore كقيم Boolean.
- قواعد Firestore تسمح للشريك بإنشاء فواتير وعناصر فواتيره فقط، مع منع التعديل والحذف.
- المزامنة لا تعيد رفع فاتورة موجودة مسبقاً في السحابة من جهاز الشريك.


## 3.7.5 — Partner/Customer unified link
- Every partner account created by Admin automatically gets one linked customer/partner record.
- Existing partner accounts are repaired automatically when Partner Management or Customers is opened.
- The link uses Partner ID + Firebase UID and is synchronized to Firestore.
- Renaming/changing Partner ID keeps the linked customer record attached.
- Deleting a partner from either linked admin view removes the Firestore user profile and linked customer record together.
- Partner accounts continue to receive only their own customers in the Customers page.
- Added `partner_uid` and `partner_email` to the local customer schema (DB version 12).

## MGE 3.7.5 — Partner workflow
- إخفاء حساب Store عن الشريك وإظهار شركة الشحن فقط مع إمكانية اختيارها.
- الشريك لا يستطيع إضافة أو إدارة شركات/حسابات الشحن.
- الشريك يستطيع تعديل فاتوراته قبل شحنها: إضافة منتج، حذف منتج، تعديل الكمية والسعر.
- عند تحديد الأدمن أن الطلبية تم شحنها، تصبح الفاتورة مقفلة للشريك.
- مزامنة تعديلات الفواتير الموجودة مسبقاً إلى Firestore، بما فيها حذف عناصر الفاتورة من السحابة.
- الشريك يستطيع إضافة وتعديل وحذف زبائنه من صفحة «زبائني»، مع ربطها تلقائياً بـ Partner ID.
- مزامنة ثنائية الاتجاه لزبائن الشريك.
- مزامنة أسماء شركات الشحن من حساب الأدمن إلى حسابات الشركاء، بدون تنزيل حسابات Store.

## MGE 3.7.7 — Shared partner/customer synchronization
- Added invoice snapshot fields: customer phone, city, address and customer type (`registered` / `normal`).
- Selecting a permanent customer fills the four customer fields automatically.
- A normal customer can be entered directly without adding a permanent customer record.
- Invoice PDF uses the customer snapshot and falls back to the linked customer record for older invoices.
- Partner shipping UI exposes the shipping company only; Store account, tracking and actual shipping cost remain admin-only.
- Partner invoice creation/update rules allow the partner workflow without exposing or modifying admin shipping-account data.
- Partner customer updates are limited to name, phone, city and address plus sync metadata.
- Sync failure reporting now records the underlying Firebase exception instead of only showing a generic failure.
- Local database version 16 adds a stable `cloud_id` for customers and a `cloud_key` for deletion tombstones without deleting existing data.
- Admin and Partner now use the same Firestore customer records: a customer added by the Partner appears in Admin, and a customer assigned by Admin appears in the Partner account.
- Customer records use stable cloud IDs to avoid local SQLite ID collisions between devices.
- Opening the Customers page triggers the appropriate cloud synchronization automatically.
- Partner customer changes are synchronized bidirectionally while preserving the Partner ID ownership rules.

### Important Firebase step
The included `firestore.rules` must be deployed to the same Firebase project before testing cloud synchronization. The Android source cannot change Firestore Security Rules by itself.

## 3.7.8 — إصلاحات إضافية
- حذف الشريك: البحث عن الحساب حسب Partner ID، حذف سجل الشريك المرتبط، ثم حذف/تعطيل الحساب عند الحاجة.
- الفاتورة: خانة سعر واحدة فقط لكل منتج، سواء أنشئت الفاتورة عبر الشريك أو عبر زبون/الأدمن.
- المزامنة: تجديد Firebase ID Token قبل المزامنة، مع عدم إيقاف مزامنة المنتجات والعملاء والفواتير بسبب فشل غير أساسي في شركات الشحن.
- يجب نشر ملف `firestore.rules` الموجود في جذر المشروع إلى مشروع Firebase نفسه؛ قواعد Firestore مطبقة على الخادم ولا يستطيع التطبيق تجاوزها.


## MGE 3.8.0 Professional Cloud
- Firestore is the central cloud database for products, customers and invoices.
- Partner synchronization is scoped by Partner ID and Firebase Authentication UID.
- Product images are uploaded to Firebase Storage and cached locally on partner devices.
- Backup export/import is a ZIP containing the SQLite database and `product_images/`.
- Product title is entered manually; image selection no longer runs OCR or changes the title.
- Publish `firestore.rules` and `storage.rules` to the exact project in `app/google-services.json` (`facturesimple-1b613`).
- Firebase Authentication Email/Password must be enabled for partner accounts.


## MGE 3.8.6 — Separate invoice and product-photo PDFs
- Invoice PDF is now completely separate from product photos to keep the invoice file small.
- Invoice PDF supports unlimited pages and continues all invoice lines automatically.
- Product photos have a separate `PDF الصور` export.
- The photo PDF contains the product image, product title and ordered quantity only.
- Photo PDF also supports multiple pages automatically.
- Invoice PDF can be shared immediately with the customer/partner; photo PDF can be sent only when requested.


## 3.8.6 cloud image restore
- Firebase Firestore/Storage is the primary source for product metadata and images after reinstall.
- Admin product sync now merges remote product IDs into a fresh local database instead of only iterating local IDs.
- Remote product images are downloaded into the app private storage and the local database stores the new device path.
- Backup restore repairs absolute image paths from the old device before synchronization.
- A missing local backup image does not erase an existing cloud image.
- Backup remains an independent safety copy.


## 3.8.20 — Invoice photo PDF fixes
- إصلاح PDF صور الزبائن ليستخدم صور المنتجات الأصلية التي يعرضها المتجر، مع تحميل الصور المحلية بشكل مباشر داخل PDF.
- إصلاح PDF الشريك ليكون ألبوم صور فقط لصور `customer_image` التي يضعها الشريك، بدون إظهار أرباح أو بيانات مالية.
- عدم استخدام صورة المتجر كبديل داخل PDF الشريك إذا لم يضع الشريك صورة خاصة.
- إصلاح دعم `file://` و`content://` والمسارات المحلية مع إبقاء Glide كحل احتياطي للصور البعيدة.

## 3.8.17 — Partner customer-facing product images & partner prices
- Added `partner_product_settings` for partner-specific product prices and customer-facing images.
- Admin can assign a dedicated price per partner from the Products screen.
- Partner accounts can add/replace their own customer-facing product image without changing the main product image.
- Partner product cards show the partner price and provide direct image sharing.
- Partner invoices automatically use the partner-specific product price when available.
- Customer invoice PDFs no longer expose partner profit; a separate Partner PDF includes partner financial information.
- Partner invoice photo PDFs use the partner customer-facing images and never fall back to the price-bearing main product image.
- Added partner invoice sharing actions and Firebase synchronization for partner product settings/images.
- Backup/restore now preserves partner customer-facing product images.


## 3.9.1
- Fixed Store revenue report showing an empty area when invoices have a missing Store account.
- Such invoices are now shown under a visible fallback group instead of being silently excluded.
- If there are no invoices in the selected period, the report now gives a clear message.
