# FactureSimple 2.1

Application Android simple de gestion des factures.

## Fonctionnalités
- Création, sauvegarde, modification et consultation des factures.
- Gestion des produits avec nom, code, prix et image.
- Recherche automatique des produits lors de la saisie.
- Logo et téléphone de l'entreprise configurables.
- Statut de paiement de chaque facture : payée / non payée.
- Statut conservé lors de la sauvegarde et affiché dans la liste des factures.
- PDF de facture avec logo, téléphone et statut de paiement.
- Données conservées localement sur le téléphone.
