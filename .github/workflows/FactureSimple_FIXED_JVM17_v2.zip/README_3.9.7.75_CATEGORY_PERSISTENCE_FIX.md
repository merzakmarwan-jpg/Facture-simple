# MGE 3.9.7.75 — Category persistence fix

- Product categories are now stored in `product_categories` as the canonical registry.
- Opening/recreating the Products screen no longer rebuilds the registry from `products.category`.
- Reopening the SQLite database no longer automatically recreates deleted categories from product rows.
- Added one-time DB migration (version 40) to normalize legacy combined values such as `A II B` into independent categories `A || B` and mark changed products dirty for the next cloud sync.
- Existing category deletion remains product-safe: deleting one category removes only that category from products while preserving other assigned categories.
- No invoice, invoice numbering, customer, shipping-account, or Firebase invoice synchronization logic was changed.
