# MGE 3.9.7.37 — Store accounting root UI fix

- Fixed the actual root cause of Store accounting/archive controls appearing as thin horizontal lines.
- Added a dedicated `topMargin()` helper so a top margin is no longer accidentally used as a child height.
- Store invoice details now use `WRAP_CONTENT` for multi-line invoice metadata instead of a fixed 72dp height that clipped text.
- Store archive list action rows now use `WRAP_CONTENT` with a real top margin, so `فتح الأرشيف` and `PDF` are fully visible.
- Store archive batch toolbar rows now use `WRAP_CONTENT`, so select/PDF/restore controls are fully visible.
- Back buttons in Store archive screens now have a real 48dp height.
- Empty archive content and archive headers use `WRAP_CONTENT` where appropriate.
- Clears the legacy notification ID 3601 left by older sync versions on app startup. Current background sync failures are not shown as intrusive notifications.
- Version: 3.9.7.37 / versionCode 99.
