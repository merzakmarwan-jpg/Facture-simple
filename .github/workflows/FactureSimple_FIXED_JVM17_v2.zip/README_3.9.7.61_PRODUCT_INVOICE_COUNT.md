# MGE 3.9.7.61 — Product page UI + invoice count

- Fixed the product image helper text to clearly read: `اضغط على الصورة للتكبير`.
- Increased the helper text height and kept it on one line to avoid the clipped/partial text shown in the product cards.
- Added a per-product count of distinct invoices containing that product.
- The count is based on `invoice_items` and counts distinct `invoice_id`, so quantities do not inflate the invoice count.
- Uses one grouped SQLite query for all products on each product-list refresh rather than one query per product.
