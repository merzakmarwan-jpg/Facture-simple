const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { getFirestore } = require("firebase-admin/firestore");

initializeApp();

exports.adminSetPartnerPassword = onCall(async (request) => {
  const caller = request.auth;
  if (!caller) throw new HttpsError("unauthenticated", "يجب تسجيل الدخول كمدير.");

  const db = getFirestore();
  const callerDoc = await db.collection("users").doc(caller.uid).get();
  const callerData = callerDoc.exists ? callerDoc.data() : {};
  if (callerData.role !== "admin" || callerData.active === false) {
    throw new HttpsError("permission-denied", "هذه العملية متاحة للمدير فقط.");
  }

  const partnerUid = String(request.data?.partnerUid || "").trim();
  const newPassword = String(request.data?.newPassword || "");
  if (!partnerUid) throw new HttpsError("invalid-argument", "معرف الشريك غير موجود.");
  if (newPassword.length < 6) throw new HttpsError("invalid-argument", "كلمة المرور يجب أن تكون 6 أحرف على الأقل.");
  if (partnerUid === caller.uid) throw new HttpsError("invalid-argument", "لا تستخدم هذه العملية لتغيير كلمة مرور المدير.");

  const partnerDoc = await db.collection("users").doc(partnerUid).get();
  if (!partnerDoc.exists || partnerDoc.data().role !== "partner") {
    throw new HttpsError("not-found", "حساب الشريك غير موجود.");
  }

  await getAuth().updateUser(partnerUid, { password: newPassword });
  await db.collection("users").doc(partnerUid).set({
    updatedAt: Date.now(),
    passwordChangedByAdminAt: Date.now()
  }, { merge: true });

  return { ok: true };
});
