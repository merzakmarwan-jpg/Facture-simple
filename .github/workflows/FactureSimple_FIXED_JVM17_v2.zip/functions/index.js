const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { getFirestore } = require("firebase-admin/firestore");

initializeApp();

exports.adminSetPartnerPassword = onCall(async (request) => {
  const caller = request.auth;
  if (!caller) throw new HttpsError("unauthenticated", "يجب تسجيل الدخول كمدير.");

  const db = getFirestore();
  const callerDoc = await db.collection("users").doc(caller.uid).get();
  const callerData = callerDoc.exists ? callerDoc.data() : {};
  if (callerData.role !== "admin" || callerData.active === false) {
    throw new HttpsError("permission-denied", "هذه العملية متاحة للمدير فقط.");
  }

  const requestedUid = String(request.data?.partnerUid || "").trim();
  const requestedPartnerId = Number(request.data?.partnerId || 0);
  const newPassword = String(request.data?.newPassword || "");
  if (!requestedUid && requestedPartnerId < 1) throw new HttpsError("invalid-argument", "معرف الشريك غير موجود.");
  if (newPassword.length < 6) throw new HttpsError("invalid-argument", "كلمة المرور يجب أن تكون 6 أحرف على الأقل.");
  if (requestedUid === caller.uid) throw new HttpsError("invalid-argument", "لا تستخدم هذه العملية لتغيير كلمة مرور المدير.");

  // Resolve the canonical Firebase Auth UID robustly. Older app versions may have
  // passed the Firestore document id or Partner ID instead of the Auth UID.
  let partnerUid = requestedUid;
  let partnerDoc = requestedUid ? await db.collection("users").doc(requestedUid).get() : null;
  if (!partnerDoc || !partnerDoc.exists || partnerDoc.data().role !== "partner") {
    partnerDoc = null;
    if (requestedUid) {
      const byUid = await db.collection("users").where("uid", "==", requestedUid).where("role", "==", "partner").limit(1).get();
      if (!byUid.empty) partnerDoc = byUid.docs[0];
    }
    if (!partnerDoc && requestedPartnerId > 0) {
      const byPartnerId = await db.collection("users").where("partnerId", "==", requestedPartnerId).where("role", "==", "partner").limit(1).get();
      if (!byPartnerId.empty) partnerDoc = byPartnerId.docs[0];
    }
  }
  if (!partnerDoc || !partnerDoc.exists || partnerDoc.data().role !== "partner") {
    throw new HttpsError("not-found", "حساب الشريك غير موجود.");
  }

  const data = partnerDoc.data() || {};
  partnerUid = String(data.uid || partnerDoc.id || "").trim();
  if (!partnerUid || partnerUid === caller.uid) throw new HttpsError("invalid-argument", "معرف حساب الشريك غير صالح.");

  try {
    await getAuth().getUser(partnerUid);
  } catch (e) {
    throw new HttpsError("not-found", "حساب الشريك غير موجود في Firebase Authentication.");
  }
  await getAuth().updateUser(partnerUid, { password: newPassword });
  await db.collection("users").doc(partnerDoc.id).set({
    uid: partnerUid,
    updatedAt: Date.now(),
    passwordChangedByAdminAt: Date.now()
  }, { merge: true });

  return { ok: true };
});
