# MGE 3.9.7.78 — Phone Startup / Invoice Performance Root Fix

Base: `MGE_3.9.7.77_SELECTED_IMAGE_SYNC.zip`

## Root cause addressed

The invoices screen previously built **all invoice cards at once on the Android UI thread**.
Each invoice card also loaded its invoice items from SQLite and created many child views.
With a large invoice history this could freeze scrolling and trigger Android's
"Application isn't responding" dialog.

At startup, the Admin account also started a heavy full catalog reconciliation in addition
to invoice synchronization. Firestore task callbacks can run on the main thread, so the
SQLite/catalog work could make the phone appear frozen during startup.

## Changes in 3.9.7.78

1. Invoice list changed to `RecyclerView`.
   - Only visible invoice cards are created.
   - The full invoice history is no longer inflated into one `LinearLayout`.
2. Invoice SQLite loading is moved to a single background executor.
3. Search is debounced by 300 ms.
4. Invoice sync reconciliation is moved to a dedicated background executor.
   - SQLite reads/writes for invoice reconciliation no longer run on the UI thread.
   - Completion callbacks return to the Android main thread before updating the UI.
5. The immediate heavy full catalog sync was removed from Activity startup.
   - WorkManager remains responsible for periodic full reconciliation.
   - Invoice synchronization and realtime invoice updates remain active.
6. The initial Firestore customer snapshot no longer starts a heavyweight full
   reconciliation during startup.
7. Existing invoice identity (`cloud_key`), invoice numbering, offline behavior,
   ordering, and edit-return behavior were not intentionally changed.

## Important

This version is intended to be tested on the **tablet first**. Do not replace or
delete the phone's local invoice database. The phone's existing invoices are not
migrated or overwritten by this change.
