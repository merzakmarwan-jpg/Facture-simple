# MGE 3.9.7.52.3 — Invoice Sync Diagnostic

Based directly on 3.9.7.52.2_SAFE_INVOICE_SYNC.

This build does not change the Firebase data model or delete/migrate cloud data.
It only improves diagnostics for a failed per-invoice synchronization:
- unwraps Firebase Task exceptions to expose the actual Firestore/Auth error code/message;
- shows the exact error in a dialog when “مزامنة هذه الفاتورة” fails;
- versionCode 117 / versionName 3.9.7.52.3.

Purpose: identify the real Firebase failure before making another synchronization change.
