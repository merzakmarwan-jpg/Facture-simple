# MGE 3.9.7.62 — Offline invoice creation + newest-first + edit return position

## Changes
- New invoices are now offline-first.
- With internet, the app reserves the next global Firestore invoice number before saving.
- Without internet, the invoice is saved immediately in SQLite with a provisional local number and `invoice_number_final=0`.
- The invoice keeps its immutable `cloud_key`/UUID. When connectivity returns, CloudManager finalizes the number safely before uploading it. A conflicting provisional number is reassigned without deleting the invoice.
- Existing invoice data is never replaced just because the device is offline.
- Invoice list remains newest-first using `created_at DESC, id DESC`, not invoice-number order.
- Editing an existing invoice preserves its original `created_at` and invoice number.
- After saving an edited invoice, the invoice list returns to the same invoice card instead of jumping to the top. The card is tagged with its local ID so the existing scroll-restoration logic can find it reliably.
- Existing search and invoice filters are preserved.

## Safety
- No Firestore invoice collection is deleted or recreated.
- No local invoices are deleted during offline creation.
- The primary phone can continue to be used normally; test the APK on the tablet first.

## Build
- Version code: 122
- Version name: 3.9.7.62
- Existing GitHub Actions Android SDK v4 workflow retained.
