# MGE 3.9.7.41 — Store accounting navigation fix

## Problem fixed
The Store accounting screens had no visible in-app navigation arrow. From `مداخيل حسابات Store` → `فواتير حساب Store` → `أرشيف Store` → archive batch, the user had to rely on Android system navigation or the page-specific buttons.

## Root-level fix
Added a Store accounting navigation history with **Back** and **Forward** arrows in the top toolbar.

- `←` returns to the exact previous Store accounting screen.
- `→` returns to the next screen after going back.
- The history stores the Store name, archive number, export ID, archive date, and invoice IDs needed to reconstruct the previous details page.
- Android system Back uses the same Store navigation history.
- The arrows are shown only on the Store accounting/revenue/archive screens, so they do not interfere with the rest of the application.
- Returning to an invoice details page reloads the same invoice IDs from the local database instead of relying on a stale in-memory list.

## Version
Version: 3.9.7.41
VersionCode: 103
