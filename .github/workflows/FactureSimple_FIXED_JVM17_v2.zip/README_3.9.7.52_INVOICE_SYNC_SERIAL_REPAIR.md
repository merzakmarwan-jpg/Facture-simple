# MGE 3.9.7.52 — Invoice synchronization serial repair

- Fixes the case where products/customers synchronize but restored invoices remain pending.
- Reconciles local invoices one-by-one instead of launching dozens of invoice writes/global-number transactions concurrently.
- Preserves valid final invoice numbers from backups unless a real cloud number collision exists.
- A single problematic invoice no longer blocks the remaining invoices; it stays dirty for a later retry.
- Waits for Firestore pending writes before reporting successful synchronization.
- VersionCode: 114
- VersionName: 3.9.7.52
