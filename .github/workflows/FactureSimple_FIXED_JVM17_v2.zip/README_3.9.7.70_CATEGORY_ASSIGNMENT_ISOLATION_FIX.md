# MGE 3.9.7.70 — Category assignment isolation fix

- Fixes legacy combined category names such as `Accélérateur II Bison`.
- Multiple categories assigned to one product are stored independently as `A || B` and never become a new global category.
- The global category chips and **إدارة الفئات** show standalone reusable categories only.
- Legacy combined names are normalized once on database upgrade and also guarded on database open.
- Remote product category values are normalized before being stored locally, preventing old combined values from returning after synchronization.
- Existing product, invoice, offline, image, and synchronization features are otherwise unchanged.
