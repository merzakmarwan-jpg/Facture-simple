# MGE 3.9.7.31 — Store Account UI + PDF Archive + Background Sync Fix

- Fixed the Store account invoice page so the PDF/WhatsApp action panel is always displayed above the invoice list.
- Added explicit scrolling for the invoice list so a long list cannot hide the action controls.
- Selected bank-received invoices can be exported to a professional PDF containing customer name, phone, city, tracking and Virement details.
- After the PDF is successfully saved, the selected invoices are marked as Store-accounted and removed from the active accounting list.
- Added a Store accounting archive with invoice metadata and a restore action to return selected invoices to the active accounting list.
- Archived Store-accounted invoices are excluded from the active Store revenue list to prevent duplicate accounting.
- Removed automatic background-sync failure notifications. WorkManager still retries the sync and the detailed status remains available from Settings, so a partial Firebase failure no longer produces the misleading lock-screen “فشلت المزامنة / 1 out of 74 underlying tasks failed” notification.
- Version: 3.9.7.31 / versionCode 93.
