package com.mge.facturesimple;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class Store extends SQLiteOpenHelper {
    private static final String DB_NAME = "facturesimple.db";
    private static final int DB_VERSION = 17;

    public Store(Context c) { super(c, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT)");
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,code TEXT,price REAL,image TEXT)");
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,city TEXT,address TEXT,reseller INTEGER DEFAULT 0,partner_id INTEGER DEFAULT 0,partner_uid TEXT,partner_email TEXT,default_shipping REAL DEFAULT 30,cloud_id TEXT)");
        db.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,client_id INTEGER,client TEXT,date TEXT,paid INTEGER DEFAULT 0,reseller INTEGER DEFAULT 0,delivery_received INTEGER DEFAULT 0,tracking_number TEXT,commission REAL DEFAULT 0,partner_id INTEGER DEFAULT 0,shipping_enabled INTEGER DEFAULT 0,shipping_charge REAL DEFAULT 0,shipping_cost REAL DEFAULT 0,partner_profit_paid INTEGER DEFAULT 0,paid_date TEXT,delivery_received_date TEXT,delivery_failure_reason TEXT,partner_profit_paid_date TEXT,shipping_company TEXT,shipping_account TEXT,shipped_by_admin INTEGER DEFAULT 0,customer_phone TEXT,customer_city TEXT,customer_address TEXT,customer_type TEXT DEFAULT 'normal',invoice_number INTEGER DEFAULT 0,cloud_key TEXT");
        db.execSQL("CREATE TABLE invoice_items(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER,product_id INTEGER,name TEXT,price REAL,qty INTEGER,sale_price REAL)");
        db.execSQL("CREATE TABLE shipping_companies(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE)");
        db.execSQL("CREATE TABLE shipping_accounts(id INTEGER PRIMARY KEY AUTOINCREMENT,company_id INTEGER NOT NULL,name TEXT NOT NULL,UNIQUE(company_id,name))");
        db.execSQL("CREATE TABLE sync_meta(entity TEXT NOT NULL,local_id INTEGER NOT NULL,state TEXT NOT NULL DEFAULT 'dirty',local_updated_at INTEGER NOT NULL,remote_updated_at INTEGER DEFAULT 0,last_synced_at INTEGER DEFAULT 0,deleted INTEGER DEFAULT 0,cloud_key TEXT,PRIMARY KEY(entity,local_id))");
        seedShipping(db,"OzonExpress",new String[]{"Store MGE","Store MGE01","Maroc General Electronic"});
        seedShipping(db,"Tawsil",new String[]{"Store MGE","Store MGE01","Maroc General Electronic"});
        put(db,"company_name","MGE");
        put(db,"phone","+212666964731");
        put(db,"footer","Merci pour votre confiance");
        put(db,"default_shipping","30");
    }

    @Override public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        // تأكد من وجود شركات الشحن والحسابات الافتراضية حتى إذا كانت قاعدة البيانات
        // موجودة مسبقاً على الإصدار 10 ولم يتم تنفيذ seed عند إنشائها.
        ensureShippingData(db);
        try{ db.execSQL("CREATE TABLE IF NOT EXISTS sync_meta(entity TEXT NOT NULL,local_id INTEGER NOT NULL,state TEXT NOT NULL DEFAULT 'dirty',local_updated_at INTEGER NOT NULL,remote_updated_at INTEGER DEFAULT 0,last_synced_at INTEGER DEFAULT 0,deleted INTEGER DEFAULT 0,cloud_key TEXT,PRIMARY KEY(entity,local_id))"); }catch(Exception ignored){}
    }

    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion) {
        if(oldVersion < 2){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN reseller INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE customers ADD COLUMN reseller INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN delivery_received INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN tracking_number TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN commission REAL DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoice_items ADD COLUMN sale_price REAL"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE invoice_items SET sale_price=price WHERE sale_price IS NULL OR sale_price=0"); }catch(Exception ignored){}
        }
        if(oldVersion < 3){
            try{ db.execSQL("ALTER TABLE customers ADD COLUMN partner_id INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE customers ADD COLUMN default_shipping REAL DEFAULT 30"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN partner_id INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN shipping_enabled INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN shipping_charge REAL DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN shipping_cost REAL DEFAULT 0"); }catch(Exception ignored){}
        }
        if(oldVersion < 4){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN partner_profit_paid INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE invoices SET partner_profit_paid=0 WHERE partner_profit_paid IS NULL"); }catch(Exception ignored){}
        }
        if(oldVersion < 5){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN paid_date TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE invoices SET paid_date=date WHERE paid=1 AND (paid_date IS NULL OR paid_date='')"); }catch(Exception ignored){}
        }
        if(oldVersion < 6){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN delivery_received_date TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN delivery_failure_reason TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE invoices SET delivery_received_date=date WHERE delivery_received=1 AND (delivery_received_date IS NULL OR delivery_received_date='')"); }catch(Exception ignored){}
        }
        if(oldVersion < 7){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN partner_profit_paid_date TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE invoices SET partner_profit_paid_date=date WHERE partner_profit_paid=1 AND (partner_profit_paid_date IS NULL OR partner_profit_paid_date='')"); }catch(Exception ignored){}
        }
        if(oldVersion < 9){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN shipping_company TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN shipping_account TEXT"); }catch(Exception ignored){}
        }
        if(oldVersion < 10){
            ensureShippingData(db);
        }
        if(oldVersion < 11){
            try{ db.execSQL("CREATE TABLE IF NOT EXISTS sync_meta(entity TEXT NOT NULL,local_id INTEGER NOT NULL,state TEXT NOT NULL DEFAULT 'dirty',local_updated_at INTEGER NOT NULL,remote_updated_at INTEGER DEFAULT 0,last_synced_at INTEGER DEFAULT 0,deleted INTEGER DEFAULT 0,cloud_key TEXT,PRIMARY KEY(entity,local_id))"); }catch(Exception ignored){}
            markExistingRowsDirty(db, "products");
            markExistingRowsDirty(db, "customers");
            markExistingRowsDirty(db, "invoices");
        }
        if(oldVersion < 12){
            try{ db.execSQL("ALTER TABLE customers ADD COLUMN partner_uid TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE customers ADD COLUMN partner_email TEXT"); }catch(Exception ignored){}
            // Any partner/customer links that already exist by Partner ID are kept.
            // New partner accounts will also receive a canonical linked customer row.
        }
        if(oldVersion < 13){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN shipped_by_admin INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE invoices SET shipped_by_admin=1 WHERE tracking_number IS NOT NULL AND tracking_number<>''"); }catch(Exception ignored){}
        }
        if(oldVersion < 14){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN customer_phone TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN customer_city TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN customer_address TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN customer_type TEXT DEFAULT 'normal'"); }catch(Exception ignored){}
        }
        if(oldVersion < 15){
            try{ db.execSQL("ALTER TABLE customers ADD COLUMN cloud_id TEXT"); }catch(Exception ignored){}
        }
        if(oldVersion < 16){
            try{ db.execSQL("ALTER TABLE sync_meta ADD COLUMN cloud_key TEXT"); }catch(Exception ignored){}
        }
        if(oldVersion < 17){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN invoice_number INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN cloud_key TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE invoices SET invoice_number=id WHERE invoice_number IS NULL OR invoice_number=0"); }catch(Exception ignored){}
        }
        // حتى في قواعد البيانات التي كانت أصلاً على الإصدار 10 أو أحدث،
        // نضمن وجود الجداول والبيانات الافتراضية.
        ensureShippingData(db);
    }

    private void ensureShippingData(SQLiteDatabase db){
        try{ db.execSQL("CREATE TABLE IF NOT EXISTS shipping_companies(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE)"); }catch(Exception ignored){}
        try{ db.execSQL("CREATE TABLE IF NOT EXISTS shipping_accounts(id INTEGER PRIMARY KEY AUTOINCREMENT,company_id INTEGER NOT NULL,name TEXT NOT NULL,UNIQUE(company_id,name))"); }catch(Exception ignored){}
        seedShipping(db,"OzonExpress",new String[]{"Store MGE","Store MGE01","Maroc General Electronic"});
        seedShipping(db,"Tawsil",new String[]{"Store MGE","Store MGE01","Maroc General Electronic"});
    }

    private void seedShipping(SQLiteDatabase db,String company,String[] accounts){
        ContentValues c=new ContentValues();c.put("name",company);long cid=db.insertWithOnConflict("shipping_companies",null,c,SQLiteDatabase.CONFLICT_IGNORE);
        if(cid==-1){Cursor q=db.query("shipping_companies",new String[]{"id"},"name=?",new String[]{company},null,null,null);try{if(q.moveToFirst())cid=q.getLong(0);}finally{q.close();}}
        for(String a:accounts){ContentValues v=new ContentValues();v.put("company_id",cid);v.put("name",a);db.insertWithOnConflict("shipping_accounts",null,v,SQLiteDatabase.CONFLICT_IGNORE);}
    }

    public static class ShippingCompany { public int id; public String name; ShippingCompany(int i,String n){id=i;name=n;} }
    public static class ShippingAccount { public int id,companyId; public String name; ShippingAccount(int i,int c,String n){id=i;companyId=c;name=n;} }

    public ArrayList<ShippingCompany> shippingCompanies(){
        ArrayList<ShippingCompany>a=new ArrayList<>();Cursor c=getReadableDatabase().query("shipping_companies",null,null,null,null,null,"name COLLATE NOCASE ASC");
        try{while(c.moveToNext())a.add(new ShippingCompany(c.getInt(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("name"))));}finally{c.close();}return a;
    }
    public ArrayList<ShippingAccount> shippingAccounts(int companyId){
        ArrayList<ShippingAccount>a=new ArrayList<>();Cursor c=getReadableDatabase().query("shipping_accounts",null,"company_id=?",new String[]{""+companyId},null,null,"name COLLATE NOCASE ASC");
        try{while(c.moveToNext())a.add(new ShippingAccount(c.getInt(c.getColumnIndexOrThrow("id")),c.getInt(c.getColumnIndexOrThrow("company_id")),c.getString(c.getColumnIndexOrThrow("name"))));}finally{c.close();}return a;
    }
    public long addShippingCompany(String name){ContentValues v=new ContentValues();v.put("name",name.trim());return getWritableDatabase().insertWithOnConflict("shipping_companies",null,v,SQLiteDatabase.CONFLICT_IGNORE);}
    public long addShippingAccount(int companyId,String name){ContentValues v=new ContentValues();v.put("company_id",companyId);v.put("name",name.trim());return getWritableDatabase().insertWithOnConflict("shipping_accounts",null,v,SQLiteDatabase.CONFLICT_IGNORE);}
    public boolean updateShippingCompany(int id,String name){ContentValues v=new ContentValues();v.put("name",name.trim());return getWritableDatabase().update("shipping_companies",v,"id=?",new String[]{""+id})>0;}
    public boolean updateShippingAccount(int id,int companyId,String name){ContentValues v=new ContentValues();v.put("company_id",companyId);v.put("name",name.trim());return getWritableDatabase().update("shipping_accounts",v,"id=?",new String[]{""+id})>0;}
    public void deleteShippingAccount(int id){getWritableDatabase().delete("shipping_accounts","id=?",new String[]{""+id});}
    public void deleteShippingCompany(int id){SQLiteDatabase d=getWritableDatabase();d.delete("shipping_accounts","company_id=?",new String[]{""+id});d.delete("shipping_companies","id=?",new String[]{""+id});}

    private void markExistingRowsDirty(SQLiteDatabase db,String table){
        try{ Cursor c=db.query(table,new String[]{"id"},null,null,null,null,null); long now=System.currentTimeMillis(); while(c.moveToNext()){ markSync(db,table,c.getInt(0),now,"dirty",0,false); } c.close(); }catch(Exception ignored){}
    }
    public void markSync(String entity,int localId,long updatedAt,String state,long remoteUpdatedAt,boolean deleted){
        markSync(getWritableDatabase(),entity,localId,updatedAt,state,remoteUpdatedAt,deleted);
    }
    private void markSync(SQLiteDatabase db,String entity,int localId,long updatedAt,String state,long remoteUpdatedAt,boolean deleted){
        ContentValues v=new ContentValues(); v.put("entity",entity); v.put("local_id",localId); v.put("state",state); v.put("local_updated_at",updatedAt); v.put("remote_updated_at",remoteUpdatedAt); v.put("last_synced_at",System.currentTimeMillis()); v.put("deleted",deleted?1:0); db.insertWithOnConflict("sync_meta",null,v,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public long syncLocalUpdatedAt(String entity,int localId){ Cursor c=getReadableDatabase().query("sync_meta",new String[]{"local_updated_at"},"entity=? AND local_id=?",new String[]{entity,String.valueOf(localId)},null,null,null); try{return c.moveToFirst()?c.getLong(0):0;}finally{c.close();} }
    public String syncState(String entity,int localId){ Cursor c=getReadableDatabase().query("sync_meta",new String[]{"state"},"entity=? AND local_id=?",new String[]{entity,String.valueOf(localId)},null,null,null); try{return c.moveToFirst()?c.getString(0):"dirty";}finally{c.close();} }
    public int syncDirtyCount(){ Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM sync_meta WHERE state='dirty'",null); try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();} }
    public int syncDirtyCount(String entity){ Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM sync_meta WHERE entity=? AND state='dirty'",new String[]{entity}); try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();} }
    public long syncLastAt(){ Cursor c=getReadableDatabase().rawQuery("SELECT MAX(last_synced_at) FROM sync_meta WHERE state='clean'",null); try{return c.moveToFirst()?c.getLong(0):0;}finally{c.close();} }
    public int syncTotal(String entity){ Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM sync_meta WHERE entity=?",new String[]{entity}); try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();} }
    public void markSyncClean(String entity,int localId,long remoteUpdatedAt){ markSync(entity,localId,System.currentTimeMillis(),"clean",remoteUpdatedAt,false); }
    public void setSyncCloudKey(String entity,int localId,String cloudKey){ ContentValues v=new ContentValues();v.put("cloud_key",cloudKey);getWritableDatabase().update("sync_meta",v,"entity=? AND local_id=?",new String[]{entity,String.valueOf(localId)}); }
    public void setInvoiceCloudKey(int invoiceId,String cloudKey){ ContentValues v=new ContentValues();v.put("cloud_key",cloudKey);getWritableDatabase().update("invoices",v,"id=?",new String[]{String.valueOf(invoiceId)});setSyncCloudKey("invoices",invoiceId,cloudKey); }
    public String syncCloudKey(String entity,int localId){ Cursor c=getReadableDatabase().query("sync_meta",new String[]{"cloud_key"},"entity=? AND local_id=?",new String[]{entity,String.valueOf(localId)},null,null,null);try{return c.moveToFirst()&&!c.isNull(0)?c.getString(0):"";}finally{c.close();} }
    public void markSyncDeleted(String entity,int localId){ markSync(entity,localId,System.currentTimeMillis(),"dirty",0,true); }

    private void put(SQLiteDatabase db,String k,String v){ ContentValues x=new ContentValues();x.put("k",k);x.put("v",v);db.insertWithOnConflict("settings",null,x,SQLiteDatabase.CONFLICT_REPLACE); }
    public void put(String k,String v){put(getWritableDatabase(),k,v);}
    public String get(String k,String def){Cursor c=getReadableDatabase().query("settings",new String[]{"v"},"k=?",new String[]{k},null,null,null);try{return c.moveToFirst()?c.getString(0):def;}finally{c.close();}}

    public static class Product { public int id;public String name,code,image;public double price; Product(int i,String n,String c,double p,String im){id=i;name=n;code=c;price=p;image=im;} }
    public static class Customer {
        public int id,partnerId;public String name,phone,city,address,partnerUid,partnerEmail,cloudId;public boolean reseller;public double defaultShipping;
        Customer(int i,String n,String p,String c,String a,boolean r,int pi,String pu,String pe,double ds,String ci){id=i;name=n;phone=p;city=c;address=a;reseller=r;partnerId=pi;partnerUid=pu;partnerEmail=pe;defaultShipping=ds;cloudId=ci==null?"":ci;}
    }
    public static class Item { public int productId,qty;public String name;public double price,salePrice;public Item(int pid,String n,double p,int q){productId=pid;name=n;price=p;qty=q;salePrice=p;}public Item(int pid,String n,double p,double sp,int q){productId=pid;name=n;price=p;salePrice=sp;qty=q;} }
    public static class Invoice {
        public int id,clientId,partnerId,invoiceNumber;public String cloudKey;public String client,date,customerPhone,customerCity,customerAddress,customerType,paidDate,trackingNumber,deliveryReceivedDate,deliveryFailureReason,partnerProfitPaidDate,shippingCompany,shippingAccount;public boolean paid,reseller,deliveryReceived,shippingEnabled,partnerProfitPaid,shippedByAdmin;public double commission,shippingCharge,shippingCost;public ArrayList<Item> items=new ArrayList<>();
        Invoice(int i,int ci,String cl,String d,boolean p){id=i;clientId=ci;client=cl;date=d;paid=p;}
    }

    public ArrayList<Product> products(String q){ArrayList<Product>a=new ArrayList<>();q=q==null?"":q.trim();Cursor c=getReadableDatabase().query("products",null,q.isEmpty()?null:"name LIKE ? OR code LIKE ?",q.isEmpty()?null:new String[]{"%"+q+"%","%"+q+"%"},null,null,"name COLLATE NOCASE ASC");try{while(c.moveToNext())a.add(new Product(c.getInt(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("name")),c.getString(c.getColumnIndexOrThrow("code")),c.getDouble(c.getColumnIndexOrThrow("price")),c.getString(c.getColumnIndexOrThrow("image"))));}finally{c.close();}return a;}
    public Product product(int id){Cursor c=getReadableDatabase().query("products",null,"id=?",new String[]{""+id},null,null,null);try{if(!c.moveToFirst())return null;return new Product(c.getInt(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("name")),c.getString(c.getColumnIndexOrThrow("code")),c.getDouble(c.getColumnIndexOrThrow("price")),c.getString(c.getColumnIndexOrThrow("image")));}finally{c.close();}}
    public void saveProduct(int id,String name,String code,double price,String image){ContentValues v=new ContentValues();v.put("name",name);v.put("code",code);v.put("price",price);v.put("image",image);long now=System.currentTimeMillis(); int actualId=id; if(id<0){actualId=(int)getWritableDatabase().insert("products",null,v);}else getWritableDatabase().update("products",v,"id=?",new String[]{""+id}); if(actualId>0)markSync("products",actualId,now,"dirty",0,false);}
    public void deleteProduct(int id){getWritableDatabase().delete("products","id=?",new String[]{""+id}); markSyncDeleted("products",id);}

    private Customer readCustomer(Cursor c){
        String pu="",pe="",ci="";
        int puIdx=c.getColumnIndex("partner_uid"), peIdx=c.getColumnIndex("partner_email"), ciIdx=c.getColumnIndex("cloud_id");
        if(puIdx>=0&&!c.isNull(puIdx))pu=c.getString(puIdx);
        if(peIdx>=0&&!c.isNull(peIdx))pe=c.getString(peIdx);
        if(ciIdx>=0&&!c.isNull(ciIdx))ci=c.getString(ciIdx);
        return new Customer(c.getInt(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("name")),c.getString(c.getColumnIndexOrThrow("phone")),c.getString(c.getColumnIndexOrThrow("city")),c.getString(c.getColumnIndexOrThrow("address")),c.getInt(c.getColumnIndexOrThrow("reseller"))==1,c.getInt(c.getColumnIndexOrThrow("partner_id")),pu,pe,c.getDouble(c.getColumnIndexOrThrow("default_shipping")),ci);
    }
    public ArrayList<Customer> customers(String q){ArrayList<Customer>a=new ArrayList<>();q=q==null?"":q.trim();Cursor c=getReadableDatabase().query("customers",null,q.isEmpty()?null:"name LIKE ? OR phone LIKE ? OR city LIKE ?",q.isEmpty()?null:new String[]{"%"+q+"%","%"+q+"%","%"+q+"%"},null,null,"name COLLATE NOCASE ASC");try{while(c.moveToNext())a.add(readCustomer(c));}finally{c.close();}return a;}
    public ArrayList<Customer> partnerCustomers(int partnerId,String q){ArrayList<Customer>a=new ArrayList<>();q=q==null?"":q.trim();String where="partner_id=? AND reseller=0";ArrayList<String>args=new ArrayList<>();args.add(""+partnerId);if(!q.isEmpty()){where+=" AND (name LIKE ? OR phone LIKE ? OR city LIKE ?)";args.add("%"+q+"%");args.add("%"+q+"%");args.add("%"+q+"%");}Cursor c=getReadableDatabase().query("customers",null,where,args.toArray(new String[0]),null,null,"name COLLATE NOCASE ASC");try{while(c.moveToNext())a.add(readCustomer(c));}finally{c.close();}return a;}
    public Customer customer(int id){Cursor c=getReadableDatabase().query("customers",null,"id=?",new String[]{""+id},null,null,null);try{if(!c.moveToFirst())return null;return readCustomer(c);}finally{c.close();}}
    public Customer customerByCloudId(String cloudId){
        if(cloudId==null||cloudId.trim().isEmpty())return null;
        Cursor c=getReadableDatabase().query("customers",null,"cloud_id=?",new String[]{cloudId},null,null,null);
        try{if(!c.moveToFirst())return null;return readCustomer(c);}finally{c.close();}
    }
    public void setCustomerCloudId(int id,String cloudId){
        ContentValues v=new ContentValues();v.put("cloud_id",cloudId);getWritableDatabase().update("customers",v,"id=?",new String[]{String.valueOf(id)});
    }
    public int saveCustomer(int id,String name,String phone,String city,String address,boolean reseller,int partnerId,double defaultShipping){ContentValues v=new ContentValues();v.put("name",name);v.put("phone",phone);v.put("city",city);v.put("address",address);v.put("reseller",reseller?1:0);v.put("partner_id",reseller?0:partnerId);v.put("default_shipping",reseller?defaultShipping:30);if(!reseller){v.putNull("partner_uid");v.putNull("partner_email");}long now=System.currentTimeMillis(); int actualId=id; if(id<0){actualId=(int)getWritableDatabase().insert("customers",null,v);}else getWritableDatabase().update("customers",v,"id=?",new String[]{""+id}); if(actualId>0)markSync("customers",actualId,now,"dirty",0,false); return actualId;}

    /** Creates or updates the single canonical customer row representing a partner account. */
    public int upsertPartnerCustomer(String uid,long partnerId,String name,String email){
        SQLiteDatabase w=getWritableDatabase();
        Cursor c=w.query("customers",new String[]{"id"},"reseller=1 AND (partner_uid=? OR partner_id=?)",new String[]{uid,String.valueOf(partnerId)},null,null,"id ASC","1");
        int id=-1; try{if(c.moveToFirst())id=c.getInt(0);}finally{c.close();}
        ContentValues v=new ContentValues();v.put("name",name==null?"":name.trim());v.put("phone",email==null?"":email.trim());v.put("city","");v.put("address","");v.put("reseller",1);v.put("partner_id",partnerId);v.put("partner_uid",uid==null?"":uid);v.put("partner_email",email==null?"":email.trim());v.put("default_shipping",30);
        long now=System.currentTimeMillis();
        if(id<0)id=(int)w.insert("customers",null,v);else w.update("customers",v,"id=?",new String[]{String.valueOf(id)});
        if(id>0)markSync("customers",id,now,"dirty",0,false);
        return id;
    }

    public int linkedPartnerCustomer(long partnerId,String uid){
        Cursor c=getReadableDatabase().query("customers",new String[]{"id"},"reseller=1 AND (partner_id=? OR partner_uid=?)",new String[]{String.valueOf(partnerId),uid==null?"":uid},null,null,"id ASC","1");
        try{return c.moveToFirst()?c.getInt(0):-1;}finally{c.close();}
    }
    public void deleteCustomer(int id){
        String cloudKey=""; Cursor c=getReadableDatabase().query("customers",new String[]{"cloud_id"},"id=?",new String[]{String.valueOf(id)},null,null,null);
        try{if(c.moveToFirst()&&!c.isNull(0))cloudKey=c.getString(0);}finally{c.close();}
        getWritableDatabase().delete("customers","id=?",new String[]{""+id}); markSyncDeleted("customers",id); if(!cloudKey.isEmpty())setSyncCloudKey("customers",id,cloudKey);
    }

    private Invoice readInvoice(Cursor c){Invoice i=new Invoice(c.getInt(c.getColumnIndexOrThrow("id")),c.getInt(c.getColumnIndexOrThrow("client_id")),c.getString(c.getColumnIndexOrThrow("client")),c.getString(c.getColumnIndexOrThrow("date")),c.getInt(c.getColumnIndexOrThrow("paid"))==1);int in=c.getColumnIndex("invoice_number");if(in>=0)i.invoiceNumber=c.getInt(in);int ck=c.getColumnIndex("cloud_key");if(ck>=0&&!c.isNull(ck))i.cloudKey=c.getString(ck);i.customerPhone=c.getString(c.getColumnIndexOrThrow("customer_phone"));i.customerCity=c.getString(c.getColumnIndexOrThrow("customer_city"));i.customerAddress=c.getString(c.getColumnIndexOrThrow("customer_address"));i.customerType=c.getString(c.getColumnIndexOrThrow("customer_type"));i.reseller=c.getInt(c.getColumnIndexOrThrow("reseller"))==1;i.deliveryReceived=c.getInt(c.getColumnIndexOrThrow("delivery_received"))==1;i.paidDate=c.getString(c.getColumnIndexOrThrow("paid_date"));i.trackingNumber=c.getString(c.getColumnIndexOrThrow("tracking_number"));i.deliveryReceivedDate=c.getString(c.getColumnIndexOrThrow("delivery_received_date"));i.deliveryFailureReason=c.getString(c.getColumnIndexOrThrow("delivery_failure_reason"));i.partnerProfitPaidDate=c.getString(c.getColumnIndexOrThrow("partner_profit_paid_date"));i.shippingCompany=c.getString(c.getColumnIndexOrThrow("shipping_company"));i.shippingAccount=c.getString(c.getColumnIndexOrThrow("shipping_account"));i.commission=c.getDouble(c.getColumnIndexOrThrow("commission"));i.partnerId=c.getInt(c.getColumnIndexOrThrow("partner_id"));i.shippingEnabled=c.getInt(c.getColumnIndexOrThrow("shipping_enabled"))==1;i.shippingCharge=c.getDouble(c.getColumnIndexOrThrow("shipping_charge"));i.shippingCost=c.getDouble(c.getColumnIndexOrThrow("shipping_cost"));i.partnerProfitPaid=c.getInt(c.getColumnIndexOrThrow("partner_profit_paid"))==1;i.shippedByAdmin=c.getInt(c.getColumnIndexOrThrow("shipped_by_admin"))==1;loadItems(i);return i;}
    public ArrayList<Invoice> invoices(String q){ArrayList<Invoice>a=new ArrayList<>();q=q==null?"":q.trim();Cursor c=getReadableDatabase().query("invoices",null,q.isEmpty()?null:"CAST(invoice_number AS TEXT) LIKE ? OR client LIKE ?",q.isEmpty()?null:new String[]{"%"+q+"%","%"+q+"%"},null,null,"id DESC");try{while(c.moveToNext())a.add(readInvoice(c));}finally{c.close();}return a;}
    public ArrayList<Invoice> partnerInvoices(int partnerId,String q){
        ArrayList<Invoice>a=new ArrayList<>(); q=q==null?"":q.trim();
        String where="partner_id=?"; java.util.ArrayList<String> args=new java.util.ArrayList<>(); args.add(String.valueOf(partnerId));
        if(!q.isEmpty()){ where += " AND (CAST(invoice_number AS TEXT) LIKE ? OR client LIKE ?)"; args.add("%"+q+"%"); args.add("%"+q+"%"); }
        Cursor c=getReadableDatabase().query("invoices",null,where,args.toArray(new String[0]),null,null,"id DESC");
        try{while(c.moveToNext())a.add(readInvoice(c));}finally{c.close();} return a;
    }

    public Invoice invoice(int id){Cursor c=getReadableDatabase().query("invoices",null,"id=?",new String[]{""+id},null,null,null);try{if(!c.moveToFirst())return null;return readInvoice(c);}finally{c.close();}}
    public Invoice invoiceByCloudKey(String key){if(key==null||key.trim().isEmpty())return null;Cursor c=getReadableDatabase().query("invoices",null,"cloud_key=?",new String[]{key.trim()},null,null,null);try{if(!c.moveToFirst())return null;return readInvoice(c);}finally{c.close();}}
    private void loadItems(Invoice i){Cursor c=getReadableDatabase().query("invoice_items",null,"invoice_id=?",new String[]{""+i.id},null,null,"id ASC");try{while(c.moveToNext())i.items.add(new Item(c.getInt(c.getColumnIndexOrThrow("product_id")),c.getString(c.getColumnIndexOrThrow("name")),c.getDouble(c.getColumnIndexOrThrow("price")),c.getDouble(c.getColumnIndexOrThrow("sale_price")),c.getInt(c.getColumnIndexOrThrow("qty"))));}finally{c.close();}}

    public int saveInvoice(int id,int clientId,String client,String customerPhone,String customerCity,String customerAddress,String customerType,boolean paid,int partnerId,boolean shippingEnabled,double shippingCharge,double shippingCost,String trackingNumber,String shippingCompany,String shippingAccount,boolean deliveryReceived,String deliveryFailureReason,boolean partnerProfitPaid,boolean shippedByAdmin,ArrayList<Item> items){
        final int[] invoiceIdForSyncHolder={id};
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{
            boolean reseller=partnerId>0;
            double productProfit=0;
            for(Item it:items) productProfit+=(it.salePrice-it.price)*it.qty;
            double netProfit=reseller?(productProfit+(shippingEnabled?shippingCharge:0)-(shippingEnabled?shippingCost:0)):0;

            String today=new SimpleDateFormat("dd/MM/yyyy",Locale.US).format(new Date());
            String invoiceDate=today;
            String paidDate=null;
            String deliveryReceivedDate=null;
            String oldFailureReason=null;
            String partnerProfitPaidDate=null;
            if(id>=0){
                Cursor old=db.query("invoices",new String[]{"date","paid","paid_date","delivery_received","delivery_received_date","delivery_failure_reason","partner_profit_paid","partner_profit_paid_date"},"id=?",new String[]{""+id},null,null,null);
                try{
                    if(old.moveToFirst()){
                        String oldDate=old.getString(0);
                        if(oldDate!=null&&!oldDate.isEmpty()) invoiceDate=oldDate;
                        boolean wasPaid=old.getInt(1)==1;
                        String oldPaidDate=old.getString(2);
                        if(paid){
                            paidDate=(wasPaid&&oldPaidDate!=null&&!oldPaidDate.isEmpty())?oldPaidDate:nowDateTime();
                        }
                        boolean wasReceived=old.getInt(3)==1;
                        String oldReceivedDate=old.getString(4);
                        deliveryReceivedDate=deliveryReceived
                                ?((wasReceived&&oldReceivedDate!=null&&!oldReceivedDate.isEmpty())?oldReceivedDate:today)
                                :null;
                        oldFailureReason=old.getString(5);
                        boolean wasProfitPaid=old.getInt(6)==1;
                        String oldProfitDate=old.getString(7);
                        partnerProfitPaidDate=partnerProfitPaid
                                ?((wasProfitPaid&&oldProfitDate!=null&&!oldProfitDate.isEmpty())?oldProfitDate:today)
                                :null;
                    }
                }finally{old.close();}
            }else{
                if(paid) paidDate=today;
                if(deliveryReceived) deliveryReceivedDate=today;
                if(partnerProfitPaid) partnerProfitPaidDate=today;
            }

            ContentValues v=new ContentValues();
            v.put("client_id",clientId);
            v.put("client",client);
            v.put("customer_phone",customerPhone);
            v.put("customer_city",customerCity);
            v.put("customer_address",customerAddress);
            v.put("customer_type",customerType==null||customerType.trim().isEmpty()?"normal":customerType.trim());
            v.put("date",invoiceDate);
            v.put("paid",paid?1:0);
            v.put("paid_date",paidDate);
            v.put("reseller",reseller?1:0);
            v.put("partner_id",partnerId);
            v.put("shipping_enabled",shippingEnabled?1:0);
            v.put("shipping_charge",shippingEnabled?shippingCharge:0);
            v.put("shipping_cost",shippingEnabled?shippingCost:0);
            v.put("tracking_number",trackingNumber);
            v.put("shipping_company",shippingEnabled?safeDb(shippingCompany):null);
            v.put("shipping_account",shippingEnabled?safeDb(shippingAccount):null);
            v.put("delivery_received",deliveryReceived?1:0);
            v.put("delivery_received_date",deliveryReceivedDate);
            String failure = deliveryReceived ? null : (deliveryFailureReason==null||deliveryFailureReason.trim().isEmpty()?oldFailureReason:deliveryFailureReason.trim());
            v.put("delivery_failure_reason",failure);
            v.put("commission",netProfit);
            v.put("partner_profit_paid",partnerProfitPaid?1:0);
            v.put("partner_profit_paid_date",partnerProfitPaidDate);
            v.put("shipped_by_admin",shippedByAdmin?1:0);

            long invoiceId;
            if(id<0){
                int nextNo=0;
                Cursor nq=db.rawQuery("SELECT COALESCE(MAX(invoice_number),0) FROM invoices WHERE partner_id=?",new String[]{String.valueOf(partnerId)});
                try{if(nq.moveToFirst())nextNo=nq.getInt(0);}finally{nq.close();}
                nextNo=Math.max(nextNo,0)+1;
                String cloudKey="inv_"+java.util.UUID.randomUUID().toString();
                v.put("invoice_number",nextNo);
                v.put("cloud_key",cloudKey);
                invoiceId=db.insert("invoices",null,v);
            }
            else{
                Cursor oq=db.query("invoices",new String[]{"invoice_number","cloud_key"},"id=?",new String[]{String.valueOf(id)},null,null,null);
                try{if(oq.moveToFirst()){v.put("invoice_number",oq.getInt(0));if(!oq.isNull(1))v.put("cloud_key",oq.getString(1));}}finally{oq.close();}
                db.update("invoices",v,"id=?",new String[]{""+id});
                invoiceId=id;
                db.delete("invoice_items","invoice_id=?",new String[]{""+id});
            }
            invoiceIdForSyncHolder[0]=(int)invoiceId;
            for(Item it:items){
                ContentValues x=new ContentValues();
                x.put("invoice_id",invoiceId);
                x.put("product_id",it.productId);
                x.put("name",it.name);
                x.put("price",it.price);
                x.put("qty",it.qty);
                x.put("sale_price",it.salePrice);
                db.insert("invoice_items",null,x);
            }
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        if(invoiceIdForSyncHolder[0] > 0) markSync("invoices",invoiceIdForSyncHolder[0],System.currentTimeMillis(),"dirty",0,false);
        return invoiceIdForSyncHolder[0];
    }

    private String safeDb(String s){return s==null?null:s.trim();}

    public void setPartnerProfitPaid(int invoiceId,boolean paid){
        ContentValues v=new ContentValues();v.put("partner_profit_paid",paid?1:0);
        if(paid)v.put("partner_profit_paid_date",today());else v.putNull("partner_profit_paid_date");
        getWritableDatabase().update("invoices",v,"id=?",new String[]{""+invoiceId});
        markSync("invoices",invoiceId,System.currentTimeMillis(),"dirty",0,false);
    }

    public void setPartnerProfitPaidBulk(ArrayList<Integer> invoiceIds,boolean paid){
        if(invoiceIds==null||invoiceIds.isEmpty())return;
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try{
            ContentValues v=new ContentValues();v.put("partner_profit_paid",paid?1:0);if(paid)v.put("partner_profit_paid_date",today());else v.putNull("partner_profit_paid_date");
            for(Integer id:invoiceIds)if(id!=null){db.update("invoices",v,"id=?",new String[]{""+id}); markSync("invoices",id,System.currentTimeMillis(),"dirty",0,false);}
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }

    public void setDeliveryStatus(int invoiceId,boolean received,String reason){
        ContentValues v=new ContentValues();
        v.put("delivery_received",received?1:0);
        if(received)v.put("delivery_received_date",today());else v.putNull("delivery_received_date");
        if(received)v.putNull("delivery_failure_reason");else if(reason==null)v.putNull("delivery_failure_reason");else v.put("delivery_failure_reason",reason);
        if(!received){
            v.put("partner_profit_paid",0);
            v.putNull("partner_profit_paid_date");
        }
        getWritableDatabase().update("invoices",v,"id=?",new String[]{""+invoiceId});
        markSync("invoices",invoiceId,System.currentTimeMillis(),"dirty",0,false);
    }

    private String today(){return new SimpleDateFormat("dd/MM/yyyy",Locale.US).format(new Date());}
    private String nowDateTime(){return new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.US).format(new Date());}


    /**
     * Returns all invoices belonging to a customer. We use both client_id and
     * the stored client name so older invoices created before customer linking
     * are also included in the monthly statement.
     */
    public ArrayList<Invoice> customerInvoices(int customerId,String customerName,boolean unpaidOnly){
        ArrayList<Invoice> a=new ArrayList<>();
        String where="(client_id=? OR client=?)";
        ArrayList<String> args=new ArrayList<>();
        args.add(""+customerId);
        args.add(customerName==null?"":customerName);
        if(unpaidOnly)where+=" AND paid=0";
        Cursor c=getReadableDatabase().query("invoices",null,where,args.toArray(new String[0]),null,null,"id DESC");
        try{while(c.moveToNext())a.add(readInvoice(c));}finally{c.close();}
        return a;
    }

    /** Mark several customer invoices as paid and keep an individual payment date. */
    public void setInvoicesPaidBulk(ArrayList<Integer> invoiceIds){
        if(invoiceIds==null||invoiceIds.isEmpty())return;
        SQLiteDatabase db=getWritableDatabase();
        db.beginTransaction();
        try{
            ContentValues v=new ContentValues();
            v.put("paid",1);
            v.put("paid_date",nowDateTime());
            for(Integer id:invoiceIds){
                if(id!=null){db.update("invoices",v,"id=? AND paid=0",new String[]{""+id}); markSync("invoices",id,System.currentTimeMillis(),"dirty",0,false);}
            }
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }

    public void deleteInvoice(int id){SQLiteDatabase db=getWritableDatabase();db.delete("invoice_items","invoice_id=?",new String[]{""+id});db.delete("invoices","id=?",new String[]{""+id}); markSyncDeleted("invoices",id);}
}
