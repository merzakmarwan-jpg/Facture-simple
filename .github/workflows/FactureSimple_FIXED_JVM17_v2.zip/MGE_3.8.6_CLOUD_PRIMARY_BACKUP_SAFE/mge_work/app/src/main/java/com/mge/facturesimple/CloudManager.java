package com.mge.facturesimple;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.firestore.Source;
import com.google.firebase.firestore.WriteBatch;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import android.os.Handler;
import android.os.Looper;

/** Firebase authentication + cloud synchronization layer for FactureSimple 3.0. */
public class CloudManager {
    private static final int MAX_IMAGE_BYTES = 200 * 1024;
    private final Context context;
    private final Store db;
    private final FirebaseAuth auth;
    private final FirebaseFirestore fs;
    private final FirebaseStorage storage;

    public String role = "partner";
    public long partnerId = 0;
    public String displayName = "";
    public boolean active = true;
    private UserProfile profile;
    /** Last synchronization failure/warnings, exposed for the settings UI. */
    public String lastSyncError = "";
    public String lastSyncWarning = "";

    // Realtime Firestore listeners. They keep invoices/customers synchronized
    // without requiring the user to leave and reopen the page.
    private ListenerRegistration realtimeInvoicesListener;
    private ListenerRegistration realtimeCustomersListener;
    private final Handler realtimeHandler = new Handler(Looper.getMainLooper());
    private Runnable realtimePendingRun;
    private boolean realtimeStarted = false;

    public CloudManager(Context c, Store store) {
        context = c.getApplicationContext();
        db = store;
        auth = FirebaseAuth.getInstance();
        fs = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();
    }

    public boolean isLoggedIn() { return auth.getCurrentUser() != null; }
    public String uid() { return isLoggedIn() ? auth.getCurrentUser().getUid() : null; }
    public String email() { return isLoggedIn() ? auth.getCurrentUser().getEmail() : null; }
    public boolean isAdmin() { return "admin".equalsIgnoreCase(role); }

    public Task<AuthResult> login(String email, String password) {
        return auth.signInWithEmailAndPassword(email.trim(), password);
    }

    public Task<AuthResult> registerPartner(String email, String password) {
        return auth.createUserWithEmailAndPassword(email.trim(), password);
    }

    public void logout() { auth.signOut(); }

    public Task<QuerySnapshot> listPartners() {
        if (!isAdmin()) throw new IllegalStateException("Admin only");
        return fs.collection("users").whereEqualTo("role", "partner").get();
    }

    /**
     * Creates a Firebase Authentication account without signing out the current admin.
     * A secondary FirebaseApp/Auth instance is used only for account creation, then deleted.
     */
    public Task<DocumentSnapshot> createPartnerAccount(String name, String emailAddress, String password, long newPartnerId) {
        if (!isAdmin()) throw new IllegalStateException("Admin only");
        if (TextUtils.isEmpty(emailAddress) || TextUtils.isEmpty(password))
            throw new IllegalArgumentException("Email and password are required");
        if (password.length() < 6) throw new IllegalArgumentException("Password must be at least 6 characters");
        if (newPartnerId < 1) throw new IllegalArgumentException("Partner ID must be greater than 0");

        String secondaryName = "partner_auth_" + System.currentTimeMillis();
        FirebaseApp secondary = FirebaseApp.initializeApp(context, FirebaseApp.getInstance().getOptions(), secondaryName);
        if (secondary == null) throw new IllegalStateException("Unable to initialize secondary Firebase app");
        FirebaseAuth secondaryAuth = FirebaseAuth.getInstance(secondary);

        return fs.collection("users").whereEqualTo("partnerId", newPartnerId).limit(1).get().continueWithTask(check -> {
            if (!check.isSuccessful()) throw check.getException();
            if (check.getResult() != null && !check.getResult().isEmpty())
                throw new IllegalStateException("Partner ID already exists");
            return secondaryAuth.createUserWithEmailAndPassword(emailAddress.trim(), password);
        }).continueWithTask(created -> {
            if (!created.isSuccessful()) throw created.getException();
            String newUid = created.getResult().getUser().getUid();
            Map<String,Object> m = new HashMap<>();
            m.put("uid", newUid);
            m.put("name", name == null ? "" : name.trim());
            m.put("email", emailAddress.trim());
            m.put("role", "partner");
            m.put("partnerId", newPartnerId);
            m.put("active", true);
            long now = System.currentTimeMillis();
            m.put("createdAt", now);
            m.put("updatedAt", now);
            return fs.collection("users").document(newUid).set(m).continueWithTask(saved -> {
                if (!saved.isSuccessful()) {
                    try { secondaryAuth.getCurrentUser().delete(); } catch (Exception ignored) {}
                    throw saved.getException();
                }
                return fs.collection("users").document(newUid).get().continueWithTask(profileTask -> {
                    if (!profileTask.isSuccessful()) throw profileTask.getException();
                    int localCustomerId=db.upsertPartnerCustomer(newUid,newPartnerId,name,emailAddress);
                    if(localCustomerId<=0) throw new IllegalStateException("Unable to create linked partner customer");
                    return pushLocalCustomer(localCustomerId).continueWith(x->{
                        if(!x.isSuccessful()) throw x.getException();
                        return profileTask.getResult();
                    });
                });
            });
        }).addOnCompleteListener(t -> {
            try { secondary.delete(); } catch (Exception ignored) {}
        });
    }

    public Task<Void> updatePartnerProfile(String partnerUid, String name, long newPartnerId, boolean enabled) {
        if (!isAdmin()) throw new IllegalStateException("Admin only");
        if (partnerUid == null || partnerUid.trim().isEmpty()) throw new IllegalArgumentException("Missing UID");
        if (newPartnerId < 1) throw new IllegalArgumentException("Partner ID must be greater than 0");
        Map<String,Object> m = new HashMap<>();
        m.put("name", name == null ? "" : name.trim());
        m.put("partnerId", newPartnerId);
        m.put("active", enabled);
        m.put("updatedAt", System.currentTimeMillis());
        return fs.collection("users").whereEqualTo("partnerId", newPartnerId).get().continueWithTask(t -> {
            if (!t.isSuccessful()) throw t.getException();
            for (DocumentSnapshot d : t.getResult().getDocuments()) {
                if (!partnerUid.equals(d.getId())) throw new IllegalStateException("Partner ID already exists");
            }
            return fs.collection("users").document(partnerUid).set(m, SetOptions.merge()).continueWithTask(saved -> {
                if(!saved.isSuccessful()) throw saved.getException();
                return fs.collection("users").document(partnerUid).get();
            }).continueWithTask(profileTask -> {
                if(!profileTask.isSuccessful()) throw profileTask.getException();
                DocumentSnapshot profileDoc=profileTask.getResult();
                String emailValue=profileDoc==null?"":str(profileDoc.getString("email"));
                int localCustomerId=db.upsertPartnerCustomer(partnerUid,newPartnerId,name,emailValue);
                if(localCustomerId>0) return pushLocalCustomer(localCustomerId);
                return com.google.android.gms.tasks.Tasks.forResult(null);
            });
        });
    }

    /** Ensures every Firebase partner has exactly one linked customer record.
     * This also repairs partner accounts created before automatic linking existed. */
    public Task<Void> ensureAllPartnerCustomers(){
        if(!isAdmin()) throw new IllegalStateException("Admin only");
        return listPartners().continueWithTask(t->{
            if(!t.isSuccessful()) throw t.getException();
            java.util.ArrayList<Task<Void>> tasks=new java.util.ArrayList<>();
            for(DocumentSnapshot d:t.getResult().getDocuments()){
                Long p=d.getLong("partnerId");
                if(p==null || p<1) continue;
                tasks.add(ensurePartnerCustomer(d.getId(),p,d.getString("name"),d.getString("email")));
            }
            return tasks.isEmpty()?com.google.android.gms.tasks.Tasks.forResult(null):com.google.android.gms.tasks.Tasks.whenAll(tasks);
        });
    }

    private Task<Void> ensurePartnerCustomer(String partnerUid,long partnerId,String name,String email){
        return fs.collection("customers").whereEqualTo("partnerId",partnerId).get().continueWithTask(q->{
            if(!q.isSuccessful()) throw q.getException();
            DocumentSnapshot found=null;
            for(DocumentSnapshot d:q.getResult().getDocuments()){
                Boolean r=d.getBoolean("reseller");
                if(Boolean.TRUE.equals(r)){found=d;break;}
            }
            if(found!=null){
                int id=parseInt(found.getId());
                if(id>0){
                    ContentValues v=new ContentValues();v.put("id",id);v.put("name",name==null?str(found.getString("name")):name);v.put("phone",email==null?str(found.getString("phone")):email);v.put("city",str(found.getString("city")));v.put("address",str(found.getString("address")));v.put("reseller",1);v.put("partner_id",partnerId);v.put("partner_uid",partnerUid);v.put("partner_email",email==null?str(found.getString("partner_email")):email);Double ds=found.getDouble("defaultShipping");v.put("default_shipping",ds==null?30:ds);
                    db.getWritableDatabase().insertWithOnConflict("customers",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);
                    db.markSyncClean("customers",id,remoteTimestamp(found));
                    return com.google.android.gms.tasks.Tasks.forResult(null);
                }
            }
            int localId=db.upsertPartnerCustomer(partnerUid,partnerId,name,email);
            if(localId<=0) throw new IllegalStateException("Unable to link partner customer");
            return pushLocalCustomer(localId);
        });
    }

    /** Removes the linked customer and the Firebase profile together.
     * Firebase Authentication itself cannot delete another user's Auth account from a client app;
     * removing the canonical users/{uid} profile immediately prevents application access. */
    public Task<Void> deletePartnerAndLinkedCustomer(String partnerUid,long partnerId){
        if(!isAdmin()) throw new IllegalStateException("Admin only");
        if(partnerId < 1) throw new IllegalArgumentException("Missing Partner ID");

        // لا نعتمد على UID المخزن محلياً فقط؛ قد يكون السجل المحلي قديماً.
        // نبحث عن الحساب حسب Partner ID ثم نحذف السجل المرتبط به.
        final String[] canonicalUid={partnerUid==null?"":partnerUid.trim()};
        return fs.collection("users").whereEqualTo("partnerId",partnerId).limit(5).get().continueWithTask(usersTask->{
            if(!usersTask.isSuccessful()) throw usersTask.getException();
            for(DocumentSnapshot d:usersTask.getResult().getDocuments()){
                if("partner".equalsIgnoreCase(str(d.getString("role")))){ canonicalUid[0]=d.getId(); break; }
            }
            return fs.collection("customers").whereEqualTo("partnerId",partnerId).get();
        }).continueWithTask(customersTask->{
            if(!customersTask.isSuccessful()) throw customersTask.getException();
            java.util.ArrayList<Task<Void>> deletes=new java.util.ArrayList<>();
            for(DocumentSnapshot d:customersTask.getResult().getDocuments()){
                if(Boolean.TRUE.equals(d.getBoolean("reseller")))
                    deletes.add(fs.collection("customers").document(d.getId()).delete());
            }
            Task<Void> customerDeletes=deletes.isEmpty()?com.google.android.gms.tasks.Tasks.forResult(null):com.google.android.gms.tasks.Tasks.whenAll(deletes);
            return customerDeletes.continueWithTask(v->{
                if(!v.isSuccessful()) throw v.getException();
                if(canonicalUid[0].isEmpty()) return com.google.android.gms.tasks.Tasks.forResult(null);
                return fs.collection("users").document(canonicalUid[0]).delete().continueWithTask(userDelete->{
                    if(userDelete.isSuccessful()) return com.google.android.gms.tasks.Tasks.forResult(null);
                    // بعض مشاريع Firebase المنشورة قد تكون فيها قاعدة delete قديمة.
                    // في هذه الحالة نعطّل الحساب نهائياً بدلاً من تركه فعالاً.
                    Map<String,Object> fallback=new HashMap<>();
                    fallback.put("active",false); fallback.put("deleted",true); fallback.put("updatedAt",System.currentTimeMillis());
                    return fs.collection("users").document(canonicalUid[0]).set(fallback,SetOptions.merge()).continueWith(f->{
                        if(!f.isSuccessful()) throw userDelete.getException()!=null?userDelete.getException():f.getException();
                        lastSyncWarning="تم حذف الشريك المرتبط وتعطيل حساب Firebase بسبب رفض حذف مستند الحساب.";
                        return null;
                    });
                });
            }).continueWith(v->{
                if(!v.isSuccessful()) throw v.getException();
                int localId=db.linkedPartnerCustomer(partnerId,canonicalUid[0]);
                if(localId<0 && partnerUid!=null) localId=db.linkedPartnerCustomer(partnerId,partnerUid);
                if(localId>0) db.deleteCustomer(localId);
                return null;
            });
        });
    }

    public Task<Void> sendPartnerPasswordReset(String emailAddress) {
        if (!isAdmin()) throw new IllegalStateException("Admin only");
        return auth.sendPasswordResetEmail(emailAddress.trim());
    }

    /**
     * Saves the authenticated user's profile in users/{uid}.
     * This is the canonical user document used by the application.
     */
    public Task<Void> saveProfile(String name, String role, long partnerId) {
        String id = uid();
        if (id == null) throw new IllegalStateException("No authenticated Firebase user");

        long now = System.currentTimeMillis();
        Map<String,Object> m = new HashMap<>();
        m.put("uid", id);
        m.put("name", name == null ? "" : name.trim());
        m.put("role", role == null ? "partner" : role.trim().toLowerCase());
        m.put("partnerId", partnerId);
        m.put("email", email() == null ? "" : email());
        m.put("active", true);
        m.put("updatedAt", now);

        // Keep createdAt when the profile already exists.
        return fs.collection("users").document(id).get().continueWithTask(t -> {
            if (t.isSuccessful() && t.getResult() != null && t.getResult().exists()) {
                return fs.collection("users").document(id).set(m, SetOptions.merge());
            }
            m.put("createdAt", now);
            return fs.collection("users").document(id).set(m);
        });
    }

    /** Reads the canonical users/{uid} document. */
    public Task<DocumentSnapshot> loadProfile() {
        String id = uid();
        if (id == null) throw new IllegalStateException("No authenticated Firebase user");
        return fs.collection("users").document(id).get();
    }

    public UserProfile getProfile() { return profile; }

    /** Loads users/{uid} without blocking the UI on a slow network. Cached profile is used first,
     * then a server refresh is attempted in the background. This prevents the white-screen-after-login issue. */
    public void loadProfileAndRun(Runnable done, Runnable failed) {
        if (!isLoggedIn()) { if (failed != null) failed.run(); return; }
        final boolean[] completed = {false};
        fs.collection("users").document(uid()).get(Source.CACHE).addOnSuccessListener(cached -> {
            if (cached != null && cached.exists() && applyProfileDocument(cached, false)) {
                completed[0] = true;
                if (done != null) done.run();
            }
            loadProfile().addOnSuccessListener(server -> {
                if (server == null || !server.exists()) {
                    if (!completed[0] && failed != null) failed.run();
                    return;
                }
                if (applyProfileDocument(server, true) && !completed[0]) { completed[0] = true; if (done != null) done.run(); }
            }).addOnFailureListener(e -> {
                recordSyncFailure(e);
                if (!completed[0] && failed != null) failed.run();
            });
        }).addOnFailureListener(e -> {
            loadProfile().addOnSuccessListener(server -> {
                if (server != null && server.exists() && applyProfileDocument(server, true)) {
                    completed[0] = true; if (done != null) done.run();
                } else if (failed != null) failed.run();
            }).addOnFailureListener(serverErr -> { recordSyncFailure(serverErr); if (failed != null) failed.run(); });
        });
    }

    private boolean applyProfileDocument(DocumentSnapshot doc, boolean strict) {
        if (doc == null || !doc.exists()) {
            lastSyncError="حساب Firebase مسجل الدخول، لكن users/"+uid()+" غير موجود";
            return false;
        }
        UserProfile p = new UserProfile();
        p.uid = uid();
        p.email = doc.getString("email") == null ? email() : doc.getString("email");
        p.name = doc.getString("name") == null ? "" : doc.getString("name");
        p.role = doc.getString("role") == null ? "partner" : doc.getString("role");
        Long partner = doc.getLong("partnerId"); p.partnerId = partner == null ? 0 : partner;
        Boolean enabled = doc.getBoolean("active"); p.active = enabled == null || enabled;
        Long created = doc.getLong("createdAt"); p.createdAt = created == null ? 0 : created;
        Long updated = doc.getLong("updatedAt"); p.updatedAt = updated == null ? 0 : updated;
        if (!p.active) { lastSyncError="حساب الشريك معطل من الأدمن"; return false; }
        if (!p.isAdmin() && !p.isPartner()) { lastSyncError="دور الحساب غير صحيح: "+p.role; return false; }
        profile=p; role=p.role; partnerId=p.partnerId; displayName=p.name; active=p.active;
        return true;
    }

    /** Pushes exactly one invoice immediately. The UI can return to the invoice list without waiting for a full sync. */
    public void pushInvoiceNow(int invoiceId, Runnable done, Runnable failed) {
        if (!isLoggedIn() || invoiceId <= 0) { if (failed != null) failed.run(); return; }
        fs.collection("invoices").document(String.valueOf(invoiceId)).get()
            .continueWithTask(t -> { if (!t.isSuccessful()) throw t.getException(); return pushLocalInvoice(invoiceId, t.getResult()); })
            .addOnSuccessListener(v -> { if (done != null) done.run(); })
            .addOnFailureListener(e -> { recordSyncFailure(e); if (failed != null) failed.run(); });
    }

    /** Pushes exactly one customer immediately, instead of running a full customer reconciliation. */
    public void pushCustomerNow(int customerId, Runnable done, Runnable failed) {
        if (!isLoggedIn() || customerId <= 0) { if (failed != null) failed.run(); return; }
        pushLocalCustomer(customerId)
            .addOnSuccessListener(v -> { if (done != null) done.run(); })
            .addOnFailureListener(e -> { recordSyncFailure(e); if (failed != null) failed.run(); });
    }

    /**
     * Phase 3.4: true Admin bidirectional synchronization.
     * Local changes are tracked in Store.sync_meta. For each entity, the newer
     * side wins using millisecond updatedAt timestamps. Dirty local deletions
     * are represented by tombstones in sync_meta so they can also be propagated.
     */
    private Task<Void> refreshAuthToken(){
        if(auth.getCurrentUser()==null) return com.google.android.gms.tasks.Tasks.forException(new IllegalStateException("لا يوجد مستخدم مسجل الدخول"));
        return auth.getCurrentUser().getIdToken(true).continueWith(t->{
            if(!t.isSuccessful()) throw t.getException();
            return null;
        });
    }

    /**
     * Starts lightweight Firestore listeners for the current account. A change
     * in customers or invoices schedules a normal bidirectional reconciliation
     * so the local SQLite database and the cloud converge on the same data.
     */
    public void startRealtimeSync(final Runnable onChanged) {
        stopRealtimeSync();
        if (!isLoggedIn()) return;
        realtimeStarted = true;

        if (isAdmin()) {
            realtimeCustomersListener = fs.collection("customers").addSnapshotListener((snap, err) -> {
                if (err != null || snap == null || !realtimeStarted) return;
                scheduleRealtimeReconcile(onChanged);
            });
            realtimeInvoicesListener = fs.collection("invoices").addSnapshotListener((snap, err) -> {
                if (err != null || snap == null || !realtimeStarted) return;
                scheduleRealtimeReconcile(onChanged);
            });
        } else if (partnerId > 0) {
            realtimeCustomersListener = fs.collection("customers")
                    .whereEqualTo("partnerId", partnerId)
                    .addSnapshotListener((snap, err) -> {
                        if (err != null || snap == null || !realtimeStarted) return;
                        scheduleRealtimeReconcile(onChanged);
                    });
            realtimeInvoicesListener = fs.collection("invoices")
                    .whereEqualTo("partner_id", partnerId)
                    .addSnapshotListener((snap, err) -> {
                        if (err != null || snap == null || !realtimeStarted) return;
                        scheduleRealtimeReconcile(onChanged);
                    });
        }
    }

    private void scheduleRealtimeReconcile(final Runnable onChanged) {
        if (!realtimeStarted) return;
        if (realtimePendingRun != null) realtimeHandler.removeCallbacks(realtimePendingRun);
        realtimePendingRun = () -> {
            if (!realtimeStarted) return;
            Runnable done = () -> { if (onChanged != null) onChanged.run(); };
            if (isAdmin()) {
                syncLocalToCloud(done, () -> { if (onChanged != null) onChanged.run(); });
            } else {
                syncCloudToLocalForPartner(done, () -> { if (onChanged != null) onChanged.run(); });
            }
        };
        // Coalesce the initial snapshot and rapid successive writes into one sync.
        realtimeHandler.postDelayed(realtimePendingRun, 350);
    }

    public void stopRealtimeSync() {
        realtimeStarted = false;
        if (realtimePendingRun != null) { realtimeHandler.removeCallbacks(realtimePendingRun); realtimePendingRun = null; }
        if (realtimeInvoicesListener != null) { realtimeInvoicesListener.remove(); realtimeInvoicesListener = null; }
        if (realtimeCustomersListener != null) { realtimeCustomersListener.remove(); realtimeCustomersListener = null; }
    }

    /** Reconciles all customer records for one partner while logged in as Admin. */
    public void syncPartnerCustomersForAdmin(long targetPartnerId, final Runnable done, final Runnable failed) {
        if (!isAdmin() || targetPartnerId <= 0) {
            if (failed != null) failed.run();
            return;
        }
        // The normal Admin customer sync is authoritative and bidirectional.
        // Running it before opening the partner's list repairs old records that
        // were created on a partner phone before the Admin had them locally.
        syncCustomersBidirectional(done, failed);
    }

    public void syncLocalToCloud(final Runnable done, final Runnable failed) {
        lastSyncError=""; lastSyncWarning="";
        if (!isLoggedIn() || !isAdmin()) { lastSyncError="لا يوجد مستخدم مدير مسجل الدخول"; if (failed != null) failed.run(); return; }
        refreshAuthToken().addOnSuccessListener(v->syncBidirectionalAdmin(done,failed)).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
    }

    public void syncBidirectionalAdmin(final Runnable done, final Runnable failed) {
        if (!isLoggedIn() || !isAdmin()) { if (failed != null) failed.run(); return; }
        // IMPORTANT: image repair is intentionally NOT part of the blocking full sync.
        // The previous version scanned/downloaded/re-uploaded every product image on
        // each manual/automatic sync. With many products this could run for minutes
        // and hit the worker timeout, causing "انتهت مهلة المزامنة السحابية".
        // Images are now normalized when they are uploaded/replaced. Existing oversized
        // cloud images can be repaired separately without blocking invoice/customer sync.
        syncShippingCompaniesToCloud(
            () -> syncProductsBidirectional(
                () -> syncCustomersBidirectional(
                    () -> syncInvoicesBidirectional(done, failed), failed),
                failed),
            failed);
    }

    private void syncProductsBidirectional(final Runnable done, final Runnable failed) {
        fs.collection("products").get().addOnSuccessListener(remote -> {
            java.util.HashMap<Integer,DocumentSnapshot> remoteMap=new java.util.HashMap<>();
            for(DocumentSnapshot d:remote.getDocuments()) remoteMap.put(parseInt(d.getId()),d);

            // IMPORTANT: include BOTH sides. The old implementation only iterated
            // local product IDs. After an uninstall/reinstall the local SQLite
            // database is empty, so the cloud catalog (and its images) was never
            // downloaded back to the Admin device.
            java.util.LinkedHashSet<Integer> ids=new java.util.LinkedHashSet<>();
            ids.addAll(remoteMap.keySet());
            android.database.Cursor c=db.getReadableDatabase().query("sync_meta",null,"entity=?",new String[]{"products"},null,null,null);
            try{while(c.moveToNext())ids.add(c.getInt(c.getColumnIndexOrThrow("local_id")));}finally{c.close();}
            android.database.Cursor pc=db.getReadableDatabase().query("products",new String[]{"id"},null,null,null,null,null);
            try{while(pc.moveToNext())ids.add(pc.getInt(0));}finally{pc.close();}

            java.util.ArrayList<Task<Void>> tasks=new java.util.ArrayList<>();
            for(Integer id:ids){
                final int localId=id; final DocumentSnapshot r=remoteMap.get(id);
                final boolean localExists=localProductExists(localId);
                final boolean tomb="dirty".equals(db.syncState("products",localId)) && !localExists;
                long localTs=db.syncLocalUpdatedAt("products",localId); long remoteTs=remoteTimestamp(r);

                if(tomb){
                    if(r==null || localTs>=remoteTs){
                        tasks.add(fs.collection("products").document(String.valueOf(localId)).delete().continueWith(t->{db.markSyncClean("products",localId,localTs);return null;}));
                    }else{
                        // Cloud is newer than a stale local tombstone: restore it,
                        // including its Storage image.
                        tasks.add(applyRemoteProduct(r));
                    }
                } else if(r==null){
                    // Local-only product: upload it to the cloud.
                    if(localExists) tasks.add(pushLocalProduct(localId));
                } else if(!localExists){
                    // Fresh install / cleared app: cloud is authoritative.
                    tasks.add(applyRemoteProduct(r));
                } else if(localTs>=remoteTs && "dirty".equals(db.syncState("products",localId))){
                    tasks.add(pushLocalProduct(localId));
                } else {
                    // Remote is authoritative and must restore metadata + image.
                    tasks.add(applyRemoteProduct(r));
                }
            }
            if(tasks.isEmpty()){if(done!=null)done.run();return;}
            com.google.android.gms.tasks.Tasks.whenAll(tasks)
                .addOnSuccessListener(v->{if(done!=null)done.run();})
                .addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
        }).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
    }

    private boolean localProductExists(int id){ Cursor c=db.getReadableDatabase().query("products",new String[]{"id"},"id=?",new String[]{String.valueOf(id)},null,null,null);try{return c.moveToFirst();}finally{c.close();} }
    private Task<Void> pushLocalProduct(int id){
        Store.Product p=db.product(id);
        if(p==null)return com.google.android.gms.tasks.Tasks.forResult(null);
        final long ts=Math.max(System.currentTimeMillis(),db.syncLocalUpdatedAt("products",id));
        // Product metadata must not depend on Firebase Storage. If an image cannot
        // be uploaded, keep the previous cloud image and still synchronize the product.
        return fs.collection("products").document(String.valueOf(id)).get().continueWithTask(read->{
            if(!read.isSuccessful()) throw read.getException();
            String existing=read.getResult()!=null?read.getResult().getString("imageUrl"):null;
            return uploadProductImageTask(p).continueWithTask(imageTask->{
                String imageUrl=existing==null?"":existing;
                if(imageTask.isSuccessful() && imageTask.getResult()!=null && !imageTask.getResult().isEmpty()) imageUrl=imageTask.getResult();
                else if(!TextUtils.isEmpty(p.image) && !p.image.startsWith("http://") && !p.image.startsWith("https://")){
                    recordSyncWarning("تعذر رفع صورة المنتج "+p.id+"؛ تمت مزامنة بيانات المنتج مع الإبقاء على الصورة السحابية الحالية.", imageTask.getException());
                }
                Map<String,Object> m=new HashMap<>();
                m.put("name",p.name);m.put("code",p.code);m.put("price",p.price);
                m.put("imageUrl",imageUrl);m.put("updatedAt",ts);m.put("updatedBy",uid());
                return fs.collection("products").document(String.valueOf(id)).set(m,SetOptions.merge());
            });
        }).continueWith(t->{
            if(!t.isSuccessful()){ recordSyncFailure(t.getException()); throw t.getException(); }
            db.markSyncClean("products",id,ts);
            return null;
        });
    }
    private Task<String> uploadProductImageTask(Store.Product p){
        if(TextUtils.isEmpty(p.image))return com.google.android.gms.tasks.Tasks.forResult("");
        if(p.image.startsWith("http://")||p.image.startsWith("https://"))return com.google.android.gms.tasks.Tasks.forResult(p.image);
        try{
            Uri uri=p.image.startsWith("content://")||p.image.startsWith("file://")?Uri.parse(p.image):Uri.fromFile(new File(p.image));
            File compressed = compressImageUri(uri, p.id);
            StorageReference ref=storage.getReference().child("products/"+p.id+"/main.jpg");
            // The object path is fixed: a replacement overwrites the previous image,
            // so no old image is left behind in Storage. Delete only after the new
            // compressed file has been prepared successfully.
            return ref.delete().continueWithTask(ignored -> ref.putFile(Uri.fromFile(compressed)))
                .continueWithTask(t->{if(!t.isSuccessful())throw t.getException();return ref.getDownloadUrl();})
                .continueWith(t->{
                    try{compressed.delete();}catch(Exception ignored){}
                    if(!t.isSuccessful())throw t.getException();
                    return t.getResult().toString();
                });
        }catch(Exception e){return com.google.android.gms.tasks.Tasks.forException(e);}
    }

    private File compressImageUri(Uri uri, int productId) throws Exception {
        File dir=new File(context.getCacheDir(),"mge_compressed_images");
        if(!dir.exists()&&!dir.mkdirs())throw new IOException("تعذر إنشاء مجلد ضغط الصور");
        File out=new File(dir,"product_"+productId+"_"+System.currentTimeMillis()+".jpg");
        BitmapFactory.Options bounds=new BitmapFactory.Options(); bounds.inJustDecodeBounds=true;
        try(InputStream in=context.getContentResolver().openInputStream(uri)){
            if(in==null)throw new IOException("تعذر قراءة الصورة");
            BitmapFactory.decodeStream(in,null,bounds);
        }
        if(bounds.outWidth<=0||bounds.outHeight<=0)throw new IOException("الصورة غير صالحة");
        int sample=1; int maxDim=Math.max(bounds.outWidth,bounds.outHeight);
        while(maxDim/sample>1600)sample*=2;
        BitmapFactory.Options opts=new BitmapFactory.Options(); opts.inSampleSize=sample;
        Bitmap bitmap;
        try(InputStream in=context.getContentResolver().openInputStream(uri)){
            if(in==null)throw new IOException("تعذر قراءة الصورة");
            bitmap=BitmapFactory.decodeStream(in,null,opts);
        }
        if(bitmap==null)throw new IOException("تعذر فك الصورة");
        try{
            int width=bitmap.getWidth(), height=bitmap.getHeight();
            for(int pass=0; pass<8; pass++){
                int quality=Math.max(25,85-pass*10);
                ByteArrayOutputStream bos=new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG,quality,bos);
                byte[] bytes=bos.toByteArray();
                if(bytes.length<=MAX_IMAGE_BYTES || pass==7){
                    try(FileOutputStream fos=new FileOutputStream(out)){fos.write(bytes);fos.flush();}
                    if(out.length()>MAX_IMAGE_BYTES){
                        float scale=0.85f;
                        Bitmap smaller=Bitmap.createScaledBitmap(bitmap,Math.max(320,(int)(width*scale)),Math.max(320,(int)(height*scale)),true);
                        if(smaller!=bitmap)bitmap.recycle(); bitmap=smaller; width=bitmap.getWidth(); height=bitmap.getHeight(); pass=-1;
                        if(width<=320||height<=320){
                            ByteArrayOutputStream last=new ByteArrayOutputStream(); bitmap.compress(Bitmap.CompressFormat.JPEG,25,last);
                            try(FileOutputStream fos=new FileOutputStream(out)){fos.write(last.toByteArray());}
                            if(out.length()>MAX_IMAGE_BYTES)throw new IOException("تعذر ضغط الصورة إلى أقل من 200KB");
                            break;
                        }
                        continue;
                    }
                    break;
                }
            }
        }finally{bitmap.recycle();}
        return out;
    }

    /** Compress every local product image before cloud upload. */
    private File compressLocalImageIfNeeded(String path,int productId) throws Exception {
        if(TextUtils.isEmpty(path)||path.startsWith("http://")||path.startsWith("https://"))return null;
        Uri uri=path.startsWith("content://")||path.startsWith("file://")?Uri.parse(path):Uri.fromFile(new File(path));
        File f=compressImageUri(uri,productId);
        return f;
    }

    /** Repair cloud images: if an existing Storage object exceeds 200KB, download,
     * compress, delete the old object and upload the normalized image. */
    private Task<String> normalizeCloudImage(int productId,String currentUrl){
        StorageReference ref=storage.getReference().child("products/"+productId+"/main.jpg");
        return ref.getMetadata().continueWithTask(metaTask->{
            if(!metaTask.isSuccessful())throw metaTask.getException();
            long size=metaTask.getResult().getSizeBytes();
            if(size<=MAX_IMAGE_BYTES)return com.google.android.gms.tasks.Tasks.forResult(currentUrl==null?"":currentUrl);
            File tmp=new File(context.getCacheDir(),"mge_cloud_"+productId+".jpg");
            return ref.getFile(tmp).continueWithTask(download->{
                if(!download.isSuccessful())throw download.getException();
                File compressed=compressLocalImageIfNeeded(Uri.fromFile(tmp).toString(),productId);
                return ref.delete().continueWithTask(del->ref.putFile(Uri.fromFile(compressed)))
                    .continueWithTask(up->{if(!up.isSuccessful())throw up.getException();return ref.getDownloadUrl();})
                    .continueWith(urlTask->{
                        try{tmp.delete();compressed.delete();}catch(Exception ignored){}
                        if(!urlTask.isSuccessful())throw urlTask.getException();
                        return urlTask.getResult().toString();
                    });
            });
        });
    }

    /** Admin repair pass for existing oversized images and images missing from Storage. */
    public void repairProductImagesCloud(final Runnable done, final Runnable failed){
        if(!isLoggedIn()||!isAdmin()){if(failed!=null)failed.run();return;}
        fs.collection("products").get().addOnSuccessListener(snapshot->{
            java.util.ArrayList<Task<?>> tasks=new java.util.ArrayList<>();
            for(DocumentSnapshot d:snapshot.getDocuments()){
                final int id=parseInt(d.getId()); final String url=str(d.getString("imageUrl"));
                Store.Product local=db.product(id);
                if((url==null||url.isEmpty()) && (local==null||TextUtils.isEmpty(local.image)))continue;
                tasks.add(normalizeCloudImage(id,url).continueWithTask(newUrl->{
                    if(newUrl.isSuccessful()){
                        String u=newUrl.getResult();
                        if(u==null)u="";
                        if(!u.equals(url))return fs.collection("products").document(String.valueOf(id)).update("imageUrl",u,"updatedAt",System.currentTimeMillis(),"updatedBy",uid());
                        return com.google.android.gms.tasks.Tasks.forResult(null);
                    }
                    // Storage object missing or inaccessible: if we have a local image,
                    // restore it from the Admin device instead of leaving a broken URL.
                    Store.Product pLocal=db.product(id);
                    if(pLocal!=null&&!TextUtils.isEmpty(pLocal.image)&&!pLocal.image.startsWith("http://")&&!pLocal.image.startsWith("https://")){
                        return uploadProductImageTask(pLocal).continueWithTask(upload->{
                            if(!upload.isSuccessful())throw upload.getException();
                            String u=upload.getResult()==null?"":upload.getResult();
                            return fs.collection("products").document(String.valueOf(id)).update("imageUrl",u,"updatedAt",System.currentTimeMillis(),"updatedBy",uid());
                        });
                    }
                    throw new RuntimeException(newUrl.getException());
                }));
            }
            if(tasks.isEmpty()){if(done!=null)done.run();return;}
            com.google.android.gms.tasks.Tasks.whenAll(tasks).addOnSuccessListener(v->{if(done!=null)done.run();}).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
        }).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
    }

    private void recordSyncFailure(Exception e){
        lastSyncError=syncErrorText(e);
    }
    private void recordSyncWarning(String message, Exception e){
        if(lastSyncWarning==null||lastSyncWarning.isEmpty()) lastSyncWarning=message;
        if(e!=null && (lastSyncError==null||lastSyncError.isEmpty())) lastSyncError=syncErrorText(e);
    }
    private String syncErrorText(Exception e){
        if(e==null)return "خطأ غير معروف";
        String code="";
        if(e instanceof FirebaseFirestoreException){
            FirebaseFirestoreException f=(FirebaseFirestoreException)e;
            code=f.getCode()==null?"":f.getCode().name();
        } else if(e instanceof com.google.firebase.auth.FirebaseAuthException){
            code=((com.google.firebase.auth.FirebaseAuthException)e).getErrorCode();
        }
        String m=e.getMessage();
        if(m==null||m.trim().isEmpty())m=e.getClass().getSimpleName();
        String project="facturesimple-1b613";
        return (code.isEmpty()?"":code+" — ")+m+"\nFirebase: "+project;
    }
    private Task<Void> applyRemoteProduct(DocumentSnapshot d){
        if(d==null)return com.google.android.gms.tasks.Tasks.forResult(null);
        final int id=parseInt(d.getId());
        final String imageUrl=str(d.getString("imageUrl"));
        ContentValues v=new ContentValues();
        v.put("id",id);
        v.put("name",str(d.getString("name")));
        v.put("code",str(d.getString("code")));
        Double price=d.getDouble("price");
        v.put("price",price==null?0:price);
        // Keep the cloud URL immediately. After the Storage download succeeds,
        // replace it with a local file so the catalog remains usable offline.
        v.put("image",imageUrl);
        db.getWritableDatabase().insertWithOnConflict("products",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);

        if(imageUrl.isEmpty()){
            db.markSyncClean("products",id,remoteTimestamp(d));
            return com.google.android.gms.tasks.Tasks.forResult(null);
        }

        return downloadProductImage(id,imageUrl).continueWith(t->{
            if(t.isSuccessful() && t.getResult()!=null && !t.getResult().isEmpty()){
                ContentValues iv=new ContentValues();
                iv.put("image",t.getResult());
                db.getWritableDatabase().update("products",iv,"id=?",new String[]{String.valueOf(id)});
            } else {
                // Do not fail the whole catalog sync just because one Storage
                // object is temporarily unavailable. The Firebase download URL
                // remains in SQLite and can still be displayed by Glide.
                recordSyncWarning("تعذر تنزيل صورة المنتج "+id+" من Firebase Storage؛ بقي رابط الصورة السحابية محفوظاً.",t.getException());
            }
            db.markSyncClean("products",id,remoteTimestamp(d));
            return null;
        });
    }

    private Store.Customer localCustomerForRemote(DocumentSnapshot d){
        if(d==null||!d.exists())return null;
        Store.Customer c=db.customerByCloudId(d.getId());
        if(c!=null)return c;
        int preferredId=parseInt(d.getId());
        if(preferredId>0){
            Store.Customer byId=db.customer(preferredId);
            Long pi=d.getLong("partnerId");int rp=pi==null?0:pi.intValue();
            boolean rr=Boolean.TRUE.equals(d.getBoolean("reseller"));
            if(byId!=null && (byId.cloudId==null||byId.cloudId.isEmpty()) && byId.partnerId==rp && byId.reseller==rr) return byId;
        }
        return null;
    }

    private boolean isCustomerTombstoneForCloudId(String cloudId){
        if(cloudId==null || cloudId.trim().isEmpty()) return false;
        Cursor c=db.getReadableDatabase().query("sync_meta",new String[]{"local_id"},
                "entity=? AND state=? AND deleted=1 AND cloud_key=?",
                new String[]{"customers","dirty",cloudId},null,null,null,"1");
        try{return c.moveToFirst();}finally{c.close();}
    }

    private void syncCustomersBidirectional(final Runnable done, final Runnable failed) {
        fs.collection("customers").get().addOnSuccessListener(remote->{
            java.util.HashMap<String,DocumentSnapshot> remoteMap=new java.util.HashMap<>();
            for(DocumentSnapshot d:remote.getDocuments()) remoteMap.put(d.getId(),d);
            java.util.ArrayList<Task<Void>> tasks=new java.util.ArrayList<>();
            // Resolve cloud records against local records without allowing a remote pull to overwrite a newer local edit.
            for(DocumentSnapshot r:remote.getDocuments()){
                // A local deletion may race the Firestore listener. Do not recreate
                // the customer from the just-arrived snapshot while its tombstone
                // is still waiting to be uploaded.
                if(isCustomerTombstoneForCloudId(r.getId())) continue;
                Store.Customer local=localCustomerForRemote(r);
                if(local==null){
                    tasks.add(applyRemoteCustomer(r));
                }else{
                    if(local.cloudId==null||local.cloudId.isEmpty()) db.setCustomerCloudId(local.id,r.getId());
                    long lt=db.syncLocalUpdatedAt("customers",local.id), rt=remoteTimestamp(r);
                    if("dirty".equals(db.syncState("customers",local.id)) && lt>=rt) tasks.add(pushLocalCustomer(local.id));
                    else tasks.add(applyRemoteCustomer(r));
                }
            }
            // Push local rows that have no cloud counterpart.
            android.database.Cursor lc=db.getReadableDatabase().query("customers",new String[]{"id"},null,null,null,null,null);
            try{while(lc.moveToNext()){
                int id=lc.getInt(0); Store.Customer c=db.customer(id); if(c==null||!"dirty".equals(db.syncState("customers",id))) continue;
                String key=(c.cloudId==null||c.cloudId.isEmpty())?String.valueOf(id):c.cloudId;
                if(!remoteMap.containsKey(key)) tasks.add(pushLocalCustomer(id));
            }}finally{lc.close();}
            // If a customer was deleted from another device, remove the stale
            // clean local copy instead of making it reappear on the Admin phone.
            android.database.Cursor missing=db.getReadableDatabase().query("customers",new String[]{"id","cloud_id"},null,null,null,null,null);
            try{while(missing.moveToNext()){
                int id=missing.getInt(0);
                String key=missing.isNull(1)?"":missing.getString(1);
                if(key.isEmpty()) key=String.valueOf(id);
                if(remoteMap.containsKey(key)) continue;
                if("dirty".equals(db.syncState("customers",id))) continue;
                db.getWritableDatabase().delete("customers","id=?",new String[]{String.valueOf(id)});
            }}finally{missing.close();}

            // Propagate local customer deletions.
            android.database.Cursor dc=db.getReadableDatabase().query("sync_meta",new String[]{"local_id"},"entity=? AND state=? AND deleted=1",new String[]{"customers","dirty"},null,null,null);
            try{while(dc.moveToNext()){
                int id=dc.getInt(0); String key=db.syncCloudKey("customers",id); if(key==null||key.isEmpty())key=String.valueOf(id); DocumentSnapshot r=remoteMap.get(key);
                if(r!=null) tasks.add(fs.collection("customers").document(key).delete().continueWith(t->{if(!t.isSuccessful())throw t.getException();db.markSyncClean("customers",id,System.currentTimeMillis());return null;}));
            }}finally{dc.close();}
            if(tasks.isEmpty()){if(done!=null)done.run();return;}
            com.google.android.gms.tasks.Tasks.whenAll(tasks).addOnSuccessListener(v->{if(done!=null)done.run();}).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
        }).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
    }
    private boolean localCustomerExists(int id){Cursor c=db.getReadableDatabase().query("customers",new String[]{"id"},"id=?",new String[]{String.valueOf(id)},null,null,null);try{return c.moveToFirst();}finally{c.close();}}
    private Task<Void> pushLocalCustomer(int id){
        Store.Customer x=db.customer(id);
        if(x==null)return com.google.android.gms.tasks.Tasks.forResult(null);
        long ts=Math.max(System.currentTimeMillis(),db.syncLocalUpdatedAt("customers",id));
        String cloudId=(x.cloudId==null?"":x.cloudId.trim());
        if(cloudId.isEmpty()) cloudId=isAdmin()?String.valueOf(id):("p"+partnerId+"_"+java.util.UUID.randomUUID().toString());
        final String finalCloudId=cloudId;
        Map<String,Object> m=new HashMap<>();
        m.put("name",x.name);m.put("phone",x.phone);m.put("city",x.city);m.put("address",x.address);
        if(isAdmin()){
            m.put("reseller",x.reseller);m.put("partnerId",x.partnerId);m.put("partnerUid",x.partnerUid==null?"":x.partnerUid);m.put("partner_email",x.partnerEmail==null?"":x.partnerEmail);m.put("defaultShipping",x.defaultShipping);
        }else{
            // Partner accounts may only own normal customers belonging to their Partner ID.
            if(x.reseller || x.partnerId!=(int)partnerId) return com.google.android.gms.tasks.Tasks.forException(new IllegalStateException("لا يمكن للشريك مزامنة زبون خارج حسابه"));
            m.put("partnerId",partnerId);m.put("reseller",false);m.put("defaultShipping",30);m.put("partnerUid",uid());m.put("partner_email",email()==null?"":email());
        }
        m.put("localId",id);m.put("updatedAt",ts);m.put("updatedBy",uid());
        return fs.collection("customers").document(finalCloudId).get().continueWithTask(read->{
            if(!read.isSuccessful()) throw read.getException();
            boolean exists=read.getResult()!=null&&read.getResult().exists();
            Map<String,Object> payload=new HashMap<>(m);
            if(exists && !isAdmin()){
                // Firestore rules intentionally restrict partner updates to the four customer fields + timestamps.
                payload.clear();payload.put("name",x.name);payload.put("phone",x.phone);payload.put("city",x.city);payload.put("address",x.address);payload.put("updatedAt",ts);payload.put("updatedBy",uid());
            }
            return fs.collection("customers").document(finalCloudId).set(payload,SetOptions.merge());
        }).continueWith(t->{
            if(!t.isSuccessful())throw t.getException();
            db.setCustomerCloudId(id,finalCloudId);db.markSyncClean("customers",id,ts);db.setSyncCloudKey("customers",id,finalCloudId);return null;
        });
    }

    private Task<Void> applyRemoteCustomer(DocumentSnapshot d){
        if(d==null||!d.exists())return com.google.android.gms.tasks.Tasks.forResult(null);
        String cloudId=d.getId();
        int preferredId=parseInt(cloudId);
        Store.Customer existing=db.customerByCloudId(cloudId);
        Long pi=d.getLong("partnerId");int partner=(pi==null?0:pi.intValue());
        boolean reseller=Boolean.TRUE.equals(d.getBoolean("reseller"));
        boolean usePreferredId=false;
        if(existing==null && preferredId>0){
            Store.Customer byId=db.customer(preferredId);
            if(byId==null) usePreferredId=true;
            else if((byId.cloudId==null||byId.cloudId.isEmpty()) && byId.partnerId==partner && byId.reseller==reseller){ existing=byId; }
        }
        ContentValues v=new ContentValues();
        if(existing!=null) v.put("id",existing.id);
        else if(usePreferredId) v.put("id",preferredId);
        v.put("name",str(d.getString("name")));v.put("phone",str(d.getString("phone")));v.put("city",str(d.getString("city")));v.put("address",str(d.getString("address")));v.put("reseller",reseller?1:0);v.put("partner_id",partner);v.put("partner_uid",str(d.getString("partnerUid")));v.put("partner_email",str(d.getString("partner_email")));Double sh=d.getDouble("defaultShipping");v.put("default_shipping",sh==null?30:sh);v.put("cloud_id",cloudId);
        int localId=existing==null? (int)db.getWritableDatabase().insert("customers",null,v) : existing.id;
        if(existing!=null) db.getWritableDatabase().update("customers",v,"id=?",new String[]{String.valueOf(localId)});
        if(localId<=0) throw new IllegalStateException("Unable to store remote customer");
        db.markSyncClean("customers",localId,remoteTimestamp(d));
        return com.google.android.gms.tasks.Tasks.forResult(null);
    }

    private void syncInvoicesBidirectional(final Runnable done, final Runnable failed) {
        fs.collection("invoices").get().addOnSuccessListener(remote->{
            java.util.HashMap<Integer,DocumentSnapshot> map=new java.util.HashMap<>();for(DocumentSnapshot d:remote.getDocuments())map.put(parseInt(d.getId()),d);
            java.util.ArrayList<Integer> ids=new java.util.ArrayList<>();android.database.Cursor mc=db.getReadableDatabase().query("sync_meta",null,"entity=?",new String[]{"invoices"},null,null,null);try{while(mc.moveToNext())ids.add(mc.getInt(mc.getColumnIndexOrThrow("local_id")));}finally{mc.close();}
            android.database.Cursor lc=db.getReadableDatabase().query("invoices",new String[]{"id"},null,null,null,null,null);try{while(lc.moveToNext())if(!ids.contains(lc.getInt(0)))ids.add(lc.getInt(0));}finally{lc.close();}
            java.util.ArrayList<Task<Void>> tasks=new java.util.ArrayList<>();
            for(Integer id:ids){DocumentSnapshot r=map.get(id);long lt=db.syncLocalUpdatedAt("invoices",id),rt=remoteTimestamp(r);boolean tomb="dirty".equals(db.syncState("invoices",id))&&!localInvoiceExists(id);
                if(tomb){if(r==null||lt>=rt)tasks.add(fs.collection("invoices").document(String.valueOf(id)).delete().continueWith(t->{db.markSyncClean("invoices",id,lt);return null;}));else tasks.add(applyRemoteInvoice(r));}
                else if(r==null||lt>=rt)tasks.add(pushLocalInvoice(id)); else tasks.add(applyRemoteInvoice(r));}
            if(tasks.isEmpty()){if(done!=null)done.run();return;}com.google.android.gms.tasks.Tasks.whenAll(tasks).addOnSuccessListener(v->{if(done!=null)done.run();}).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
        }).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
    }
    private boolean localInvoiceExists(int id){Cursor c=db.getReadableDatabase().query("invoices",new String[]{"id"},"id=?",new String[]{String.valueOf(id)},null,null,null);try{return c.moveToFirst();}finally{c.close();}}
    private Task<Void> pushLocalInvoice(int id){ return pushLocalInvoice(id,null); }

    private Task<Void> pushLocalInvoice(int id, DocumentSnapshot remote){
        Store.Invoice x=db.invoice(id);
        if(x==null)return com.google.android.gms.tasks.Tasks.forResult(null);
        long ts=Math.max(System.currentTimeMillis(),db.syncLocalUpdatedAt("invoices",id));
        Map<String,Object> m=new HashMap<>();
        m.put("client_id",x.clientId);m.put("client",x.client);m.put("customer_phone",x.customerPhone);m.put("customer_city",x.customerCity);m.put("customer_address",x.customerAddress);m.put("customer_type",x.customerType);m.put("date",x.date);m.put("paid",x.paid);m.put("reseller",x.reseller);m.put("delivery_received",x.deliveryReceived);m.put("tracking_number",x.trackingNumber);m.put("commission",x.commission);m.put("partner_id",x.partnerId);m.put("shipping_enabled",x.shippingEnabled);m.put("shipping_charge",x.shippingCharge);m.put("shipping_cost",x.shippingCost);m.put("partner_profit_paid",x.partnerProfitPaid);m.put("paid_date",x.paidDate);m.put("delivery_received_date",x.deliveryReceivedDate);m.put("delivery_failure_reason",x.deliveryFailureReason);m.put("partner_profit_paid_date",x.partnerProfitPaidDate);m.put("shipping_company",x.shippingCompany);m.put("shipping_account",x.shippingAccount);m.put("shipped_by_admin",x.shippedByAdmin);m.put("updatedAt",ts);m.put("updatedBy",uid());

        // Partner updates are deliberately restricted to the same fields allowed by
        // firestore.rules. On an existing cloud invoice, do not send protected
        // fields such as paid/delivery/shipped_by_admin back from a stale phone.
        if(!isAdmin() && remote!=null && remote.exists()){
            Map<String,Object> allowed=new HashMap<>();
            allowed.put("client_id",x.clientId);
            allowed.put("client",x.client);
            allowed.put("customer_phone",x.customerPhone);
            allowed.put("customer_city",x.customerCity);
            allowed.put("customer_address",x.customerAddress);
            allowed.put("customer_type",x.customerType);
            allowed.put("shipping_enabled",x.shippingEnabled);
            allowed.put("shipping_charge",x.shippingCharge);
            allowed.put("shipping_company",x.shippingCompany);
            allowed.put("commission",x.commission);
            allowed.put("updatedAt",ts);
            allowed.put("updatedBy",uid());
            m=allowed;
        }

        return fs.collection("invoices").document(String.valueOf(id)).set(m,SetOptions.merge())
                .continueWithTask(t->{if(!t.isSuccessful())throw t.getException();return uploadInvoiceItems(id);})
                .continueWith(t->{if(!t.isSuccessful())throw t.getException();db.markSyncClean("invoices",id,ts);return null;});
    }
    private Task<Void> applyRemoteInvoice(DocumentSnapshot d){
        int id=parseInt(d.getId());ContentValues v=new ContentValues();v.put("id",id);putS(v,"client_id",d.getLong("client_id"));putS(v,"client",d.getString("client"));putS(v,"customer_phone",d.getString("customer_phone"));putS(v,"customer_city",d.getString("customer_city"));putS(v,"customer_address",d.getString("customer_address"));putS(v,"customer_type",d.getString("customer_type"));putS(v,"date",d.getString("date"));putB(v,"paid",d.getBoolean("paid"));putB(v,"reseller",d.getBoolean("reseller"));putB(v,"delivery_received",d.getBoolean("delivery_received"));putS(v,"tracking_number",d.getString("tracking_number"));putD(v,"commission",d.getDouble("commission"));putS(v,"partner_id",d.getLong("partner_id"));putB(v,"shipping_enabled",d.getBoolean("shipping_enabled"));putD(v,"shipping_charge",d.getDouble("shipping_charge"));putD(v,"shipping_cost",d.getDouble("shipping_cost"));putB(v,"partner_profit_paid",d.getBoolean("partner_profit_paid"));putS(v,"paid_date",d.getString("paid_date"));putS(v,"delivery_received_date",d.getString("delivery_received_date"));putS(v,"delivery_failure_reason",d.getString("delivery_failure_reason"));putS(v,"partner_profit_paid_date",d.getString("partner_profit_paid_date"));putS(v,"shipping_company",d.getString("shipping_company"));putS(v,"shipping_account",d.getString("shipping_account"));putB(v,"shipped_by_admin",d.getBoolean("shipped_by_admin"));db.getWritableDatabase().insertWithOnConflict("invoices",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);db.markSyncClean("invoices",id,remoteTimestamp(d));return fs.collection("invoices").document(String.valueOf(id)).collection("items").get().continueWith(t->{if(!t.isSuccessful())throw t.getException();android.database.sqlite.SQLiteDatabase local=db.getWritableDatabase();local.delete("invoice_items","invoice_id=?",new String[]{String.valueOf(id)});for(DocumentSnapshot it:t.getResult().getDocuments()){ContentValues x=new ContentValues();x.put("id",parseInt(it.getId()));x.put("invoice_id",id);x.put("product_id",it.getLong("productId")==null?0:it.getLong("productId"));x.put("name",str(it.getString("name")));Double p=it.getDouble("price"),sp=it.getDouble("salePrice");Long q=it.getLong("qty");x.put("price",p==null?0:p);x.put("sale_price",sp==null?0:sp);x.put("qty",q==null?0:q);local.insertWithOnConflict("invoice_items",null,x,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);}return null;});
    }

    private long remoteTimestamp(DocumentSnapshot d){if(d==null||!d.exists())return 0;Long x=d.getLong("updatedAt");return x==null?0:x;}
    private static class CursorCompat { private final android.database.Cursor c; CursorCompat(android.database.Cursor x){c=x;} boolean moveToNext(){return c.moveToNext();} int id(){return c.getInt(c.getColumnIndexOrThrow("local_id"));} void close(){c.close();} }

    /**
     * Phase 3.2: synchronize the local product catalog and its main images.
     * Firestore keeps product metadata + imageUrl; Firebase Storage keeps the
     * binary image at products/{id}/main.jpg. The local database is never
     * replaced by a remote URL on the Admin device.
     */
    public void syncProductsToCloud(final Runnable done, final Runnable failed) {
        if (!isLoggedIn() || !isAdmin()) { if (failed != null) failed.run(); return; }
        syncProducts(done, failed);
    }

    private void syncProducts(Runnable done, Runnable failed) {
        android.database.Cursor c = db.getReadableDatabase().query("products", null, null, null, null, null, "id ASC");
        java.util.ArrayList<Store.Product> products = new java.util.ArrayList<>();
        try {
            while (c.moveToNext()) {
                int id=c.getInt(c.getColumnIndexOrThrow("id"));
                String name=c.getString(c.getColumnIndexOrThrow("name"));
                String code=c.getString(c.getColumnIndexOrThrow("code"));
                double price=c.getDouble(c.getColumnIndexOrThrow("price"));
                String image=c.getString(c.getColumnIndexOrThrow("image"));
                products.add(new Store.Product(id,name,code,price,image));
            }
        } finally { c.close(); }

        if (products.isEmpty()) { if (done != null) done.run(); return; }
        final int[] remaining={products.size()};
        final boolean[] failedOnce={false};
        for (Store.Product product: products) {
            uploadOrReuseProductImage(product, imageUrl -> {
                Map<String,Object> m=new HashMap<>();
                m.put("name", product.name);
                m.put("code", product.code);
                m.put("price", product.price);
                m.put("imageUrl", imageUrl == null ? "" : imageUrl);
                m.put("updatedAt", System.currentTimeMillis());
                m.put("updatedBy", uid());
                fs.collection("products").document(String.valueOf(product.id)).set(m, SetOptions.merge())
                    .addOnSuccessListener(v -> {
                        if (--remaining[0]==0 && !failedOnce[0] && done!=null) done.run();
                    })
                    .addOnFailureListener(e -> {
                        if (!failedOnce[0]) { failedOnce[0]=true; if(failed!=null)failed.run(); }
                    });
            }, e -> {
                if (!failedOnce[0]) { failedOnce[0]=true; if(failed!=null)failed.run(); }
            });
        }
    }

    private interface ImageUrlCallback { void onResult(String url); }
    private interface ErrorCallback { void onError(Exception e); }

    private void uploadOrReuseProductImage(Store.Product product, ImageUrlCallback ok, ErrorCallback bad) {
        uploadProductImageTask(product)
            .addOnSuccessListener(ok::onResult)
            .addOnFailureListener(bad::onError);
    }

    /** Upload all local customers. Admin-only because partners must never write customer data. */
    private void syncCustomersToCloud(final Runnable done, final Runnable failed) {
        android.database.Cursor c=db.getReadableDatabase().query("customers",null,null,null,null,null,"id ASC");
        java.util.ArrayList<Map<String,Object>> docs=new java.util.ArrayList<>();
        try {
            while(c.moveToNext()) {
                int id=c.getInt(c.getColumnIndexOrThrow("id"));
                Map<String,Object> m=new HashMap<>();
                m.put("name",c.getString(c.getColumnIndexOrThrow("name")));
                m.put("phone",c.getString(c.getColumnIndexOrThrow("phone")));
                m.put("city",c.getString(c.getColumnIndexOrThrow("city")));
                m.put("address",c.getString(c.getColumnIndexOrThrow("address")));
                m.put("reseller",c.getInt(c.getColumnIndexOrThrow("reseller"))==1);
                m.put("partnerId",c.getInt(c.getColumnIndexOrThrow("partner_id")));
                int puIdx=c.getColumnIndex("partner_uid"), peIdx=c.getColumnIndex("partner_email");
                m.put("partnerUid",puIdx>=0 && !c.isNull(puIdx)?c.getString(puIdx):"");
                m.put("partner_email",peIdx>=0 && !c.isNull(peIdx)?c.getString(peIdx):"");
                m.put("defaultShipping",c.getDouble(c.getColumnIndexOrThrow("default_shipping")));
                m.put("updatedAt",System.currentTimeMillis());
                m.put("updatedBy",uid());
                Map<String,Object> row=new HashMap<>(); row.put("id",id); row.put("data",m); docs.add(row);
            }
        } finally { c.close(); }
        if(docs.isEmpty()){ if(done!=null)done.run(); return; }
        final int[] remaining={docs.size()}; final boolean[] failedOnce={false};
        for(Map<String,Object> row:docs){
            int id=((Number)row.get("id")).intValue();
            fs.collection("customers").document(String.valueOf(id)).set((Map<String,Object>)row.get("data"),SetOptions.merge())
                .addOnSuccessListener(v->{if(--remaining[0]==0&&!failedOnce[0]&&done!=null)done.run();})
                .addOnFailureListener(e->{if(!failedOnce[0]){failedOnce[0]=true;recordSyncFailure(e);if(failed!=null)failed.run();}});
        }
    }

    /** Upload all local invoices and wait for every invoice's item subcollection. */
    private void syncInvoicesToCloud(final Runnable done, final Runnable failed){
        android.database.Cursor c=db.getReadableDatabase().query("invoices",null,null,null,null,null,"id ASC");
        java.util.ArrayList<Integer> ids=new java.util.ArrayList<>();
        java.util.HashMap<Integer,Map<String,Object>> rows=new java.util.HashMap<>();
        String[] cols={"client_id","client","customer_phone","customer_city","customer_address","customer_type","date","paid","reseller","delivery_received","tracking_number","commission","partner_id","shipping_enabled","shipping_charge","shipping_cost","partner_profit_paid","paid_date","delivery_received_date","delivery_failure_reason","partner_profit_paid_date","shipping_company","shipping_account","shipped_by_admin"};
        try{
            while(c.moveToNext()){
                int id=c.getInt(c.getColumnIndexOrThrow("id")); ids.add(id); Map<String,Object> m=new HashMap<>();
                for(String col:cols){int idx=c.getColumnIndex(col);if(idx<0)continue;Object val;if(c.isNull(idx))val=null;else if(col.equals("client")||col.equals("customer_phone")||col.equals("customer_city")||col.equals("customer_address")||col.equals("customer_type")||col.contains("date")||col.equals("tracking_number")||col.equals("delivery_failure_reason")||col.equals("shipping_company")||col.equals("shipping_account"))val=c.getString(idx);else if(col.equals("commission")||col.equals("shipping_charge")||col.equals("shipping_cost"))val=c.getDouble(idx);else val=c.getInt(idx);m.put(col,val);} 
                m.put("updatedAt",System.currentTimeMillis()); m.put("updatedBy",uid()); rows.put(id,m);
            }
        }finally{c.close();}
        if(ids.isEmpty()){if(done!=null)done.run();return;}
        final int[] remaining={ids.size()}; final boolean[] failedOnce={false};
        for(Integer invoiceId:ids){
            fs.collection("invoices").document(String.valueOf(invoiceId)).set(rows.get(invoiceId),SetOptions.merge())
                .continueWithTask(t->{if(!t.isSuccessful())throw t.getException();return uploadInvoiceItems(invoiceId);})
                .addOnSuccessListener(v->{if(--remaining[0]==0&&!failedOnce[0]&&done!=null)done.run();})
                .addOnFailureListener(e->{if(!failedOnce[0]){failedOnce[0]=true;recordSyncFailure(e);if(failed!=null)failed.run();}});
        }
    }

    private Task<Void> uploadInvoiceItems(int invoiceId){
        android.database.Cursor c=db.getReadableDatabase().query("invoice_items",null,"invoice_id=?",new String[]{String.valueOf(invoiceId)},null,null,"id ASC");
        final java.util.HashMap<Integer,Map<String,Object>> localItems=new java.util.HashMap<>();
        try{while(c.moveToNext()){
            int itemId=c.getInt(c.getColumnIndexOrThrow("id")); Map<String,Object> m=new HashMap<>();
            m.put("productId",c.getInt(c.getColumnIndexOrThrow("product_id")));
            m.put("name",c.getString(c.getColumnIndexOrThrow("name")));
            m.put("price",c.getDouble(c.getColumnIndexOrThrow("price")));
            m.put("salePrice",c.getDouble(c.getColumnIndexOrThrow("sale_price")));
            m.put("qty",c.getInt(c.getColumnIndexOrThrow("qty")));
            localItems.put(itemId,m);
        }}finally{c.close();}
        return fs.collection("invoices").document(String.valueOf(invoiceId)).collection("items").get().continueWithTask(t->{
            if(!t.isSuccessful())throw t.getException();
            WriteBatch batch=fs.batch();
            java.util.HashSet<Integer> remoteIds=new java.util.HashSet<>();
            for(DocumentSnapshot d:t.getResult().getDocuments()){int rid=parseInt(d.getId());remoteIds.add(rid);if(!localItems.containsKey(rid))batch.delete(d.getReference());}
            for(Map.Entry<Integer,Map<String,Object>> e:localItems.entrySet()) batch.set(fs.collection("invoices").document(String.valueOf(invoiceId)).collection("items").document(String.valueOf(e.getKey())),e.getValue(),SetOptions.merge());
            return batch.commit();
        });
    }

    private Task<Void> syncShippingCompaniesToCloud(final Runnable done, final Runnable failed){
        try{
            java.util.HashMap<Integer,Store.ShippingCompany> local=new java.util.HashMap<>();
            for(Store.ShippingCompany x:db.shippingCompanies()) local.put(x.id,x);
            return fs.collection("shipping_companies").get().continueWithTask(t->{
                if(!t.isSuccessful())throw t.getException();
                WriteBatch b=fs.batch();java.util.HashSet<Integer> remote=new java.util.HashSet<>();
                for(DocumentSnapshot d:t.getResult().getDocuments()){int id=parseInt(d.getId());remote.add(id);if(!local.containsKey(id))b.delete(d.getReference());}
                long now=System.currentTimeMillis();
                for(Store.ShippingCompany x:local.values()){Map<String,Object> m=new HashMap<>();m.put("name",x.name);m.put("updatedAt",now);b.set(fs.collection("shipping_companies").document(String.valueOf(x.id)),m,SetOptions.merge());}
                return b.commit();
            }).addOnSuccessListener(v->{if(done!=null)done.run();}).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
        }catch(Exception e){recordSyncFailure(e);if(failed!=null)failed.run();return com.google.android.gms.tasks.Tasks.forResult(null);}
    }

    private void syncShippingCompaniesFromCloud(final Runnable done, final Runnable failed){
        fs.collection("shipping_companies").get().addOnSuccessListener(remote->{
            if(remote.isEmpty()){if(done!=null)done.run();return;}
            android.database.sqlite.SQLiteDatabase local=db.getWritableDatabase();
            local.delete("shipping_accounts",null,null);local.delete("shipping_companies",null,null);
            for(DocumentSnapshot d:remote.getDocuments()){ContentValues v=new ContentValues();v.put("id",parseInt(d.getId()));v.put("name",str(d.getString("name")));local.insertWithOnConflict("shipping_companies",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);}
            // Partner accounts are intentionally never downloaded.
            if(done!=null)done.run();
        }).addOnFailureListener(e->{
            recordSyncWarning("تعذر تحديث شركات الشحن، لكن ستستمر مزامنة المنتجات والعملاء والفواتير.",e);
            if(done!=null)done.run();
        });
    }

    /** Pull the cloud catalog and the current partner's customers/invoices into local SQLite. */
    public void syncCloudToLocalForPartner(final Runnable done, final Runnable failed) {
        lastSyncError=""; lastSyncWarning="";
        if (!isLoggedIn() || isAdmin() || partnerId <= 0) { lastSyncError="حساب الشريك غير صالح أو غير مسجل الدخول"; if (failed != null) failed.run(); return; }
        // نجدد رمز Firebase قبل كل مزامنة، وهذا مهم خصوصاً عند تثبيت التطبيق على هاتف جديد.
        refreshAuthToken().addOnSuccessListener(v -> {
            syncShippingCompaniesFromCloud(() -> {
                syncProductsFromCloud(() -> {
                    syncPartnerCustomersBidirectional(() -> {
                        syncPartnerInvoicesBidirectional(done, failed);
                    }, failed);
                }, failed);
            }, failed);
        }).addOnFailureListener(e -> {
            recordSyncFailure(e);
            if(failed != null) failed.run();
        });
    }

    private void syncPartnerInvoicesBidirectional(final Runnable done, final Runnable failed){
        // Pull the partner's cloud invoices first so we can compare timestamps and
        // avoid sending a stale local invoice back to a document that the Admin has
        // already shipped/locked. This was a major source of partner sync failures.
        fs.collection("invoices").whereEqualTo("partner_id",partnerId).get().addOnSuccessListener(remote->{
            final java.util.HashMap<Integer,DocumentSnapshot> remoteMap=new java.util.HashMap<>();
            for(DocumentSnapshot d:remote.getDocuments()) remoteMap.put(parseInt(d.getId()),d);

            java.util.ArrayList<Integer> localDirty=new java.util.ArrayList<>();
            android.database.Cursor c=db.getReadableDatabase().query("sync_meta",new String[]{"local_id"},"entity=? AND state=?",new String[]{"invoices","dirty"},null,null,"local_id ASC");
            try{
                while(c.moveToNext()){
                    int id=c.getInt(0);
                    Store.Invoice inv=db.invoice(id);
                    if(inv!=null && inv.partnerId==partnerId && !inv.shippedByAdmin) localDirty.add(id);
                }
            }finally{c.close();}

            java.util.ArrayList<Task<Void>> tasks=new java.util.ArrayList<>();
            for(Integer id:localDirty){
                Store.Invoice local=db.invoice(id);
                DocumentSnapshot r=remoteMap.get(id);
                if(local==null) continue;

                // If the Admin has already shipped/locked the cloud invoice, never
                // attempt a partner update. Pull the authoritative cloud version.
                if(r!=null && Boolean.TRUE.equals(r.getBoolean("shipped_by_admin"))){
                    tasks.add(applyRemoteInvoice(r));
                    continue;
                }

                long localTs=db.syncLocalUpdatedAt("invoices",id);
                long remoteTs=remoteTimestamp(r);
                if(r==null || localTs>=remoteTs){
                    tasks.add(pushLocalInvoice(id,r));
                }else{
                    tasks.add(applyRemoteInvoice(r));
                }
            }

            Task<Void> reconcile=tasks.isEmpty()
                    ? com.google.android.gms.tasks.Tasks.forResult(null)
                    : com.google.android.gms.tasks.Tasks.whenAll(tasks);
            reconcile.addOnSuccessListener(v->syncInvoicesFromCloud(done,failed))
                .addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
        }).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
    }

    private void syncProductsFromCloud(final Runnable done, final Runnable failed){
        fs.collection("products").get().addOnSuccessListener(products -> {
            java.util.List<com.google.firebase.firestore.DocumentSnapshot> docs=products.getDocuments();
            if(docs.isEmpty()){if(done!=null)done.run();return;}
            final int[] remaining={docs.size()};
            android.database.sqlite.SQLiteDatabase local=db.getWritableDatabase();
            for(com.google.firebase.firestore.DocumentSnapshot d:docs){
                final int pid=parseInt(d.getId());
                final String imageUrl=str(d.getString("imageUrl"));
                ContentValues v=new ContentValues();
                v.put("id",pid); v.put("name",str(d.getString("name"))); v.put("code",str(d.getString("code")));
                Double price=d.getDouble("price"); v.put("price",price==null?0:price);
                // Keep the cloud URL immediately; then replace it with a local cached copy when possible.
                v.put("image",imageUrl);
                local.insertWithOnConflict("products",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);
                if(imageUrl.isEmpty()){
                    if(--remaining[0]==0&&done!=null)done.run();
                    continue;
                }
                downloadProductImage(pid,imageUrl).addOnSuccessListener(path->{
                    if(path!=null&&!path.isEmpty()){
                        ContentValues iv=new ContentValues(); iv.put("image",path);
                        db.getWritableDatabase().update("products",iv,"id=?",new String[]{String.valueOf(pid)});
                    }
                    if(--remaining[0]==0&&done!=null)done.run();
                }).addOnFailureListener(e->{
                    // Image download must not make the whole cloud sync fail.
                    recordSyncWarning("تعذر تنزيل صورة المنتج "+pid+"؛ تم تنزيل بيانات المنتج.",e);
                    if(--remaining[0]==0&&done!=null)done.run();
                });
            }
        }).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
    }

    private Task<String> downloadProductImage(int productId,String imageUrl){
        try{
            File dir=new File(context.getFilesDir(),"product_images");
            if(!dir.exists()&&!dir.mkdirs()) return com.google.android.gms.tasks.Tasks.forException(new IllegalStateException("تعذر إنشاء مجلد صور المنتجات"));
            File out=new File(dir,"cloud_"+productId+".jpg");
            return storage.getReference().child("products/"+productId+"/main.jpg").getFile(out).continueWith(t->{
                if(!t.isSuccessful()) throw t.getException();
                return Uri.fromFile(out).toString();
            });
        }catch(Exception e){return com.google.android.gms.tasks.Tasks.forException(e);}
    }

    private void syncCustomersFromCloud(final Runnable done, final Runnable failed){
        fs.collection("customers").whereEqualTo("partnerId",partnerId).get().addOnSuccessListener(customers->{
            android.database.sqlite.SQLiteDatabase local=db.getWritableDatabase();
            for(com.google.firebase.firestore.DocumentSnapshot d:customers.getDocuments()){
                ContentValues v=new ContentValues();v.put("id",parseInt(d.getId()));v.put("name",str(d.getString("name")));v.put("phone",str(d.getString("phone")));v.put("city",str(d.getString("city")));v.put("address",str(d.getString("address")));v.put("reseller",Boolean.TRUE.equals(d.getBoolean("reseller"))?1:0);v.put("partner_id",partnerId);v.put("partner_uid",str(d.getString("partnerUid")));v.put("partner_email",str(d.getString("partner_email")));Double sh=d.getDouble("defaultShipping");v.put("default_shipping",sh==null?30:sh);local.insertWithOnConflict("customers",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);
            }
            if(done!=null)done.run();
        }).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
    }

    private void syncPartnerCustomersBidirectional(final Runnable done, final Runnable failed){
        fs.collection("customers").whereEqualTo("partnerId",partnerId).get().addOnSuccessListener(remote->{
            java.util.HashMap<String,DocumentSnapshot> remoteMap=new java.util.HashMap<>();
            for(DocumentSnapshot d:remote.getDocuments()) if(!Boolean.TRUE.equals(d.getBoolean("reseller"))) remoteMap.put(d.getId(),d);
            java.util.ArrayList<Task<Void>> tasks=new java.util.ArrayList<>();
            for(DocumentSnapshot r:remote.getDocuments()){
                if(Boolean.TRUE.equals(r.getBoolean("reseller"))) continue;
                if(isCustomerTombstoneForCloudId(r.getId())) continue;
                Store.Customer local=localCustomerForRemote(r);
                if(local==null){
                    tasks.add(applyRemoteCustomer(r));
                }else{
                    if(local.cloudId==null||local.cloudId.isEmpty()) db.setCustomerCloudId(local.id,r.getId());
                    long lt=db.syncLocalUpdatedAt("customers",local.id), rt=remoteTimestamp(r);
                    if(local.partnerId==(int)partnerId && "dirty".equals(db.syncState("customers",local.id)) && lt>=rt) tasks.add(pushLocalCustomer(local.id));
                    else tasks.add(applyRemoteCustomer(r));
                }
            }
            android.database.Cursor lc=db.getReadableDatabase().query("customers",new String[]{"id"},"partner_id=? AND reseller=0",new String[]{String.valueOf(partnerId)},null,null,null);
            try{while(lc.moveToNext()){
                int id=lc.getInt(0); Store.Customer c=db.customer(id); if(c==null||!"dirty".equals(db.syncState("customers",id))) continue;
                String key=(c.cloudId==null||c.cloudId.isEmpty())?String.valueOf(id):c.cloudId;
                if(!remoteMap.containsKey(key)) tasks.add(pushLocalCustomer(id));
            }}finally{lc.close();}
            android.database.Cursor dc=db.getReadableDatabase().query("sync_meta",new String[]{"local_id"},"entity=? AND state=? AND deleted=1",new String[]{"customers","dirty"},null,null,null);
            try{while(dc.moveToNext()){int id=dc.getInt(0);String key=db.syncCloudKey("customers",id);if(key==null||key.isEmpty())key=String.valueOf(id);if(remoteMap.containsKey(key))tasks.add(fs.collection("customers").document(key).delete().continueWith(t->{if(!t.isSuccessful())throw t.getException();db.markSyncClean("customers",id,System.currentTimeMillis());return null;}));}}finally{dc.close();}
            if(tasks.isEmpty()){if(done!=null)done.run();return;}
            com.google.android.gms.tasks.Tasks.whenAll(tasks).addOnSuccessListener(v->{if(done!=null)done.run();}).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
        }).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
    }

    private void syncInvoicesFromCloud(final Runnable done, final Runnable failed){
        fs.collection("invoices").whereEqualTo("partner_id",partnerId).get().addOnSuccessListener(invoices->{
            java.util.List<com.google.firebase.firestore.DocumentSnapshot> docs=invoices.getDocuments();
            if(docs.isEmpty()){if(done!=null)done.run();return;}
            final int[] remaining={docs.size()}; final boolean[] failedOnce={false};
            android.database.sqlite.SQLiteDatabase local=db.getWritableDatabase();
            for(com.google.firebase.firestore.DocumentSnapshot d:docs){
                ContentValues v=new ContentValues();v.put("id",parseInt(d.getId()));putS(v,"client_id",d.getLong("client_id"));putS(v,"client",d.getString("client"));putS(v,"customer_phone",d.getString("customer_phone"));putS(v,"customer_city",d.getString("customer_city"));putS(v,"customer_address",d.getString("customer_address"));putS(v,"customer_type",d.getString("customer_type"));putS(v,"date",d.getString("date"));putB(v,"paid",d.getBoolean("paid"));putB(v,"reseller",d.getBoolean("reseller"));putB(v,"delivery_received",d.getBoolean("delivery_received"));putS(v,"tracking_number",d.getString("tracking_number"));putD(v,"commission",d.getDouble("commission"));putS(v,"partner_id",d.getLong("partner_id"));putB(v,"shipping_enabled",d.getBoolean("shipping_enabled"));putD(v,"shipping_charge",d.getDouble("shipping_charge"));putD(v,"shipping_cost",d.getDouble("shipping_cost"));putB(v,"partner_profit_paid",d.getBoolean("partner_profit_paid"));putS(v,"paid_date",d.getString("paid_date"));putS(v,"delivery_received_date",d.getString("delivery_received_date"));putS(v,"delivery_failure_reason",d.getString("delivery_failure_reason"));putS(v,"partner_profit_paid_date",d.getString("partner_profit_paid_date"));putS(v,"shipping_company",d.getString("shipping_company"));putS(v,"shipping_account",d.getString("shipping_account"));putB(v,"shipped_by_admin",d.getBoolean("shipped_by_admin"));local.insertWithOnConflict("invoices",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);
                final int invoiceId=parseInt(d.getId());
                d.getReference().collection("items").get().addOnSuccessListener(items->{
                    local.delete("invoice_items","invoice_id=?",new String[]{String.valueOf(invoiceId)});
                    for(com.google.firebase.firestore.DocumentSnapshot it:items.getDocuments()){ContentValues x=new ContentValues();x.put("id",parseInt(it.getId()));x.put("invoice_id",invoiceId);putS(x,"product_id",it.getLong("productId"));putS(x,"name",it.getString("name"));putD(x,"price",it.getDouble("price"));putD(x,"sale_price",it.getDouble("salePrice"));putS(x,"qty",it.getLong("qty"));local.insertWithOnConflict("invoice_items",null,x,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);}
                    if(--remaining[0]==0&&!failedOnce[0]&&done!=null)done.run();
                }).addOnFailureListener(e->{if(!failedOnce[0]){failedOnce[0]=true;recordSyncFailure(e);if(failed!=null)failed.run();}});
            }
        }).addOnFailureListener(e->{recordSyncFailure(e);if(failed!=null)failed.run();});
    }

    private int parseInt(String s){try{return Integer.parseInt(s);}catch(Exception e){return 0;}}
    private String str(String s){return s==null?"":s;}
    private void putS(ContentValues v,String k,Object o){if(o==null)v.putNull(k);else if(o instanceof Number)v.put(k,((Number)o).longValue());else v.put(k,String.valueOf(o));}
    private void putD(ContentValues v,String k,Double o){if(o==null)v.put(k,0d);else v.put(k,o);}
    private void putB(ContentValues v,String k,Long o){v.put(k,o!=null&&o!=0?1:0);}
    private void putB(ContentValues v,String k,Boolean o){v.put(k,Boolean.TRUE.equals(o)?1:0);}

}
