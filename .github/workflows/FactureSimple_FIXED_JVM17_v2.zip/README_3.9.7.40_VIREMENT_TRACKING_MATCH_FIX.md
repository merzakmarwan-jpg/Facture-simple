# MGE 3.9.7.40 — Virement tracking match final narrow fix

Fixes the remaining OzonExpress case where the PDF contains `Gouna08263107890` followed by `0OM`, while the invoice already stored in MGE contains the same shipment with an extra wrapped zero / `O`-vs-`0` suffix representation (for example `Gouna0826310789000M`).

The lookup now:
- keeps exact and canonical matching first;
- supports the normal route-suffix variants;
- adds one deliberately narrow fallback for the same carrier + numeric tracking core when the only difference is one trailing zero and the short route suffix has the `O`/`0` ambiguity;
- does not broadly fuzzy-match arbitrary tracking numbers.

This is specifically targeted to the failing invoice shown in the supplied screenshots and PDF.

Version: 3.9.7.40
VersionCode: 102
