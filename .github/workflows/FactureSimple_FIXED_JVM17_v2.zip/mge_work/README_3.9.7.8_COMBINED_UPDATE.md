# MGE 3.9.7.8 — Invoice Filters + Edit/Pricing Fix

This release restores all invoice features from 3.9.7.6 and keeps the fixes from 3.9.7.7.

- Search invoices by invoice number, customer name, or customer phone number.
- Filter invoices by Store/shipping account.
- Store filter remains selected after synchronization/rebuilding the invoice list.
- Preserve Store account when editing an invoice.
- Preserve saved shipping amount and actual shipping cost when editing.
- Keep partner settlement price separate from the customer sale price.
- Remember customer-specific sale prices for partner customers.
