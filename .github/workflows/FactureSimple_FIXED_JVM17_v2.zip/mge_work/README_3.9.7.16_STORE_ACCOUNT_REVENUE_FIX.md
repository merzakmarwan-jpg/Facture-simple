# 3.9.7.16 — Store Accounts + Revenue Fix

## Fixed
1. Shipping-company Store accounts are now synchronized with Firestore in `shipping_accounts` instead of only synchronizing company names.
2. Synchronization no longer deletes all local Store accounts when the remote company list is loaded.
3. Existing invoices preserve their original Store account while editing; if an old account is temporarily missing from settings, it is restored into the spinner for that invoice instead of silently switching to another account.
4. Store revenue period filtering uses the Virement date when a Virement exists, otherwise the invoice date. This makes imported shipping-company settlements appear in the accounting period in which the transfer was received/recorded.

## Important for the existing database
Run one successful admin cloud synchronization after installing this build. Existing local Store accounts will be uploaded to Firestore under `shipping_accounts` and will no longer disappear on the next synchronization.
