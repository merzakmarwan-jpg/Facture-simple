# MGE 3.9.7.12 — Offline-safe global invoice numbering

## Changes
- Invoice identity remains the immutable Firestore `cloud_key`/UUID; the visible invoice number is not used as document identity.
- Online creation reserves the next global number using the Firestore counter transaction shared by Admin and Partners.
- Offline creation is allowed immediately and receives a provisional local number. It is never used to overwrite another invoice.
- When internet returns, provisional numbers are finalized through the same global counter. If another device already used that number, the offline invoice receives the next free number automatically without losing or deleting the invoice.
- Existing historical invoices keep their numbers.
- Invoice ordering is now based on `created_at DESC`, so the newest invoices appear first even when their visible numbers are not consecutive.
- Editing an invoice preserves its original `created_at` and invoice number.
- Added SQLite fields: `created_at` and `invoice_number_final`.
- Firestore rules allow safe bootstrap of the shared invoice counter at zero and strict +1 increments afterwards.

## Build
GitHub Actions uses JDK 17, Gradle 8.9 and Android SDK 35.
