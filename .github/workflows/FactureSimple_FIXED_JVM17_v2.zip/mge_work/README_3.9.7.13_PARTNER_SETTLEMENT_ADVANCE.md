# MGE 3.9.7.13

- Hide supplier management from partner home screen.
- Add partner recipient for customer advance payments.
- Persist advance recipient on invoices and sync it with Firebase.
- Deduct only advances received by the selected partner from partner settlement.
- Show selected invoice total, partner profit, partner advances and final payable amount live.
- Save each partner settlement locally with invoice-level snapshot rows for later review.
