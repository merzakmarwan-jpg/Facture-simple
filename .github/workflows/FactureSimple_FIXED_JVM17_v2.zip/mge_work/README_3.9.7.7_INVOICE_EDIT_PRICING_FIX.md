# MGE 3.9.7.8 — Invoice Edit & Partner Pricing Fix

This update is based on **MGE 3.9.7.5 Invoice Filter Persistence** and fixes regressions in invoice editing and partner/customer pricing.

## Fixes

1. **Store account is preserved when editing an invoice**
   - The saved shipping company is restored first.
   - Its Store-account list is rebuilt.
   - The exact Store account saved on the invoice is then restored.
   - Editing no longer silently switches an invoice from one Store account (for example MGE) to another account such as Karamatech.

2. **Customer shipping amount and actual shipping cost are preserved on edit**
   - Existing invoices no longer receive the current default shipping amount of 30 DH merely because the editor refreshes.
   - The invoice's stored `shipping_charge` and `shipping_cost` remain the source of truth while editing.

3. **Partner settlement price is kept separate from customer sale price**
   - `sale_price` = price charged to the partner's customer.
   - `partner_price` = price used to settle the product with the partner.
   - Editing an existing invoice no longer replaces the customer sale price with the partner settlement price.

4. **Remembered prices now work for partner customers too**
   - When a registered customer belongs to a partner, the manually entered customer-facing sale price is saved for that customer/product pair.
   - The next invoice for the same customer and product reuses that last customer price.
   - The partner settlement price remains stored separately.

5. **Existing invoice values are not recalculated just by opening the editor**
   - Editing keeps the invoice's existing customer-facing prices unless the customer is explicitly changed.

## Important pricing example

Product public/customer price: **370 DH**
Partner settlement price: **360 DH**

The partner's customer invoice remains **370 DH**, while the partner settlement remains **360 DH** and the partner margin is **10 DH**.

## Version

**3.9.7.8**


## Restored from 3.9.7.6

6. **Invoice search by customer phone number**
   - The invoice search now accepts invoice number, customer name, or customer phone number.
   - This also works when viewing partner invoices.

7. **Store account filter on the invoices page**
   - Added a Store filter showing only invoices whose saved `shipping_account` matches the selected Store account.
   - The filter works together with partner/normal, delivery status, partner selection, and search filters.

8. **Store filter survives synchronization**
   - The selected Store account is kept in `invoiceStoreFilter` and restored after the invoice screen is rebuilt by synchronization.
