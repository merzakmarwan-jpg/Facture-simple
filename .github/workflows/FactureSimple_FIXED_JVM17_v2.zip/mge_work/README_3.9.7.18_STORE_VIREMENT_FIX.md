# 3.9.7.18 — Store Virement PDF Matching Fix

## Fixed
1. OzonExpress Virement PDFs where the shipment-code suffix is wrapped onto a separate line (for example `SDS082631144171` + `XL`) are now reconstructed as the full tracking code `SDS082631144171XL`.
2. The parser no longer treats the PDF footer `1/1` as a second Colis row.
3. The parser retries PDF extraction using content-stream order when the normal positioned extraction returns the header but no Colis rows.
4. OzonExpress route/source tokens such as `OA`, `RI`, `AP`, and `SE` are not appended to the tracking number.
5. This makes the Virement row match the existing invoice by its exact tracking number, allowing the selected Store account and Virement settlement values to be applied.

## Verified against the supplied OzonExpress PDF
- Virement: `VRT-N-2644628-200826-74-82204`
- Colis: `1`
- Tracking: `SDS082631144171XL`
- CRBT: `3990 DH`
- Frais: `45 DH`
- Net: `3945 DH`

The supplied invoice #14 uses the same tracking number, so after this parser fix the review dialog should report `1` matching invoice instead of `0`.
