# MGE 3.9.7.9 — Partner Login Crash Fix

## Problem
On partner accounts, the application could open normally and then close a few seconds later while the background partner synchronization was running. Admin accounts were not affected.

## Root cause fixed
The partner synchronization of `partner_product_settings` attempted to read the Firestore field `productId` as a String before falling back to a numeric value. The field is normally stored as a Firestore number. On affected Firebase/SDK data this type mismatch could throw from the asynchronous partner-sync callback and terminate the application process.

## Fix
`productId` is now read as a Firestore numeric `Long` first, with a safe String fallback only for legacy documents.

## Preserved features
This version is based on MGE 3.9.7.8 and keeps:
- invoice phone-number search
- Store account invoice filter
- invoice filter persistence during synchronization
- Store/shipping values preserved when editing invoices
- separate partner settlement price and customer sale price
- remembered customer/product sale prices
- supplier/order features and previous PDF/advance-payment updates
