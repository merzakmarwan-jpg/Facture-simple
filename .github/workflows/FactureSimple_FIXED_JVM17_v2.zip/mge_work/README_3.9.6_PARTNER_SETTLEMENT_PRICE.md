# MGE 3.9.6 — Partner settlement price

This update separates the customer-facing sale price from the partner settlement price.

Example:
- Product public price: 370 DH
- Customer invoice sale price: 370 DH
- Partner settlement price: 360 DH
- Partner margin: 10 DH per unit

The partner settlement price is remembered per partner/product and is stored in invoice items as `partner_price`, while `sale_price` remains the price charged to the customer.

Customer-specific remembered prices remain independent.

## 3.9.6.1 BUILD FIX
- Fixed Java compilation error in `Store.java` inside `loadItems()` caused by a variable declaration immediately after a `while` statement without braces.
- The loop now uses explicit braces so `partner_price` is read correctly for each invoice item.
