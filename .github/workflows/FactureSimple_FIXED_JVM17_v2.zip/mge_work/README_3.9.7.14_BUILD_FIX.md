# MGE 3.9.7.14 — Build + offline invoice numbering fix

## Build fixes
- Added the missing `advanceReceivedByPartnerId` field to `Store.Invoice`, matching the existing SQLite column, Firestore mapping, settlement logic and UI code.
- Replaced the unsupported Firestore `Transaction.create(...)` call with `Transaction.set(...)` for safe counter bootstrap.
- `pushInvoiceNow()` now finalizes a provisional offline invoice number through the shared Firestore counter before uploading the invoice. This prevents a provisional number from being published when another device has already reserved the same number.

## Numbering behavior
- Online invoices use the shared atomic Firestore counter for Admin + Partners.
- Offline invoices keep a provisional local number and are never identified by that number; each invoice has its own cloud UUID.
- When connectivity returns, the provisional number is replaced by the next available global number if necessary, without deleting or overwriting the invoice.
- Invoice list ordering remains by `created_at DESC`, so newest invoices appear first regardless of invoice number.

## Version
- versionCode: 88
- versionName: 3.9.7.14
