# MGE 3.9.7.10 — Build Fix

## Fix
The previous 3.9.7.10 source called `Store.setInvoiceAssemblyCompleted(...)` from `MainActivity`, but the corresponding method was missing from `Store.java`, causing the GitHub Actions Java compilation error:

`cannot find symbol: method setInvoiceAssemblyCompleted(int,boolean)`

The method has now been added. It updates only `assembly_completed`, marks the invoice dirty for synchronization, and does not overwrite any other invoice fields.

## GitHub Actions
The APK artifact name in the workflow was also corrected from `MGE-3.9.7.8-APK` to `MGE-3.9.7.10-APK`.
