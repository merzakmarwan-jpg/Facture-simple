# MGE 3.9.4 — Store Revenue Description Height Fix

## Fix
- Fixed the Store revenue page description being clipped because the TextView was given a fixed height of 34dp.
- The description now uses `WRAP_CONTENT`, internal vertical padding, and line spacing so the complete Arabic text is visible when it wraps to multiple lines.
- Applied the same safe `WRAP_CONTENT` treatment to the main Reports description to prevent the same UI clipping there.

## Version
- versionName: 3.9.4
- versionCode: 79
- GitHub Actions artifact: `MGE-3.9.4-APK`

No Firestore data or invoice logic was changed by this UI-only fix.
