# MGE 3.9.6.3 — Multi-page Invoice PDF Fix

## Fix
Invoice PDF export/share now supports multiple pages.

Previously `buildInvoiceOnlyPdf()` created and finished only one `PdfDocument.Page`, so products beyond the first page were cut off. The new implementation:

- Keeps the existing first-page invoice design.
- Automatically creates continuation pages when the product list exceeds the available space.
- Repeats the product table header on continuation pages.
- Keeps the invoice number, customer name, MGE identity and page number on continuation pages.
- Moves the shipping charge, total, partner profit and footer to the final page.
- Shares the complete PDF through the Android system share dialog.
- Continues saving the PDF in `Download/FactureSimple`.

## File changed
`app/src/main/java/com/mge/facturesimple/MainActivity.java`

## Note
The source project archive did not include `gradlew`, and the execution environment does not have a system Gradle installation, so an Android Gradle build could not be executed here. The Java change was checked structurally in the source.
