# MGE 3.9.7.10 — Invoice Assembly & Partner Accounting Status

## Updates
- Added `assembly_completed` invoice field, persisted locally and synchronized with Firestore.
- Invoice editor now has an admin-controlled checkbox: `📦 تم تجميع الطلبية بالكامل`.
- Invoice cards show a prominent green/red assembly status banner.
- Partner invoices show a prominent green/red partner-accounting status banner based on `partner_profit_paid`.
- Store account is hidden from partner users in invoice cards and the invoice Store filter is hidden for partner users.
- Existing 3.9.7.8/3.9.7.9 invoice filters, phone search, Store filtering, pricing and partner-login fixes are preserved.

## Compatibility
- SQLite DB version raised from 30 to 31. Existing databases receive the new field automatically.
- Older Firestore invoices without `assembly_completed` are treated as not assembled.
