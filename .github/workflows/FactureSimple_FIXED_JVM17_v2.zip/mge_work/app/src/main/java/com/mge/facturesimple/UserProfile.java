package com.mge.facturesimple;

import java.util.HashMap;
import java.util.Map;

/** Cloud user profile stored in Firestore: users/{uid}. */
public class UserProfile {
    public String uid = "";
    public String name = "";
    public String email = "";
    public String role = "partner";
    public long partnerId = 0;
    public boolean active = true;
    public long createdAt = 0;
    public long updatedAt = 0;

    public boolean isAdmin() {
        return "admin".equalsIgnoreCase(role);
    }

    public boolean isPartner() {
        return "partner".equalsIgnoreCase(role);
    }

    public Map<String, Object> toMap() {
        Map<String, Object> m = new HashMap<>();
        m.put("uid", uid);
        m.put("name", name);
        m.put("email", email);
        m.put("role", role);
        m.put("partnerId", partnerId);
        m.put("active", active);
        m.put("createdAt", createdAt);
        m.put("updatedAt", updatedAt);
        return m;
    }
}
