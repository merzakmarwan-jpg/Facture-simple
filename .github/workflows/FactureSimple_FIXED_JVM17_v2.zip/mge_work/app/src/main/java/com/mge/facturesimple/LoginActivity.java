package com.mge.facturesimple;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends Activity {
    CloudManager cloud; Store db;
    int blue=Color.rgb(20,103,205), green=Color.rgb(18,155,72), bg=Color.rgb(246,248,252);
    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    EditText input(String h){EditText e=new EditText(this);e.setHint(h);e.setTextSize(15);e.setSingleLine(true);e.setPadding(dp(14),0,dp(14),0);e.setBackground(round(Color.WHITE,Color.rgb(220,226,235),14,1));return e;}
    GradientDrawable round(int fill,int stroke,int r,int sw){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(r));if(sw>0)g.setStroke(dp(sw),stroke);return g;}
    Button btn(String s,int color){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setTextSize(15);b.setGravity(Gravity.CENTER);b.setMinHeight(dp(52));b.setMinimumHeight(dp(52));b.setHeight(dp(52));b.setPadding(dp(12),0,dp(12),0);b.setIncludeFontPadding(true);b.setBackground(round(color,color,14,0));return b;}
    @Override public void onCreate(Bundle b){super.onCreate(b);db=new Store(this);cloud=new CloudManager(this,db);if(cloud.isLoggedIn()){cloud.loadProfileAndRun(()->{if(CrashReporter.hasReport(this)) showCrashReportAndThenOpen(); else openApp();},()->showLogin());}else showLogin();}
    void showCrashReportAndThenOpen(){
        String report=CrashReporter.readReport(this);
        TextView tv=new TextView(this);
        tv.setText(report); tv.setTextSize(11); tv.setTextColor(Color.rgb(31,41,55));
        tv.setPadding(dp(12),dp(8),dp(12),dp(8));
        ScrollView sv=new ScrollView(this); sv.addView(tv);
        new AlertDialog.Builder(this)
            .setTitle("⚠️ تم اكتشاف انهيار سابق")
            .setMessage("هذه نسخة تشخيصية. التقرير يحدد الصفحة والسطر الذي تسبب في إغلاق التطبيق.\nانسخ التقرير وأرسله لي قبل متابعة الاختبار.")
            .setView(sv)
            .setPositiveButton("نسخ ثم متابعة",(d,w)->{
                ((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(android.content.ClipData.newPlainText("MGE Crash Report",report));
                Toast.makeText(this,"تم نسخ التقرير",Toast.LENGTH_SHORT).show();
                CrashReporter.deleteReport(this);
                openApp();
            })
            .setNeutralButton("حذف التقرير والمتابعة",(d,w)->{CrashReporter.deleteReport(this);openApp();})
            .setNegativeButton("إغلاق",null)
            .show();
    }
    void showLogin(){
        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(bg);
        scroll.setClipToPadding(false);

        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(20),dp(22),dp(20),dp(24));
        root.setBackgroundColor(bg);
        scroll.addView(root,new ScrollView.LayoutParams(-1,-2));

        Space top=new Space(this);
        root.addView(top,new LinearLayout.LayoutParams(1,dp(10)));

        ImageView logo=new ImageView(this);
        logo.setImageResource(R.drawable.logo_mge);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams logoLp=new LinearLayout.LayoutParams(dp(260),dp(120));
        logoLp.gravity=Gravity.CENTER_HORIZONTAL;
        logoLp.bottomMargin=dp(8);
        root.addView(logo,logoLp);

        TextView title=new TextView(this);
        title.setText("MGE Cloud");
        title.setTextSize(25);
        title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        title.setTextColor(Color.rgb(31,41,55));
        title.setGravity(Gravity.CENTER);
        title.setIncludeFontPadding(true);
        root.addView(title,new LinearLayout.LayoutParams(-1,dp(52)));

        TextView info=new TextView(this);
        info.setText("تسجيل الدخول للوصول إلى بياناتك السحابية");
        info.setTextSize(15);
        info.setGravity(Gravity.CENTER);
        info.setTextColor(Color.GRAY);
        info.setIncludeFontPadding(true);
        LinearLayout.LayoutParams infoLp=new LinearLayout.LayoutParams(-1,dp(48));
        infoLp.bottomMargin=dp(8);
        root.addView(info,infoLp);

        EditText email=input("البريد الإلكتروني");
        EditText pass=input("كلمة المرور");
        pass.setInputType(0x81);
        root.addView(email,lp(320,54,0,8));
        root.addView(pass,lp(320,54,0,16));

        Button login=loginButton("تسجيل الدخول",blue);
        root.addView(login,lp(320,60,0,12));

        TextView note=new TextView(this);
        note.setText("ملاحظة: حسابات الشركاء ينشئها المدير فقط من إدارة الشركاء.");
        note.setTextSize(13);
        note.setLineSpacing(dp(4),1.0f);
        note.setTextColor(Color.rgb(110,118,130));
        note.setGravity(Gravity.CENTER);
        note.setIncludeFontPadding(true);
        LinearLayout.LayoutParams noteLp=new LinearLayout.LayoutParams(-1,dp(70));
        noteLp.leftMargin=dp(8); noteLp.rightMargin=dp(8);
        root.addView(note,noteLp);

        login.setOnClickListener(v->{String e=email.getText().toString().trim(),p=pass.getText().toString();if(e.isEmpty()||p.isEmpty()){Toast.makeText(this,"أدخل البريد وكلمة المرور",Toast.LENGTH_SHORT).show();return;}login.setEnabled(false);cloud.login(e,p).addOnSuccessListener(x->cloud.loadProfileAndRun(()->openApp(),()->{cloud.logout();login.setEnabled(true);Toast.makeText(this,"الحساب موجود لكن لم يتم إعداد صلاحياته في السحابة",Toast.LENGTH_LONG).show();})).addOnFailureListener(x->{login.setEnabled(true);Toast.makeText(this,"فشل الدخول: "+x.getMessage(),Toast.LENGTH_LONG).show();});});
        setContentView(scroll);
    }
    Button loginButton(String text,int color){
        Button b=new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(18);
        b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setIncludeFontPadding(true);
        b.setMinHeight(dp(60));
        b.setMinimumHeight(dp(60));
        b.setHeight(dp(60));
        b.setPadding(dp(8),0,dp(8),0);
        b.setSingleLine(true);
        b.setEllipsize(null);
        b.setBackground(round(color,color,16,0));
        return b;
    }
    LinearLayout.LayoutParams lp(int w,int h,int l,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w<0?w:dp(w),dp(h));p.setMargins(dp(l),0,0,dp(b));return p;}
    void openApp(){startActivity(new android.content.Intent(this,MainActivity.class));finish();}
}
