package com.mge.facturesimple;

import android.content.Context;
import android.os.Build;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Diagnostic crash logger for MGE diagnostic builds. */
public final class CrashReporter {
    private static final String FILE_NAME = "mge_last_crash.txt";
    private static volatile String currentScreen = "غير معروف";
    private static volatile Thread.UncaughtExceptionHandler previousHandler;

    private CrashReporter() {}

    public static void install(Context context) {
        final Context app = context.getApplicationContext();
        previousHandler = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                writeReport(app, thread, throwable);
            } catch (Throwable ignored) {
                // Never allow the diagnostic logger to interfere with Android's crash handling.
            }
            if (previousHandler != null) previousHandler.uncaughtException(thread, throwable);
        });
    }

    public static void setCurrentScreen(String screen) {
        if (screen != null && !screen.trim().isEmpty()) currentScreen = screen;
    }

    private static void writeReport(Context context, Thread thread, Throwable throwable) {
        File file = new File(context.getFilesDir(), FILE_NAME);
        StringWriter sw = new StringWriter();
        throwable.printStackTrace(new PrintWriter(sw));
        String report =
                "MGE CRASH REPORT\n" +
                "================\n" +
                "Date: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()) + "\n" +
                "App: MGE Diagnostic\n" +
                "Version: 3.8.10-DIAG\n" +
                "Android: " + Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")\n" +
                "Device: " + Build.MANUFACTURER + " " + Build.MODEL + "\n" +
                "Thread: " + (thread == null ? "unknown" : thread.getName()) + "\n" +
                "Last screen: " + currentScreen + "\n" +
                "Exception: " + throwable.getClass().getName() + "\n" +
                "Message: " + String.valueOf(throwable.getMessage()) + "\n\n" +
                "STACK TRACE\n" +
                sw + "\n";
        try (FileOutputStream out = new FileOutputStream(file, false)) {
            out.write(report.getBytes("UTF-8"));
            out.flush();
        } catch (Exception ignored) {}
    }

    public static File getReportFile(Context context) {
        return new File(context.getApplicationContext().getFilesDir(), FILE_NAME);
    }

    public static boolean hasReport(Context context) {
        File f = getReportFile(context);
        return f.exists() && f.length() > 0;
    }

    public static String readReport(Context context) {
        File f = getReportFile(context);
        if (!f.exists()) return "لا يوجد تقرير انهيار.";
        try {
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            byte[] buffer = new byte[4096];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            in.close();
            return new String(out.toByteArray(), "UTF-8");
        } catch (Exception e) {
            return "تعذر قراءة تقرير الانهيار: " + e.getMessage();
        }
    }

    public static void deleteReport(Context context) {
        File f = getReportFile(context);
        if (f.exists()) f.delete();
    }
}
