package com.mge.facturesimple;

import android.app.Application;

public class MGEApplication extends Application {
    @Override public void onCreate() {
        super.onCreate();
        CrashReporter.install(this);
    }
}
