# MGE 3.9.7.6 — Invoice phone search + Store account filter

## New invoice filters
- Search invoices by invoice number, customer name, **or customer phone number**.
- Added a **Store account** filter showing only invoices whose `shipping_account` matches the selected Store account.
- The Store filter works together with the existing filters:
  - all / partner / normal invoices
  - all / not received / received
  - selected partner
  - search text

## Synchronization behavior
The Store selection is stored in `invoiceStoreFilter` and restored by account name, so Firebase synchronization/rebuilding the invoice screen does not reset the selected Store.

## Important
The Store filter refers to the shipping account saved on the invoice (`shipping_account`). It therefore shows invoices that were shipped using that Store account, rather than filtering by the full invoice amount or customer account.
