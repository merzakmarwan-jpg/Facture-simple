# 3.9.7.17 — Store Virement Import + Revenue Fix

## Fixed
1. OzonExpress Virement PDF parsing: the short token between the shipment code and phone number (OA/RI/AP/SE, etc.) is not part of the tracking number.
2. Imported Virement rows now match existing invoice tracking numbers correctly.
3. The Store selected during Virement import is written as the authoritative Store account on every matched invoice, so an old/wrong account is not retained.
4. Store revenue uses the exact CRBT, fees and net values from an imported Virement when available.
5. Store revenue details use the same settlement values.
6. The report now renders local data immediately before the Firebase refresh callback, so the page does not remain visually empty while synchronization is running.

The uploaded OzonExpress PDF contains 4 colis, 4215 DH CRBT and 160 DH fees. Its shipment codes are SALE072630545636, SDS072630565541, Tine072630567511 and SALE082630594055.
