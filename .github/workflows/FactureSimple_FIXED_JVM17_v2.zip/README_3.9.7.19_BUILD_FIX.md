# 3.9.7.19 — Build Fix after Store Virement parser fix

## Fixed
- Fixed `CloudManager.java` compilation errors in `syncShippingCompaniesFromCloud()` caused by nested `continueWithTask()` generic type inference.
- Replaced the nested continuation with `Tasks.whenAllSuccess()` using two explicitly typed `Task<QuerySnapshot>` instances.
- No Store/Virement business logic was changed by this build-only correction.
- The 3.9.7.18 Virement PDF matching fix remains included.

## Expected build
The previous errors at `CloudManager.java:1432` and `:1434` (`cannot infer type-variable(s) TContinuationResult`) should no longer occur.
