# MGE 3.9.7.38 — Virement PDF tracking-code wrap fix

- Fixed OzonExpress Virement PDF parsing when a tracking code is split across lines by PDFBox.
- Example from the supplied PDF: `Gouna08263107890` followed by `0OM` on the next line. The parser now reconstructs the full code instead of dropping `0OM`.
- Also handles suffixes such as `EY` on the following line.
- Phone numbers and dates after the tracking code are not incorrectly appended because the optional suffix must contain a letter.
- This is a parser fix, not a cosmetic font-size workaround: the supplied OzonExpress PDF itself contains the line break, so changing the app font cannot repair the source PDF.
- The resulting full tracking code is then passed through the existing canonical invoice lookup.
- Version: 3.9.7.38 / versionCode 100.
