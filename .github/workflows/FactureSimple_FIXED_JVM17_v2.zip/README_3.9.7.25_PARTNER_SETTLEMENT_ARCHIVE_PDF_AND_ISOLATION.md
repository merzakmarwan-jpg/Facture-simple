# MGE 3.9.7.25 — Partner settlement isolation + archive PDF

- A partner settlement can only include delivered, unpaid invoices that have never been included in an earlier partner settlement.
- Previous settlement invoices are excluded from the next settlement, even if they remain delivered.
- The archive now has a PDF button for every saved settlement.
- The settlement PDF is generated from the saved settlement items, so it represents that exact accounting batch rather than the current global invoice list.
- Settlement items store customer/contact/tracking/shipping/store snapshots for future PDF generation.
- Existing settlement records remain readable; older records without snapshots fall back to their invoice-linked data where available.
