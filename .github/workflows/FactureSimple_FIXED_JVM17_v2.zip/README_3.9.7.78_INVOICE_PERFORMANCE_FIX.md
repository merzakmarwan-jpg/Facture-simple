# MGE 3.9.7.78 — Invoice performance / ANR fix

- The invoice screen no longer creates all 195+ invoice cards at once.
- First 30 invoices are rendered immediately. More are appended automatically as the user approaches the bottom.
- Search and all invoice filters still operate on the full local invoice set; only rendering is batched.
- Editing an older invoice still restores the same invoice by loading only the batches needed to reach it.
- Realtime/manual refresh behavior is preserved.
- Heavy full Admin catalog reconciliation is delayed 3.5 seconds after startup so the home screen becomes responsive first.
- No invoice data, invoice numbers, cloud_key values, Firebase rules, or database contents are deleted/replaced.
