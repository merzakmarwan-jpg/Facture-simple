# MGE 3.9.7.32 — Store Account PDF / Archive UI

- Store account invoice screen now shows its PDF/WhatsApp accounting controls immediately below the Store title.
- Only invoices marked as received at the bank can be selected for a Store accounting PDF.
- The selected batch is exported and shared through WhatsApp; after normal export the selected invoices are archived and disappear from the active Store list.
- Store archive supports selecting a subset, generating a new PDF without re-archiving those invoices, and restoring selected invoices back to the active accounting list.
- The Store archive is independent from the partner-profit settlement archive.
- The invoice list no longer uses a nested ScrollView, preventing the action controls from being hidden on small screens.
