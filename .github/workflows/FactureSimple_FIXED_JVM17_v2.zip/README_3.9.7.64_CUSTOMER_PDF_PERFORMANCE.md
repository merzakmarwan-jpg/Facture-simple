# MGE 3.9.7.64

Based on MGE 3.9.7.63.

Changes in this release:
- Product-photo invoice PDF now includes customer name, phone and address.
- Invoice list cards were made substantially lighter to reduce UI blocking when there are 200+ invoices.
- Heavy per-invoice sharing/sync/delete actions are moved behind a compact Options dialog instead of creating all controls for every invoice at once.
- Invoice card remains clickable and opens the invoice editor.
- Existing local image cache, invoice sync, offline creation, invoice numbering and ordering are preserved.

Build note: the supplied project does not contain a Gradle wrapper, so this environment cannot run ./gradlew. The source/ZIP was checked structurally, but an APK build was not performed here.
