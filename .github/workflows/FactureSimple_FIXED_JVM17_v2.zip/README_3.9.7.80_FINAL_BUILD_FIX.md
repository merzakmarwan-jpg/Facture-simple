# MGE 3.9.7.80 — Final clean build fix

Base: MGE 3.9.7.79 PHONE_STARTUP_PERFORMANCE_FIX.

- Fixed the compile error in MainActivity caused by calling `getChildAt()` on the generic `View v` received by `OnScrollChangeListener`.
- The code now uses the actual `mainScroll` ScrollView.
- No invoice, Firebase, numbering, cloud_key, offline, or synchronization logic was changed.
- The source contains exactly one `onDestroy()` implementation.
- GitHub Actions artifact name updated to MGE-3.9.7.80-APK.
