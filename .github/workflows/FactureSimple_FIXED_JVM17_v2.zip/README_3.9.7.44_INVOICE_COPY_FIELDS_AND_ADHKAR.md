# MGE 3.9.7.44 — Invoice copy fields + last-page adhkar

- Each customer field on invoice cards is independently copyable: name, phone, city, address, tracking number.
- Invoice PDF shows Bismillah once on the first page only.
- Product/customer-images PDF shows Bismillah once on the first page only.
- Add/Edit Invoice includes a multiline adhkar field stored per invoice.
- Adhkar is rendered once at the bottom of the final page of invoice PDF and image PDF.
- Invoice adhkar is synchronized through Firestore.
- Database version 36; app version 3.9.7.44 / versionCode 106.
