# MGE 3.9.7.67 — Multiple Product Categories

- A product can belong to multiple saved categories.
- Product editor uses a multi-select category picker.
- New categories are saved once and can be reused across products.
- Product category filters match products belonging to any selected category.
- Bulk category management adds the chosen category to selected products instead of replacing existing categories.
- Choosing General / no category clears all categories for the selected products.
- Existing single-category products remain compatible and are treated as one category.
- Firebase product metadata continues to use the existing category field as a joined category list for compatibility.
