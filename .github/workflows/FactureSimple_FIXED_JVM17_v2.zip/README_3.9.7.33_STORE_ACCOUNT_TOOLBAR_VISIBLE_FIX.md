# MGE 3.9.7.33 — Store Account Toolbar Visibility Fix

- Fixed the Store account invoice/PDF action toolbar appearing as a thin horizontal line on some phones.
- Replaced the collapsible card toolbar with an explicit fixed-height vertical toolbar inside the main ScrollView.
- The Store screen now visibly shows: select received invoices, clear selection, PDF + WhatsApp, and Store archive.
- Store accounting archive remains separate from partner settlement archive.
- Version: 3.9.7.33 / versionCode 95.
