# MGE 3.9.7.52.2 — Safe Invoice Sync

This build is based directly on MGE 3.9.7.52.1.

Key safety changes:
- A stale local invoice-deletion tombstone can no longer delete a newer Firestore invoice.
- Legacy remote invoices without `updatedAt` are not auto-deleted.
- Firestore invoice identity remains the immutable `inv_<UUID>` cloud key.
- Global invoice numbers continue to use the Firestore transaction counter.
- GitHub Actions builds the Android project directly and uses `android-actions/setup-android@v4`.
- No Firestore data is migrated, renamed, or deleted by this build.
