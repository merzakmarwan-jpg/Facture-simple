# MGE 3.9.7.27 — Virement tracking base match fix

Fixes Virement import matching when the OzonExpress PDF extraction omits the short route suffix (for example `GK` / `XL`) while the invoice stores it.

The importer now:
- keeps exact tracking matching;
- keeps normalized alphanumeric matching;
- falls back to the stable carrier + numeric tracking base when only a 1–4 letter suffix differs;
- preserves the selected shipping company and Store/account during Virement application.

Example: `BML082631029228` now matches invoice tracking `BML082631029228GK`.
