# MGE 3.9.7.79 — Phone startup / invoice list performance fix

- Existing Admin devices no longer start the full invoice + catalogue reconciliation immediately at app launch.
- A device with existing local invoices/products uses its local database first, keeping Home and navigation responsive.
- A fresh Admin device with an empty local database still performs the initial cloud synchronization after the UI has been stable for 5 seconds.
- Invoice list queries now load invoice headers only; line items are loaded only for invoice cards that are actually rendered.
- Invoice lazy rendering batch reduced to 20 cards to keep scrolling smooth on phones with 195+ invoices.
- Invoice numbers, `cloud_key`, Firebase rules, existing invoices, and local database contents are not deleted or replaced.
