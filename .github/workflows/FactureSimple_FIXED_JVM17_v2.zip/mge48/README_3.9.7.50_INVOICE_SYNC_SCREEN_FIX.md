# MGE 3.9.7.50 — Invoice Sync Screen Fix

- Version: 3.9.7.50
- versionCode: 112

The previous invoice-page change invoked the full Admin synchronization and showed the misleading message “تعذر تحديث الفواتير من السحابة” when any unrelated sync component failed.

This version uses a dedicated Admin invoice-only bidirectional sync when the invoices page opens. It downloads server invoices, uploads local invoices missing from Firestore, and keeps local data without showing an intrusive error toast when the sync fails. Other data synchronization remains on its normal background/manual paths.
