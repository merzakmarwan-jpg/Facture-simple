# MGE 3.9.7.48 — Invoice synchronization reliability fix

- The invoices screen now explicitly reconciles with Firebase when opened for both Admin and Partner accounts.
- After server reconciliation completes, the invoice list is refreshed immediately, so invoices created on another device appear without restarting the app.
- If immediate single-invoice upload fails, MGE schedules an immediate network-constrained retry instead of waiting only for the periodic sync cycle.
- No invoice, customer, product, PDF, adhkar, settlement, or search behavior was removed.

Version: 3.9.7.48
VersionCode: 110
