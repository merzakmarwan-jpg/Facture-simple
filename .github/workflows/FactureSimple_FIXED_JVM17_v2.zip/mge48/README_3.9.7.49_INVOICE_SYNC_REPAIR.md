# MGE 3.9.7.49 — Invoice Sync Repair

- Version: `3.9.7.49`
- versionCode: `111`
- Repairs the case where local devices contain more invoices than Firestore because an invoice was saved locally but its `sync_meta` state was missing/clean.
- Admin invoice synchronization now performs a repair pass: every local invoice that is missing from Firestore is uploaded, while local deletion tombstones are still respected and are never resurrected.
- Existing dirty invoices continue to be pushed normally.
- This is designed to reconcile cases such as 163 invoices on one admin device versus 160 on another.
