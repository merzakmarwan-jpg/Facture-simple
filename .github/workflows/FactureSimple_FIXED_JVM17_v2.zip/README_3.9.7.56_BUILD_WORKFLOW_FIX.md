# MGE 3.9.7.56

Build workflow fix: use android-actions/setup-android v4 with automatic license acceptance and explicit Android 35 packages. Invoice bidirectional sync from 3.9.7.54/55 is preserved.
