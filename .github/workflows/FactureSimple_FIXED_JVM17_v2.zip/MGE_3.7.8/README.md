# MGE 3.4.0 — Offline/Online Bidirectional Sync

## 3.4
- Added local `sync_meta` tracking for products, customers and invoices.
- Admin sync is bidirectional: local and Firebase changes are reconciled using `updatedAt`; the newer side wins.
- Local deletes are represented as tombstones and propagated to Firebase when the local change is newer.
- Remote invoice items are pulled into SQLite without marking them dirty.
- Partner remains cloud-read-only and continues to pull only its partner-scoped customers/invoices.
- Existing Firebase project/package remain unchanged: `facturesimple-1b613`, `com.mge.facturesimple`.

## Sync behavior
- `clean`: local and remote agree.
- `dirty`: local change waiting for sync.
- Conflict: compare local `sync_meta.local_updated_at` with remote `updatedAt`; the newer timestamp wins.
- Offline: local SQLite remains usable; changes are queued as dirty until the next successful sync.


## MGE 3.6.1.0 — Sync Center
- Added a dedicated MGE Cloud sync center in Settings.
- Shows connectivity, pending changes, last sync time, and per-entity status.
- Manual sync is disabled while offline.
- Keeps Admin bidirectional sync and Partner cloud-to-local sync.


## MGE 3.6.0 — Automatic cloud sync
- WorkManager schedules automatic sync every 15 minutes when network is available.
- A one-time sync is queued when the main app starts.
- Admin syncs local SQLite bidirectionally with Firebase; Partner pulls cloud data into local SQLite.
- Sync failures can show a notification when Android notification permission is granted.
- Manual “Sync now” also queues the same background worker.


## MGE 3.7.1 — Professional Products UI
- تحسين قائمة المنتجات ببطاقات مرنة تمنع قص أسماء المنتجات والأسعار أثناء البحث.
- عرض السعر بشكل واضح داخل كل بطاقة.
- الضغط على صورة المنتج يفتح عارض صور كامل الشاشة مع التكبير باللمس والتحريك.
- تحسين أزرار التعديل والحذف مع تأكيد قبل الحذف.
- الحفاظ على Firebase والمزامنة وصلاحيات Admin/Partner والوظائف السابقة.
- استخدام شعار MGE نفسه كأيقونة للتطبيق.


## MGE 3.7.3 — Partner Invoices
- الشريك يرى جميع الفواتير المرتبطة بـ Partner ID الخاصة به، بما فيها الفواتير التي أنشأها المدير.
- الشريك يستطيع إنشاء فاتورة جديدة من صفحة الفواتير.
- Partner ID للشريك يُفرض تلقائياً ولا يمكن تغييره من واجهة الفاتورة.
- الفواتير الجديدة للشريك تُرفع إلى Firestore أثناء المزامنة.
- إصلاح قراءة حقول paid / reseller / delivery_received / shipping_enabled / partner_profit_paid من Firestore كقيم Boolean.
- قواعد Firestore تسمح للشريك بإنشاء فواتير وعناصر فواتيره فقط، مع منع التعديل والحذف.
- المزامنة لا تعيد رفع فاتورة موجودة مسبقاً في السحابة من جهاز الشريك.


## 3.7.5 — Partner/Customer unified link
- Every partner account created by Admin automatically gets one linked customer/partner record.
- Existing partner accounts are repaired automatically when Partner Management or Customers is opened.
- The link uses Partner ID + Firebase UID and is synchronized to Firestore.
- Renaming/changing Partner ID keeps the linked customer record attached.
- Deleting a partner from either linked admin view removes the Firestore user profile and linked customer record together.
- Partner accounts continue to receive only their own customers in the Customers page.
- Added `partner_uid` and `partner_email` to the local customer schema (DB version 12).

## MGE 3.7.5 — Partner workflow
- إخفاء حساب Store عن الشريك وإظهار شركة الشحن فقط مع إمكانية اختيارها.
- الشريك لا يستطيع إضافة أو إدارة شركات/حسابات الشحن.
- الشريك يستطيع تعديل فاتوراته قبل شحنها: إضافة منتج، حذف منتج، تعديل الكمية والسعر.
- عند تحديد الأدمن أن الطلبية تم شحنها، تصبح الفاتورة مقفلة للشريك.
- مزامنة تعديلات الفواتير الموجودة مسبقاً إلى Firestore، بما فيها حذف عناصر الفاتورة من السحابة.
- الشريك يستطيع إضافة وتعديل وحذف زبائنه من صفحة «زبائني»، مع ربطها تلقائياً بـ Partner ID.
- مزامنة ثنائية الاتجاه لزبائن الشريك.
- مزامنة أسماء شركات الشحن من حساب الأدمن إلى حسابات الشركاء، بدون تنزيل حسابات Store.

## MGE 3.7.7 — Shared partner/customer synchronization
- Added invoice snapshot fields: customer phone, city, address and customer type (`registered` / `normal`).
- Selecting a permanent customer fills the four customer fields automatically.
- A normal customer can be entered directly without adding a permanent customer record.
- Invoice PDF uses the customer snapshot and falls back to the linked customer record for older invoices.
- Partner shipping UI exposes the shipping company only; Store account, tracking and actual shipping cost remain admin-only.
- Partner invoice creation/update rules allow the partner workflow without exposing or modifying admin shipping-account data.
- Partner customer updates are limited to name, phone, city and address plus sync metadata.
- Sync failure reporting now records the underlying Firebase exception instead of only showing a generic failure.
- Local database version 16 adds a stable `cloud_id` for customers and a `cloud_key` for deletion tombstones without deleting existing data.
- Admin and Partner now use the same Firestore customer records: a customer added by the Partner appears in Admin, and a customer assigned by Admin appears in the Partner account.
- Customer records use stable cloud IDs to avoid local SQLite ID collisions between devices.
- Opening the Customers page triggers the appropriate cloud synchronization automatically.
- Partner customer changes are synchronized bidirectionally while preserving the Partner ID ownership rules.

### Important Firebase step
The included `firestore.rules` must be deployed to the same Firebase project before testing cloud synchronization. The Android source cannot change Firestore Security Rules by itself.

## 3.7.8 — إصلاحات إضافية
- حذف الشريك: البحث عن الحساب حسب Partner ID، حذف سجل الشريك المرتبط، ثم حذف/تعطيل الحساب عند الحاجة.
- الفاتورة: خانة سعر واحدة فقط لكل منتج، سواء أنشئت الفاتورة عبر الشريك أو عبر زبون/الأدمن.
- المزامنة: تجديد Firebase ID Token قبل المزامنة، مع عدم إيقاف مزامنة المنتجات والعملاء والفواتير بسبب فشل غير أساسي في شركات الشحن.
- يجب نشر ملف `firestore.rules` الموجود في جذر المشروع إلى مشروع Firebase نفسه؛ قواعد Firestore مطبقة على الخادم ولا يستطيع التطبيق تجاوزها.


## MGE 3.7.8 — 3.7.8 FIXED / backup images / partner links
- Backup export now creates a ZIP containing `facturesimple.db` **and the complete `files/product_images` folder**.
- Backup import restores both the SQLite database and product image files. Old `.db`-only backups remain supported.
- Product creation/editing no longer reads the product title from the selected image. The product name is entered manually by the user.
- Partner/customer assignment now uses the real Firebase `partnerId`, not the local SQLite ID of the linked partner customer. This fixes the case where Admin sees one customer while the Partner sees different customers.
- Customers created by Admin for a Partner now carry the Partner Firebase UID/email locally and in Firestore.
- Customers created by a Partner keep the same `partnerId` + `partnerUid` relationship and therefore appear in Admin.
- Partner deletion no longer attempts to delete `users/{uid}` from the client. The Firebase profile is disabled with `active=false` and `deleted=true`, avoiding `PERMISSION_DENIED` on projects that disallow user-document deletion.
- Deleted partner profiles are excluded from automatic partner-customer repair so they cannot be recreated accidentally.
- Firestore/Storage rules in this package were aligned with the Android sync logic. **They still must be published to the same Firebase project.**

### Firebase rules deployment
From the project root, deploy both rule files to the Firebase project used by `google-services.json`:

```bash
firebase deploy --only firestore:rules,storage
```

If Firebase CLI is not available, copy the contents of `firestore.rules` into Firestore Database → Rules and `storage.rules` into Storage → Rules, then publish.
