# MGE 3.9.7.47 — Build Fix

Fixed the GitHub Actions Java compilation error in Store.java caused by using `Collections.sort(...)` without importing `java.util.Collections`.

Version: 3.9.7.47
VersionCode: 109

No functional changes were made to the smart product search, quantity entry, invoice protection, adhkar, or settlement PDF features.
