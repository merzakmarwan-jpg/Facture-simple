# MGE 3.9.7.60 — Store/Shipping Account Sync Fix

- Store accounts under `shipping_accounts` are now synchronized bidirectionally with the admin cloud catalog.
- A device with only the default/seeded accounts no longer hides Store accounts already present on the server.
- Manual invoice refresh also refreshes the Store/shipping account catalog.
- Realtime listeners pull Store/company changes without creating a write-listener feedback loop.
- The cloud catalog is pulled only after local Store/company/account data has been committed to Firestore, so local accounts are not lost during the bidirectional pass.
- Empty remote shipping collections do not erase the local seeded catalog.
- Invoice data and invoice `shipping_account` text remain untouched; this fix only ensures the referenced Store accounts exist on every device.
