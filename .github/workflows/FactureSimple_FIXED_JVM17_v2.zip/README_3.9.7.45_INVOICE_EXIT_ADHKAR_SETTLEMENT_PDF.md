# MGE 3.9.7.45 — Invoice exit protection, clearer Adhkar, settlement summary cleanup

- Android Back, bottom navigation, and the top menu are protected while creating/editing an invoice.
- Exit asks whether to save the invoice or close without saving.
- Adhkar in the final PDF page are larger, bold, darker, and more readable.
- Adhkar remains rendered once at the bottom of the final page only.
- Removed `مجموع الفواتير / Total invoices` from the partner settlement PDF summary.
- Version 3.9.7.45 / VersionCode 107.
