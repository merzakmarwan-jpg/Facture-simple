# MGE 3.9.7.57 — Root Invoice Sync Fix

This build is based on MGE 3.9.7.52.2 and focuses on the invoice synchronization path.

## Root causes addressed
- The global `counters/invoice_numbers` document must be readable/writable by authenticated active users; without the Firestore `counters` rule, new invoice number allocation fails with `PERMISSION_DENIED`.
- The non-invoice full synchronization no longer starts a second invoice synchronization pass. This removes duplicate/repeated invoice reconciliation after a successful invoice pass.
- Manual single-invoice retry no longer schedules an automatic Worker retry after failure. One button press is one attempt; the invoice remains dirty when it fails.
- Invoice identity remains the immutable `inv_<UUID>` cloud key. Visible invoice numbers are allocated centrally by a Firestore transaction.
- New invoices require successful online number reservation, so the phone and tablet cannot independently generate the same final number.
- Invoice header and `items` are considered synchronized only after both cloud writes/readback complete.
- Existing stale local deletion tombstones are not allowed to delete a newer/legacy remote invoice.
- Firestore data is not migrated, renamed, or deleted by the application during upgrade.

## Firebase action required once
Publish the included `firestore.rules` in the Firebase Console. The critical addition is `match /counters/{id}` for the shared invoice-number counter.

## Build
- versionName: 3.9.7.57
- versionCode: 117
- Android SDK 35 / JDK 17 / Gradle 8.9
- GitHub Actions uses `android-actions/setup-android@v4`.

## Safety
Install/test this build on the tablet first. Do not uninstall or clear the primary phone that contains production invoices.
