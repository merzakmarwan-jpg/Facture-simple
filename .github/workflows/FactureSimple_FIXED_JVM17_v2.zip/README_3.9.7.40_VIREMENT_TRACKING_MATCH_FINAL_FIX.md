# MGE 3.9.7.40 — Final OzonExpress Virement tracking reconstruction fix

This update replaces the fragile Virement row-boundary detection with deterministic row collection: every table row is collected until the next numeric row, so a tracking suffix on a separate PDFBox line is never dropped.

The tracking parser now receives only the text before the pickup/delivery dates. It reconstructs the full tracking code from the stable carrier+digits token plus an immediately following short alphanumeric suffix containing a letter.

Verified against the supplied OzonExpress Virement PDF `VRT-N-2647127-240826-39-78106.pdf`: the expected tracking codes are reconstructed as:
- `Goul072630559117UT`
- `TANT082631106528ZU`
- `Imzm082631111307MF`
- `AROUI082631259606HT`
- `MDL082631259633BM`
- `AGA082631259638ZK`
- `SFI082631264809CF`
- `Srgn082631266312MA`
- `Imnt082631266429OD`

Validation: the supplied PDF was processed row-by-row and all 9 expected tracking codes were reconstructed, including the two failing cases `Imzm...7MF` and `AROUI...6HT`, plus the split `SFI...C` + `F` case. This is a parser/matching fix, not a font-size workaround. The source PDF contains the suffixes on separate lines; the application must reconstruct them before invoice matching.

Version: 3.9.7.40
VersionCode: 102
