# MGE 3.9.7.59 — Invoice manual/automatic refresh

- Added a visible `☁️ تحديث ومزامنة الفواتير` button at the top of the invoices page.
- Added pull-to-refresh when the invoice page is scrolled to the top.
- Manual/gesture refresh forces the existing server-backed bidirectional invoice reconciliation.
- Added foreground invoice refresh every 5 minutes while the invoices page is open.
- Existing Firestore realtime listener remains enabled.
- Existing WorkManager background sync remains enabled (15 minutes when network is available).
- No local invoice replacement/import/deletion was added.
