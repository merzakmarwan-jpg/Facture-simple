package com.mge.facturesimple;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class Store extends SQLiteOpenHelper {
    private static final String DB_NAME = "facturesimple.db";
    private static final int DB_VERSION = 34;

    public Store(Context c) { super(c, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT)");
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,code TEXT,price REAL,image TEXT,available INTEGER DEFAULT 1,price_tiers TEXT DEFAULT '')");
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,city TEXT,address TEXT,reseller INTEGER DEFAULT 0,partner_id INTEGER DEFAULT 0,partner_uid TEXT,partner_email TEXT,default_shipping REAL DEFAULT 30,cloud_id TEXT)");
        db.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,client_id INTEGER,client TEXT,date TEXT,paid INTEGER DEFAULT 0,reseller INTEGER DEFAULT 0,delivery_received INTEGER DEFAULT 0,tracking_number TEXT,commission REAL DEFAULT 0,partner_id INTEGER DEFAULT 0,shipping_enabled INTEGER DEFAULT 0,shipping_charge REAL DEFAULT 0,shipping_cost REAL DEFAULT 0,partner_profit_paid INTEGER DEFAULT 0,paid_date TEXT,delivery_received_date TEXT,delivery_failure_reason TEXT,partner_profit_paid_date TEXT,shipping_company TEXT,shipping_account TEXT,bank_received INTEGER DEFAULT 0,bank_received_date TEXT,shipped_by_admin INTEGER DEFAULT 0,customer_phone TEXT,customer_city TEXT,customer_address TEXT,customer_type TEXT DEFAULT 'normal',invoice_number INTEGER DEFAULT 0,cloud_key TEXT,company_accounted INTEGER DEFAULT 0,company_accounted_date TEXT,company_accounting_store TEXT,company_accounting_export_id TEXT,virement_code TEXT,virement_date TEXT,virement_total_crbt REAL DEFAULT 0,virement_total_fees REAL DEFAULT 0,virement_net REAL DEFAULT 0,advance_payment REAL DEFAULT 0,advance_payment_date TEXT,advance_received_by_partner_id INTEGER DEFAULT 0,assembly_completed INTEGER DEFAULT 0,created_at INTEGER DEFAULT 0,invoice_number_final INTEGER DEFAULT 1)");
        db.execSQL("CREATE TABLE invoice_items(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER,product_id INTEGER,name TEXT,price REAL,qty INTEGER,sale_price REAL,partner_price REAL DEFAULT 0)");
        db.execSQL("CREATE TABLE shipping_companies(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE)");
        db.execSQL("CREATE TABLE shipping_accounts(id INTEGER PRIMARY KEY AUTOINCREMENT,company_id INTEGER NOT NULL,name TEXT NOT NULL,UNIQUE(company_id,name))");
        db.execSQL("CREATE TABLE sync_meta(entity TEXT NOT NULL,local_id INTEGER NOT NULL,state TEXT NOT NULL DEFAULT 'dirty',local_updated_at INTEGER NOT NULL,remote_updated_at INTEGER DEFAULT 0,last_synced_at INTEGER DEFAULT 0,deleted INTEGER DEFAULT 0,cloud_key TEXT,PRIMARY KEY(entity,local_id))");
        db.execSQL("CREATE TABLE suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE,phone TEXT,email TEXT,address TEXT,notes TEXT)");
        db.execSQL("CREATE TABLE supplier_products(id INTEGER PRIMARY KEY AUTOINCREMENT,supplier_id INTEGER NOT NULL,name TEXT NOT NULL,code TEXT,price REAL DEFAULT 0,image TEXT,notes TEXT,FOREIGN KEY(supplier_id) REFERENCES suppliers(id))");
        db.execSQL("CREATE TABLE supplier_orders(id INTEGER PRIMARY KEY AUTOINCREMENT,supplier_id INTEGER NOT NULL,date TEXT,total REAL DEFAULT 0,FOREIGN KEY(supplier_id) REFERENCES suppliers(id))");
        db.execSQL("CREATE TABLE supplier_order_items(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER NOT NULL,product_id INTEGER NOT NULL,name TEXT,code TEXT,price REAL,qty INTEGER,total REAL,FOREIGN KEY(order_id) REFERENCES supplier_orders(id))");
        db.execSQL("CREATE TABLE partner_product_settings(id INTEGER PRIMARY KEY AUTOINCREMENT,partner_id INTEGER NOT NULL,product_id INTEGER NOT NULL,partner_price REAL DEFAULT 0,price_tiers TEXT DEFAULT '',customer_image TEXT DEFAULT '',updated_at INTEGER DEFAULT 0,UNIQUE(partner_id,product_id))");
        db.execSQL("CREATE TABLE customer_product_prices(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_key TEXT NOT NULL,customer_id INTEGER NOT NULL,product_id INTEGER NOT NULL,last_price REAL NOT NULL DEFAULT 0,updated_at INTEGER DEFAULT 0,UNIQUE(customer_key,product_id))");
        seedShipping(db,"OzonExpress",new String[]{"Store MGE","Store MGE01","Maroc General Electronic"});
        seedShipping(db,"Tawsil",new String[]{"Store MGE","Store MGE01","Maroc General Electronic"});
        put(db,"company_name","MGE");
        put(db,"phone","+212666964731");
        put(db,"footer","Merci pour votre confiance");
        put(db,"default_shipping","30");
    }

    @Override public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        // تأكد من وجود شركات الشحن والحسابات الافتراضية حتى إذا كانت قاعدة البيانات
        // موجودة مسبقاً على الإصدار 10 ولم يتم تنفيذ seed عند إنشائها.
        ensureShippingData(db);
        try{ db.execSQL("CREATE TABLE IF NOT EXISTS partner_product_settings(id INTEGER PRIMARY KEY AUTOINCREMENT,partner_id INTEGER NOT NULL,product_id INTEGER NOT NULL,partner_price REAL DEFAULT 0,price_tiers TEXT DEFAULT '',customer_image TEXT DEFAULT '',updated_at INTEGER DEFAULT 0,UNIQUE(partner_id,product_id))"); }catch(Exception ignored){}
        try{ db.execSQL("CREATE TABLE IF NOT EXISTS sync_meta(entity TEXT NOT NULL,local_id INTEGER NOT NULL,state TEXT NOT NULL DEFAULT 'dirty',local_updated_at INTEGER NOT NULL,remote_updated_at INTEGER DEFAULT 0,last_synced_at INTEGER DEFAULT 0,deleted INTEGER DEFAULT 0,cloud_key TEXT,PRIMARY KEY(entity,local_id))"); }catch(Exception ignored){}
        try{ db.execSQL("ALTER TABLE invoice_items ADD COLUMN partner_price REAL DEFAULT 0"); }catch(Exception ignored){}
        try{ db.execSQL("ALTER TABLE invoices ADD COLUMN advance_payment REAL DEFAULT 0"); }catch(Exception ignored){}
        try{ db.execSQL("ALTER TABLE invoices ADD COLUMN advance_payment_date TEXT"); }catch(Exception ignored){}
        try{ db.execSQL("ALTER TABLE invoices ADD COLUMN advance_received_by_partner_id INTEGER DEFAULT 0"); }catch(Exception ignored){}
        try{ db.execSQL("ALTER TABLE invoices ADD COLUMN assembly_completed INTEGER DEFAULT 0"); }catch(Exception ignored){}
        try{ db.execSQL("CREATE TABLE IF NOT EXISTS partner_settlements(id INTEGER PRIMARY KEY AUTOINCREMENT,partner_id INTEGER NOT NULL,partner_name TEXT,date TEXT,total_invoices REAL DEFAULT 0,total_profit REAL DEFAULT 0,total_advances REAL DEFAULT 0,amount_paid REAL DEFAULT 0,invoice_count INTEGER DEFAULT 0)" ); }catch(Exception ignored){}
        try{ db.execSQL("CREATE TABLE IF NOT EXISTS partner_settlement_items(id INTEGER PRIMARY KEY AUTOINCREMENT,settlement_id INTEGER NOT NULL,invoice_id INTEGER NOT NULL,invoice_number INTEGER,invoice_total REAL DEFAULT 0,profit REAL DEFAULT 0,advance REAL DEFAULT 0)" ); }catch(Exception ignored){}
        try{ db.execSQL("ALTER TABLE partner_settlement_items ADD COLUMN client TEXT"); }catch(Exception ignored){}
        try{ db.execSQL("ALTER TABLE partner_settlement_items ADD COLUMN customer_phone TEXT"); }catch(Exception ignored){}
        try{ db.execSQL("ALTER TABLE partner_settlement_items ADD COLUMN customer_city TEXT"); }catch(Exception ignored){}
        try{ db.execSQL("ALTER TABLE partner_settlement_items ADD COLUMN customer_address TEXT"); }catch(Exception ignored){}
        try{ db.execSQL("ALTER TABLE partner_settlement_items ADD COLUMN tracking_number TEXT"); }catch(Exception ignored){}
        try{ db.execSQL("ALTER TABLE partner_settlement_items ADD COLUMN shipping_charge REAL DEFAULT 0"); }catch(Exception ignored){}
        try{ db.execSQL("ALTER TABLE partner_settlement_items ADD COLUMN shipping_cost REAL DEFAULT 0"); }catch(Exception ignored){}
        try{ db.execSQL("ALTER TABLE partner_settlement_items ADD COLUMN shipping_company TEXT"); }catch(Exception ignored){}
        try{ db.execSQL("ALTER TABLE partner_settlement_items ADD COLUMN shipping_account TEXT"); }catch(Exception ignored){}
        try{ db.execSQL("ALTER TABLE partner_settlement_items ADD COLUMN delivery_received INTEGER DEFAULT 0"); }catch(Exception ignored){}
        try{ db.execSQL("ALTER TABLE invoices ADD COLUMN created_at INTEGER DEFAULT 0"); }catch(Exception ignored){}
        try{ db.execSQL("ALTER TABLE invoices ADD COLUMN invoice_number_final INTEGER DEFAULT 1"); }catch(Exception ignored){}
        try{ db.execSQL("CREATE TABLE IF NOT EXISTS customer_product_prices(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_key TEXT NOT NULL,customer_id INTEGER NOT NULL,product_id INTEGER NOT NULL,last_price REAL NOT NULL DEFAULT 0,updated_at INTEGER DEFAULT 0,UNIQUE(customer_key,product_id))"); }catch(Exception ignored){}
        try{ db.execSQL("CREATE TABLE IF NOT EXISTS suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE,phone TEXT,email TEXT,address TEXT,notes TEXT)"); }catch(Exception ignored){}
        try{ db.execSQL("CREATE TABLE IF NOT EXISTS supplier_products(id INTEGER PRIMARY KEY AUTOINCREMENT,supplier_id INTEGER NOT NULL,name TEXT NOT NULL,code TEXT,price REAL DEFAULT 0,image TEXT,notes TEXT)"); }catch(Exception ignored){}
        try{ db.execSQL("CREATE TABLE IF NOT EXISTS supplier_orders(id INTEGER PRIMARY KEY AUTOINCREMENT,supplier_id INTEGER NOT NULL,date TEXT,total REAL DEFAULT 0)"); }catch(Exception ignored){}
        try{ db.execSQL("CREATE TABLE IF NOT EXISTS supplier_order_items(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER NOT NULL,product_id INTEGER NOT NULL,name TEXT,code TEXT,price REAL,qty INTEGER,total REAL)"); }catch(Exception ignored){}
        try{ db.execSQL("CREATE INDEX IF NOT EXISTS idx_supplier_orders_supplier ON supplier_orders(supplier_id,id)"); }catch(Exception ignored){}
        try{ db.execSQL("CREATE INDEX IF NOT EXISTS idx_supplier_order_items_order ON supplier_order_items(order_id,id)"); }catch(Exception ignored){}
    }

    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion) {
        if(oldVersion < 2){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN reseller INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE customers ADD COLUMN reseller INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN delivery_received INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN tracking_number TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN commission REAL DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoice_items ADD COLUMN sale_price REAL"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE invoice_items SET sale_price=price WHERE sale_price IS NULL OR sale_price=0"); }catch(Exception ignored){}
        }
        if(oldVersion < 3){
            try{ db.execSQL("ALTER TABLE customers ADD COLUMN partner_id INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE customers ADD COLUMN default_shipping REAL DEFAULT 30"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN partner_id INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN shipping_enabled INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN shipping_charge REAL DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN shipping_cost REAL DEFAULT 0"); }catch(Exception ignored){}
        }
        if(oldVersion < 4){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN partner_profit_paid INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE invoices SET partner_profit_paid=0 WHERE partner_profit_paid IS NULL"); }catch(Exception ignored){}
        }
        if(oldVersion < 5){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN paid_date TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE invoices SET paid_date=date WHERE paid=1 AND (paid_date IS NULL OR paid_date='')"); }catch(Exception ignored){}
        }
        if(oldVersion < 6){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN delivery_received_date TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN delivery_failure_reason TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE invoices SET delivery_received_date=date WHERE delivery_received=1 AND (delivery_received_date IS NULL OR delivery_received_date='')"); }catch(Exception ignored){}
        }
        if(oldVersion < 7){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN partner_profit_paid_date TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE invoices SET partner_profit_paid_date=date WHERE partner_profit_paid=1 AND (partner_profit_paid_date IS NULL OR partner_profit_paid_date='')"); }catch(Exception ignored){}
        }
        if(oldVersion < 9){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN shipping_company TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN shipping_account TEXT"); }catch(Exception ignored){}
        }
        if(oldVersion < 10){
            ensureShippingData(db);
        }
        if(oldVersion < 29){
            try{ db.execSQL("CREATE TABLE IF NOT EXISTS suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE,phone TEXT,email TEXT,address TEXT,notes TEXT)"); }catch(Exception ignored){}
            try{ db.execSQL("CREATE TABLE IF NOT EXISTS supplier_products(id INTEGER PRIMARY KEY AUTOINCREMENT,supplier_id INTEGER NOT NULL,name TEXT NOT NULL,code TEXT,price REAL DEFAULT 0,image TEXT,notes TEXT)"); }catch(Exception ignored){}
            try{ db.execSQL("CREATE TABLE IF NOT EXISTS supplier_orders(id INTEGER PRIMARY KEY AUTOINCREMENT,supplier_id INTEGER NOT NULL,date TEXT,total REAL DEFAULT 0)"); }catch(Exception ignored){}
            try{ db.execSQL("CREATE TABLE IF NOT EXISTS supplier_order_items(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER NOT NULL,product_id INTEGER NOT NULL,name TEXT,code TEXT,price REAL,qty INTEGER,total REAL)"); }catch(Exception ignored){}
        }
        if(oldVersion < 28){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN advance_payment REAL DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN advance_payment_date TEXT"); }catch(Exception ignored){}
        try{ db.execSQL("ALTER TABLE invoices ADD COLUMN advance_received_by_partner_id INTEGER DEFAULT 0"); }catch(Exception ignored){}
        try{ db.execSQL("ALTER TABLE invoices ADD COLUMN assembly_completed INTEGER DEFAULT 0"); }catch(Exception ignored){}
        try{ db.execSQL("CREATE TABLE IF NOT EXISTS partner_settlements(id INTEGER PRIMARY KEY AUTOINCREMENT,partner_id INTEGER NOT NULL,partner_name TEXT,date TEXT,total_invoices REAL DEFAULT 0,total_profit REAL DEFAULT 0,total_advances REAL DEFAULT 0,amount_paid REAL DEFAULT 0,invoice_count INTEGER DEFAULT 0)" ); }catch(Exception ignored){}
        try{ db.execSQL("CREATE TABLE IF NOT EXISTS partner_settlement_items(id INTEGER PRIMARY KEY AUTOINCREMENT,settlement_id INTEGER NOT NULL,invoice_id INTEGER NOT NULL,invoice_number INTEGER,invoice_total REAL DEFAULT 0,profit REAL DEFAULT 0,advance REAL DEFAULT 0)" ); }catch(Exception ignored){}
        try{ db.execSQL("ALTER TABLE invoices ADD COLUMN created_at INTEGER DEFAULT 0"); }catch(Exception ignored){}
        try{ db.execSQL("ALTER TABLE invoices ADD COLUMN invoice_number_final INTEGER DEFAULT 1"); }catch(Exception ignored){}
        }
        if(oldVersion < 31){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN assembly_completed INTEGER DEFAULT 0"); }catch(Exception ignored){}
        try{ db.execSQL("CREATE TABLE IF NOT EXISTS partner_settlements(id INTEGER PRIMARY KEY AUTOINCREMENT,partner_id INTEGER NOT NULL,partner_name TEXT,date TEXT,total_invoices REAL DEFAULT 0,total_profit REAL DEFAULT 0,total_advances REAL DEFAULT 0,amount_paid REAL DEFAULT 0,invoice_count INTEGER DEFAULT 0)" ); }catch(Exception ignored){}
        try{ db.execSQL("CREATE TABLE IF NOT EXISTS partner_settlement_items(id INTEGER PRIMARY KEY AUTOINCREMENT,settlement_id INTEGER NOT NULL,invoice_id INTEGER NOT NULL,invoice_number INTEGER,invoice_total REAL DEFAULT 0,profit REAL DEFAULT 0,advance REAL DEFAULT 0)" ); }catch(Exception ignored){}
        try{ db.execSQL("ALTER TABLE invoices ADD COLUMN created_at INTEGER DEFAULT 0"); }catch(Exception ignored){}
        try{ db.execSQL("ALTER TABLE invoices ADD COLUMN invoice_number_final INTEGER DEFAULT 1"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE invoices SET assembly_completed=0 WHERE assembly_completed IS NULL"); }catch(Exception ignored){}
        }
        if(oldVersion < 32){
            // Invoice numbering is now allocated globally by Firestore. Existing
            // invoice numbers are intentionally preserved so historical invoices
            // are never silently renumbered during an app update.
            try{ db.execSQL("UPDATE invoices SET invoice_number=id WHERE invoice_number IS NULL OR invoice_number=0"); }catch(Exception ignored){}
        }
        if(oldVersion < 27){
            try{ db.execSQL("ALTER TABLE invoice_items ADD COLUMN partner_price REAL DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE invoice_items SET partner_price=sale_price WHERE partner_price IS NULL OR partner_price=0"); }catch(Exception ignored){}
        }
        if(oldVersion < 24){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN bank_received INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN bank_received_date TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE invoices SET bank_received_date=date WHERE bank_received=1 AND (bank_received_date IS NULL OR bank_received_date='')"); }catch(Exception ignored){}
        }
        if(oldVersion < 25){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN company_accounted INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN company_accounted_date TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN company_accounting_store TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN company_accounting_export_id TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN virement_code TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN virement_date TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN virement_total_crbt REAL DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN virement_total_fees REAL DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN virement_net REAL DEFAULT 0"); }catch(Exception ignored){}
        }
        if(oldVersion < 11){
            try{ db.execSQL("CREATE TABLE IF NOT EXISTS sync_meta(entity TEXT NOT NULL,local_id INTEGER NOT NULL,state TEXT NOT NULL DEFAULT 'dirty',local_updated_at INTEGER NOT NULL,remote_updated_at INTEGER DEFAULT 0,last_synced_at INTEGER DEFAULT 0,deleted INTEGER DEFAULT 0,cloud_key TEXT,PRIMARY KEY(entity,local_id))"); }catch(Exception ignored){}
            markExistingRowsDirty(db, "products");
            markExistingRowsDirty(db, "customers");
            markExistingRowsDirty(db, "invoices");
        }
        if(oldVersion < 12){
            try{ db.execSQL("ALTER TABLE customers ADD COLUMN partner_uid TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE customers ADD COLUMN partner_email TEXT"); }catch(Exception ignored){}
            // Any partner/customer links that already exist by Partner ID are kept.
            // New partner accounts will also receive a canonical linked customer row.
        }
        if(oldVersion < 13){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN shipped_by_admin INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE invoices SET shipped_by_admin=1 WHERE tracking_number IS NOT NULL AND tracking_number<>''"); }catch(Exception ignored){}
        }
        if(oldVersion < 14){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN customer_phone TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN customer_city TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN customer_address TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN customer_type TEXT DEFAULT 'normal'"); }catch(Exception ignored){}
        }
        if(oldVersion < 15){
            try{ db.execSQL("ALTER TABLE customers ADD COLUMN cloud_id TEXT"); }catch(Exception ignored){}
        }
        if(oldVersion < 16){
            try{ db.execSQL("ALTER TABLE sync_meta ADD COLUMN cloud_key TEXT"); }catch(Exception ignored){}
        }
        if(oldVersion < 19){
            try{ db.execSQL("ALTER TABLE products ADD COLUMN available INTEGER DEFAULT 1"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE products ADD COLUMN price_tiers TEXT DEFAULT ''"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE products SET available=1 WHERE available IS NULL"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE products SET price_tiers='' WHERE price_tiers IS NULL"); }catch(Exception ignored){}
        }
        if(oldVersion < 20){
            try{ db.execSQL("CREATE INDEX IF NOT EXISTS idx_products_available ON products(available)"); }catch(Exception ignored){}
        }
        if(oldVersion < 22){
            try{ db.execSQL("CREATE TABLE IF NOT EXISTS partner_product_settings(id INTEGER PRIMARY KEY AUTOINCREMENT,partner_id INTEGER NOT NULL,product_id INTEGER NOT NULL,partner_price REAL DEFAULT 0,price_tiers TEXT DEFAULT '',customer_image TEXT DEFAULT '',updated_at INTEGER DEFAULT 0,UNIQUE(partner_id,product_id))"); }catch(Exception ignored){}
            try{ db.execSQL("CREATE INDEX IF NOT EXISTS idx_partner_product_settings_partner ON partner_product_settings(partner_id)"); }catch(Exception ignored){}
            try{ db.execSQL("CREATE INDEX IF NOT EXISTS idx_partner_product_settings_product ON partner_product_settings(product_id)"); }catch(Exception ignored){}
        }
        if(oldVersion < 23){
            try{ db.execSQL("ALTER TABLE partner_product_settings ADD COLUMN price_tiers TEXT DEFAULT ''"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE partner_product_settings SET price_tiers='' WHERE price_tiers IS NULL"); }catch(Exception ignored){}
        }
        if(oldVersion < 26){
            try{ db.execSQL("ALTER TABLE invoice_items ADD COLUMN partner_price REAL DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("CREATE TABLE IF NOT EXISTS customer_product_prices(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_key TEXT NOT NULL,customer_id INTEGER NOT NULL,product_id INTEGER NOT NULL,last_price REAL NOT NULL DEFAULT 0,updated_at INTEGER DEFAULT 0,UNIQUE(customer_key,product_id))"); }catch(Exception ignored){}
        try{ db.execSQL("CREATE TABLE IF NOT EXISTS suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE,phone TEXT,email TEXT,address TEXT,notes TEXT)"); }catch(Exception ignored){}
        try{ db.execSQL("CREATE TABLE IF NOT EXISTS supplier_products(id INTEGER PRIMARY KEY AUTOINCREMENT,supplier_id INTEGER NOT NULL,name TEXT NOT NULL,code TEXT,price REAL DEFAULT 0,image TEXT,notes TEXT)"); }catch(Exception ignored){}
        try{ db.execSQL("CREATE TABLE IF NOT EXISTS supplier_orders(id INTEGER PRIMARY KEY AUTOINCREMENT,supplier_id INTEGER NOT NULL,date TEXT,total REAL DEFAULT 0)"); }catch(Exception ignored){}
        try{ db.execSQL("CREATE TABLE IF NOT EXISTS supplier_order_items(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER NOT NULL,product_id INTEGER NOT NULL,name TEXT,code TEXT,price REAL,qty INTEGER,total REAL)"); }catch(Exception ignored){}
            try{ db.execSQL("CREATE INDEX IF NOT EXISTS idx_customer_product_prices_customer ON customer_product_prices(customer_key)"); }catch(Exception ignored){}
            try{ db.execSQL("CREATE INDEX IF NOT EXISTS idx_customer_product_prices_product ON customer_product_prices(product_id)"); }catch(Exception ignored){}
        }
        if(oldVersion < 17){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN invoice_number INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN cloud_key TEXT"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE invoices SET invoice_number=id WHERE invoice_number IS NULL OR invoice_number=0"); }catch(Exception ignored){}
        }
        if(oldVersion < 33){
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN created_at INTEGER DEFAULT 0"); }catch(Exception ignored){}
            try{ db.execSQL("ALTER TABLE invoices ADD COLUMN invoice_number_final INTEGER DEFAULT 1"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE invoices SET created_at=id*1000 WHERE created_at IS NULL OR created_at=0"); }catch(Exception ignored){}
            try{ db.execSQL("UPDATE invoices SET invoice_number_final=1 WHERE invoice_number_final IS NULL"); }catch(Exception ignored){}
            try{ db.execSQL("CREATE INDEX IF NOT EXISTS idx_invoices_created_at ON invoices(created_at DESC)"); }catch(Exception ignored){}
        }
        // حتى في قواعد البيانات التي كانت أصلاً على الإصدار 10 أو أحدث،
        // نضمن وجود الجداول والبيانات الافتراضية.
        ensureShippingData(db);
    }

    private void ensureShippingData(SQLiteDatabase db){
        try{ db.execSQL("CREATE TABLE IF NOT EXISTS shipping_companies(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE)"); }catch(Exception ignored){}
        try{ db.execSQL("CREATE TABLE IF NOT EXISTS shipping_accounts(id INTEGER PRIMARY KEY AUTOINCREMENT,company_id INTEGER NOT NULL,name TEXT NOT NULL,UNIQUE(company_id,name))"); }catch(Exception ignored){}
        seedShipping(db,"OzonExpress",new String[]{"Store MGE","Store MGE01","Maroc General Electronic"});
        seedShipping(db,"Tawsil",new String[]{"Store MGE","Store MGE01","Maroc General Electronic"});
    }

    private void seedShipping(SQLiteDatabase db,String company,String[] accounts){
        ContentValues c=new ContentValues();c.put("name",company);long cid=db.insertWithOnConflict("shipping_companies",null,c,SQLiteDatabase.CONFLICT_IGNORE);
        if(cid==-1){Cursor q=db.query("shipping_companies",new String[]{"id"},"name=?",new String[]{company},null,null,null);try{if(q.moveToFirst())cid=q.getLong(0);}finally{q.close();}}
        for(String a:accounts){ContentValues v=new ContentValues();v.put("company_id",cid);v.put("name",a);db.insertWithOnConflict("shipping_accounts",null,v,SQLiteDatabase.CONFLICT_IGNORE);}
    }

    public static class ShippingCompany { public int id; public String name; ShippingCompany(int i,String n){id=i;name=n;} }
    public static class ShippingAccount { public int id,companyId; public String name; ShippingAccount(int i,int c,String n){id=i;companyId=c;name=n;} }

    public ArrayList<ShippingCompany> shippingCompanies(){
        ArrayList<ShippingCompany>a=new ArrayList<>();Cursor c=getReadableDatabase().query("shipping_companies",null,null,null,null,null,"name COLLATE NOCASE ASC");
        try{while(c.moveToNext())a.add(new ShippingCompany(c.getInt(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("name"))));}finally{c.close();}return a;
    }
    public ArrayList<ShippingAccount> shippingAccounts(int companyId){
        ArrayList<ShippingAccount>a=new ArrayList<>();Cursor c=getReadableDatabase().query("shipping_accounts",null,"company_id=?",new String[]{""+companyId},null,null,"name COLLATE NOCASE ASC");
        try{while(c.moveToNext())a.add(new ShippingAccount(c.getInt(c.getColumnIndexOrThrow("id")),c.getInt(c.getColumnIndexOrThrow("company_id")),c.getString(c.getColumnIndexOrThrow("name"))));}finally{c.close();}return a;
    }
    /** All configured Store/shipping accounts across all shipping companies. */
    public ArrayList<ShippingAccount> shippingAccountsAll(){
        ArrayList<ShippingAccount>a=new ArrayList<>();
        Cursor c=getReadableDatabase().query("shipping_accounts",null,null,null,null,null,"name COLLATE NOCASE ASC, id ASC");
        try{while(c.moveToNext())a.add(new ShippingAccount(c.getInt(c.getColumnIndexOrThrow("id")),c.getInt(c.getColumnIndexOrThrow("company_id")),c.getString(c.getColumnIndexOrThrow("name"))));}finally{c.close();}
        return a;
    }
    public long addShippingCompany(String name){ContentValues v=new ContentValues();v.put("name",name.trim());return getWritableDatabase().insertWithOnConflict("shipping_companies",null,v,SQLiteDatabase.CONFLICT_IGNORE);}
    public long addShippingAccount(int companyId,String name){ContentValues v=new ContentValues();v.put("company_id",companyId);v.put("name",name.trim());return getWritableDatabase().insertWithOnConflict("shipping_accounts",null,v,SQLiteDatabase.CONFLICT_IGNORE);}
    public boolean updateShippingCompany(int id,String name){ContentValues v=new ContentValues();v.put("name",name.trim());return getWritableDatabase().update("shipping_companies",v,"id=?",new String[]{""+id})>0;}
    public boolean updateShippingAccount(int id,int companyId,String name){ContentValues v=new ContentValues();v.put("company_id",companyId);v.put("name",name.trim());return getWritableDatabase().update("shipping_accounts",v,"id=?",new String[]{""+id})>0;}
    public void deleteShippingAccount(int id){getWritableDatabase().delete("shipping_accounts","id=?",new String[]{""+id});}
    public void deleteShippingCompany(int id){SQLiteDatabase d=getWritableDatabase();d.delete("shipping_accounts","company_id=?",new String[]{""+id});d.delete("shipping_companies","id=?",new String[]{""+id});}

    private void markExistingRowsDirty(SQLiteDatabase db,String table){
        try{ Cursor c=db.query(table,new String[]{"id"},null,null,null,null,null); long now=System.currentTimeMillis(); while(c.moveToNext()){ markSync(db,table,c.getInt(0),now,"dirty",0,false); } c.close(); }catch(Exception ignored){}
    }
    public void markSync(String entity,int localId,long updatedAt,String state,long remoteUpdatedAt,boolean deleted){
        markSync(getWritableDatabase(),entity,localId,updatedAt,state,remoteUpdatedAt,deleted);
    }
    private void markSync(SQLiteDatabase db,String entity,int localId,long updatedAt,String state,long remoteUpdatedAt,boolean deleted){
        // Preserve cloud_key across every sync_meta state transition. Losing it when
        // changing dirty -> clean was the reason deleted invoices could be downloaded
        // again after synchronization.
        String cloudKey="";
        Cursor old=db.query("sync_meta",new String[]{"cloud_key"},"entity=? AND local_id=?",new String[]{entity,String.valueOf(localId)},null,null,null);
        try{if(old.moveToFirst()&&!old.isNull(0))cloudKey=old.getString(0);}finally{old.close();}
        ContentValues v=new ContentValues(); v.put("entity",entity); v.put("local_id",localId); v.put("state",state); v.put("local_updated_at",updatedAt); v.put("remote_updated_at",remoteUpdatedAt); v.put("last_synced_at",System.currentTimeMillis()); v.put("deleted",deleted?1:0); if(!cloudKey.isEmpty())v.put("cloud_key",cloudKey); db.insertWithOnConflict("sync_meta",null,v,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public long syncLocalUpdatedAt(String entity,int localId){ Cursor c=getReadableDatabase().query("sync_meta",new String[]{"local_updated_at"},"entity=? AND local_id=?",new String[]{entity,String.valueOf(localId)},null,null,null); try{return c.moveToFirst()?c.getLong(0):0;}finally{c.close();} }
    public String syncState(String entity,int localId){ Cursor c=getReadableDatabase().query("sync_meta",new String[]{"state"},"entity=? AND local_id=?",new String[]{entity,String.valueOf(localId)},null,null,null); try{return c.moveToFirst()?c.getString(0):"dirty";}finally{c.close();} }
    public int syncDirtyCount(){ Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM sync_meta WHERE state='dirty'",null); try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();} }
    public int syncDirtyCount(String entity){ Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM sync_meta WHERE entity=? AND state='dirty'",new String[]{entity}); try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();} }
    public long syncLastAt(){ Cursor c=getReadableDatabase().rawQuery("SELECT MAX(last_synced_at) FROM sync_meta WHERE state='clean'",null); try{return c.moveToFirst()?c.getLong(0):0;}finally{c.close();} }
    public int syncTotal(String entity){ Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM sync_meta WHERE entity=?",new String[]{entity}); try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();} }
    public void markSyncClean(String entity,int localId,long remoteUpdatedAt){ markSync(entity,localId,System.currentTimeMillis(),"clean",remoteUpdatedAt,false); }
    public void setSyncCloudKey(String entity,int localId,String cloudKey){ ContentValues v=new ContentValues();v.put("cloud_key",cloudKey);getWritableDatabase().update("sync_meta",v,"entity=? AND local_id=?",new String[]{entity,String.valueOf(localId)}); }
    public void setInvoiceCloudKey(int invoiceId,String cloudKey){ ContentValues v=new ContentValues();v.put("cloud_key",cloudKey);getWritableDatabase().update("invoices",v,"id=?",new String[]{String.valueOf(invoiceId)});setSyncCloudKey("invoices",invoiceId,cloudKey); }
    public String syncCloudKey(String entity,int localId){ Cursor c=getReadableDatabase().query("sync_meta",new String[]{"cloud_key"},"entity=? AND local_id=?",new String[]{entity,String.valueOf(localId)},null,null,null);try{return c.moveToFirst()&&!c.isNull(0)?c.getString(0):"";}finally{c.close();} }
    public void markSyncDeleted(String entity,int localId){ markSync(entity,localId,System.currentTimeMillis(),"dirty",0,true); }

    private void put(SQLiteDatabase db,String k,String v){ ContentValues x=new ContentValues();x.put("k",k);x.put("v",v);db.insertWithOnConflict("settings",null,x,SQLiteDatabase.CONFLICT_REPLACE); }
    public void put(String k,String v){put(getWritableDatabase(),k,v);}
    public String get(String k,String def){Cursor c=getReadableDatabase().query("settings",new String[]{"v"},"k=?",new String[]{k},null,null,null);try{return c.moveToFirst()?c.getString(0):def;}finally{c.close();}}

    public static class Product {
        public int id; public String name,code,image,priceTiers; public double price; public boolean available;
        Product(int i,String n,String c,double p,String im,boolean a,String tiers){id=i;name=n;code=c;price=p;image=im;available=a;priceTiers=tiers==null?"":tiers;}
        public double priceForQty(int qty){
            double result=price;
            if(qty<=0 || priceTiers==null || priceTiers.trim().isEmpty()) return result;
            String[] rows=priceTiers.split(";");
            int best=0;
            for(String row:rows){
                try{ String[] x=row.trim().split("="); if(x.length<2) continue; int min=Integer.parseInt(x[0].trim()); double p=Double.parseDouble(x[1].trim()); if(min>0 && min<=qty && min>=best){best=min;result=p;} }catch(Exception ignored){}
            }
            return result;
        }
    }
    public static class Customer {
        public int id,partnerId;public String name,phone,city,address,partnerUid,partnerEmail,cloudId;public boolean reseller;public double defaultShipping;
        Customer(int i,String n,String p,String c,String a,boolean r,int pi,String pu,String pe,double ds,String ci){id=i;name=n;phone=p;city=c;address=a;reseller=r;partnerId=pi;partnerUid=pu;partnerEmail=pe;defaultShipping=ds;cloudId=ci==null?"":ci;}
    }
    public static class Item { public int productId,qty;public String name;public double price,salePrice,partnerPrice;public Item(int pid,String n,double p,int q){productId=pid;name=n;price=p;qty=q;salePrice=p;partnerPrice=p;}public Item(int pid,String n,double p,double sp,int q){productId=pid;name=n;price=p;salePrice=sp;qty=q;partnerPrice=sp;} public Item(int pid,String n,double p,double sp,double pp,int q){productId=pid;name=n;price=p;salePrice=sp;partnerPrice=pp;qty=q;} }
    public static class Invoice {
        public int id,clientId,partnerId,invoiceNumber,advanceReceivedByPartnerId;public long createdAt;public boolean invoiceNumberFinal=true;public String cloudKey;public String client,date,customerPhone,customerCity,customerAddress,customerType,paidDate,trackingNumber,deliveryReceivedDate,deliveryFailureReason,partnerProfitPaidDate,bankReceivedDate,shippingCompany,shippingAccount,companyAccountedDate,companyAccountingStore,companyAccountingExportId,virementCode,virementDate,advancePaymentDate;public boolean paid,reseller,deliveryReceived,shippingEnabled,partnerProfitPaid,bankReceived,shippedByAdmin,companyAccounted,assemblyCompleted;public double commission,shippingCharge,shippingCost,virementTotalCrbt,virementTotalFees,virementNet,advancePayment;public ArrayList<Item> items=new ArrayList<>();
        Invoice(int i,int ci,String cl,String d,boolean p){id=i;clientId=ci;client=cl;date=d;paid=p;}
    }

    public ArrayList<Product> products(String q){ArrayList<Product>a=new ArrayList<>();q=q==null?"":q.trim();Cursor c=getReadableDatabase().query("products",null,q.isEmpty()?null:"name LIKE ? OR code LIKE ?",q.isEmpty()?null:new String[]{"%"+q+"%","%"+q+"%"},null,null,"name COLLATE NOCASE ASC");try{while(c.moveToNext())a.add(readProduct(c));}finally{c.close();}return a;}
    public Product product(int id){Cursor c=getReadableDatabase().query("products",null,"id=?",new String[]{""+id},null,null,null);try{if(!c.moveToFirst())return null;return readProduct(c);}finally{c.close();}}
    /** Returns the original catalog image for a supplier product, matching by code first and then name. */
    public String productImageForSupplier(String code,String name){
        String img="";
        if(code!=null && !code.trim().isEmpty()){
            Cursor c=getReadableDatabase().query("products",new String[]{"image"},"code=?",new String[]{code.trim()},null,null,"id DESC","1");
            try{if(c.moveToFirst() && !c.isNull(0)) img=c.getString(0);}finally{c.close();}
        }
        if(img==null || img.trim().isEmpty()){
            if(name!=null && !name.trim().isEmpty()){
                Cursor c=getReadableDatabase().query("products",new String[]{"image"},"name=?",new String[]{name.trim()},null,null,"id DESC","1");
                try{if(c.moveToFirst() && !c.isNull(0)) img=c.getString(0);}finally{c.close();}
            }
        }
        return img==null?"":img.trim();
    }
    private Product readProduct(Cursor c){
        int ai=c.getColumnIndex("available"); int ti=c.getColumnIndex("price_tiers");
        boolean available=ai<0 || c.isNull(ai) || c.getInt(ai)!=0;
        String tiers=ti<0||c.isNull(ti)?"":c.getString(ti);
        return new Product(c.getInt(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("name")),c.getString(c.getColumnIndexOrThrow("code")),c.getDouble(c.getColumnIndexOrThrow("price")),c.getString(c.getColumnIndexOrThrow("image")),available,tiers);
    }
    public void saveProduct(int id,String name,String code,double price,String image,boolean available,String priceTiers){ContentValues v=new ContentValues();v.put("name",name);v.put("code",code);v.put("price",price);v.put("image",image);v.put("available",available?1:0);v.put("price_tiers",priceTiers==null?"":priceTiers);long now=System.currentTimeMillis(); int actualId=id; if(id<0){actualId=(int)getWritableDatabase().insert("products",null,v);}else getWritableDatabase().update("products",v,"id=?",new String[]{""+id}); if(actualId>0)markSync("products",actualId,now,"dirty",0,false);}
    public static class Supplier { public int id; public String name,phone,email,address,notes; Supplier(int i,String n,String p,String e,String a,String no){id=i;name=n;phone=p;email=e;address=a;notes=no;} }
    public static class SupplierProduct { public int id,supplierId; public String name,code,image,notes; public double price; SupplierProduct(int i,int si,String n,String c,double p,String im,String no){id=i;supplierId=si;name=n;code=c;price=p;image=im;notes=no;} }
    public ArrayList<Supplier> suppliers(String q){ArrayList<Supplier>a=new ArrayList<>();q=q==null?"":q.trim();Cursor c=getReadableDatabase().query("suppliers",null,q.isEmpty()?null:"name LIKE ? OR phone LIKE ?",q.isEmpty()?null:new String[]{"%"+q+"%","%"+q+"%"},null,null,"name COLLATE NOCASE ASC");try{while(c.moveToNext())a.add(new Supplier(c.getInt(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("name")),c.getString(c.getColumnIndexOrThrow("phone")),c.getString(c.getColumnIndexOrThrow("email")),c.getString(c.getColumnIndexOrThrow("address")),c.getString(c.getColumnIndexOrThrow("notes"))));}finally{c.close();}return a;}
    public Supplier supplier(int id){Cursor c=getReadableDatabase().query("suppliers",null,"id=?",new String[]{String.valueOf(id)},null,null,null);try{if(!c.moveToFirst())return null;return new Supplier(c.getInt(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("name")),c.getString(c.getColumnIndexOrThrow("phone")),c.getString(c.getColumnIndexOrThrow("email")),c.getString(c.getColumnIndexOrThrow("address")),c.getString(c.getColumnIndexOrThrow("notes")));}finally{c.close();}}
    public int saveSupplier(int id,String name,String phone,String email,String address,String notes){ContentValues v=new ContentValues();v.put("name",name);v.put("phone",phone);v.put("email",email);v.put("address",address);v.put("notes",notes);if(id<0){long x=getWritableDatabase().insertWithOnConflict("suppliers",null,v,SQLiteDatabase.CONFLICT_IGNORE);return (int)x;}getWritableDatabase().update("suppliers",v,"id=?",new String[]{String.valueOf(id)});return id;}
    public void deleteSupplier(int id){SQLiteDatabase d=getWritableDatabase();d.delete("supplier_order_items","order_id IN (SELECT id FROM supplier_orders WHERE supplier_id=?)",new String[]{String.valueOf(id)});d.delete("supplier_orders","supplier_id=?",new String[]{String.valueOf(id)});d.delete("supplier_products","supplier_id=?",new String[]{String.valueOf(id)});d.delete("suppliers","id=?",new String[]{String.valueOf(id)});}
    public ArrayList<SupplierProduct> supplierProducts(int supplierId,String q){ArrayList<SupplierProduct>a=new ArrayList<>();q=q==null?"":q.trim();String w="supplier_id=?";ArrayList<String>args=new ArrayList<>();args.add(String.valueOf(supplierId));if(!q.isEmpty()){w+=" AND (name LIKE ? OR code LIKE ?)";args.add("%"+q+"%");args.add("%"+q+"%");}Cursor c=getReadableDatabase().query("supplier_products",null,w,args.toArray(new String[0]),null,null,"name COLLATE NOCASE ASC");try{while(c.moveToNext())a.add(new SupplierProduct(c.getInt(c.getColumnIndexOrThrow("id")),supplierId,c.getString(c.getColumnIndexOrThrow("name")),c.getString(c.getColumnIndexOrThrow("code")),c.getDouble(c.getColumnIndexOrThrow("price")),c.getString(c.getColumnIndexOrThrow("image")),c.getString(c.getColumnIndexOrThrow("notes"))));}finally{c.close();}return a;}
    public SupplierProduct supplierProduct(int id){Cursor c=getReadableDatabase().query("supplier_products",null,"id=?",new String[]{String.valueOf(id)},null,null,null);try{if(!c.moveToFirst())return null;return new SupplierProduct(id,c.getInt(c.getColumnIndexOrThrow("supplier_id")),c.getString(c.getColumnIndexOrThrow("name")),c.getString(c.getColumnIndexOrThrow("code")),c.getDouble(c.getColumnIndexOrThrow("price")),c.getString(c.getColumnIndexOrThrow("image")),c.getString(c.getColumnIndexOrThrow("notes")));}finally{c.close();}}
    public int saveSupplierProduct(int id,int supplierId,String name,String code,double price,String image,String notes){ContentValues v=new ContentValues();v.put("supplier_id",supplierId);v.put("name",name);v.put("code",code);v.put("price",price);v.put("image",image);v.put("notes",notes);if(id<0)return (int)getWritableDatabase().insert("supplier_products",null,v);getWritableDatabase().update("supplier_products",v,"id=?",new String[]{String.valueOf(id)});return id;}
    public void deleteSupplierProduct(int id){getWritableDatabase().delete("supplier_products","id=?",new String[]{String.valueOf(id)});}

    public static class SupplierOrder { public int id,supplierId; public String date; public double total; SupplierOrder(int i,int si,String d,double t){id=i;supplierId=si;date=d;total=t;} }
    public static class SupplierOrderItem { public int id,orderId,productId,qty; public String name,code; public double price,total; SupplierOrderItem(int i,int oi,int pi,String n,String c,double p,int q,double t){id=i;orderId=oi;productId=pi;name=n;code=c;price=p;qty=q;total=t;} }
    public ArrayList<SupplierOrder> supplierOrders(int supplierId){
        ArrayList<SupplierOrder>a=new ArrayList<>();
        Cursor c=getReadableDatabase().query("supplier_orders",null,"supplier_id=?",new String[]{String.valueOf(supplierId)},null,null,"id DESC");
        try{while(c.moveToNext())a.add(new SupplierOrder(c.getInt(c.getColumnIndexOrThrow("id")),supplierId,c.getString(c.getColumnIndexOrThrow("date")),c.getDouble(c.getColumnIndexOrThrow("total"))));}finally{c.close();}
        return a;
    }
    public SupplierOrder supplierOrder(int id){
        Cursor c=getReadableDatabase().query("supplier_orders",null,"id=?",new String[]{String.valueOf(id)},null,null,null);
        try{if(!c.moveToFirst())return null;return new SupplierOrder(id,c.getInt(c.getColumnIndexOrThrow("supplier_id")),c.getString(c.getColumnIndexOrThrow("date")),c.getDouble(c.getColumnIndexOrThrow("total")));}finally{c.close();}
    }
    public ArrayList<SupplierOrderItem> supplierOrderItems(int orderId){
        ArrayList<SupplierOrderItem>a=new ArrayList<>();
        Cursor c=getReadableDatabase().query("supplier_order_items",null,"order_id=?",new String[]{String.valueOf(orderId)},null,null,"id ASC");
        try{while(c.moveToNext())a.add(new SupplierOrderItem(c.getInt(c.getColumnIndexOrThrow("id")),orderId,c.getInt(c.getColumnIndexOrThrow("product_id")),c.getString(c.getColumnIndexOrThrow("name")),c.getString(c.getColumnIndexOrThrow("code")),c.getDouble(c.getColumnIndexOrThrow("price")),c.getInt(c.getColumnIndexOrThrow("qty")),c.getDouble(c.getColumnIndexOrThrow("total"))));}finally{c.close();}
        return a;
    }
    public int createSupplierOrder(int supplierId,ArrayList<SupplierOrderItem> items,String date){
        SQLiteDatabase d=getWritableDatabase();d.beginTransaction();
        try{double total=0;for(SupplierOrderItem x:items)total+=x.total;ContentValues v=new ContentValues();v.put("supplier_id",supplierId);v.put("date",date);v.put("total",total);int id=(int)d.insert("supplier_orders",null,v);if(id<=0)throw new IllegalStateException("order insert failed");
            for(SupplierOrderItem x:items){ContentValues iv=new ContentValues();iv.put("order_id",id);iv.put("product_id",x.productId);iv.put("name",x.name);iv.put("code",x.code);iv.put("price",x.price);iv.put("qty",x.qty);iv.put("total",x.total);d.insert("supplier_order_items",null,iv);}d.setTransactionSuccessful();return id;
        }finally{d.endTransaction();}
    }
    public void updateSupplierOrder(int orderId,ArrayList<SupplierOrderItem> items){
        SQLiteDatabase d=getWritableDatabase();d.beginTransaction();
        try{double total=0;for(SupplierOrderItem x:items)total+=x.total;ContentValues v=new ContentValues();v.put("total",total);v.put("date",new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.US).format(new Date()));d.update("supplier_orders",v,"id=?",new String[]{String.valueOf(orderId)});d.delete("supplier_order_items","order_id=?",new String[]{String.valueOf(orderId)});
            for(SupplierOrderItem x:items){ContentValues iv=new ContentValues();iv.put("order_id",orderId);iv.put("product_id",x.productId);iv.put("name",x.name);iv.put("code",x.code);iv.put("price",x.price);iv.put("qty",x.qty);iv.put("total",x.total);d.insert("supplier_order_items",null,iv);}d.setTransactionSuccessful();
        }finally{d.endTransaction();}
    }
    public void deleteSupplierOrder(int orderId){SQLiteDatabase d=getWritableDatabase();d.delete("supplier_order_items","order_id=?",new String[]{String.valueOf(orderId)});d.delete("supplier_orders","id=?",new String[]{String.valueOf(orderId)});}

    public static class PartnerProductSetting {
        public int id,partnerId,productId; public double partnerPrice; public String priceTiers,customerImage;
        PartnerProductSetting(int i,int pi,int prod,double price,String tiers,String image){id=i;partnerId=pi;productId=prod;partnerPrice=price;priceTiers=tiers==null?"":tiers;customerImage=image==null?"":image;}
        public double priceForQty(int qty){
            double result=partnerPrice;
            if(qty<=0 || priceTiers==null || priceTiers.trim().isEmpty()) return result;
            int best=0;
            for(String row:priceTiers.split(";")){
                try{String[] x=row.trim().split("=");if(x.length<2)continue;int min=Integer.parseInt(x[0].trim());double p=Double.parseDouble(x[1].trim());if(min>0&&min<=qty&&min>=best){best=min;result=p;}}catch(Exception ignored){}
            }
            return result;
        }
    }
    public PartnerProductSetting partnerProductSetting(int partnerId,int productId){Cursor c=getReadableDatabase().query("partner_product_settings",null,"partner_id=? AND product_id=?",new String[]{String.valueOf(partnerId),String.valueOf(productId)},null,null,null);try{if(!c.moveToFirst())return null;int ti=c.getColumnIndex("price_tiers");String tiers=ti<0||c.isNull(ti)?"":c.getString(ti);return new PartnerProductSetting(c.getInt(c.getColumnIndexOrThrow("id")),partnerId,productId,c.getDouble(c.getColumnIndexOrThrow("partner_price")),tiers,c.getString(c.getColumnIndexOrThrow("customer_image")));}finally{c.close();}}
    public ArrayList<PartnerProductSetting> partnerProductSettingsForProduct(int productId){ArrayList<PartnerProductSetting>a=new ArrayList<>();Cursor c=getReadableDatabase().query("partner_product_settings",null,"product_id=?",new String[]{String.valueOf(productId)},null,null,"partner_id ASC");try{while(c.moveToNext()){int ti=c.getColumnIndex("price_tiers");String tiers=ti<0||c.isNull(ti)?"":c.getString(ti);a.add(new PartnerProductSetting(c.getInt(c.getColumnIndexOrThrow("id")),c.getInt(c.getColumnIndexOrThrow("partner_id")),productId,c.getDouble(c.getColumnIndexOrThrow("partner_price")),tiers,c.getString(c.getColumnIndexOrThrow("customer_image"))));}}finally{c.close();}return a;}
    public ArrayList<PartnerProductSetting> partnerProductSettings(int partnerId){ArrayList<PartnerProductSetting>a=new ArrayList<>();Cursor c=getReadableDatabase().query("partner_product_settings",null,"partner_id=?",new String[]{String.valueOf(partnerId)},null,null,"product_id ASC");try{while(c.moveToNext()){int ti=c.getColumnIndex("price_tiers");String tiers=ti<0||c.isNull(ti)?"":c.getString(ti);a.add(new PartnerProductSetting(c.getInt(c.getColumnIndexOrThrow("id")),partnerId,c.getInt(c.getColumnIndexOrThrow("product_id")),c.getDouble(c.getColumnIndexOrThrow("partner_price")),tiers,c.getString(c.getColumnIndexOrThrow("customer_image"))));}}finally{c.close();}return a;}
    public void savePartnerProductSetting(int partnerId,int productId,double price,String priceTiers,String image){ContentValues v=new ContentValues();v.put("partner_id",partnerId);v.put("product_id",productId);v.put("partner_price",price);v.put("price_tiers",priceTiers==null?"":priceTiers);v.put("customer_image",image==null?"":image);v.put("updated_at",System.currentTimeMillis());getWritableDatabase().insertWithOnConflict("partner_product_settings",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
    public void savePartnerProductSetting(int partnerId,int productId,double price,String image){PartnerProductSetting old=partnerProductSetting(partnerId,productId);savePartnerProductSetting(partnerId,productId,price,old==null?"":old.priceTiers,image);}
    public double partnerPrice(int partnerId,int productId){PartnerProductSetting s=partnerProductSetting(partnerId,productId);return s!=null&&s.partnerPrice>0?s.partnerPrice:0;}
    public double partnerPriceForQty(int partnerId,int productId,int qty){PartnerProductSetting s=partnerProductSetting(partnerId,productId);return s==null?0:s.priceForQty(qty);}
    public String partnerCustomerImage(int partnerId,int productId){PartnerProductSetting s=partnerProductSetting(partnerId,productId);return s==null?"":safeDb(s.customerImage);}
    private String safeDb(String x){return x==null?"":x;}

    /** Last manually used sale price for a specific registered customer/product pair. */
    public double customerProductPrice(int customerId,int productId){
        if(customerId<=0||productId<=0)return 0;
        Customer c=customer(customerId); if(c==null)return 0;
        String key=(c.cloudId==null||c.cloudId.trim().isEmpty())?"local:"+customerId:c.cloudId.trim();
        Cursor cur=getReadableDatabase().query("customer_product_prices",new String[]{"last_price"},"customer_key=? AND product_id=?",new String[]{key,String.valueOf(productId)},null,null,null,"1");
        try{if(!cur.moveToFirst())return 0;return cur.getDouble(0);}finally{cur.close();}
    }
    public String customerProductPriceKey(int customerId){
        Customer c=customer(customerId); if(c==null)return "";
        return (c.cloudId==null||c.cloudId.trim().isEmpty())?"local:"+customerId:c.cloudId.trim();
    }
    public void saveCustomerProductPrice(int customerId,int productId,double price){
        if(customerId<=0||productId<=0||price<=0)return;
        String key=customerProductPriceKey(customerId); if(key.isEmpty())return;
        ContentValues v=new ContentValues();v.put("customer_key",key);v.put("customer_id",customerId);v.put("product_id",productId);v.put("last_price",price);v.put("updated_at",System.currentTimeMillis());
        getWritableDatabase().insertWithOnConflict("customer_product_prices",null,v,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public ArrayList<ContentValues> customerProductPricesForSync(){
        ArrayList<ContentValues>a=new ArrayList<>();
        Cursor c=getReadableDatabase().query("customer_product_prices",null,null,null,null,null,"updated_at ASC");
        try{while(c.moveToNext()){ContentValues v=new ContentValues();v.put("customer_key",c.getString(c.getColumnIndexOrThrow("customer_key")));v.put("customer_id",c.getInt(c.getColumnIndexOrThrow("customer_id")));v.put("product_id",c.getInt(c.getColumnIndexOrThrow("product_id")));v.put("last_price",c.getDouble(c.getColumnIndexOrThrow("last_price")));v.put("updated_at",c.getLong(c.getColumnIndexOrThrow("updated_at")));a.add(v);}}finally{c.close();}return a;
    }

    public void saveProduct(int id,String name,String code,double price,String image){ saveProduct(id,name,code,price,image,true,""); }
    public void deleteProduct(int id){getWritableDatabase().delete("products","id=?",new String[]{""+id}); markSyncDeleted("products",id);}

    private Customer readCustomer(Cursor c){
        String pu="",pe="",ci="";
        int puIdx=c.getColumnIndex("partner_uid"), peIdx=c.getColumnIndex("partner_email"), ciIdx=c.getColumnIndex("cloud_id");
        if(puIdx>=0&&!c.isNull(puIdx))pu=c.getString(puIdx);
        if(peIdx>=0&&!c.isNull(peIdx))pe=c.getString(peIdx);
        if(ciIdx>=0&&!c.isNull(ciIdx))ci=c.getString(ciIdx);
        return new Customer(c.getInt(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("name")),c.getString(c.getColumnIndexOrThrow("phone")),c.getString(c.getColumnIndexOrThrow("city")),c.getString(c.getColumnIndexOrThrow("address")),c.getInt(c.getColumnIndexOrThrow("reseller"))==1,c.getInt(c.getColumnIndexOrThrow("partner_id")),pu,pe,c.getDouble(c.getColumnIndexOrThrow("default_shipping")),ci);
    }
    public ArrayList<Customer> customers(String q){ArrayList<Customer>a=new ArrayList<>();q=q==null?"":q.trim();Cursor c=getReadableDatabase().query("customers",null,q.isEmpty()?null:"name LIKE ? OR phone LIKE ? OR city LIKE ?",q.isEmpty()?null:new String[]{"%"+q+"%","%"+q+"%","%"+q+"%"},null,null,"name COLLATE NOCASE ASC");try{while(c.moveToNext())a.add(readCustomer(c));}finally{c.close();}return a;}

    /**
     * Customers owned by the company itself. Partner-owned customers are
     * deliberately excluded so the invoice customer picker can never mix
     * another partner's customer into a company invoice.
     */
    public ArrayList<Customer> companyCustomers(String q){
        ArrayList<Customer>a=new ArrayList<>();
        q=q==null?"":q.trim();
        String where="partner_id=0 AND reseller=0";
        ArrayList<String>args=new ArrayList<>();
        if(!q.isEmpty()){where+=" AND (name LIKE ? OR phone LIKE ? OR city LIKE ?)";args.add("%"+q+"%");args.add("%"+q+"%");args.add("%"+q+"%");}
        Cursor c=getReadableDatabase().query("customers",null,where,args.toArray(new String[0]),null,null,"name COLLATE NOCASE ASC");
        try{while(c.moveToNext())a.add(readCustomer(c));}finally{c.close();}
        return a;
    }

    public ArrayList<Customer> partnerCustomers(int partnerId,String q){ArrayList<Customer>a=new ArrayList<>();q=q==null?"":q.trim();String where="partner_id=? AND reseller=0";ArrayList<String>args=new ArrayList<>();args.add(""+partnerId);if(!q.isEmpty()){where+=" AND (name LIKE ? OR phone LIKE ? OR city LIKE ?)";args.add("%"+q+"%");args.add("%"+q+"%");args.add("%"+q+"%");}Cursor c=getReadableDatabase().query("customers",null,where,args.toArray(new String[0]),null,null,"name COLLATE NOCASE ASC");try{while(c.moveToNext())a.add(readCustomer(c));}finally{c.close();}return a;}
    public Customer customer(int id){Cursor c=getReadableDatabase().query("customers",null,"id=?",new String[]{""+id},null,null,null);try{if(!c.moveToFirst())return null;return readCustomer(c);}finally{c.close();}}
    public Customer customerByCloudId(String cloudId){
        if(cloudId==null||cloudId.trim().isEmpty())return null;
        Cursor c=getReadableDatabase().query("customers",null,"cloud_id=?",new String[]{cloudId},null,null,null);
        try{if(!c.moveToFirst())return null;return readCustomer(c);}finally{c.close();}
    }
    public void setCustomerCloudId(int id,String cloudId){
        ContentValues v=new ContentValues();v.put("cloud_id",cloudId);getWritableDatabase().update("customers",v,"id=?",new String[]{String.valueOf(id)});
    }
    public int saveCustomer(int id,String name,String phone,String city,String address,boolean reseller,int partnerId,double defaultShipping){ContentValues v=new ContentValues();v.put("name",name);v.put("phone",phone);v.put("city",city);v.put("address",address);v.put("reseller",reseller?1:0);v.put("partner_id",reseller?0:partnerId);v.put("default_shipping",reseller?defaultShipping:30);if(!reseller){v.putNull("partner_uid");v.putNull("partner_email");}long now=System.currentTimeMillis(); int actualId=id; if(id<0){actualId=(int)getWritableDatabase().insert("customers",null,v);}else getWritableDatabase().update("customers",v,"id=?",new String[]{""+id}); if(actualId>0)markSync("customers",actualId,now,"dirty",0,false); return actualId;}

    /** Creates or updates the single canonical customer row representing a partner account. */
    public int upsertPartnerCustomer(String uid,long partnerId,String name,String email,String phone){
        SQLiteDatabase w=getWritableDatabase();
        Cursor c=w.query("customers",new String[]{"id"},"reseller=1 AND (partner_uid=? OR partner_id=?)",new String[]{uid,String.valueOf(partnerId)},null,null,"id ASC","1");
        int id=-1; try{if(c.moveToFirst())id=c.getInt(0);}finally{c.close();}
        ContentValues v=new ContentValues();v.put("name",name==null?"":name.trim());v.put("phone",phone==null?"":phone.trim());v.put("city","");v.put("address","");v.put("reseller",1);v.put("partner_id",partnerId);v.put("partner_uid",uid==null?"":uid);v.put("partner_email",email==null?"":email.trim());v.put("default_shipping",30);
        long now=System.currentTimeMillis();
        if(id<0)id=(int)w.insert("customers",null,v);else w.update("customers",v,"id=?",new String[]{String.valueOf(id)});
        if(id>0)markSync("customers",id,now,"dirty",0,false);
        return id;
    }

    public int linkedPartnerCustomer(long partnerId,String uid){
        Cursor c=getReadableDatabase().query("customers",new String[]{"id"},"reseller=1 AND (partner_id=? OR partner_uid=?)",new String[]{String.valueOf(partnerId),uid==null?"":uid},null,null,"id ASC","1");
        try{return c.moveToFirst()?c.getInt(0):-1;}finally{c.close();}
    }
    /** Returns the canonical local customer row representing a partner account. */
    public Customer partnerAccountCustomer(long partnerId){
        if(partnerId<=0)return null;
        Cursor c=getReadableDatabase().query("customers",null,
                "reseller=1 AND partner_id=?",new String[]{String.valueOf(partnerId)},
                null,null,"id ASC","1");
        try{if(!c.moveToFirst())return null;return readCustomer(c);}finally{c.close();}
    }
    public void deleteCustomer(int id){
        String cloudKey=""; Cursor c=getReadableDatabase().query("customers",new String[]{"cloud_id"},"id=?",new String[]{String.valueOf(id)},null,null,null);
        try{if(c.moveToFirst()&&!c.isNull(0))cloudKey=c.getString(0);}finally{c.close();}
        getWritableDatabase().delete("customers","id=?",new String[]{""+id}); markSyncDeleted("customers",id); if(!cloudKey.isEmpty())setSyncCloudKey("customers",id,cloudKey);
    }

    private Invoice readInvoice(Cursor c){Invoice i=new Invoice(c.getInt(c.getColumnIndexOrThrow("id")),c.getInt(c.getColumnIndexOrThrow("client_id")),c.getString(c.getColumnIndexOrThrow("client")),c.getString(c.getColumnIndexOrThrow("date")),c.getInt(c.getColumnIndexOrThrow("paid"))==1);int in=c.getColumnIndex("invoice_number");if(in>=0)i.invoiceNumber=c.getInt(in);int inf=c.getColumnIndex("invoice_number_final");if(inf>=0&&!c.isNull(inf))i.invoiceNumberFinal=c.getInt(inf)==1;int cat=c.getColumnIndex("created_at");if(cat>=0&&!c.isNull(cat))i.createdAt=c.getLong(cat);if(i.createdAt<=0)i.createdAt=i.id*1000L;int ck=c.getColumnIndex("cloud_key");if(ck>=0&&!c.isNull(ck))i.cloudKey=c.getString(ck);i.customerPhone=c.getString(c.getColumnIndexOrThrow("customer_phone"));i.customerCity=c.getString(c.getColumnIndexOrThrow("customer_city"));i.customerAddress=c.getString(c.getColumnIndexOrThrow("customer_address"));i.customerType=c.getString(c.getColumnIndexOrThrow("customer_type"));i.reseller=c.getInt(c.getColumnIndexOrThrow("reseller"))==1;i.deliveryReceived=c.getInt(c.getColumnIndexOrThrow("delivery_received"))==1;i.paidDate=c.getString(c.getColumnIndexOrThrow("paid_date"));i.trackingNumber=c.getString(c.getColumnIndexOrThrow("tracking_number"));i.deliveryReceivedDate=c.getString(c.getColumnIndexOrThrow("delivery_received_date"));i.deliveryFailureReason=c.getString(c.getColumnIndexOrThrow("delivery_failure_reason"));i.partnerProfitPaidDate=c.getString(c.getColumnIndexOrThrow("partner_profit_paid_date"));i.bankReceived=c.getInt(c.getColumnIndexOrThrow("bank_received"))==1;i.bankReceivedDate=c.getString(c.getColumnIndexOrThrow("bank_received_date"));int ca=c.getColumnIndex("company_accounted");i.companyAccounted=ca>=0&&!c.isNull(ca)&&c.getInt(ca)==1;int cad=c.getColumnIndex("company_accounted_date");i.companyAccountedDate=cad>=0&&!c.isNull(cad)?c.getString(cad):"";int cas=c.getColumnIndex("company_accounting_store");i.companyAccountingStore=cas>=0&&!c.isNull(cas)?c.getString(cas):"";int cae=c.getColumnIndex("company_accounting_export_id");i.companyAccountingExportId=cae>=0&&!c.isNull(cae)?c.getString(cae):"";int vc=c.getColumnIndex("virement_code");i.virementCode=vc>=0&&!c.isNull(vc)?c.getString(vc):"";int vd=c.getColumnIndex("virement_date");i.virementDate=vd>=0&&!c.isNull(vd)?c.getString(vd):"";int vt=c.getColumnIndex("virement_total_crbt");i.virementTotalCrbt=vt>=0&&!c.isNull(vt)?c.getDouble(vt):0;int vf=c.getColumnIndex("virement_total_fees");i.virementTotalFees=vf>=0&&!c.isNull(vf)?c.getDouble(vf):0;int vn=c.getColumnIndex("virement_net");i.virementNet=vn>=0&&!c.isNull(vn)?c.getDouble(vn):0;int ap=c.getColumnIndex("advance_payment");i.advancePayment=ap>=0&&!c.isNull(ap)?c.getDouble(ap):0;int apr=c.getColumnIndex("advance_received_by_partner_id");i.advanceReceivedByPartnerId=apr>=0&&!c.isNull(apr)?c.getInt(apr):0;int apd=c.getColumnIndex("advance_payment_date");i.advancePaymentDate=apd>=0&&!c.isNull(apd)?c.getString(apd):"";i.shippingCompany=c.getString(c.getColumnIndexOrThrow("shipping_company"));i.shippingAccount=c.getString(c.getColumnIndexOrThrow("shipping_account"));i.commission=c.getDouble(c.getColumnIndexOrThrow("commission"));i.partnerId=c.getInt(c.getColumnIndexOrThrow("partner_id"));i.shippingEnabled=c.getInt(c.getColumnIndexOrThrow("shipping_enabled"))==1;i.shippingCharge=c.getDouble(c.getColumnIndexOrThrow("shipping_charge"));i.shippingCost=c.getDouble(c.getColumnIndexOrThrow("shipping_cost"));i.partnerProfitPaid=c.getInt(c.getColumnIndexOrThrow("partner_profit_paid"))==1;i.shippedByAdmin=c.getInt(c.getColumnIndexOrThrow("shipped_by_admin"))==1;int ac=c.getColumnIndex("assembly_completed");i.assemblyCompleted=ac>=0&&!c.isNull(ac)&&c.getInt(ac)==1;loadItems(i);return i;}
    /**
     * Invoice list order: newest invoice date first.
     *
     * Local SQLite ids are not reliable chronological ids because cloud invoices
     * can be downloaded in an arbitrary Firestore document order. Therefore the
     * invoices screen must never use id DESC as its primary ordering.
     */
    private static final String INVOICE_ORDER =
            "created_at DESC, id DESC";

    public ArrayList<Invoice> invoices(String q){
        ArrayList<Invoice>a=new ArrayList<>();q=q==null?"":q.trim();
        String where=q.isEmpty()?null:"CAST(invoice_number AS TEXT) LIKE ? OR client LIKE ? OR customer_phone LIKE ?";
        String[] args=q.isEmpty()?null:new String[]{"%"+q+"%","%"+q+"%","%"+q+"%"};
        Cursor c=getReadableDatabase().query("invoices",null,where,args,null,null,INVOICE_ORDER);
        try{while(c.moveToNext())a.add(readInvoice(c));}finally{c.close();}return a;
    }
    public void markCompanyAccounting(ArrayList<Integer> ids,String storeName,String exportId){
        if(ids==null||ids.isEmpty()) return;
        String now=new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.US).format(new Date());
        SQLiteDatabase d=getWritableDatabase(); d.beginTransaction();
        try{ ContentValues v=new ContentValues();v.put("company_accounted",1);v.put("company_accounted_date",now);v.put("company_accounting_store",storeName==null?"":storeName);v.put("company_accounting_export_id",exportId==null?"":exportId);
            for(Integer id:ids){if(id==null)continue;d.update("invoices",v,"id=?",new String[]{String.valueOf(id)});markSync("invoices",id,System.currentTimeMillis(),"dirty",0,false);}
            d.setTransactionSuccessful();
        }finally{d.endTransaction();}
    }
    public void applyVirementToInvoice(int id,String code,String date,double crbt,double fees,double net,String company,String store){
        ContentValues v=new ContentValues();
        v.put("virement_code",code==null?"":code);
        v.put("virement_date",date==null?"":date);
        v.put("virement_total_crbt",crbt);
        v.put("virement_total_fees",fees);
        v.put("virement_net",net);
        v.put("shipping_cost",fees);
        // Importing a Virement means the carrier has transferred the settlement.
        // Mark the matched invoice as received by the bank immediately.
        v.put("bank_received",1);
        v.put("bank_received_date",date==null||date.trim().isEmpty()?today():date);
        // The Store selected during Virement import is authoritative for this settlement.
        v.put("shipping_company",company==null?"":company);
        v.put("shipping_account",store==null?"":store);
        getWritableDatabase().update("invoices",v,"id=?",new String[]{String.valueOf(id)});
        markSync("invoices",id,System.currentTimeMillis(),"dirty",0,false);
    }
    /**
     * Finds an invoice by carrier tracking code.
     *
     * Virement PDFs can contain line breaks, non-breaking spaces, hidden
     * Unicode characters, or different letter casing around the tracking code.
     * SQLite exact matching therefore misses valid invoices even when the
     * visible code is identical. First try the fast exact lookup, then fall
     * back to a canonical alphanumeric comparison in Java.
     */
    public Invoice invoiceByTracking(String tracking){
        if(tracking==null||tracking.trim().isEmpty()) return null;
        String wanted=tracking.trim();
        SQLiteDatabase rd=getReadableDatabase();
        Cursor exact=rd.query("invoices",null,"tracking_number=?",new String[]{wanted},null,null,"id DESC","1");
        try{
            if(exact.moveToFirst()) return readInvoice(exact);
        }finally{ exact.close(); }

        final String canonicalWanted=canonicalTracking(wanted);
        if(canonicalWanted.isEmpty()) return null;
        Cursor all=rd.query("invoices",null,"tracking_number IS NOT NULL AND TRIM(tracking_number)<>''",null,null,null,"id DESC");
        try{
            while(all.moveToNext()){
                String stored=all.getString(all.getColumnIndexOrThrow("tracking_number"));
                if(canonicalWanted.equals(canonicalTracking(stored))) return readInvoice(all);
            }
        }finally{ all.close(); }
        return null;
    }

    private static String canonicalTracking(String value){
        if(value==null) return "";
        // Remove whitespace, NBSP/zero-width characters and punctuation that
        // may be introduced when PDF text is extracted or manually entered.
        return value.replaceAll("[\\s\\u00A0\\u200B-\\u200D\\uFEFF]","")
                .replaceAll("[^A-Za-z0-9]","")
                .toUpperCase(java.util.Locale.ROOT);
    }

    public ArrayList<Invoice> partnerInvoices(int partnerId,String q){
        ArrayList<Invoice>a=new ArrayList<>(); q=q==null?"":q.trim();
        String where="partner_id=?"; java.util.ArrayList<String> args=new java.util.ArrayList<>(); args.add(String.valueOf(partnerId));
        if(!q.isEmpty()){ where += " AND (CAST(invoice_number AS TEXT) LIKE ? OR client LIKE ? OR customer_phone LIKE ?)"; args.add("%"+q+"%"); args.add("%"+q+"%"); args.add("%"+q+"%"); }
        Cursor c=getReadableDatabase().query("invoices",null,where,args.toArray(new String[0]),null,null,INVOICE_ORDER);
        try{while(c.moveToNext())a.add(readInvoice(c));}finally{c.close();} return a;
    }

    public Invoice invoice(int id){Cursor c=getReadableDatabase().query("invoices",null,"id=?",new String[]{""+id},null,null,null);try{if(!c.moveToFirst())return null;return readInvoice(c);}finally{c.close();}}
    public Invoice invoiceByCloudKey(String key){if(key==null||key.trim().isEmpty())return null;Cursor c=getReadableDatabase().query("invoices",null,"cloud_key=?",new String[]{key.trim()},null,null,null);try{if(!c.moveToFirst())return null;return readInvoice(c);}finally{c.close();}}
    private void loadItems(Invoice i){Cursor c=getReadableDatabase().query("invoice_items",null,"invoice_id=?",new String[]{""+i.id},null,null,"id ASC");try{while(c.moveToNext()){int ppc=c.getColumnIndex("partner_price"); double pp=ppc<0||c.isNull(ppc)?c.getDouble(c.getColumnIndexOrThrow("sale_price")):c.getDouble(ppc); i.items.add(new Item(c.getInt(c.getColumnIndexOrThrow("product_id")),c.getString(c.getColumnIndexOrThrow("name")),c.getDouble(c.getColumnIndexOrThrow("price")),c.getDouble(c.getColumnIndexOrThrow("sale_price")),pp,c.getInt(c.getColumnIndexOrThrow("qty"))));}}finally{c.close();}}

    public int saveInvoice(int id,int clientId,String client,String customerPhone,String customerCity,String customerAddress,String customerType,boolean paid,int partnerId,boolean shippingEnabled,double shippingCharge,double shippingCost,double advancePayment,int advanceReceivedByPartnerId,String trackingNumber,String shippingCompany,String shippingAccount,boolean deliveryReceived,String deliveryFailureReason,boolean partnerProfitPaid,boolean shippedByAdmin,ArrayList<Item> items,int forcedInvoiceNumber,boolean invoiceNumberFinal){
        final int[] invoiceIdForSyncHolder={id};
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{
            boolean reseller=partnerId>0;
            double productProfit=0;
            double partnerMargin=0;
            for(Item it:items){ productProfit+=(it.salePrice-it.price)*it.qty; double pp=it.partnerPrice>0?it.partnerPrice:it.salePrice; partnerMargin+=(it.salePrice-pp)*it.qty; }
            double netProfit=reseller?((partnerMargin)+(shippingEnabled?shippingCharge:0)-(shippingEnabled?shippingCost:0)):0;

            String today=new SimpleDateFormat("dd/MM/yyyy",Locale.US).format(new Date());
            String invoiceDate=today;
            String paidDate=null;
            String deliveryReceivedDate=null;
            String oldFailureReason=null;
            String partnerProfitPaidDate=null;
            if(id>=0){
                Cursor old=db.query("invoices",new String[]{"date","paid","paid_date","delivery_received","delivery_received_date","delivery_failure_reason","partner_profit_paid","partner_profit_paid_date"},"id=?",new String[]{""+id},null,null,null);
                try{
                    if(old.moveToFirst()){
                        String oldDate=old.getString(0);
                        if(oldDate!=null&&!oldDate.isEmpty()) invoiceDate=oldDate;
                        boolean wasPaid=old.getInt(1)==1;
                        String oldPaidDate=old.getString(2);
                        if(paid){
                            paidDate=(wasPaid&&oldPaidDate!=null&&!oldPaidDate.isEmpty())?oldPaidDate:nowDateTime();
                        }
                        boolean wasReceived=old.getInt(3)==1;
                        String oldReceivedDate=old.getString(4);
                        deliveryReceivedDate=deliveryReceived
                                ?((wasReceived&&oldReceivedDate!=null&&!oldReceivedDate.isEmpty())?oldReceivedDate:today)
                                :null;
                        oldFailureReason=old.getString(5);
                        boolean wasProfitPaid=old.getInt(6)==1;
                        String oldProfitDate=old.getString(7);
                        partnerProfitPaidDate=partnerProfitPaid
                                ?((wasProfitPaid&&oldProfitDate!=null&&!oldProfitDate.isEmpty())?oldProfitDate:today)
                                :null;
                    }
                }finally{old.close();}
            }else{
                if(paid) paidDate=today;
                if(deliveryReceived) deliveryReceivedDate=today;
                if(partnerProfitPaid) partnerProfitPaidDate=today;
            }

            ContentValues v=new ContentValues();
            v.put("client_id",clientId);
            v.put("client",client);
            v.put("customer_phone",customerPhone);
            v.put("customer_city",customerCity);
            v.put("customer_address",customerAddress);
            v.put("customer_type",customerType==null||customerType.trim().isEmpty()?"normal":customerType.trim());
            v.put("date",invoiceDate);
            v.put("paid",paid?1:0);
            v.put("paid_date",paidDate);
            v.put("reseller",reseller?1:0);
            v.put("partner_id",partnerId);
            v.put("shipping_enabled",shippingEnabled?1:0);
            v.put("shipping_charge",shippingEnabled?shippingCharge:0);
            v.put("shipping_cost",shippingEnabled?shippingCost:0);
            v.put("tracking_number",trackingNumber);
            v.put("shipping_company",shippingEnabled?safeDb(shippingCompany):null);
            v.put("shipping_account",shippingEnabled?safeDb(shippingAccount):null);
            v.put("delivery_received",deliveryReceived?1:0);
            v.put("delivery_received_date",deliveryReceivedDate);
            String failure = deliveryReceived ? null : (deliveryFailureReason==null||deliveryFailureReason.trim().isEmpty()?oldFailureReason:deliveryFailureReason.trim());
            v.put("delivery_failure_reason",failure);
            v.put("commission",netProfit);
            v.put("partner_profit_paid",partnerProfitPaid?1:0);
            v.put("partner_profit_paid_date",partnerProfitPaidDate);
            v.put("shipped_by_admin",shippedByAdmin?1:0);
            double safeAdvance=Math.max(0,advancePayment);
            v.put("advance_payment",safeAdvance);
            v.put("advance_received_by_partner_id",safeAdvance>0?Math.max(0,advanceReceivedByPartnerId):0);
            String advanceDate=null;
            if(safeAdvance>0){
                Cursor aq=db.query("invoices",new String[]{"advance_payment","advance_payment_date"},"id=?",new String[]{String.valueOf(id)},null,null,null);
                try{ if(aq.moveToFirst() && aq.getDouble(0)>0 && aq.getString(1)!=null && !aq.getString(1).isEmpty()) advanceDate=aq.getString(1); }finally{aq.close();}
                if(advanceDate==null) advanceDate=nowDateTime();
            }
            v.put("advance_payment_date",advanceDate);

            long invoiceId;
            if(id<0){
                // New invoice numbers are now global (shared by Admin + all Partners).
                // When CloudManager has reserved a number atomically in Firestore, use
                // that exact number. The local MAX fallback is kept only for a local
                // database/offline installation where no cloud allocator is available.
                int nextNo=forcedInvoiceNumber;
                if(nextNo<=0){
                    Cursor nq=db.rawQuery("SELECT COALESCE(MAX(invoice_number),0) FROM invoices",null);
                    try{if(nq.moveToFirst())nextNo=nq.getInt(0);}finally{nq.close();}
                    nextNo=Math.max(nextNo,0)+1;
                }
                String cloudKey="inv_"+java.util.UUID.randomUUID().toString();
                v.put("invoice_number",nextNo);
                v.put("invoice_number_final",invoiceNumberFinal?1:0);
                v.put("created_at",System.currentTimeMillis());
                v.put("cloud_key",cloudKey);
                invoiceId=db.insert("invoices",null,v);
            }
            else{
                Cursor oq=db.query("invoices",new String[]{"invoice_number","cloud_key","created_at","invoice_number_final"},"id=?",new String[]{String.valueOf(id)},null,null,null);
                try{if(oq.moveToFirst()){v.put("invoice_number",oq.getInt(0));if(!oq.isNull(1))v.put("cloud_key",oq.getString(1));if(!oq.isNull(2))v.put("created_at",oq.getLong(2));if(!oq.isNull(3))v.put("invoice_number_final",oq.getInt(3));}}finally{oq.close();}
                db.update("invoices",v,"id=?",new String[]{""+id});
                invoiceId=id;
                db.delete("invoice_items","invoice_id=?",new String[]{""+id});
            }
            invoiceIdForSyncHolder[0]=(int)invoiceId;
            for(Item it:items){
                ContentValues x=new ContentValues();
                x.put("invoice_id",invoiceId);
                x.put("product_id",it.productId);
                x.put("name",it.name);
                x.put("price",it.price);
                x.put("qty",it.qty);
                x.put("sale_price",it.salePrice);
                x.put("partner_price",it.partnerPrice>0?it.partnerPrice:it.salePrice);
                db.insert("invoice_items",null,x);
            }
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        if(invoiceIdForSyncHolder[0] > 0) markSync("invoices",invoiceIdForSyncHolder[0],System.currentTimeMillis(),"dirty",0,false);
        return invoiceIdForSyncHolder[0];
    }

    public int nextLocalInvoiceNumber(){
        Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(MAX(invoice_number),0) FROM invoices",null);
        try{ return c.moveToFirst()?Math.max(0,c.getInt(0))+1:1; } finally { c.close(); }
    }
    public void finalizeInvoiceNumber(int invoiceId,int number){
        if(invoiceId<=0||number<=0)return;
        ContentValues v=new ContentValues();v.put("invoice_number",number);v.put("invoice_number_final",1);
        getWritableDatabase().update("invoices",v,"id=?",new String[]{String.valueOf(invoiceId)});
        markSync("invoices",invoiceId,System.currentTimeMillis(),"dirty",0,false);
    }

    /** Update only the assembly status so editing an invoice cannot overwrite it. */
    public void setInvoiceAssemblyCompleted(int invoiceId, boolean completed){
        if(invoiceId<=0)return;
        ContentValues v=new ContentValues();
        v.put("assembly_completed",completed?1:0);
        getWritableDatabase().update("invoices",v,"id=?",new String[]{String.valueOf(invoiceId)});
        markSync("invoices",invoiceId,System.currentTimeMillis(),"dirty",0,false);
    }

    public void setBankReceived(int invoiceId,boolean received){
        ContentValues v=new ContentValues();v.put("bank_received",received?1:0);
        if(received)v.put("bank_received_date",today());else v.putNull("bank_received_date");
        getWritableDatabase().update("invoices",v,"id=?",new String[]{""+invoiceId});
        markSync("invoices",invoiceId,System.currentTimeMillis(),"dirty",0,false);
    }

    public void setBankReceivedBulk(ArrayList<Integer> invoiceIds,boolean received){
        if(invoiceIds==null||invoiceIds.isEmpty())return;
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try{
            ContentValues v=new ContentValues();v.put("bank_received",received?1:0);if(received)v.put("bank_received_date",today());else v.putNull("bank_received_date");
            for(Integer id:invoiceIds)if(id!=null){db.update("invoices",v,"id=?",new String[]{""+id});markSync("invoices",id,System.currentTimeMillis(),"dirty",0,false);}
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }

    public boolean invoiceAlreadyInPartnerSettlement(int invoiceId){
        if(invoiceId<=0)return false;
        Cursor c=getReadableDatabase().rawQuery("SELECT 1 FROM partner_settlement_items WHERE invoice_id=? LIMIT 1",new String[]{String.valueOf(invoiceId)});
        try{return c.moveToFirst();}finally{c.close();}
    }

    public long createPartnerSettlement(int partnerId,String partnerName,ArrayList<Integer> invoiceIds){
        if(invoiceIds==null||invoiceIds.isEmpty())return -1;
        SQLiteDatabase d=getWritableDatabase(); d.beginTransaction(); long sid=-1;
        try{
            double totalInvoices=0,totalProfit=0,totalAdvances=0; int count=0;
            ArrayList<Invoice> valid=new ArrayList<>();
            for(Integer iid:invoiceIds){
                if(iid==null)continue; Invoice i=invoice(iid);
                if(i==null||i.partnerId!=partnerId||!i.deliveryReceived||i.partnerProfitPaid||invoiceAlreadyInPartnerSettlement(i.id))continue;
                valid.add(i); totalInvoices+=invoiceTotalForSettlement(i); totalProfit+=i.commission;
                if(i.advanceReceivedByPartnerId==partnerId) totalAdvances+=Math.max(0,i.advancePayment); count++;
            }
            if(valid.isEmpty()){ return -1; }
            double amount=Math.max(0,totalProfit-totalAdvances);
            ContentValues v=new ContentValues(); v.put("partner_id",partnerId);v.put("partner_name",partnerName==null?"":partnerName);v.put("date",nowDateTime());v.put("total_invoices",totalInvoices);v.put("total_profit",totalProfit);v.put("total_advances",totalAdvances);v.put("amount_paid",amount);v.put("invoice_count",count);
            sid=d.insert("partner_settlements",null,v);
            if(sid>0){
                for(Invoice i:valid){
                    ContentValues x=new ContentValues();x.put("settlement_id",sid);x.put("invoice_id",i.id);x.put("invoice_number",i.invoiceNumber);x.put("invoice_total",invoiceTotalForSettlement(i));x.put("profit",i.commission);x.put("advance",i.advanceReceivedByPartnerId==partnerId?Math.max(0,i.advancePayment):0);
                    Store.Customer settlementCustomer=i.clientId>0?customer(i.clientId):null;
                    String settlementClient=(i.client!=null&&!i.client.trim().isEmpty())?i.client:(settlementCustomer!=null?settlementCustomer.name:"");
                    String settlementPhone=(i.customerPhone!=null&&!i.customerPhone.trim().isEmpty())?i.customerPhone:(settlementCustomer!=null?settlementCustomer.phone:"");
                    String settlementCity=(i.customerCity!=null&&!i.customerCity.trim().isEmpty())?i.customerCity:(settlementCustomer!=null?settlementCustomer.city:"");
                    String settlementAddress=(i.customerAddress!=null&&!i.customerAddress.trim().isEmpty())?i.customerAddress:(settlementCustomer!=null?settlementCustomer.address:"");
                    x.put("client",settlementClient); x.put("customer_phone",settlementPhone); x.put("customer_city",settlementCity); x.put("customer_address",settlementAddress); x.put("tracking_number",i.trackingNumber==null?"":i.trackingNumber); x.put("shipping_charge",i.shippingCharge); x.put("shipping_cost",i.shippingCost); x.put("shipping_company",i.shippingCompany==null?"":i.shippingCompany); x.put("shipping_account",i.shippingAccount==null?"":i.shippingAccount); x.put("delivery_received",i.deliveryReceived?1:0);
                    d.insert("partner_settlement_items",null,x);
                }
            }
            d.setTransactionSuccessful();
        }finally{d.endTransaction();}
        return sid;
    }

    public static class PartnerSettlementItem{public int id,settlementId,invoiceId,invoiceNumber;public String client,phone,city,address,tracking,shippingCompany,shippingAccount;public double invoiceTotal,profit,advance,shippingCharge,shippingCost;public boolean received;
        PartnerSettlementItem(int id,int sid,int iid,int no,String c,String ph,String ci,String ad,String tr,double total,double pr,double adv,double sh,double actual,String company,String account,boolean rec){this.id=id;settlementId=sid;invoiceId=iid;invoiceNumber=no;client=c;phone=ph;city=ci;address=ad;tracking=tr;invoiceTotal=total;profit=pr;advance=adv;shippingCharge=sh;shippingCost=actual;shippingCompany=company;shippingAccount=account;received=rec;}}
    public ArrayList<PartnerSettlementItem> partnerSettlementItems(int settlementId){
        ArrayList<PartnerSettlementItem>a=new ArrayList<>(); Cursor c=getReadableDatabase().query("partner_settlement_items",null,"settlement_id=?",new String[]{String.valueOf(settlementId)},null,null,"id ASC");
        try{while(c.moveToNext()){a.add(new PartnerSettlementItem(c.getInt(c.getColumnIndexOrThrow("id")),c.getInt(c.getColumnIndexOrThrow("settlement_id")),c.getInt(c.getColumnIndexOrThrow("invoice_id")),c.getInt(c.getColumnIndexOrThrow("invoice_number")),safeCol(c,"client"),safeCol(c,"customer_phone"),safeCol(c,"customer_city"),safeCol(c,"customer_address"),safeCol(c,"tracking_number"),c.getDouble(c.getColumnIndexOrThrow("invoice_total")),c.getDouble(c.getColumnIndexOrThrow("profit")),c.getDouble(c.getColumnIndexOrThrow("advance")),c.getDouble(c.getColumnIndexOrThrow("shipping_charge")),c.getDouble(c.getColumnIndexOrThrow("shipping_cost")),safeCol(c,"shipping_company"),safeCol(c,"shipping_account"),c.getInt(c.getColumnIndexOrThrow("delivery_received"))!=0));}}finally{c.close();}return a;
    }
    private String safeCol(Cursor c,String name){int k=c.getColumnIndex(name);return k<0||c.isNull(k)?"":c.getString(k);}

    private double invoiceTotalForSettlement(Invoice i){double t=0;for(Item x:i.items)t+=x.salePrice*x.qty;return t+(i.shippingEnabled?i.shippingCharge:0);}
    public static class PartnerSettlement {public int id,partnerId,invoiceCount;public String partnerName,date;public double totalInvoices,totalProfit,totalAdvances,amountPaid;PartnerSettlement(int i,int p,String n,String d,double ti,double tp,double ta,double ap,int c){id=i;partnerId=p;partnerName=n;date=d;totalInvoices=ti;totalProfit=tp;totalAdvances=ta;amountPaid=ap;invoiceCount=c;}}
    public ArrayList<PartnerSettlement> partnerSettlements(int partnerId){ArrayList<PartnerSettlement>a=new ArrayList<>();Cursor c=getReadableDatabase().query("partner_settlements",null,"partner_id=?",new String[]{String.valueOf(partnerId)},null,null,"id DESC");try{while(c.moveToNext())a.add(new PartnerSettlement(c.getInt(c.getColumnIndexOrThrow("id")),c.getInt(c.getColumnIndexOrThrow("partner_id")),c.getString(c.getColumnIndexOrThrow("partner_name")),c.getString(c.getColumnIndexOrThrow("date")),c.getDouble(c.getColumnIndexOrThrow("total_invoices")),c.getDouble(c.getColumnIndexOrThrow("total_profit")),c.getDouble(c.getColumnIndexOrThrow("total_advances")),c.getDouble(c.getColumnIndexOrThrow("amount_paid")),c.getInt(c.getColumnIndexOrThrow("invoice_count"))));}finally{c.close();}return a;}

    public void setPartnerProfitPaid(int invoiceId,boolean paid){
        ContentValues v=new ContentValues();v.put("partner_profit_paid",paid?1:0);
        if(paid)v.put("partner_profit_paid_date",today());else v.putNull("partner_profit_paid_date");
        getWritableDatabase().update("invoices",v,"id=?",new String[]{""+invoiceId});
        markSync("invoices",invoiceId,System.currentTimeMillis(),"dirty",0,false);
    }

    public void setPartnerProfitPaidBulk(ArrayList<Integer> invoiceIds,boolean paid){
        if(invoiceIds==null||invoiceIds.isEmpty())return;
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try{
            ContentValues v=new ContentValues();v.put("partner_profit_paid",paid?1:0);if(paid)v.put("partner_profit_paid_date",today());else v.putNull("partner_profit_paid_date");
            for(Integer id:invoiceIds)if(id!=null){db.update("invoices",v,"id=?",new String[]{""+id}); markSync("invoices",id,System.currentTimeMillis(),"dirty",0,false);}
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }

    public void setDeliveryStatus(int invoiceId,boolean received,String reason){
        ContentValues v=new ContentValues();
        v.put("delivery_received",received?1:0);
        if(received)v.put("delivery_received_date",today());else v.putNull("delivery_received_date");
        if(received)v.putNull("delivery_failure_reason");else if(reason==null)v.putNull("delivery_failure_reason");else v.put("delivery_failure_reason",reason);
        if(!received){
            v.put("partner_profit_paid",0);
            v.putNull("partner_profit_paid_date");
        }
        getWritableDatabase().update("invoices",v,"id=?",new String[]{""+invoiceId});
        markSync("invoices",invoiceId,System.currentTimeMillis(),"dirty",0,false);
    }

    private String today(){return new SimpleDateFormat("dd/MM/yyyy",Locale.US).format(new Date());}
    private String nowDateTime(){return new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.US).format(new Date());}


    /**
     * Returns all invoices belonging to a customer. We use both client_id and
     * the stored client name so older invoices created before customer linking
     * are also included in the monthly statement.
     */
    public ArrayList<Invoice> customerInvoices(int customerId,String customerName,boolean unpaidOnly){
        ArrayList<Invoice> a=new ArrayList<>();
        String where="(client_id=? OR client=?)";
        ArrayList<String> args=new ArrayList<>();
        args.add(""+customerId);
        args.add(customerName==null?"":customerName);
        if(unpaidOnly)where+=" AND paid=0";
        Cursor c=getReadableDatabase().query("invoices",null,where,args.toArray(new String[0]),null,null,INVOICE_ORDER);
        try{while(c.moveToNext())a.add(readInvoice(c));}finally{c.close();}
        return a;
    }

    /** Mark several customer invoices as paid and keep an individual payment date. */
    public void setInvoicesPaidBulk(ArrayList<Integer> invoiceIds){
        if(invoiceIds==null||invoiceIds.isEmpty())return;
        SQLiteDatabase db=getWritableDatabase();
        db.beginTransaction();
        try{
            ContentValues v=new ContentValues();
            v.put("paid",1);
            v.put("paid_date",nowDateTime());
            for(Integer id:invoiceIds){
                if(id!=null){db.update("invoices",v,"id=? AND paid=0",new String[]{""+id}); markSync("invoices",id,System.currentTimeMillis(),"dirty",0,false);}
            }
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }

    /** Remove a local duplicate after its corresponding cloud document has already been removed. */
    public void removeInvoiceDuplicateLocal(int id){
        SQLiteDatabase db=getWritableDatabase();
        db.delete("invoice_items","invoice_id=?",new String[]{String.valueOf(id)});
        db.delete("invoices","id=?",new String[]{String.valueOf(id)});
        db.delete("sync_meta","entity=? AND local_id=?",new String[]{"invoices",String.valueOf(id)});
    }

    public void deleteInvoice(int id){
        // Keep the immutable cloud key in sync_meta before removing the local row.
        // Otherwise a later cloud sync has no way to know which Firestore document
        // was intentionally deleted and will download it again.
        String cloudKey="";
        Cursor c=getReadableDatabase().query("invoices",new String[]{"cloud_key"},"id=?",new String[]{String.valueOf(id)},null,null,null);
        try{if(c.moveToFirst()&&!c.isNull(0))cloudKey=c.getString(0);}finally{c.close();}
        getWritableDatabase().delete("invoice_items","invoice_id=?",new String[]{""+id});
        getWritableDatabase().delete("invoices","id=?",new String[]{""+id});
        markSyncDeleted("invoices",id);
        if(!cloudKey.isEmpty())setSyncCloudKey("invoices",id,cloudKey);
    }
}
