package ma.mge.facturesimple

import android.content.ContentValues
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class Item(var name: String, var qty: Double, var price: Double) {
    fun total() = qty * price
}

class MainActivity : AppCompatActivity() {

    private lateinit var invoiceNo: EditText
    private lateinit var customer: EditText
    private lateinit var itemsBox: LinearLayout
    private lateinit var totalView: TextView
    private val items = mutableListOf<Item>()
    private val prefs by lazy { getSharedPreferences("invoices", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        invoiceNo.setText(nextInvoiceNumber().toString())
        addItemRow()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val title = TextView(this).apply {
            text = "فاتورة بسيطة"
            textSize = 25f
            gravity = Gravity.CENTER
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 8, 0, 18)
        }
        root.addView(title, lp())

        invoiceNo = field("رقم الفاتورة")
        customer = field("اسم الزبون (اختياري)")
        root.addView(invoiceNo, lp())
        root.addView(customer, lp())

        val date = TextView(this).apply {
            text = "التاريخ: " + today()
            textSize = 16f
            setPadding(4, 4, 4, 12)
        }
        root.addView(date, lp())

        val header = TextView(this).apply {
            text = "المنتجات"
            textSize = 19f
            setTypeface(null, Typeface.BOLD)
        }
        root.addView(header, lp())

        val scroll = ScrollView(this)
        itemsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 4, 0, 4)
        }
        scroll.addView(itemsBox)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val add = Button(this).apply {
            text = "＋ إضافة منتج"
            setOnClickListener { addItemRow() }
        }
        root.addView(add, lp())

        totalView = TextView(this).apply {
            text = "TOTAL : 0.00 DH"
            textSize = 22f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 12)
        }
        root.addView(totalView, lp())

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val save = Button(this).apply {
            text = "حفظ"
            setOnClickListener { saveInvoice() }
        }
        val pdf = Button(this).apply {
            text = "PDF"
            setOnClickListener { createPdfAndShare() }
        }
        val clear = Button(this).apply {
            text = "فاتورة جديدة"
            setOnClickListener { resetInvoice() }
        }
        buttons.addView(save, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(pdf, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(clear, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(buttons)

        setContentView(root)
    }

    private fun addItemRow() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 6, 0, 6)
        }

        val name = field("البيان / اسم المنتج")
        val qty = field("الكمية")
        val price = field("الثمن DH")

        qty.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        price.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL

        val remove = Button(this).apply {
            text = "حذف هذا المنتج"
            setOnClickListener {
                itemsBox.removeView(row)
                updateTotal()
            }
        }

        val watcher = object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { updateTotal() }
            override fun afterTextChanged(e: android.text.Editable?) {}
        }
        qty.addTextChangedListener(watcher)
        price.addTextChangedListener(watcher)

        row.addView(name, lp())
        val numbers = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        numbers.addView(qty, LinearLayout.LayoutParams(0, -2, 1f))
        numbers.addView(price, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(numbers)
        row.addView(remove, lp())
        itemsBox.addView(row)
    }

    private fun readItems(): List<Item> {
        val result = mutableListOf<Item>()
        for (i in 0 until itemsBox.childCount) {
            val row = itemsBox.getChildAt(i) as? LinearLayout ?: continue
            if (row.childCount < 2) continue
            val name = (row.getChildAt(0) as EditText).text.toString().trim()
            val numbers = row.getChildAt(1) as? LinearLayout ?: continue
            val qty = (numbers.getChildAt(0) as EditText).text.toString().toDoubleOrNull() ?: 0.0
            val price = (numbers.getChildAt(1) as EditText).text.toString().toDoubleOrNull() ?: 0.0
            if (name.isNotEmpty()) result.add(Item(name, qty, price))
        }
        return result
    }

    private fun updateTotal() {
        var total = 0.0
        for (i in 0 until itemsBox.childCount) {
            val row = itemsBox.getChildAt(i) as? LinearLayout ?: continue
            val numbers = row.getChildAt(1) as? LinearLayout ?: continue
            val q = (numbers.getChildAt(0) as EditText).text.toString().toDoubleOrNull() ?: 0.0
            val p = (numbers.getChildAt(1) as EditText).text.toString().toDoubleOrNull() ?: 0.0
            total += q * p
        }
        totalView.text = String.format(Locale.US, "TOTAL : %.2f DH", total)
    }

    private fun saveInvoice() {
        val no = invoiceNo.text.toString().trim()
        val obj = JSONObject()
        obj.put("number", no)
        obj.put("date", today())
        obj.put("customer", customer.text.toString())
        val arr = JSONArray()
        readItems().forEach {
            arr.put(JSONObject().apply {
                put("name", it.name); put("qty", it.qty); put("price", it.price)
            })
        }
        obj.put("items", arr)
        prefs.edit().putString("invoice_$no", obj.toString()).apply()
        Toast.makeText(this, "تم حفظ الفاتورة رقم $no", Toast.LENGTH_SHORT).show()
    }

    private fun createPdfAndShare() {
        val no = invoiceNo.text.toString().trim()
        val data = readItems()
        if (data.isEmpty()) {
            Toast.makeText(this, "أضف منتجًا واحدًا على الأقل", Toast.LENGTH_SHORT).show()
            return
        }

        val doc = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = doc.startPage(pageInfo)
        val c = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 16f
            typeface = Typeface.create("sans", Typeface.NORMAL)
        }
        val bold = Paint(paint).apply { typeface = Typeface.DEFAULT_BOLD }

        c.drawText("FACTURE / فاتورة", 220f, 45f, bold)
        c.drawText("N° : $no", 45f, 80f, paint)
        c.drawText("Date : ${today()}", 45f, 105f, paint)
        val cust = customer.text.toString()
        if (cust.isNotEmpty()) c.drawText("Client : $cust", 45f, 130f, paint)

        var y = 175f
        c.drawText("Produit / البيان", 45f, y, bold)
        c.drawText("Qté", 360f, y, bold)
        c.drawText("Prix", 420f, y, bold)
        c.drawText("Total", 500f, y, bold)
        y += 10
        c.drawLine(40f, y, 555f, y, paint)
        y += 28

        var grand = 0.0
        data.forEach {
            val t = it.total()
            grand += t
            c.drawText(it.name.take(34), 45f, y, paint)
            c.drawText(fmt(it.qty), 360f, y, paint)
            c.drawText(fmt(it.price), 420f, y, paint)
            c.drawText(fmt(t), 500f, y, paint)
            y += 28
        }
        y += 15
        c.drawLine(40f, y, 555f, y, paint)
        y += 35
        c.drawText("TOTAL : ${fmt(grand)} DH", 370f, y, bold)
        y += 55
        c.drawText("Merci pour votre confiance", 200f, y, paint)

        doc.finishPage(page)

        val filename = "Facture_$no.pdf"
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, filename)
            put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
        if (uri != null) {
            contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) }
            doc.close()
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "مشاركة الفاتورة"))
        } else {
            doc.close()
            Toast.makeText(this, "تعذر إنشاء ملف PDF", Toast.LENGTH_SHORT).show()
        }
    }

    private fun resetInvoice() {
        itemsBox.removeAllViews()
        customer.setText("")
        invoiceNo.setText(nextInvoiceNumber().toString())
        addItemRow()
        updateTotal()
    }

    private fun nextInvoiceNumber(): Int {
        val last = prefs.getInt("last_number", 0) + 1
        prefs.edit().putInt("last_number", last).apply()
        return last
    }

    private fun field(hint: String): EditText =
        EditText(this).apply {
            this.hint = hint
            textSize = 16f
            setPadding(14, 10, 14, 10)
            background = androidx.appcompat.content.res.AppCompatResources.getDrawable(
                this@MainActivity, android.R.drawable.edit_text
            )
        }

    private fun lp() = LinearLayout.LayoutParams(-1, -2).apply {
        bottomMargin = 6
    }

    private fun today(): String =
        SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())

    private fun fmt(v: Double): String =
        String.format(Locale.US, "%.2f", v)
}
